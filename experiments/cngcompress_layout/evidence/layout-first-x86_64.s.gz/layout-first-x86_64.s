	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
LCPI0_0:
	.byte	0                               ## 0x0
	.byte	1                               ## 0x1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI0_1:
	.byte	2                               ## 0x2
	.byte	2                               ## 0x2
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI0_2:
	.quad	1                               ## 0x1
	.quad	1                               ## 0x1
LCPI0_3:
	.long	2147483648                      ## 0x80000000
	.long	2147483648                      ## 0x80000000
	.long	2147483648                      ## 0x80000000
	.long	2147483648                      ## 0x80000000
LCPI0_4:
	.byte	4                               ## 0x4
	.byte	4                               ## 0x4
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI0_5:
	.byte	0                               ## 0x0
	.byte	1                               ## 0x1
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ## @_ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$15240, %rsp                    ## imm = 0x3B88
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	cmpq	$2097160, %rsi                  ## imm = 0x200008
	ja	LBB0_88
## %bb.1:
	movq	%rdx, %rbx
	movq	%rsi, %rdx
	leaq	512(,%rsi,2), %rax
	cmpq	%rax, %rcx
	jb	LBB0_88
## %bb.2:
	movb	$0, (%rbx)
	movb	%dl, 1(%rbx)
	movb	%dh, 2(%rbx)
	movl	%edx, %eax
	shrl	$16, %eax
	movb	%al, 3(%rbx)
	movb	$0, 4(%rbx)
	testq	%rdx, %rdx
	je	LBB0_18
## %bb.3:
	movq	%rdi, %r15
	leaq	-1456(%rbp), %rdi
	movl	$1024, %esi                     ## imm = 0x400
	movq	%rdx, %r14
	callq	___bzero
	leaq	-11180(%rbp), %rdi
	movl	$3072, %esi                     ## imm = 0xC00
	callq	___bzero
	movq	%r14, -312(%rbp)                ## 8-byte Spill
	movq	%r14, %rcx
	xorl	%eax, %eax
	andq	$4194300, %rcx                  ## imm = 0x3FFFFC
	je	LBB0_5
	.p2align	4
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r15,%rax), %edx
	incl	-1456(%rbp,%rdx,4)
	movzbl	1(%r15,%rax), %edx
	incl	-11180(%rbp,%rdx,4)
	movzbl	2(%r15,%rax), %edx
	incl	-10156(%rbp,%rdx,4)
	movzbl	3(%r15,%rax), %edx
	incl	-9132(%rbp,%rdx,4)
	addq	$4, %rax
	cmpq	%rcx, %rax
	jb	LBB0_4
LBB0_5:
	movq	%rax, %rcx
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	subq	%rdx, %rcx
	jae	LBB0_10
## %bb.6:
                                        ## kill: def $edx killed $edx killed $rdx def $rdx
	subl	%eax, %edx
	andl	$3, %edx
	je	LBB0_8
	.p2align	4
LBB0_7:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r15,%rax), %esi
	incl	-1456(%rbp,%rsi,4)
	incq	%rax
	decq	%rdx
	jne	LBB0_7
LBB0_8:
	cmpq	$-4, %rcx
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	ja	LBB0_10
	.p2align	4
LBB0_9:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r15,%rax), %ecx
	incl	-1456(%rbp,%rcx,4)
	movzbl	1(%r15,%rax), %ecx
	incl	-1456(%rbp,%rcx,4)
	movzbl	2(%r15,%rax), %ecx
	incl	-1456(%rbp,%rcx,4)
	movzbl	3(%r15,%rax), %ecx
	incl	-1456(%rbp,%rcx,4)
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	LBB0_9
LBB0_10:
	xorl	%eax, %eax
	.p2align	4
LBB0_11:                                ## =>This Inner Loop Header: Depth=1
	movdqu	-11180(%rbp,%rax,4), %xmm0
	movdqu	-11164(%rbp,%rax,4), %xmm1
	movdqu	-1456(%rbp,%rax,4), %xmm2
	paddd	%xmm0, %xmm2
	movdqu	-1440(%rbp,%rax,4), %xmm0
	paddd	%xmm1, %xmm0
	movdqu	-10156(%rbp,%rax,4), %xmm1
	movdqu	-10140(%rbp,%rax,4), %xmm3
	movdqu	-9132(%rbp,%rax,4), %xmm4
	paddd	%xmm1, %xmm4
	paddd	%xmm2, %xmm4
	movdqu	-9116(%rbp,%rax,4), %xmm1
	paddd	%xmm3, %xmm1
	paddd	%xmm0, %xmm1
	movdqu	%xmm4, -1456(%rbp,%rax,4)
	movdqu	%xmm1, -1440(%rbp,%rax,4)
	addq	$8, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	jne	LBB0_11
## %bb.12:
	movd	%edx, %xmm0
	pshufd	$0, %xmm0, %xmm1                ## xmm1 = xmm0[0,0,0,0]
	movd	LCPI0_5(%rip), %xmm6            ## xmm6 = [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
	pxor	%xmm12, %xmm12
	xorl	%eax, %eax
	movdqa	LCPI0_3(%rip), %xmm10           ## xmm10 = [2147483648,2147483648,2147483648,2147483648]
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, -352(%rbp)               ## 16-byte Spill
	pxor	%xmm7, %xmm7
	pxor	%xmm3, %xmm3
	pxor	%xmm5, %xmm5
	pxor	%xmm14, %xmm14
	pxor	%xmm11, %xmm11
	pxor	%xmm2, %xmm2
	movdqa	%xmm1, %xmm9
	.p2align	4
LBB0_13:                                ## =>This Inner Loop Header: Depth=1
	movdqa	%xmm1, -384(%rbp)               ## 16-byte Spill
	movdqa	%xmm12, -416(%rbp)              ## 16-byte Spill
	movq	-1456(%rbp,%rax,4), %xmm15      ## xmm15 = mem[0],zero
	movq	-1448(%rbp,%rax,4), %xmm1       ## xmm1 = mem[0],zero
	movdqa	%xmm1, -432(%rbp)               ## 16-byte Spill
	movdqa	%xmm15, %xmm0
	pxor	%xmm12, %xmm12
	pcmpeqd	%xmm12, %xmm0
	movdqa	%xmm0, %xmm13
	pcmpeqd	%xmm4, %xmm4
	pxor	%xmm4, %xmm13
	pshufd	$80, %xmm13, %xmm8              ## xmm8 = xmm13[0,0,1,1]
	por	%xmm8, %xmm5
	movdqa	%xmm5, -400(%rbp)               ## 16-byte Spill
	pcmpeqd	%xmm12, %xmm1
	movdqa	%xmm1, %xmm12
	pxor	%xmm4, %xmm12
	pshufd	$80, %xmm12, %xmm5              ## xmm5 = xmm12[0,0,1,1]
	por	%xmm5, %xmm14
	movdqa	%xmm14, -368(%rbp)              ## 16-byte Spill
	movdqa	%xmm7, %xmm5
	movdqa	%xmm10, %xmm14
	movdqa	%xmm3, %xmm10
	packssdw	%xmm0, %xmm0
	packsswb	%xmm0, %xmm0
	pand	%xmm0, %xmm5
	pandn	%xmm6, %xmm0
	movdqa	%xmm0, %xmm7
	por	%xmm5, %xmm7
	movdqa	%xmm6, %xmm0
	paddb	LCPI0_1(%rip), %xmm0            ## [2,2,u,u,u,u,u,u,u,u,u,u,u,u,u,u]
	packssdw	%xmm1, %xmm1
	packsswb	%xmm1, %xmm1
	pand	%xmm1, %xmm10
	pandn	%xmm0, %xmm1
	movdqa	%xmm1, %xmm3
	por	%xmm10, %xmm3
	movdqa	%xmm14, %xmm10
	movdqa	-368(%rbp), %xmm14              ## 16-byte Reload
	movdqa	%xmm15, %xmm8
	pshufd	$212, %xmm13, %xmm0             ## xmm0 = xmm13[0,1,1,3]
	movdqa	LCPI0_2(%rip), %xmm5            ## xmm5 = [1,1]
	pand	%xmm5, %xmm0
	movdqa	-352(%rbp), %xmm4               ## 16-byte Reload
	paddq	%xmm0, %xmm4
	movdqa	%xmm4, -352(%rbp)               ## 16-byte Spill
	pxor	%xmm10, %xmm8
	movdqa	%xmm11, %xmm13
	pxor	%xmm10, %xmm11
	pcmpgtd	%xmm8, %xmm11
	pand	%xmm11, %xmm13
	pandn	%xmm15, %xmm11
	movdqa	%xmm15, %xmm4
	pshufd	$212, %xmm12, %xmm0             ## xmm0 = xmm12[0,1,1,3]
	movdqa	-416(%rbp), %xmm12              ## 16-byte Reload
	pand	%xmm5, %xmm0
	paddq	%xmm0, %xmm12
	movdqa	-384(%rbp), %xmm1               ## 16-byte Reload
	movdqa	%xmm1, %xmm0
	pxor	%xmm10, %xmm0
	pcmpgtd	%xmm8, %xmm0
	movdqa	-432(%rbp), %xmm15              ## 16-byte Reload
	movdqa	%xmm15, %xmm5
	pand	%xmm0, %xmm4
	pandn	%xmm1, %xmm0
	movdqa	%xmm0, %xmm1
	por	%xmm4, %xmm1
	movdqa	%xmm9, %xmm0
	pxor	%xmm10, %xmm0
	pxor	%xmm10, %xmm5
	pcmpgtd	%xmm5, %xmm0
	movdqa	%xmm2, %xmm4
	pxor	%xmm10, %xmm4
	pcmpgtd	%xmm5, %xmm4
	movdqa	%xmm2, %xmm5
	pand	%xmm4, %xmm5
	pandn	%xmm15, %xmm4
	pand	%xmm0, %xmm15
	pandn	%xmm9, %xmm0
	movdqa	%xmm0, %xmm9
	por	%xmm15, %xmm9
	por	%xmm13, %xmm11
	movdqa	%xmm4, %xmm2
	por	%xmm5, %xmm2
	movdqa	-400(%rbp), %xmm5               ## 16-byte Reload
	addq	$4, %rax
	paddb	LCPI0_4(%rip), %xmm6            ## [4,4,u,u,u,u,u,u,u,u,u,u,u,u,u,u]
	cmpq	$256, %rax                      ## imm = 0x100
	jne	LBB0_13
## %bb.14:
	paddq	-352(%rbp), %xmm12              ## 16-byte Folded Reload
	pshufd	$238, %xmm12, %xmm0             ## xmm0 = xmm12[2,3,2,3]
	paddq	%xmm12, %xmm0
	movq	%xmm0, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB0_19
## %bb.15:
	cmpq	$1, %rax
	jne	LBB0_20
## %bb.16:
	por	%xmm5, %xmm14
	psllq	$63, %xmm14
	movmskpd	%xmm14, %eax
	testl	%eax, %eax
	je	LBB0_56
## %bb.17:
	pmaxub	%xmm3, %xmm7
	movdqa	%xmm7, %xmm0
	psrlw	$8, %xmm0
	pmaxub	%xmm7, %xmm0
	movd	%xmm0, %eax
	jmp	LBB0_57
LBB0_18:
	movl	$5, %eax
	jmp	LBB0_86
LBB0_19:
	movdqa	%xmm1, %xmm0
	pxor	%xmm10, %xmm0
	movdqa	%xmm9, %xmm3
	pxor	%xmm10, %xmm3
	pcmpgtd	%xmm0, %xmm3
	pand	%xmm3, %xmm1
	pandn	%xmm9, %xmm3
	por	%xmm1, %xmm3
	movd	%xmm3, %eax
	pshufd	$85, %xmm3, %xmm0               ## xmm0 = xmm3[1,1,1,1]
	movd	%xmm0, %ecx
	cmpl	%ecx, %eax
	cmovbl	%eax, %ecx
	movdqa	%xmm2, %xmm0
	pxor	%xmm10, %xmm0
	pxor	%xmm11, %xmm10
	pcmpgtd	%xmm0, %xmm10
	pand	%xmm10, %xmm11
	pandn	%xmm2, %xmm10
	por	%xmm11, %xmm10
	movd	%xmm10, %eax
	pshufd	$85, %xmm10, %xmm0              ## xmm0 = xmm10[1,1,1,1]
	movd	%xmm0, %edx
	cmpl	%edx, %eax
	cmoval	%eax, %edx
	addl	%ecx, %ecx
	cmpl	%ecx, %edx
	jbe	LBB0_55
LBB0_20:
	movq	%r15, -368(%rbp)                ## 8-byte Spill
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, -64(%rbp)
	movdqa	%xmm0, -80(%rbp)
	movdqa	%xmm0, -96(%rbp)
	movdqa	%xmm0, -112(%rbp)
	movdqa	%xmm0, -128(%rbp)
	movdqa	%xmm0, -144(%rbp)
	movdqa	%xmm0, -160(%rbp)
	movdqa	%xmm0, -176(%rbp)
	movdqa	%xmm0, -192(%rbp)
	movdqa	%xmm0, -208(%rbp)
	movdqa	%xmm0, -224(%rbp)
	movdqa	%xmm0, -240(%rbp)
	movdqa	%xmm0, -256(%rbp)
	movdqa	%xmm0, -272(%rbp)
	movdqa	%xmm0, -288(%rbp)
	movdqa	%xmm0, -304(%rbp)
	leaq	-4016(%rbp), %rdi
	movl	$512, %esi                      ## imm = 0x200
	callq	___bzero
	leaq	-3504(%rbp), %rdi
	movl	$2048, %esi                     ## imm = 0x800
	callq	___bzero
	movl	$28, %eax
	.p2align	4
LBB0_21:                                ## =>This Inner Loop Header: Depth=1
	movl	$0, -3532(%rbp,%rax)
	movw	$0, -3528(%rbp,%rax)
	movl	$0, -3524(%rbp,%rax)
	movw	$0, -3520(%rbp,%rax)
	movl	$0, -3516(%rbp,%rax)
	movw	$0, -3512(%rbp,%rax)
	movl	$0, -3508(%rbp,%rax)
	movw	$0, -3504(%rbp,%rax)
	addq	$32, %rax
	cmpq	$2076, %rax                     ## imm = 0x81C
	jne	LBB0_21
## %bb.22:
	leaq	-6060(%rbp), %rdi
	movl	$2044, %esi                     ## imm = 0x7FC
	callq	___bzero
	leaq	-15272(%rbp), %rdi
	movl	$4088, %esi                     ## imm = 0xFF8
	callq	___bzero
	xorl	%r15d, %r15d
	xorl	%eax, %eax
	jmp	LBB0_24
	.p2align	4
LBB0_23:                                ##   in Loop: Header=BB0_24 Depth=1
	addq	$2, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB0_28
LBB0_24:                                ## =>This Inner Loop Header: Depth=1
	movl	-1456(%rbp,%rax,4), %ecx
	testl	%ecx, %ecx
	je	LBB0_26
## %bb.25:                              ##   in Loop: Header=BB0_24 Depth=1
	movl	%ecx, -3504(%rbp,%r15,8)
	movw	%ax, -3500(%rbp,%r15,8)
	incq	%r15
LBB0_26:                                ##   in Loop: Header=BB0_24 Depth=1
	movl	-1452(%rbp,%rax,4), %ecx
	testl	%ecx, %ecx
	je	LBB0_23
## %bb.27:                              ##   in Loop: Header=BB0_24 Depth=1
	movl	%ecx, -3504(%rbp,%r15,8)
	leal	1(%rax), %ecx
	movw	%cx, -3500(%rbp,%r15,8)
	incq	%r15
	jmp	LBB0_23
LBB0_28:
	cmpq	$1, %r15
	jbe	LBB0_91
## %bb.29:
	leaq	-3504(,%r15,8), %rsi
	addq	%rbp, %rsi
	bsrq	%r15, %rdx
	xorl	$63, %edx
	addl	%edx, %edx
	xorq	$126, %rdx
	leaq	-3504(%rbp), %rdi
	movl	$1, %ecx
	callq	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	cmpq	$8, %r15
	ja	LBB0_31
## %bb.30:
	xorl	%eax, %eax
	jmp	LBB0_33
LBB0_31:
	movl	%r15d, %eax
	andl	$7, %eax
	movl	$8, %ecx
	cmovneq	%rax, %rcx
	movq	%r15, %rax
	subq	%rcx, %rax
	xorl	%ecx, %ecx
	.p2align	4
LBB0_32:                                ## =>This Inner Loop Header: Depth=1
	movups	-3504(%rbp,%rcx,8), %xmm0
	movups	-3488(%rbp,%rcx,8), %xmm1
	shufps	$136, %xmm1, %xmm0              ## xmm0 = xmm0[0,2],xmm1[0,2]
	movups	-3472(%rbp,%rcx,8), %xmm1
	movups	-3456(%rbp,%rcx,8), %xmm2
	shufps	$136, %xmm2, %xmm1              ## xmm1 = xmm1[0,2],xmm2[0,2]
	movups	%xmm0, -6060(%rbp,%rcx,4)
	movups	%xmm1, -6044(%rbp,%rcx,4)
	addq	$8, %rcx
	cmpq	%rcx, %rax
	jne	LBB0_32
	.p2align	4
LBB0_33:                                ## =>This Inner Loop Header: Depth=1
	movl	-3504(%rbp,%rax,8), %ecx
	movl	%ecx, -6060(%rbp,%rax,4)
	incq	%rax
	cmpq	%rax, %r15
	jne	LBB0_33
## %bb.34:
	movq	$0, -328(%rbp)
	movq	%r15, -320(%rbp)
	leaq	(%r15,%r15), %rax
	leaq	-1(,%r15,2), %rcx
	cmpq	%rcx, %r15
	jae	LBB0_47
## %bb.35:
	leaq	-1(%r15), %rcx
	leaq	-6060(,%r15,4), %rdx
	addq	%rbp, %rdx
	xorl	%esi, %esi
	leaq	-328(%rbp), %rdi
	leaq	-320(%rbp), %r8
	jmp	LBB0_38
	.p2align	4
LBB0_36:                                ##   in Loop: Header=BB0_38 Depth=1
	movq	%r14, %r11
	movq	%r8, %r12
LBB0_37:                                ##   in Loop: Header=BB0_38 Depth=1
	leaq	1(%r11), %r14
	movq	%r14, (%r12)
	movl	-6060(%rbp,%r11,4), %r14d
	addl	-6060(%rbp,%r10,4), %r14d
	movl	%r14d, (%rdx,%rsi,4)
	movq	%r9, -15272(%rbp,%r10,8)
	movq	%r9, -15272(%rbp,%r11,8)
	incq	%rsi
	cmpq	%rsi, %rcx
	je	LBB0_47
LBB0_38:                                ## =>This Inner Loop Header: Depth=1
	leaq	(%r15,%rsi), %r9
	movq	-328(%rbp), %r10
	movq	-320(%rbp), %r11
	cmpq	%r15, %r10
	jae	LBB0_42
## %bb.39:                              ##   in Loop: Header=BB0_38 Depth=1
	cmpq	%r11, %r9
	jne	LBB0_41
## %bb.40:                              ##   in Loop: Header=BB0_38 Depth=1
	movq	%rdi, %r14
	jmp	LBB0_43
	.p2align	4
LBB0_41:                                ##   in Loop: Header=BB0_38 Depth=1
	movl	-6060(%rbp,%r10,4), %r12d
	movq	%rdi, %r14
	cmpl	-6060(%rbp,%r11,4), %r12d
	jbe	LBB0_43
	.p2align	4
LBB0_42:                                ##   in Loop: Header=BB0_38 Depth=1
	movq	%r11, %r10
	movq	%r8, %r14
LBB0_43:                                ##   in Loop: Header=BB0_38 Depth=1
	leaq	1(%r10), %r11
	movq	%r11, (%r14)
	movq	-328(%rbp), %r11
	movq	-320(%rbp), %r14
	cmpq	%r15, %r11
	jae	LBB0_36
## %bb.44:                              ##   in Loop: Header=BB0_38 Depth=1
	cmpq	%r14, %r9
	jne	LBB0_46
## %bb.45:                              ##   in Loop: Header=BB0_38 Depth=1
	movq	%rdi, %r12
	jmp	LBB0_37
	.p2align	4
LBB0_46:                                ##   in Loop: Header=BB0_38 Depth=1
	movl	-6060(%rbp,%r11,4), %r13d
	movq	%rdi, %r12
	cmpl	-6060(%rbp,%r14,4), %r13d
	jbe	LBB0_37
	jmp	LBB0_36
LBB0_47:
	addq	$-2, %rax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	jmp	LBB0_49
	.p2align	4
LBB0_48:                                ##   in Loop: Header=BB0_49 Depth=1
	cmpl	%esi, %edx
	cmovbel	%esi, %edx
	movzwl	-3500(%rbp,%rcx,8), %edi
	movb	%sil, -304(%rbp,%rdi)
	incq	%rcx
	cmpq	%r15, %rcx
	je	LBB0_52
LBB0_49:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_51 Depth 2
	movl	$0, %esi
	cmpq	%rax, %rcx
	je	LBB0_48
## %bb.50:                              ##   in Loop: Header=BB0_49 Depth=1
	xorl	%esi, %esi
	movq	%rcx, %rdi
	.p2align	4
LBB0_51:                                ##   Parent Loop BB0_49 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	incl	%esi
	movq	-15272(%rbp,%rdi,8), %rdi
	cmpq	%rax, %rdi
	jne	LBB0_51
	jmp	LBB0_48
LBB0_52:
	cmpl	$13, %edx
	jb	LBB0_64
## %bb.53:
	leaq	-8108(%rbp), %rdi
	movl	$2048, %esi                     ## imm = 0x800
	callq	___bzero
	movl	%r15d, %eax
	andl	$3, %eax
	cmpq	$4, %r15
	jae	LBB0_58
## %bb.54:
	xorl	%ecx, %ecx
	jmp	LBB0_61
LBB0_55:
	addq	$5, %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	-312(%rbp), %rbx                ## 8-byte Reload
	movq	%rbx, %rdx
	callq	_memcpy
	addq	$5, %rbx
	jmp	LBB0_85
LBB0_56:
	xorl	%eax, %eax
LBB0_57:
	movb	$4, (%rbx)
	movb	%al, 5(%rbx)
	movl	$6, %eax
	jmp	LBB0_86
LBB0_58:
	movq	%r15, %rdx
	andq	$-4, %rdx
	xorl	%ecx, %ecx
	.p2align	4
LBB0_59:                                ## =>This Inner Loop Header: Depth=1
	movl	-3504(%rbp,%rcx,8), %esi
	movzwl	-3500(%rbp,%rcx,8), %edi
	movl	%esi, -8108(%rbp,%rcx,8)
	movw	%di, -8104(%rbp,%rcx,8)
	movl	-3496(%rbp,%rcx,8), %esi
	movzwl	-3492(%rbp,%rcx,8), %edi
	movl	%esi, -8100(%rbp,%rcx,8)
	movw	%di, -8096(%rbp,%rcx,8)
	movl	-3488(%rbp,%rcx,8), %esi
	movzwl	-3484(%rbp,%rcx,8), %edi
	movl	%esi, -8092(%rbp,%rcx,8)
	movw	%di, -8088(%rbp,%rcx,8)
	movl	-3480(%rbp,%rcx,8), %esi
	movzwl	-3476(%rbp,%rcx,8), %edi
	movl	%esi, -8084(%rbp,%rcx,8)
	movw	%di, -8080(%rbp,%rcx,8)
	addq	$4, %rcx
	cmpq	%rcx, %rdx
	jne	LBB0_59
## %bb.60:
	testq	%rax, %rax
	je	LBB0_63
LBB0_61:
	leaq	-8104(,%rcx,8), %rdx
	addq	%rbp, %rdx
	leaq	-3500(,%rcx,8), %rcx
	addq	%rbp, %rcx
	xorl	%esi, %esi
	.p2align	4
LBB0_62:                                ## =>This Inner Loop Header: Depth=1
	movl	-4(%rcx,%rsi,8), %edi
	movzwl	(%rcx,%rsi,8), %r8d
	movl	%edi, -4(%rdx,%rsi,8)
	movw	%r8w, (%rdx,%rsi,8)
	incq	%rsi
	cmpq	%rsi, %rax
	jne	LBB0_62
LBB0_63:
	leaq	-8108(%rbp), %rdi
	leaq	-304(%rbp), %rcx
	movq	%r15, %rsi
	movl	$12, %edx
	callq	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
LBB0_64:
	leaq	-304(%rbp), %rdi
	leaq	-4016(%rbp), %rsi
	callq	__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	movl	$3, %eax
	xorl	%r14d, %r14d
	.p2align	4
LBB0_65:                                ## =>This Inner Loop Header: Depth=1
	movzbl	-307(%rbp,%rax), %ecx
	imull	-1468(%rbp,%rax,4), %ecx
	addq	%rcx, %r14
	movzbl	-306(%rbp,%rax), %ecx
	imull	-1464(%rbp,%rax,4), %ecx
	movzbl	-305(%rbp,%rax), %edx
	imull	-1460(%rbp,%rax,4), %edx
	addq	%rcx, %rdx
	addq	%r14, %rdx
	movzbl	-304(%rbp,%rax), %r14d
	imull	-1456(%rbp,%rax,4), %r14d
	addq	%rdx, %r14
	addq	$4, %rax
	cmpq	$259, %rax                      ## imm = 0x103
	jne	LBB0_65
## %bb.66:
	leaq	5(%rbx), %r15
	leaq	-304(%rbp), %rdi
	movl	$128, %edx
	movq	%r15, %rsi
	callq	__ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
	xorl	%edi, %edi
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	cmpq	$1025, %rdx                     ## imm = 0x401
	setae	%dil
	leaq	(%rdi,%rdi,2), %rcx
	leaq	(%rax,%rcx,4), %rsi
	addq	$9, %rsi
	shrq	$3, %r14
	addq	%r14, %rsi
	addq	$-4, %rsi
	leaq	5(%rdx), %r8
	cmpq	%r8, %rsi
	movq	-368(%rbp), %r9                 ## 8-byte Reload
	jae	LBB0_80
## %bb.67:
	movq	%r8, -400(%rbp)                 ## 8-byte Spill
	movq	%r15, -384(%rbp)                ## 8-byte Spill
	leaq	(%rdi,%rdi,2), %r8
	incq	%r8
	leaq	(%rax,%rcx,4), %rdi
	addq	$5, %rdi
	addq	$5, %rax
	cmpq	$1025, %rdx                     ## imm = 0x401
	setae	%cl
	addb	%cl, %cl
	movq	%rdx, %rsi
	shrq	%cl, %rsi
	addq	%rbx, %rax
	movq	%rax, -416(%rbp)                ## 8-byte Spill
	xorl	%r12d, %r12d
	xorl	%r10d, %r10d
	movq	%rdi, %r11
	movq	%r8, -352(%rbp)                 ## 8-byte Spill
	jmp	LBB0_69
	.p2align	4
LBB0_68:                                ##   in Loop: Header=BB0_69 Depth=1
	subq	%rsi, %r10
	addq	%rsi, %r9
	movq	%r13, %r12
	movq	%r11, %rdi
	cmpq	%r8, %r13
	je	LBB0_81
LBB0_69:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_72 Depth 2
                                        ##     Child Loop BB0_76 Depth 2
	movq	%r12, %rcx
	imulq	%rsi, %rcx
	leaq	1(%r12), %r13
	leaq	(%rcx,%rsi), %r14
	cmpq	%r8, %r13
	cmoveq	%rdx, %r14
	cmpq	%r14, %rcx
	jae	LBB0_77
## %bb.70:                              ##   in Loop: Header=BB0_69 Depth=1
	addq	%r10, %r14
	xorl	%r8d, %r8d
	xorl	%edx, %edx
	xorl	%r15d, %r15d
	movq	%rdi, %r11
	jmp	LBB0_72
	.p2align	4
LBB0_71:                                ##   in Loop: Header=BB0_72 Depth=2
	incq	%rdx
	cmpq	%rdx, %r14
	je	LBB0_74
LBB0_72:                                ##   Parent Loop BB0_69 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r15, %rax
	movl	%r8d, %ecx
	movzbl	(%r9,%rdx), %r8d
	movzwl	-4016(%rbp,%r8,2), %r15d
	shlq	%cl, %r15
	orq	%rax, %r15
	movzbl	-304(%rbp,%r8), %r8d
	addl	%ecx, %r8d
	cmpl	$32, %r8d
	jb	LBB0_71
## %bb.73:                              ##   in Loop: Header=BB0_72 Depth=2
	movl	%r15d, (%rbx,%r11)
	addq	$4, %r11
	shrq	$32, %r15
	addl	$-32, %r8d
	jmp	LBB0_71
	.p2align	4
LBB0_74:                                ##   in Loop: Header=BB0_69 Depth=1
	testl	%r8d, %r8d
	je	LBB0_79
## %bb.75:                              ##   in Loop: Header=BB0_69 Depth=1
	addl	$8, %r8d
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	.p2align	4
LBB0_76:                                ##   Parent Loop BB0_69 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movb	%r15b, (%rbx,%r11)
	incq	%r11
	shrq	$8, %r15
	addl	$-8, %r8d
	cmpl	$8, %r8d
	ja	LBB0_76
LBB0_77:                                ##   in Loop: Header=BB0_69 Depth=1
	movq	-352(%rbp), %r8                 ## 8-byte Reload
	cmpq	%r8, %r13
	je	LBB0_68
LBB0_78:                                ##   in Loop: Header=BB0_69 Depth=1
	movl	%r11d, %eax
	subl	%edi, %eax
	movq	-416(%rbp), %rcx                ## 8-byte Reload
	movl	%eax, (%rcx,%r12,4)
	jmp	LBB0_68
LBB0_79:                                ##   in Loop: Header=BB0_69 Depth=1
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	movq	-352(%rbp), %r8                 ## 8-byte Reload
	cmpq	%r8, %r13
	jne	LBB0_78
	jmp	LBB0_68
LBB0_80:
	movq	%r15, %rdi
	movq	%r9, %rsi
	movq	%r8, %rbx
	jmp	LBB0_84
LBB0_81:
	movq	-400(%rbp), %rax                ## 8-byte Reload
	cmpq	%rax, %r11
	jae	LBB0_83
## %bb.82:
	movb	$36, (%rbx)
	movq	%r11, %rax
	jmp	LBB0_86
LBB0_83:
	movq	-384(%rbp), %rdi                ## 8-byte Reload
	movq	-368(%rbp), %rsi                ## 8-byte Reload
	movq	%rax, %rbx
LBB0_84:
	callq	_memcpy
LBB0_85:
	movq	%rbx, %rax
LBB0_86:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rcx
	movq	(%rcx), %rcx
	cmpq	-48(%rbp), %rcx
	jne	LBB0_90
## %bb.87:
	addq	$15240, %rsp                    ## imm = 0x3B88
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB0_88:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp3:                                  ## EH_LABEL
	leaq	L_.str(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ## EH_LABEL
LBB0_89:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB0_90:
	callq	___stack_chk_fail
LBB0_91:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp0:                                  ## EH_LABEL
	leaq	L_.str.15(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ## EH_LABEL
	jmp	LBB0_89
LBB0_92:
Ltmp2:                                  ## EH_LABEL
	jmp	LBB0_94
LBB0_93:
Ltmp5:                                  ## EH_LABEL
LBB0_94:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ## >> Call Site 1 <<
	.uleb128 Ltmp3-Lfunc_begin0             ##   Call between Lfunc_begin0 and Ltmp3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ## >> Call Site 2 <<
	.uleb128 Ltmp4-Ltmp3                    ##   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ##     jumps to Ltmp5
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ## >> Call Site 3 <<
	.uleb128 Ltmp0-Ltmp4                    ##   Call between Ltmp4 and Ltmp0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ## >> Call Site 4 <<
	.uleb128 Ltmp1-Ltmp0                    ##   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ##     jumps to Ltmp2
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ## >> Call Site 5 <<
	.uleb128 Lfunc_end0-Ltmp1               ##   Call between Ltmp1 and Lfunc_end0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE: ## @_ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	subq	$128, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	xorps	%xmm0, %xmm0
	movaps	%xmm0, -48(%rbp)
	movaps	%xmm0, -64(%rbp)
	movaps	%xmm0, -80(%rbp)
	movl	$0, -32(%rbp)
	xorl	%eax, %eax
	jmp	LBB1_1
	.p2align	4
LBB1_11:                                ##   in Loop: Header=BB1_1 Depth=1
	addq	$2, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB1_12
LBB1_1:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%rax), %ecx
	cmpq	$13, %rcx
	jae	LBB1_2
## %bb.6:                               ##   in Loop: Header=BB1_1 Depth=1
	testq	%rcx, %rcx
	je	LBB1_8
## %bb.7:                               ##   in Loop: Header=BB1_1 Depth=1
	incl	-80(%rbp,%rcx,4)
LBB1_8:                                 ##   in Loop: Header=BB1_1 Depth=1
	movzbl	1(%rdi,%rax), %ecx
	cmpq	$12, %rcx
	ja	LBB1_2
## %bb.9:                               ##   in Loop: Header=BB1_1 Depth=1
	testq	%rcx, %rcx
	je	LBB1_11
## %bb.10:                              ##   in Loop: Header=BB1_1 Depth=1
	incl	-80(%rbp,%rcx,4)
	jmp	LBB1_11
LBB1_12:
	movl	-76(%rbp), %ecx
	cmpl	$2, %ecx
	ja	LBB1_13
## %bb.17:
	movl	$0, -128(%rbp)
	addl	%ecx, %ecx
	movl	-72(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$4, %eax
	ja	LBB1_13
## %bb.18:
	movl	%ecx, -124(%rbp)
	addl	%eax, %eax
	movl	-68(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$8, %ecx
	ja	LBB1_13
## %bb.19:
	movl	%eax, -120(%rbp)
	addl	%ecx, %ecx
	movl	-64(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$16, %eax
	ja	LBB1_13
## %bb.20:
	movl	%ecx, -116(%rbp)
	addl	%eax, %eax
	movl	-60(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$32, %ecx
	ja	LBB1_13
## %bb.21:
	movl	%eax, -112(%rbp)
	addl	%ecx, %ecx
	movl	-56(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$64, %eax
	ja	LBB1_13
## %bb.22:
	movl	%ecx, -108(%rbp)
	addl	%eax, %eax
	movl	-52(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$128, %ecx
	ja	LBB1_13
## %bb.23:
	movl	%eax, -104(%rbp)
	addl	%ecx, %ecx
	movl	-48(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$256, %eax                      ## imm = 0x100
	ja	LBB1_13
## %bb.24:
	movl	%ecx, -100(%rbp)
	addl	%eax, %eax
	movl	-44(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$512, %ecx                      ## imm = 0x200
	ja	LBB1_13
## %bb.25:
	movl	%eax, -96(%rbp)
	addl	%ecx, %ecx
	movl	-40(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$1024, %eax                     ## imm = 0x400
	ja	LBB1_13
## %bb.26:
	movl	%ecx, -92(%rbp)
	addl	%eax, %eax
	movl	-36(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$2048, %ecx                     ## imm = 0x800
	ja	LBB1_13
## %bb.27:
	movl	%eax, -88(%rbp)
	addl	%ecx, %ecx
	movl	-32(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$4096, %eax                     ## imm = 0x1000
	ja	LBB1_13
## %bb.28:
	movl	%ecx, -84(%rbp)
	jne	LBB1_14
## %bb.29:
	xorl	%eax, %eax
	jmp	LBB1_30
	.p2align	4
LBB1_36:                                ##   in Loop: Header=BB1_30 Depth=1
	movw	%r9w, (%rsi,%rax,2)
LBB1_37:                                ##   in Loop: Header=BB1_30 Depth=1
	incq	%rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB1_38
LBB1_30:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_33 Depth 2
                                        ##     Child Loop BB1_35 Depth 2
	movzbl	(%rdi,%rax), %r8d
	testl	%r8d, %r8d
	je	LBB1_37
## %bb.31:                              ##   in Loop: Header=BB1_30 Depth=1
	movl	-132(%rbp,%r8,4), %ecx
	leal	1(%rcx), %edx
	movl	%edx, -132(%rbp,%r8,4)
	movl	%r8d, %edx
	andl	$3, %edx
	xorl	%r9d, %r9d
	cmpb	$4, %r8b
	jb	LBB1_35
## %bb.32:                              ##   in Loop: Header=BB1_30 Depth=1
	andl	$-4, %r8d
	xorl	%r9d, %r9d
	.p2align	4
LBB1_33:                                ##   Parent Loop BB1_30 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	andl	$16383, %r9d                    ## imm = 0x3FFF
	movl	%ecx, %r10d
	andl	$1, %r10d
	leal	(%r10,%r9,2), %r9d
	movl	%ecx, %r10d
	andl	$2, %r10d
	leal	(%r10,%r9,4), %r9d
	movl	%ecx, %r10d
	shrl	$2, %r10d
	andl	$1, %r10d
	orl	%r9d, %r10d
	movl	%ecx, %r9d
	shrl	$3, %r9d
	movzwl	%r10w, %r10d
	andl	$1, %r9d
	leal	(%r9,%r10,2), %r9d
	shrl	$4, %ecx
	addl	$-4, %r8d
	jne	LBB1_33
## %bb.34:                              ##   in Loop: Header=BB1_30 Depth=1
	testl	%edx, %edx
	je	LBB1_36
	.p2align	4
LBB1_35:                                ##   Parent Loop BB1_30 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	%r9w, %r8d
	movl	%ecx, %r9d
	andl	$1, %r9d
	leal	(%r9,%r8,2), %r9d
	shrl	%ecx
	decl	%edx
	jne	LBB1_35
	jmp	LBB1_36
LBB1_38:
	addq	$128, %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	retq
LBB1_2:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp6:                                  ## EH_LABEL
	leaq	L_.str.18(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ## EH_LABEL
LBB1_3:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB1_13:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp12:                                 ## EH_LABEL
	leaq	L_.str.19(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ## EH_LABEL
	jmp	LBB1_3
LBB1_14:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp9:                                  ## EH_LABEL
	leaq	L_.str.20(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ## EH_LABEL
	jmp	LBB1_3
LBB1_15:
Ltmp11:                                 ## EH_LABEL
	jmp	LBB1_5
LBB1_16:
Ltmp14:                                 ## EH_LABEL
	jmp	LBB1_5
LBB1_4:
Ltmp8:                                  ## EH_LABEL
LBB1_5:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ## >> Call Site 1 <<
	.uleb128 Ltmp6-Lfunc_begin1             ##   Call between Lfunc_begin1 and Ltmp6
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin1             ## >> Call Site 2 <<
	.uleb128 Ltmp7-Ltmp6                    ##   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin1             ##     jumps to Ltmp8
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin1             ## >> Call Site 3 <<
	.uleb128 Ltmp12-Ltmp7                   ##   Call between Ltmp7 and Ltmp12
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin1            ## >> Call Site 4 <<
	.uleb128 Ltmp13-Ltmp12                  ##   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin1            ##     jumps to Ltmp14
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin1            ## >> Call Site 5 <<
	.uleb128 Ltmp9-Ltmp13                   ##   Call between Ltmp13 and Ltmp9
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin1             ## >> Call Site 6 <<
	.uleb128 Ltmp10-Ltmp9                   ##   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin1            ##     jumps to Ltmp11
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin1            ## >> Call Site 7 <<
	.uleb128 Lfunc_end1-Ltmp10              ##   Call between Ltmp10 and Lfunc_end1
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
__ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE: ## @_ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	addq	%rdx, %rdx
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	xorl	%eax, %eax
	jmp	LBB2_1
LBB2_57:                                ##   in Loop: Header=BB2_1 Depth=1
	movb	%r10b, (%rsi,%r14)
LBB2_58:                                ##   in Loop: Header=BB2_1 Depth=1
	addq	$2, %rax
LBB2_59:                                ##   in Loop: Header=BB2_1 Depth=1
	cmpq	$256, %rcx                      ## imm = 0x100
	jae	LBB2_60
LBB2_1:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_4 Depth 2
	movq	%rcx, %r11
	movzbl	(%rdi,%rcx), %r10d
	movl	$256, %ecx                      ## imm = 0x100
	cmpq	$255, %r11
	je	LBB2_6
## %bb.2:                               ##   in Loop: Header=BB2_1 Depth=1
	leaq	1(%r11), %r9
	.p2align	4
LBB2_4:                                 ##   Parent Loop BB2_1 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	cmpb	%r10b, (%rdi,%r9)
	jne	LBB2_5
## %bb.3:                               ##   in Loop: Header=BB2_4 Depth=2
	incq	%r9
	cmpq	$256, %r9                       ## imm = 0x100
	jne	LBB2_4
LBB2_6:                                 ##   in Loop: Header=BB2_1 Depth=1
	movq	%rcx, %r9
	subq	%r11, %r9
	cmpb	%r8b, %r10b
	jne	LBB2_7
LBB2_17:                                ##   in Loop: Header=BB2_1 Depth=1
	cmpq	$19, %r9
	jb	LBB2_34
LBB2_18:                                ##   in Loop: Header=BB2_1 Depth=1
	cmpq	%rdx, %rax
	jae	LBB2_19
## %bb.21:                              ##   in Loop: Header=BB2_1 Depth=1
	movq	%rax, %r10
	shrq	%r10
	testb	$1, %al
	jne	LBB2_26
## %bb.22:                              ##   in Loop: Header=BB2_1 Depth=1
	movb	$15, (%rsi,%r10)
	leaq	1(%rax), %r11
	cmpq	%rdx, %r11
	jae	LBB2_27
## %bb.23:                              ##   in Loop: Header=BB2_1 Depth=1
	addq	$-19, %r9
	movl	%r9d, %r11d
	shlb	$4, %r11b
	orb	%r11b, (%rsi,%r10)
	leaq	2(%rax), %r10
	cmpq	%rdx, %r10
	jae	LBB2_31
## %bb.24:                              ##   in Loop: Header=BB2_1 Depth=1
	shrl	$4, %r9d
	cmpb	$16, %r9b
	jae	LBB2_31
## %bb.25:                              ##   in Loop: Header=BB2_1 Depth=1
	shrq	%r10
	movb	%r9b, (%rsi,%r10)
	addq	$3, %rax
	jmp	LBB2_59
	.p2align	4
LBB2_5:                                 ##   in Loop: Header=BB2_1 Depth=1
	movq	%r9, %rcx
	movq	%rcx, %r9
	subq	%r11, %r9
	cmpb	%r8b, %r10b
	je	LBB2_17
LBB2_7:                                 ##   in Loop: Header=BB2_1 Depth=1
	cmpq	%rdx, %rax
	jae	LBB2_9
## %bb.8:                               ##   in Loop: Header=BB2_1 Depth=1
	cmpb	$16, %r10b
	jae	LBB2_9
## %bb.13:                              ##   in Loop: Header=BB2_1 Depth=1
	testb	$1, %al
	jne	LBB2_15
## %bb.14:                              ##   in Loop: Header=BB2_1 Depth=1
	movq	%rax, %r8
	shrq	%r8
	movb	%r10b, (%rsi,%r8)
	jmp	LBB2_16
	.p2align	4
LBB2_15:                                ##   in Loop: Header=BB2_1 Depth=1
	movl	%r10d, %r8d
	shlb	$4, %r8b
	movq	%rax, %r11
	shrq	%r11
	orb	%r8b, (%rsi,%r11)
LBB2_16:                                ##   in Loop: Header=BB2_1 Depth=1
	incq	%rax
	decq	%r9
	movl	%r10d, %r8d
	cmpq	$19, %r9
	jae	LBB2_18
LBB2_34:                                ##   in Loop: Header=BB2_1 Depth=1
	cmpq	$2, %r9
	jbe	LBB2_35
## %bb.39:                              ##   in Loop: Header=BB2_1 Depth=1
	cmpq	%rdx, %rax
	jae	LBB2_40
## %bb.42:                              ##   in Loop: Header=BB2_1 Depth=1
	movq	%rax, %r10
	shrq	%r10
	testb	$1, %al
	jne	LBB2_45
## %bb.43:                              ##   in Loop: Header=BB2_1 Depth=1
	movb	$14, (%rsi,%r10)
	leaq	1(%rax), %r11
	cmpq	%rdx, %r11
	jae	LBB2_46
## %bb.44:                              ##   in Loop: Header=BB2_1 Depth=1
	shlb	$4, %r9b
	addb	$-48, %r9b
	orb	%r9b, (%rsi,%r10)
	jmp	LBB2_58
	.p2align	4
LBB2_35:                                ##   in Loop: Header=BB2_1 Depth=1
	testq	%r9, %r9
	je	LBB2_59
## %bb.36:                              ##   in Loop: Header=BB2_1 Depth=1
	cmpb	$15, %r10b
	ja	LBB2_38
## %bb.37:                              ##   in Loop: Header=BB2_1 Depth=1
	movq	%rdx, %r11
	subq	%rax, %r11
	movl	$0, %ebx
	cmovaeq	%r11, %rbx
	jbe	LBB2_38
## %bb.50:                              ##   in Loop: Header=BB2_1 Depth=1
	movl	%r10d, %r11d
	shlb	$4, %r11b
	movq	%rax, %r14
	shrq	%r14
	movl	%r10d, %r15d
	testb	$1, %al
	je	LBB2_52
## %bb.51:                              ##   in Loop: Header=BB2_1 Depth=1
	movzbl	(%rsi,%r14), %r15d
	orb	%r11b, %r15b
LBB2_52:                                ##   in Loop: Header=BB2_1 Depth=1
	movb	%r15b, (%rsi,%r14)
	leaq	1(%rax), %r14
	cmpq	$1, %r9
	jne	LBB2_54
## %bb.53:                              ##   in Loop: Header=BB2_1 Depth=1
	movq	%r14, %rax
	jmp	LBB2_59
	.p2align	4
LBB2_26:                                ##   in Loop: Header=BB2_1 Depth=1
	orb	$-16, (%rsi,%r10)
	leaq	1(%rax), %r10
	cmpq	%rdx, %r10
	jae	LBB2_27
## %bb.29:                              ##   in Loop: Header=BB2_1 Depth=1
	addq	$-19, %r9
	movl	%r9d, %r11d
	andb	$15, %r11b
	shrq	%r10
	movb	%r11b, (%rsi,%r10)
	leaq	2(%rax), %r10
	cmpq	%rdx, %r10
	jae	LBB2_31
## %bb.30:                              ##   in Loop: Header=BB2_1 Depth=1
	shrl	$4, %r9d
	cmpb	$16, %r9b
	jae	LBB2_31
## %bb.33:                              ##   in Loop: Header=BB2_1 Depth=1
	shlb	$4, %r9b
	shrq	%r10
	orb	%r9b, (%rsi,%r10)
	addq	$3, %rax
	jmp	LBB2_59
LBB2_45:                                ##   in Loop: Header=BB2_1 Depth=1
	orb	$-32, (%rsi,%r10)
	leaq	1(%rax), %r10
	cmpq	%rdx, %r10
	jae	LBB2_46
## %bb.48:                              ##   in Loop: Header=BB2_1 Depth=1
	addb	$-3, %r9b
	shrq	%r10
	movb	%r9b, (%rsi,%r10)
	jmp	LBB2_58
LBB2_54:                                ##   in Loop: Header=BB2_1 Depth=1
	cmpq	$1, %rbx
	je	LBB2_38
## %bb.55:                              ##   in Loop: Header=BB2_1 Depth=1
	shrq	%r14
	testb	$1, %al
	jne	LBB2_57
## %bb.56:                              ##   in Loop: Header=BB2_1 Depth=1
	orb	(%rsi,%r14), %r11b
	movl	%r11d, %r10d
	jmp	LBB2_57
LBB2_60:
	incq	%rax
	shrq	%rax
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB2_19:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp27:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_27:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp30:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_31:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp33:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_9:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp15:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_38:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp18:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_40:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp21:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_46:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp24:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ## EH_LABEL
LBB2_10:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB2_47:
Ltmp26:                                 ## EH_LABEL
	jmp	LBB2_12
LBB2_41:
Ltmp23:                                 ## EH_LABEL
	jmp	LBB2_12
LBB2_49:
Ltmp20:                                 ## EH_LABEL
	jmp	LBB2_12
LBB2_11:
Ltmp17:                                 ## EH_LABEL
	jmp	LBB2_12
LBB2_32:
Ltmp35:                                 ## EH_LABEL
	jmp	LBB2_12
LBB2_28:
Ltmp32:                                 ## EH_LABEL
	jmp	LBB2_12
LBB2_20:
Ltmp29:                                 ## EH_LABEL
LBB2_12:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ## >> Call Site 1 <<
	.uleb128 Ltmp27-Lfunc_begin2            ##   Call between Lfunc_begin2 and Ltmp27
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin2            ## >> Call Site 2 <<
	.uleb128 Ltmp28-Ltmp27                  ##   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin2            ##     jumps to Ltmp29
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin2            ## >> Call Site 3 <<
	.uleb128 Ltmp30-Ltmp28                  ##   Call between Ltmp28 and Ltmp30
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin2            ## >> Call Site 4 <<
	.uleb128 Ltmp31-Ltmp30                  ##   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin2            ##     jumps to Ltmp32
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin2            ## >> Call Site 5 <<
	.uleb128 Ltmp33-Ltmp31                  ##   Call between Ltmp31 and Ltmp33
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin2            ## >> Call Site 6 <<
	.uleb128 Ltmp34-Ltmp33                  ##   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin2            ##     jumps to Ltmp35
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin2            ## >> Call Site 7 <<
	.uleb128 Ltmp15-Ltmp34                  ##   Call between Ltmp34 and Ltmp15
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin2            ## >> Call Site 8 <<
	.uleb128 Ltmp16-Ltmp15                  ##   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin2            ##     jumps to Ltmp17
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin2            ## >> Call Site 9 <<
	.uleb128 Ltmp18-Ltmp16                  ##   Call between Ltmp16 and Ltmp18
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin2            ## >> Call Site 10 <<
	.uleb128 Ltmp19-Ltmp18                  ##   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin2            ##     jumps to Ltmp20
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin2            ## >> Call Site 11 <<
	.uleb128 Ltmp21-Ltmp19                  ##   Call between Ltmp19 and Ltmp21
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin2            ## >> Call Site 12 <<
	.uleb128 Ltmp22-Ltmp21                  ##   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin2            ##     jumps to Ltmp23
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin2            ## >> Call Site 13 <<
	.uleb128 Ltmp24-Ltmp22                  ##   Call between Ltmp22 and Ltmp24
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin2            ## >> Call Site 14 <<
	.uleb128 Ltmp25-Ltmp24                  ##   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin2            ##     jumps to Ltmp26
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin2            ## >> Call Site 15 <<
	.uleb128 Lfunc_end2-Ltmp25              ##   Call between Ltmp25 and Lfunc_end2
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ## @_ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception3
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$25944, %rsp                    ## imm = 0x6558
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	cmpq	$5, %rsi
	jb	LBB3_3
## %bb.1:
	cmpq	$2097160, %rcx                  ## imm = 0x200008
	ja	LBB3_3
## %bb.2:
	movq	%rdi, %r12
	movl	1(%rdi), %eax
	cmpq	%rax, %rcx
	jne	LBB3_3
## %bb.7:
	movzbl	(%r12), %eax
	cmpl	$36, %eax
	je	LBB3_22
## %bb.8:
	cmpl	$4, %eax
	je	LBB3_16
## %bb.9:
	testl	%eax, %eax
	jne	LBB3_23
## %bb.10:
	leaq	5(%rcx), %rax
	cmpq	%rax, %rsi
	jne	LBB3_11
## %bb.13:
	testq	%rcx, %rcx
	je	LBB3_155
## %bb.14:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB3_157
## %bb.15:
	addq	$5, %r12
	movq	%rdx, %rdi
	movq	%r12, %rsi
	movq	%rcx, %rdx
	addq	$25944, %rsp                    ## imm = 0x6558
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	_memcpy                         ## TAILCALL
LBB3_16:
	cmpq	$6, %rsi
	jne	LBB3_18
## %bb.17:
	testq	%rcx, %rcx
	je	LBB3_18
## %bb.20:
	movzbl	5(%r12), %esi
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB3_157
## %bb.21:
	movq	%rdx, %rdi
	movq	%rcx, %rdx
	addq	$25944, %rsp                    ## imm = 0x6558
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	_memset                         ## TAILCALL
LBB3_22:
	cmpq	$6, %rsi
	jbe	LBB3_23
## %bb.25:
	movq	%rsi, %r15
	movq	%rdx, -536(%rbp)                ## 8-byte Spill
	xorps	%xmm0, %xmm0
	movaps	%xmm0, -64(%rbp)
	movaps	%xmm0, -80(%rbp)
	movaps	%xmm0, -96(%rbp)
	movaps	%xmm0, -112(%rbp)
	movaps	%xmm0, -128(%rbp)
	movaps	%xmm0, -144(%rbp)
	movaps	%xmm0, -160(%rbp)
	movaps	%xmm0, -176(%rbp)
	movaps	%xmm0, -192(%rbp)
	movaps	%xmm0, -208(%rbp)
	movaps	%xmm0, -224(%rbp)
	movaps	%xmm0, -240(%rbp)
	movaps	%xmm0, -256(%rbp)
	movaps	%xmm0, -272(%rbp)
	movaps	%xmm0, -288(%rbp)
	movaps	%xmm0, -304(%rbp)
	leaq	-1408(%rbp), %rdi
	movl	$512, %esi                      ## imm = 0x200
	movq	%rcx, %r13
	callq	___bzero
	leaq	-5(%r15), %rsi
	leaq	5(%r12), %rdi
	leaq	-304(%rbp), %rdx
	callq	__ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
	leaq	5(%rax), %rbx
	movq	%rax, %r14
	addq	$17, %rax
	movq	%r13, -440(%rbp)                ## 8-byte Spill
	cmpq	$1025, %r13                     ## imm = 0x401
	cmovbq	%rbx, %rax
	cmpq	%rax, %r15
	jb	LBB3_26
## %bb.28:
	movq	%r15, %r13
	leaq	-304(%rbp), %rdi
	leaq	-1408(%rbp), %rsi
	callq	__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	leaq	-25984(%rbp), %rdi
	movl	$8192, %esi                     ## imm = 0x2000
	callq	___bzero
	xorl	%eax, %eax
	movq	-440(%rbp), %r9                 ## 8-byte Reload
	movq	%r14, %r15
	jmp	LBB3_29
	.p2align	4
LBB3_33:                                ##   in Loop: Header=BB3_29 Depth=1
	incq	%rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB3_34
LBB3_29:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB3_32 Depth 2
	movzbl	-304(%rbp,%rax), %ecx
	testq	%rcx, %rcx
	je	LBB3_33
## %bb.30:                              ##   in Loop: Header=BB3_29 Depth=1
	movzwl	-1408(%rbp,%rax,2), %edx
	cmpq	$4095, %rdx                     ## imm = 0xFFF
	ja	LBB3_33
## %bb.31:                              ##   in Loop: Header=BB3_29 Depth=1
	movl	%ecx, %esi
	shll	$8, %esi
	orl	%eax, %esi
	movl	$1, %edi
                                        ## kill: def $cl killed $cl killed $rcx
	shlq	%cl, %rdi
	.p2align	4
LBB3_32:                                ##   Parent Loop BB3_29 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movw	%si, -25984(%rbp,%rdx,2)
	addq	%rdi, %rdx
	cmpq	$4096, %rdx                     ## imm = 0x1000
	jb	LBB3_32
	jmp	LBB3_33
LBB3_34:
	cmpq	$1025, %r9                      ## imm = 0x401
	jae	LBB3_52
## %bb.35:
	movq	%r13, %rsi
	subq	%rbx, %rsi
	addq	%r12, %rbx
	movq	%rbx, -17792(%rbp)
	movq	%rsi, -17784(%rbp)
	testq	%r9, %r9
	movq	-536(%rbp), %rdi                ## 8-byte Reload
	je	LBB3_36
## %bb.38:
	movq	%r13, %rax
	addq	$-6, %rax
	movq	%rax, -496(%rbp)                ## 8-byte Spill
	leaq	(%r15,%r12), %rax
	addq	$8, %rax
	movq	%rax, -360(%rbp)                ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%r11d, %r11d
	xorl	%r8d, %r8d
	xorl	%eax, %eax
	xorl	%r10d, %r10d
	jmp	LBB3_39
	.p2align	4
LBB3_41:                                ##   in Loop: Header=BB3_39 Depth=1
	movl	(%rbx,%r14), %r13d
LBB3_50:                                ##   in Loop: Header=BB3_39 Depth=1
	movl	%r13d, %edx
	movl	%eax, %ecx
	shlq	%cl, %rdx
	orq	%rdx, %r8
	orl	$32, %eax
	movq	%r10, %r14
LBB3_51:                                ##   in Loop: Header=BB3_39 Depth=1
	movl	%r8d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movzwl	-25984(%rbp,%rcx,2), %ecx
	movb	%cl, (%rdi,%r11)
	shrl	$8, %ecx
	shrq	%cl, %r8
	subl	%ecx, %eax
	incq	%r11
	cmpq	%r9, %r11
	je	LBB3_37
LBB3_39:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB3_46 Depth 2
                                        ##     Child Loop BB3_49 Depth 2
	cmpl	$11, %eax
	ja	LBB3_51
## %bb.40:                              ##   in Loop: Header=BB3_39 Depth=1
	leaq	4(%r14), %r10
	cmpq	%rsi, %r10
	jbe	LBB3_41
## %bb.42:                              ##   in Loop: Header=BB3_39 Depth=1
	xorl	%r13d, %r13d
	movq	%rsi, %rcx
	subq	%r14, %rcx
	movq	%rcx, -408(%rbp)                ## 8-byte Spill
	jbe	LBB3_50
## %bb.43:                              ##   in Loop: Header=BB3_39 Depth=1
	movq	-496(%rbp), %rdx                ## 8-byte Reload
	subq	%r15, %rdx
	subq	%r14, %rdx
	movq	-408(%rbp), %rcx                ## 8-byte Reload
                                        ## kill: def $ecx killed $ecx killed $rcx def $rcx
	andl	$3, %ecx
	movq	%rcx, -376(%rbp)                ## 8-byte Spill
	cmpq	$3, %rdx
	jae	LBB3_45
## %bb.44:                              ##   in Loop: Header=BB3_39 Depth=1
	xorl	%r12d, %r12d
	xorl	%r13d, %r13d
	jmp	LBB3_48
LBB3_45:                                ##   in Loop: Header=BB3_39 Depth=1
	andq	$-4, -408(%rbp)                 ## 8-byte Folded Spill
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	addq	%r14, %rcx
	movq	%rcx, -336(%rbp)                ## 8-byte Spill
	xorl	%r12d, %r12d
	movl	$24, %edx
	xorl	%r13d, %r13d
LBB3_46:                                ##   Parent Loop BB3_39 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movzbl	-2(%rcx,%r12), %r9d
	leal	-16(%rdx), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, %r9d
	movl	%r9d, -312(%rbp)                ## 4-byte Spill
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movzbl	-3(%rcx,%r12), %r9d
	movl	%r9d, -352(%rbp)                ## 4-byte Spill
	movzbl	-1(%rcx,%r12), %r9d
	movl	%r9d, -368(%rbp)                ## 4-byte Spill
	leal	-8(%rdx), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -368(%rbp)                 ## 4-byte Folded Spill
	orl	-352(%rbp), %r13d               ## 4-byte Folded Reload
	movl	-312(%rbp), %r9d                ## 4-byte Reload
	orl	%r13d, %r9d
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movzbl	(%rcx,%r12), %r13d
	movl	%edx, %ecx
	shll	%cl, %r13d
	orl	-368(%rbp), %r13d               ## 4-byte Folded Reload
	orl	%r9d, %r13d
	addq	$4, %r12
	addl	$32, %edx
	cmpq	%r12, -408(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_46
## %bb.47:                              ##   in Loop: Header=BB3_39 Depth=1
	cmpq	$0, -376(%rbp)                  ## 8-byte Folded Reload
	movq	-440(%rbp), %r9                 ## 8-byte Reload
	je	LBB3_50
LBB3_48:                                ##   in Loop: Header=BB3_39 Depth=1
	leal	(,%r12,8), %ecx
	addq	%r12, %r14
	addq	%rbx, %r14
	xorl	%edx, %edx
LBB3_49:                                ##   Parent Loop BB3_39 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r14,%rdx), %r9d
	shll	%cl, %r9d
	orl	%r9d, %r13d
	movq	-440(%rbp), %r9                 ## 8-byte Reload
	incq	%rdx
	addl	$8, %ecx
	cmpq	%rdx, -376(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_49
	jmp	LBB3_50
LBB3_52:
	leaq	-17792(%rbp), %rdi
	movl	$16384, %esi                    ## imm = 0x4000
	callq	___bzero
	xorl	%eax, %eax
	movq	-536(%rbp), %r14                ## 8-byte Reload
	movq	%r13, %r8
	jmp	LBB3_53
	.p2align	4
LBB3_55:                                ##   in Loop: Header=BB3_53 Depth=1
	shll	$16, %ecx
	movl	$16777216, %edi                 ## imm = 0x1000000
	movl	%ecx, %esi
LBB3_56:                                ##   in Loop: Header=BB3_53 Depth=1
	movzbl	%dl, %ecx
	orl	%esi, %ecx
	orl	%edi, %ecx
	movl	%ecx, -17792(%rbp,%rax,4)
	incq	%rax
	cmpq	$4096, %rax                     ## imm = 0x1000
	je	LBB3_57
LBB3_53:                                ## =>This Inner Loop Header: Depth=1
	movzwl	-25984(%rbp,%rax,2), %edx
	movl	%edx, %ecx
	shrl	$8, %ecx
	movq	%rax, %rsi
	shrq	%cl, %rsi
	movzwl	-25984(%rbp,%rsi,2), %edi
	movl	%edi, %esi
	shrl	$8, %esi
	addl	%ecx, %esi
	cmpl	$12, %esi
	ja	LBB3_55
## %bb.54:                              ##   in Loop: Header=BB3_53 Depth=1
	shll	$8, %edi
	movzwl	%di, %ecx
	shll	$16, %esi
	orl	%ecx, %esi
	movl	$33554432, %edi                 ## imm = 0x2000000
	jmp	LBB3_56
LBB3_57:
	xorps	%xmm0, %xmm0
	movaps	%xmm0, -576(%rbp)
	movaps	%xmm0, -592(%rbp)
	movaps	%xmm0, -608(%rbp)
	movaps	%xmm0, -624(%rbp)
	movaps	%xmm0, -640(%rbp)
	movaps	%xmm0, -656(%rbp)
	movaps	%xmm0, -672(%rbp)
	movaps	%xmm0, -688(%rbp)
	movaps	%xmm0, -704(%rbp)
	movaps	%xmm0, -720(%rbp)
	movaps	%xmm0, -736(%rbp)
	movaps	%xmm0, -752(%rbp)
	movl	5(%r12,%r15), %esi
	movq	%r8, %rax
	leaq	17(%r15), %rdx
	subq	%rdx, %rax
	movq	%rsi, -432(%rbp)                ## 8-byte Spill
	cmpq	%rsi, %rax
	movq	-440(%rbp), %rcx                ## 8-byte Reload
	jb	LBB3_58
## %bb.60:
	movq	%rcx, %r10
	shrq	$2, %r10
	leaq	(%r12,%rdx), %rax
	movq	%rax, -520(%rbp)                ## 8-byte Spill
	movq	%rax, -720(%rbp)
	movq	-432(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -712(%rbp)
	addq	%rax, %rdx
	movq	%r14, -896(%rbp)
	movq	%r10, -888(%rbp)
	movl	4(%r12,%rbx), %esi
	movq	%r8, %rax
	subq	%rdx, %rax
	cmpq	%rsi, %rax
	jb	LBB3_58
## %bb.61:
	leaq	(%r12,%rdx), %rax
	movq	%rax, -512(%rbp)                ## 8-byte Spill
	movq	%rax, -680(%rbp)
	movq	%rsi, -672(%rbp)
	addq	%rsi, %rdx
	leaq	(%r14,%r10), %rax
	movq	%rax, -824(%rbp)                ## 8-byte Spill
	movq	%rax, -880(%rbp)
	movq	%r10, -872(%rbp)
	movl	8(%r12,%rbx), %edi
	movq	%r8, %rax
	subq	%rdx, %rax
	cmpq	%rdi, %rax
	movq	%r10, -832(%rbp)                ## 8-byte Spill
	jb	LBB3_58
## %bb.62:
	leaq	(%r10,%r10,2), %r9
	subq	%r9, %rcx
	leaq	(%r12,%rdx), %rax
	movq	%rax, -504(%rbp)                ## 8-byte Spill
	movq	%rax, -640(%rbp)
	movq	%rdi, -632(%rbp)
	addq	%rdi, %rdx
	leaq	(%r14,%r10,2), %rax
	movq	%rax, -808(%rbp)                ## 8-byte Spill
	movq	%rax, -864(%rbp)
	movq	%r10, -856(%rbp)
	movq	%r8, %rax
	subq	%rdx, %rax
	addq	%r12, %rdx
	movq	%rdx, -552(%rbp)                ## 8-byte Spill
	movq	%rdx, -600(%rbp)
	movq	%rax, -528(%rbp)                ## 8-byte Spill
	movq	%rax, -592(%rbp)
	cmpq	$-1, %rcx
	cmoveq	%rcx, %rcx
	addq	%r14, %r9
	movq	%r9, -816(%rbp)                 ## 8-byte Spill
	movq	%r9, -848(%rbp)
	movq	%rcx, -440(%rbp)                ## 8-byte Spill
	movq	%rcx, -840(%rbp)
	addq	$-18, %r8
	movq	%r8, -496(%rbp)                 ## 8-byte Spill
	movq	-432(%rbp), %rax                ## 8-byte Reload
	addq	%r15, %rax
	leaq	(%rax,%rsi), %rcx
	leaq	20(%r15,%r12), %rdx
	movq	%rdx, -784(%rbp)                ## 8-byte Spill
	leaq	20(%r12,%rax), %rdx
	movq	%rdx, -776(%rbp)                ## 8-byte Spill
	leaq	(%r12,%rcx), %rdx
	addq	$20, %rdx
	movq	%rdx, -768(%rbp)                ## 8-byte Spill
	addq	%rdi, %rcx
	movq	%rcx, -800(%rbp)                ## 8-byte Spill
	movq	%rsi, -488(%rbp)                ## 8-byte Spill
	movq	%rdi, -480(%rbp)                ## 8-byte Spill
	leaq	(%rdi,%rsi), %rcx
	addq	%rax, %rcx
	leaq	(%r12,%rcx), %rax
	addq	$20, %rax
	movq	%rax, -760(%rbp)                ## 8-byte Spill
	leaq	(%r12,%rcx), %rax
	addq	$17, %rax
	movq	%rax, -792(%rbp)                ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%eax, %eax
	xorl	%edx, %edx
	movl	$0, -312(%rbp)                  ## 4-byte Folded Spill
	movq	$0, -376(%rbp)                  ## 8-byte Folded Spill
	movq	$0, -400(%rbp)                  ## 8-byte Folded Spill
	movq	$0, -336(%rbp)                  ## 8-byte Folded Spill
	xorl	%esi, %esi
	xorl	%r12d, %r12d
	xorl	%edi, %edi
	movq	$0, -408(%rbp)                  ## 8-byte Folded Spill
	movq	$0, -320(%rbp)                  ## 8-byte Folded Spill
	movq	$0, -360(%rbp)                  ## 8-byte Folded Spill
	xorl	%r11d, %r11d
	xorl	%r9d, %r9d
	movq	$0, -368(%rbp)                  ## 8-byte Folded Spill
	jmp	LBB3_63
	.p2align	4
LBB3_109:                               ##   in Loop: Header=BB3_63 Depth=1
	movq	-400(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -328(%rbp)                ## 8-byte Spill
	movl	%r14d, %esi
	movq	-352(%rbp), %r14                ## 8-byte Reload
LBB3_121:                               ##   in Loop: Header=BB3_63 Depth=1
	movzbl	%r8b, %ecx
	subl	%ecx, %r12d
	movl	%r12d, -312(%rbp)               ## 4-byte Spill
	movzbl	%r9b, %ecx
	subl	%ecx, %edi
	addq	%rdx, %r15
	movzbl	%r10b, %r8d
	movl	%eax, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17792(%rbp,%rcx,4), %r9d
	movl	%r9d, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	shrq	%cl, %rax
	movq	%rax, -336(%rbp)                ## 8-byte Spill
	subl	%r8d, %r11d
	addq	%r13, %rbx
	movq	%r15, %rdx
	movq	%rbx, %rax
	subl	%ecx, %esi
	movq	-816(%rbp), %rcx                ## 8-byte Reload
	movw	%r9w, (%rcx,%r14)
	shrl	$24, %r9d
	addq	%r9, %r14
	movq	-832(%rbp), %r10                ## 8-byte Reload
	movq	%r10, %rcx
	subq	-368(%rbp), %rcx                ## 8-byte Folded Reload
	movq	-472(%rbp), %r8                 ## 8-byte Reload
	movq	%r8, %r12
	movq	-416(%rbp), %rbx                ## 8-byte Reload
	movq	%rbx, -320(%rbp)                ## 8-byte Spill
	movq	-448(%rbp), %r13                ## 8-byte Reload
	movq	%r13, %r9
	cmpq	$1, %rcx
	jbe	LBB3_122
LBB3_63:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB3_77 Depth 2
                                        ##     Child Loop BB3_80 Depth 2
                                        ##     Child Loop BB3_90 Depth 2
                                        ##     Child Loop BB3_93 Depth 2
                                        ##     Child Loop BB3_103 Depth 2
                                        ##     Child Loop BB3_106 Depth 2
                                        ##     Child Loop BB3_116 Depth 2
                                        ##     Child Loop BB3_119 Depth 2
	movq	%r14, -352(%rbp)                ## 8-byte Spill
	movq	%r10, %rcx
	movq	%rdx, %r15
	subq	%rdx, %rcx
	cmpq	$2, %rcx
	jb	LBB3_64
## %bb.66:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	%r10, %rcx
	subq	%rax, %rcx
	cmpq	$2, %rcx
	movq	%r12, %r14
	jb	LBB3_67
## %bb.68:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-440(%rbp), %rcx                ## 8-byte Reload
	subq	-352(%rbp), %rcx                ## 8-byte Folded Reload
	cmpq	$2, %rcx
	jb	LBB3_67
## %bb.69:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	%rax, %rbx
	movl	-312(%rbp), %r12d               ## 4-byte Reload
	cmpl	$11, %r12d
	ja	LBB3_70
## %bb.71:                              ##   in Loop: Header=BB3_63 Depth=1
	leaq	4(%r14), %rcx
	cmpq	-432(%rbp), %rcx                ## 8-byte Folded Reload
	movl	%esi, %edx
	movq	%rcx, -472(%rbp)                ## 8-byte Spill
	ja	LBB3_73
## %bb.72:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-520(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%r14), %r13d
	movq	-336(%rbp), %rax                ## 8-byte Reload
LBB3_81:                                ##   in Loop: Header=BB3_63 Depth=1
	movl	%edx, %esi
	movl	%r13d, %r8d
	movl	%r12d, %ecx
	shlq	%cl, %r8
	movq	-376(%rbp), %r10                ## 8-byte Reload
	orq	%r8, %r10
	orl	$32, %r12d
	jmp	LBB3_82
	.p2align	4
LBB3_70:                                ##   in Loop: Header=BB3_63 Depth=1
	movq	%r14, -472(%rbp)                ## 8-byte Spill
	movq	-376(%rbp), %r10                ## 8-byte Reload
	movq	-336(%rbp), %rax                ## 8-byte Reload
LBB3_82:                                ##   in Loop: Header=BB3_63 Depth=1
	movl	%r10d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17792(%rbp,%rcx,4), %r13d
	movl	%r13d, %r8d
	shrl	$16, %r8d
	movl	%r8d, %ecx
	shrq	%cl, %r10
	movq	-536(%rbp), %rcx                ## 8-byte Reload
	movq	-368(%rbp), %r14                ## 8-byte Reload
	movw	%r13w, (%rcx,%r14)
	cmpl	$11, %edi
	movq	%r10, -376(%rbp)                ## 8-byte Spill
	ja	LBB3_83
## %bb.84:                              ##   in Loop: Header=BB3_63 Depth=1
	leaq	4(%r9), %rcx
	movq	%rcx, -448(%rbp)                ## 8-byte Spill
	cmpq	-488(%rbp), %rcx                ## 8-byte Folded Reload
	ja	LBB3_86
## %bb.85:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-512(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%r9), %r14d
LBB3_94:                                ##   in Loop: Header=BB3_63 Depth=1
	movl	%r14d, %r9d
	movl	%edi, %ecx
	shlq	%cl, %r9
	movq	-408(%rbp), %r10                ## 8-byte Reload
	orq	%r9, %r10
	orl	$32, %edi
	jmp	LBB3_95
	.p2align	4
LBB3_83:                                ##   in Loop: Header=BB3_63 Depth=1
	movq	%r9, -448(%rbp)                 ## 8-byte Spill
	movq	-408(%rbp), %r10                ## 8-byte Reload
LBB3_95:                                ##   in Loop: Header=BB3_63 Depth=1
	movl	%r10d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17792(%rbp,%rcx,4), %edx
	movl	%edx, %r9d
	shrl	$16, %r9d
	movl	%r9d, %ecx
	shrq	%cl, %r10
	movq	-824(%rbp), %rcx                ## 8-byte Reload
	movw	%dx, (%rcx,%r15)
	cmpl	$11, %r11d
	movl	%esi, %r14d
	movq	%r10, -408(%rbp)                ## 8-byte Spill
	ja	LBB3_96
## %bb.97:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-320(%rbp), %r10                ## 8-byte Reload
	leaq	4(%r10), %rcx
	movq	%rcx, -416(%rbp)                ## 8-byte Spill
	cmpq	-480(%rbp), %rcx                ## 8-byte Folded Reload
	ja	LBB3_99
## %bb.98:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-504(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%r10), %r10d
LBB3_107:                               ##   in Loop: Header=BB3_63 Depth=1
	movl	%r10d, %r10d
	movl	%r11d, %ecx
	shlq	%cl, %r10
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	orq	%r10, %rcx
	orl	$32, %r11d
	jmp	LBB3_108
	.p2align	4
LBB3_96:                                ##   in Loop: Header=BB3_63 Depth=1
	movq	-320(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -416(%rbp)                ## 8-byte Spill
	movq	-360(%rbp), %rcx                ## 8-byte Reload
LBB3_108:                               ##   in Loop: Header=BB3_63 Depth=1
	movq	%rcx, -360(%rbp)                ## 8-byte Spill
	shrl	$24, %r13d
	addq	%r13, -368(%rbp)                ## 8-byte Folded Spill
	movq	-360(%rbp), %rcx                ## 8-byte Reload
                                        ## kill: def $ecx killed $ecx killed $rcx def $rcx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17792(%rbp,%rcx,4), %r13d
	movl	%r13d, %r10d
	shrl	$16, %r10d
	movl	%r10d, %ecx
	shrq	%cl, -360(%rbp)                 ## 8-byte Folded Spill
	shrl	$24, %edx
	movq	-808(%rbp), %rcx                ## 8-byte Reload
	movw	%r13w, (%rcx,%rbx)
	shrl	$24, %r13d
	cmpl	$11, %r14d
	ja	LBB3_109
## %bb.110:                             ##   in Loop: Header=BB3_63 Depth=1
	movl	%r12d, -312(%rbp)               ## 4-byte Spill
	movq	-400(%rbp), %r12                ## 8-byte Reload
	leaq	4(%r12), %rsi
	cmpq	-528(%rbp), %rsi                ## 8-byte Folded Reload
	movq	%rax, -336(%rbp)                ## 8-byte Spill
	ja	LBB3_112
## %bb.111:                             ##   in Loop: Header=BB3_63 Depth=1
	movq	-552(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%r12), %eax
LBB3_120:                               ##   in Loop: Header=BB3_63 Depth=1
	movl	%eax, %r12d
	movl	%r14d, %ecx
	shlq	%cl, %r12
	movq	-336(%rbp), %rax                ## 8-byte Reload
	orq	%r12, %rax
	orl	$32, %r14d
	movq	%rsi, -328(%rbp)                ## 8-byte Spill
	movq	%rsi, -400(%rbp)                ## 8-byte Spill
	movl	%r14d, %esi
	movq	-352(%rbp), %r14                ## 8-byte Reload
	movl	-312(%rbp), %r12d               ## 4-byte Reload
	jmp	LBB3_121
LBB3_73:                                ##   in Loop: Header=BB3_63 Depth=1
	xorl	%r13d, %r13d
	movq	%r14, %rcx
	subq	-432(%rbp), %rcx                ## 8-byte Folded Reload
	movq	-336(%rbp), %rax                ## 8-byte Reload
	jae	LBB3_81
## %bb.74:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-432(%rbp), %rsi                ## 8-byte Reload
	subq	%r14, %rsi
	movq	%rsi, -344(%rbp)                ## 8-byte Spill
                                        ## kill: def $esi killed $esi killed $rsi def $rsi
	andl	$3, %esi
	cmpq	$-4, %rcx
	jbe	LBB3_76
## %bb.75:                              ##   in Loop: Header=BB3_63 Depth=1
	xorl	%r10d, %r10d
	xorl	%r13d, %r13d
	jmp	LBB3_79
LBB3_86:                                ##   in Loop: Header=BB3_63 Depth=1
	xorl	%r14d, %r14d
	movq	%r9, %rcx
	subq	-488(%rbp), %rcx                ## 8-byte Folded Reload
	jae	LBB3_94
## %bb.87:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-488(%rbp), %rdx                ## 8-byte Reload
	subq	%r9, %rdx
	movq	%rdx, -384(%rbp)                ## 8-byte Spill
                                        ## kill: def $edx killed $edx killed $rdx def $rdx
	andl	$3, %edx
	cmpq	$-4, %rcx
	movq	%rdx, -392(%rbp)                ## 8-byte Spill
	jbe	LBB3_89
## %bb.88:                              ##   in Loop: Header=BB3_63 Depth=1
	xorl	%r10d, %r10d
	xorl	%r14d, %r14d
	jmp	LBB3_92
LBB3_99:                                ##   in Loop: Header=BB3_63 Depth=1
	movq	%r10, %rsi
	xorl	%r10d, %r10d
	movq	%rsi, %rcx
	subq	-480(%rbp), %rcx                ## 8-byte Folded Reload
	jae	LBB3_107
## %bb.100:                             ##   in Loop: Header=BB3_63 Depth=1
	movq	%rsi, %r10
	movq	%rsi, -320(%rbp)                ## 8-byte Spill
	movq	-480(%rbp), %rsi                ## 8-byte Reload
	subq	%r10, %rsi
	movq	%rsi, -424(%rbp)                ## 8-byte Spill
                                        ## kill: def $esi killed $esi killed $rsi def $rsi
	andl	$3, %esi
	cmpq	$-4, %rcx
	movq	-320(%rbp), %r10                ## 8-byte Reload
	movq	%rsi, -456(%rbp)                ## 8-byte Spill
	jbe	LBB3_102
## %bb.101:                             ##   in Loop: Header=BB3_63 Depth=1
	xorl	%ecx, %ecx
	xorl	%r10d, %r10d
	jmp	LBB3_105
LBB3_112:                               ##   in Loop: Header=BB3_63 Depth=1
	xorl	%eax, %eax
	movq	-528(%rbp), %rcx                ## 8-byte Reload
	subq	%r12, %rcx
	movq	%rcx, -424(%rbp)                ## 8-byte Spill
	jbe	LBB3_120
## %bb.113:                             ##   in Loop: Header=BB3_63 Depth=1
	movq	-800(%rbp), %rcx                ## 8-byte Reload
	leaq	(%rcx,%r12), %rax
	movq	-496(%rbp), %rcx                ## 8-byte Reload
	subq	%rax, %rcx
	movq	-424(%rbp), %rax                ## 8-byte Reload
                                        ## kill: def $eax killed $eax killed $rax def $rax
	andl	$3, %eax
	movq	%rax, -456(%rbp)                ## 8-byte Spill
	cmpq	$3, %rcx
	movq	%r12, -400(%rbp)                ## 8-byte Spill
	jae	LBB3_115
## %bb.114:                             ##   in Loop: Header=BB3_63 Depth=1
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	jmp	LBB3_118
LBB3_76:                                ##   in Loop: Header=BB3_63 Depth=1
	movq	%rsi, -384(%rbp)                ## 8-byte Spill
	movq	-344(%rbp), %rcx                ## 8-byte Reload
	andl	$-4, %ecx
	movq	%rcx, -344(%rbp)                ## 8-byte Spill
	movq	-784(%rbp), %rcx                ## 8-byte Reload
	addq	%r14, %rcx
	movq	%rcx, -392(%rbp)                ## 8-byte Spill
	xorl	%r10d, %r10d
	movl	$24, %r8d
	xorl	%r13d, %r13d
LBB3_77:                                ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-392(%rbp), %rsi                ## 8-byte Reload
	movzbl	-2(%rsi,%r10), %ecx
	movl	%ecx, -448(%rbp)                ## 4-byte Spill
	leal	-16(%r8), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -448(%rbp)                 ## 4-byte Folded Spill
	movzbl	-3(%rsi,%r10), %ecx
	movl	%ecx, -328(%rbp)                ## 4-byte Spill
	movzbl	-1(%rsi,%r10), %ecx
	movl	%ecx, -416(%rbp)                ## 4-byte Spill
	leal	-8(%r8), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -416(%rbp)                 ## 4-byte Folded Spill
	orl	-328(%rbp), %r13d               ## 4-byte Folded Reload
	orl	%r13d, -448(%rbp)               ## 4-byte Folded Spill
	movzbl	(%rsi,%r10), %r13d
	movl	%r8d, %ecx
	shll	%cl, %r13d
	orl	-416(%rbp), %r13d               ## 4-byte Folded Reload
	orl	-448(%rbp), %r13d               ## 4-byte Folded Reload
	addq	$4, %r10
	addl	$32, %r8d
	cmpq	%r10, -344(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_77
## %bb.78:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-384(%rbp), %rsi                ## 8-byte Reload
	testq	%rsi, %rsi
	je	LBB3_81
LBB3_79:                                ##   in Loop: Header=BB3_63 Depth=1
	leal	(,%r10,8), %ecx
	addq	%r10, %r14
	addq	-520(%rbp), %r14                ## 8-byte Folded Reload
	xorl	%r8d, %r8d
LBB3_80:                                ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r14,%r8), %r10d
	shll	%cl, %r10d
	orl	%r10d, %r13d
	incq	%r8
	addl	$8, %ecx
	cmpq	%r8, %rsi
	jne	LBB3_80
	jmp	LBB3_81
LBB3_89:                                ##   in Loop: Header=BB3_63 Depth=1
	movq	-384(%rbp), %rcx                ## 8-byte Reload
	andl	$-4, %ecx
	movq	%rcx, -384(%rbp)                ## 8-byte Spill
	movq	-776(%rbp), %rcx                ## 8-byte Reload
	addq	%r9, %rcx
	movq	%rcx, -464(%rbp)                ## 8-byte Spill
	xorl	%r10d, %r10d
	movl	$24, %ecx
	xorl	%r14d, %r14d
LBB3_90:                                ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rcx, -312(%rbp)                ## 8-byte Spill
	movq	-464(%rbp), %rdx                ## 8-byte Reload
	movzbl	-2(%rdx,%r10), %ecx
	movl	%ecx, -416(%rbp)                ## 4-byte Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	addl	$-16, %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -416(%rbp)                 ## 4-byte Folded Spill
	movzbl	-3(%rdx,%r10), %ecx
	movl	%ecx, -344(%rbp)                ## 4-byte Spill
	movzbl	-1(%rdx,%r10), %ecx
	movl	%ecx, -328(%rbp)                ## 4-byte Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	addl	$-8, %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -328(%rbp)                 ## 4-byte Folded Spill
	orl	-344(%rbp), %r14d               ## 4-byte Folded Reload
	orl	%r14d, -416(%rbp)               ## 4-byte Folded Spill
	movzbl	(%rdx,%r10), %r14d
	movq	-312(%rbp), %rcx                ## 8-byte Reload
                                        ## kill: def $cl killed $cl killed $rcx
	shll	%cl, %r14d
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	orl	-328(%rbp), %r14d               ## 4-byte Folded Reload
	orl	-416(%rbp), %r14d               ## 4-byte Folded Reload
	addq	$4, %r10
	addl	$32, %ecx
	cmpq	%r10, -384(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_90
## %bb.91:                              ##   in Loop: Header=BB3_63 Depth=1
	movq	-392(%rbp), %rdx                ## 8-byte Reload
	testq	%rdx, %rdx
	je	LBB3_94
LBB3_92:                                ##   in Loop: Header=BB3_63 Depth=1
	leal	(,%r10,8), %ecx
	addq	%r10, %r9
	addq	-512(%rbp), %r9                 ## 8-byte Folded Reload
	xorl	%r10d, %r10d
LBB3_93:                                ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r9,%r10), %edx
	shll	%cl, %edx
	orl	%edx, %r14d
	movq	-392(%rbp), %rdx                ## 8-byte Reload
	incq	%r10
	addl	$8, %ecx
	cmpq	%r10, %rdx
	jne	LBB3_93
	jmp	LBB3_94
LBB3_102:                               ##   in Loop: Header=BB3_63 Depth=1
	movq	-424(%rbp), %rcx                ## 8-byte Reload
	andl	$-4, %ecx
	movq	%rcx, -424(%rbp)                ## 8-byte Spill
	movq	-768(%rbp), %rcx                ## 8-byte Reload
	addq	%r10, %rcx
	movq	%rcx, -384(%rbp)                ## 8-byte Spill
	xorl	%ecx, %ecx
	movl	$24, %esi
	movq	%rsi, -344(%rbp)                ## 8-byte Spill
	xorl	%r10d, %r10d
LBB3_103:                               ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rcx, -312(%rbp)                ## 8-byte Spill
	movq	-384(%rbp), %rsi                ## 8-byte Reload
	movzbl	-2(%rsi,%rcx), %ecx
	movl	%ecx, -328(%rbp)                ## 4-byte Spill
	movq	-344(%rbp), %rcx                ## 8-byte Reload
	addl	$-16, %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -328(%rbp)                 ## 4-byte Folded Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	movzbl	-3(%rsi,%rcx), %ecx
	movl	%ecx, -464(%rbp)                ## 4-byte Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	movzbl	-1(%rsi,%rcx), %ecx
	movl	%ecx, -392(%rbp)                ## 4-byte Spill
	movq	-344(%rbp), %rsi                ## 8-byte Reload
	leal	-8(%rsi), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -392(%rbp)                 ## 4-byte Folded Spill
	orl	-464(%rbp), %r10d               ## 4-byte Folded Reload
	orl	%r10d, -328(%rbp)               ## 4-byte Folded Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	movq	-384(%rbp), %r10                ## 8-byte Reload
	movzbl	(%r10,%rcx), %r10d
	movl	%esi, %ecx
	shll	%cl, %r10d
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	orl	-392(%rbp), %r10d               ## 4-byte Folded Reload
	orl	-328(%rbp), %r10d               ## 4-byte Folded Reload
	addq	$4, %rcx
	addl	$32, %esi
	movq	%rsi, -344(%rbp)                ## 8-byte Spill
	cmpq	%rcx, -424(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_103
## %bb.104:                             ##   in Loop: Header=BB3_63 Depth=1
	movq	-456(%rbp), %rsi                ## 8-byte Reload
	testq	%rsi, %rsi
	movq	%rcx, -312(%rbp)                ## 8-byte Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	je	LBB3_107
LBB3_105:                               ##   in Loop: Header=BB3_63 Depth=1
	movq	%rcx, -312(%rbp)                ## 8-byte Spill
	leal	(,%rcx,8), %ecx
	movl	%ecx, -344(%rbp)                ## 4-byte Spill
	movq	-320(%rbp), %rsi                ## 8-byte Reload
	addq	-312(%rbp), %rsi                ## 8-byte Folded Reload
	addq	-504(%rbp), %rsi                ## 8-byte Folded Reload
	movq	%rsi, -320(%rbp)                ## 8-byte Spill
	movq	$0, -312(%rbp)                  ## 8-byte Folded Spill
LBB3_106:                               ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-320(%rbp), %rsi                ## 8-byte Reload
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	movzbl	(%rsi,%rcx), %ecx
	movl	%ecx, -328(%rbp)                ## 4-byte Spill
	movl	-344(%rbp), %esi                ## 4-byte Reload
	movl	%esi, %ecx
	shll	%cl, -328(%rbp)                 ## 4-byte Folded Spill
	orl	-328(%rbp), %r10d               ## 4-byte Folded Reload
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	incq	%rcx
	addl	$8, %esi
	movl	%esi, -344(%rbp)                ## 4-byte Spill
	movq	%rcx, -312(%rbp)                ## 8-byte Spill
	cmpq	%rcx, -456(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_106
	jmp	LBB3_107
LBB3_115:                               ##   in Loop: Header=BB3_63 Depth=1
	andq	$-4, -424(%rbp)                 ## 8-byte Folded Spill
	movq	-760(%rbp), %rcx                ## 8-byte Reload
	addq	%r12, %rcx
	movq	%rcx, -384(%rbp)                ## 8-byte Spill
	xorl	%ecx, %ecx
	movl	$24, %eax
	movq	%rax, -344(%rbp)                ## 8-byte Spill
	xorl	%eax, %eax
LBB3_116:                               ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rcx, -320(%rbp)                ## 8-byte Spill
	movq	-384(%rbp), %r12                ## 8-byte Reload
	movzbl	-2(%r12,%rcx), %ecx
	movl	%ecx, -328(%rbp)                ## 4-byte Spill
	movq	-344(%rbp), %rcx                ## 8-byte Reload
	addl	$-16, %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -328(%rbp)                 ## 4-byte Folded Spill
	movq	-320(%rbp), %rcx                ## 8-byte Reload
	movzbl	-3(%r12,%rcx), %ecx
	movl	%ecx, -464(%rbp)                ## 4-byte Spill
	movq	-320(%rbp), %rcx                ## 8-byte Reload
	movzbl	-1(%r12,%rcx), %ecx
	movl	%ecx, -392(%rbp)                ## 4-byte Spill
	movq	-344(%rbp), %r12                ## 8-byte Reload
	leal	-8(%r12), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -392(%rbp)                 ## 4-byte Folded Spill
	orl	-464(%rbp), %eax                ## 4-byte Folded Reload
	orl	%eax, -328(%rbp)                ## 4-byte Folded Spill
	movq	-320(%rbp), %rax                ## 8-byte Reload
	movq	-384(%rbp), %rcx                ## 8-byte Reload
	movzbl	(%rcx,%rax), %eax
	movl	%r12d, %ecx
	shll	%cl, %eax
	movq	-320(%rbp), %rcx                ## 8-byte Reload
	orl	-392(%rbp), %eax                ## 4-byte Folded Reload
	orl	-328(%rbp), %eax                ## 4-byte Folded Reload
	addq	$4, %rcx
	addl	$32, %r12d
	movq	%r12, -344(%rbp)                ## 8-byte Spill
	cmpq	%rcx, -424(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_116
## %bb.117:                             ##   in Loop: Header=BB3_63 Depth=1
	cmpq	$0, -456(%rbp)                  ## 8-byte Folded Reload
	je	LBB3_120
LBB3_118:                               ##   in Loop: Header=BB3_63 Depth=1
	movq	%rcx, -320(%rbp)                ## 8-byte Spill
	leal	(,%rcx,8), %ecx
	movq	-400(%rbp), %r12                ## 8-byte Reload
	addq	-320(%rbp), %r12                ## 8-byte Folded Reload
	addq	-792(%rbp), %r12                ## 8-byte Folded Reload
	movq	%r12, -400(%rbp)                ## 8-byte Spill
	movq	$0, -320(%rbp)                  ## 8-byte Folded Spill
	movl	%edi, -540(%rbp)                ## 4-byte Spill
LBB3_119:                               ##   Parent Loop BB3_63 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-400(%rbp), %r12                ## 8-byte Reload
	movq	-320(%rbp), %rdi                ## 8-byte Reload
	movzbl	(%r12,%rdi), %r12d
	movl	-540(%rbp), %edi                ## 4-byte Reload
	shll	%cl, %r12d
	orl	%r12d, %eax
	movq	-320(%rbp), %r12                ## 8-byte Reload
	incq	%r12
	addl	$8, %ecx
	movq	%r12, -320(%rbp)                ## 8-byte Spill
	cmpq	%r12, -456(%rbp)                ## 8-byte Folded Reload
	jne	LBB3_119
	jmp	LBB3_120
LBB3_67:
	movq	%r9, %r13
	movq	-320(%rbp), %rbx                ## 8-byte Reload
	movq	%r14, %r8
	jmp	LBB3_65
LBB3_36:
	xorl	%eax, %eax
	xorl	%r10d, %r10d
	xorl	%r8d, %r8d
LBB3_37:
	movq	%r8, -17768(%rbp)
	movq	%r10, -17776(%rbp)
	movl	%eax, -17760(%rbp)
	leaq	-17792(%rbp), %rdi
	callq	__ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
LBB3_155:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB3_157
## %bb.156:
	addq	$25944, %rsp                    ## imm = 0x6558
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB3_64:
	movq	%r9, %r13
	movq	-320(%rbp), %rbx                ## 8-byte Reload
	movq	%r12, %r8
LBB3_65:
	movq	-400(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -328(%rbp)                ## 8-byte Spill
	movq	%r15, %rdx
	movq	-352(%rbp), %r14                ## 8-byte Reload
LBB3_122:
	movq	%rdx, -744(%rbp)
	movq	%rax, -736(%rbp)
	movq	%r14, -728(%rbp)
	movq	-368(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -752(%rbp)
	movq	-520(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -720(%rbp)
	movq	-432(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -712(%rbp)
	movq	%r8, -704(%rbp)
	movq	-376(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -696(%rbp)
	movl	-312(%rbp), %eax                ## 4-byte Reload
	movl	%eax, -688(%rbp)
	movq	-512(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -680(%rbp)
	movq	-488(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -672(%rbp)
	movq	%r13, -664(%rbp)
	movq	-408(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -656(%rbp)
	movl	%edi, -648(%rbp)
	movq	-504(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -640(%rbp)
	movq	-480(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -632(%rbp)
	movq	%rbx, -624(%rbp)
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -616(%rbp)
	movl	%r11d, -608(%rbp)
	movq	-552(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -600(%rbp)
	movq	-528(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -592(%rbp)
	movq	-328(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -584(%rbp)
	movq	-336(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -576(%rbp)
	movl	%esi, -568(%rbp)
	xorl	%ebx, %ebx
	jmp	LBB3_123
	.p2align	4
LBB3_141:                               ##   in Loop: Header=BB3_123 Depth=1
	movq	24(%r9), %rdx
LBB3_153:                               ##   in Loop: Header=BB3_123 Depth=1
	andl	$4095, %edx                     ## imm = 0xFFF
	movzwl	-25984(%rbp,%rdx,2), %ecx
	movq	(%rdi), %rax
	movb	%cl, (%rax,%r8)
	shrl	$8, %ecx
	shrq	%cl, 24(%r9)
	subl	%ecx, 32(%r9)
LBB3_154:                               ##   in Loop: Header=BB3_123 Depth=1
	leaq	-720(,%rsi,8), %rdi
	addq	%rbp, %rdi
	callq	__ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
	incq	%rbx
	cmpq	$4, %rbx
	je	LBB3_155
LBB3_123:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB3_125 Depth 2
                                        ##       Child Loop BB3_132 Depth 3
                                        ##       Child Loop BB3_135 Depth 3
                                        ##     Child Loop BB3_148 Depth 2
                                        ##     Child Loop BB3_151 Depth 2
	movq	%rbx, %rax
	shlq	$4, %rax
	leaq	(%rax,%rbp), %rdi
	addq	$-896, %rdi                     ## imm = 0xFC80
	movq	-888(%rbp,%rax), %r9
	movq	-752(%rbp,%rbx,8), %r8
	movq	%r9, %rax
	subq	%r8, %rax
	leaq	(%rbx,%rbx,4), %rsi
	cmpq	$2, %rax
	jb	LBB3_139
## %bb.124:                             ##   in Loop: Header=BB3_123 Depth=1
	leaq	-720(,%rsi,8), %r10
	addq	%rbp, %r10
	movq	%rdi, -360(%rbp)                ## 8-byte Spill
	movq	(%rdi), %r14
	movl	-688(%rbp,%rsi,8), %eax
	movq	-696(%rbp,%rsi,8), %r11
	jmp	LBB3_125
	.p2align	4
LBB3_127:                               ##   in Loop: Header=BB3_125 Depth=2
	movq	(%r10), %rcx
	movl	(%rcx,%r12), %r13d
LBB3_136:                               ##   in Loop: Header=BB3_125 Depth=2
	movl	%r13d, %edx
	movl	%eax, %ecx
	shlq	%cl, %rdx
	orq	%rdx, %r11
	movq	%r15, 16(%r10)
	orl	$32, %eax
LBB3_137:                               ##   in Loop: Header=BB3_125 Depth=2
	movl	%r11d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17792(%rbp,%rcx,4), %edx
	movl	%edx, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	shrq	%cl, %r11
	subl	%ecx, %eax
	movw	%dx, (%r14,%r8)
	shrl	$24, %edx
	addq	%rdx, %r8
	movq	%r9, %rcx
	subq	%r8, %rcx
	cmpq	$1, %rcx
	jbe	LBB3_138
LBB3_125:                               ##   Parent Loop BB3_123 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB3_132 Depth 3
                                        ##       Child Loop BB3_135 Depth 3
	cmpl	$11, %eax
	ja	LBB3_137
## %bb.126:                             ##   in Loop: Header=BB3_125 Depth=2
	movq	8(%r10), %rdi
	movq	16(%r10), %r12
	leaq	4(%r12), %r15
	cmpq	%rdi, %r15
	jbe	LBB3_127
## %bb.128:                             ##   in Loop: Header=BB3_125 Depth=2
	xorl	%r13d, %r13d
	movq	%r12, %rcx
	subq	%rdi, %rcx
	jae	LBB3_136
## %bb.129:                             ##   in Loop: Header=BB3_125 Depth=2
	movq	(%r10), %r13
	subq	%r12, %rdi
	movl	%edi, %edx
	andl	$3, %edx
	movq	%rdx, -472(%rbp)                ## 8-byte Spill
	cmpq	$-4, %rcx
	movq	%r13, -320(%rbp)                ## 8-byte Spill
	jbe	LBB3_131
## %bb.130:                             ##   in Loop: Header=BB3_125 Depth=2
	xorl	%ecx, %ecx
	xorl	%r13d, %r13d
	movq	-472(%rbp), %rdi                ## 8-byte Reload
	jmp	LBB3_134
LBB3_131:                               ##   in Loop: Header=BB3_125 Depth=2
	andq	$-4, %rdi
	leaq	(%r12,%r13), %rcx
	addq	$3, %rcx
	movq	%rcx, -376(%rbp)                ## 8-byte Spill
	xorl	%ecx, %ecx
	movl	$24, %edx
	movq	%rdx, -312(%rbp)                ## 8-byte Spill
	xorl	%r13d, %r13d
LBB3_132:                               ##   Parent Loop BB3_123 Depth=1
                                        ##     Parent Loop BB3_125 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	%rcx, -336(%rbp)                ## 8-byte Spill
	movq	-376(%rbp), %rdx                ## 8-byte Reload
	movzbl	-2(%rdx,%rcx), %ecx
	movl	%ecx, -368(%rbp)                ## 4-byte Spill
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	addl	$-16, %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -368(%rbp)                 ## 4-byte Folded Spill
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movzbl	-3(%rdx,%rcx), %ecx
	movl	%ecx, -408(%rbp)                ## 4-byte Spill
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movzbl	-1(%rdx,%rcx), %ecx
	movl	%ecx, -352(%rbp)                ## 4-byte Spill
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	leal	-8(%rdx), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -352(%rbp)                 ## 4-byte Folded Spill
	orl	-408(%rbp), %r13d               ## 4-byte Folded Reload
	orl	%r13d, -368(%rbp)               ## 4-byte Folded Spill
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movq	-376(%rbp), %r13                ## 8-byte Reload
	movzbl	(%r13,%rcx), %r13d
	movl	%edx, %ecx
	shll	%cl, %r13d
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	orl	-352(%rbp), %r13d               ## 4-byte Folded Reload
	orl	-368(%rbp), %r13d               ## 4-byte Folded Reload
	addq	$4, %rcx
	addl	$32, %edx
	movq	%rdx, -312(%rbp)                ## 8-byte Spill
	cmpq	%rcx, %rdi
	jne	LBB3_132
## %bb.133:                             ##   in Loop: Header=BB3_125 Depth=2
	movq	-472(%rbp), %rdi                ## 8-byte Reload
	testq	%rdi, %rdi
	je	LBB3_136
LBB3_134:                               ##   in Loop: Header=BB3_125 Depth=2
	movq	%rcx, %rdx
	leal	(,%rcx,8), %ecx
	addq	%rdx, %r12
	addq	%r12, -320(%rbp)                ## 8-byte Folded Spill
	xorl	%edx, %edx
	.p2align	4
LBB3_135:                               ##   Parent Loop BB3_123 Depth=1
                                        ##     Parent Loop BB3_125 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	-320(%rbp), %r12                ## 8-byte Reload
	movzbl	(%r12,%rdx), %r12d
	shll	%cl, %r12d
	orl	%r12d, %r13d
	incq	%rdx
	addl	$8, %ecx
	cmpq	%rdx, %rdi
	jne	LBB3_135
	jmp	LBB3_136
	.p2align	4
LBB3_138:                               ##   in Loop: Header=BB3_123 Depth=1
	movl	%eax, 32(%r10)
	movq	%r11, 24(%r10)
	movq	-360(%rbp), %rdi                ## 8-byte Reload
LBB3_139:                               ##   in Loop: Header=BB3_123 Depth=1
	movq	%r8, -752(%rbp,%rbx,8)
	cmpq	%r9, %r8
	jae	LBB3_154
## %bb.140:                             ##   in Loop: Header=BB3_123 Depth=1
	leaq	-720(,%rsi,8), %r9
	addq	%rbp, %r9
	movl	-688(%rbp,%rsi,8), %eax
	cmpq	$12, %rax
	jae	LBB3_141
## %bb.142:                             ##   in Loop: Header=BB3_123 Depth=1
	movq	8(%r9), %r13
	movq	16(%r9), %r12
	leaq	4(%r12), %r10
	cmpq	%r13, %r10
	ja	LBB3_144
## %bb.143:                             ##   in Loop: Header=BB3_123 Depth=1
	movq	(%r9), %rcx
	movl	(%rcx,%r12), %r15d
LBB3_152:                               ##   in Loop: Header=BB3_123 Depth=1
	movl	%r15d, %edx
	movl	%eax, %ecx
	shlq	%cl, %rdx
	orq	24(%r9), %rdx
	movq	%rdx, 24(%r9)
	movq	%r10, 16(%r9)
	addl	$32, %eax
	movl	%eax, 32(%r9)
	jmp	LBB3_153
LBB3_144:                               ##   in Loop: Header=BB3_123 Depth=1
	xorl	%r15d, %r15d
	movq	%r12, %rcx
	subq	%r13, %rcx
	jae	LBB3_152
## %bb.145:                             ##   in Loop: Header=BB3_123 Depth=1
	movq	(%r9), %r14
	subq	%r12, %r13
	movl	%r13d, %edx
	andl	$3, %edx
	movq	%rdx, -352(%rbp)                ## 8-byte Spill
	cmpq	$-4, %rcx
	jbe	LBB3_147
## %bb.146:                             ##   in Loop: Header=BB3_123 Depth=1
	xorl	%r11d, %r11d
	xorl	%r15d, %r15d
	movq	-352(%rbp), %r13                ## 8-byte Reload
	jmp	LBB3_150
LBB3_147:                               ##   in Loop: Header=BB3_123 Depth=1
	andq	$-4, %r13
	movq	%r14, -376(%rbp)                ## 8-byte Spill
	leaq	(%r14,%r12), %rcx
	addq	$3, %rcx
	movq	%rcx, -360(%rbp)                ## 8-byte Spill
	xorl	%r11d, %r11d
	movl	$24, %edx
	xorl	%r15d, %r15d
LBB3_148:                               ##   Parent Loop BB3_123 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	movzbl	-2(%rcx,%r11), %r14d
	leal	-16(%rdx), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, %r14d
	movl	%r14d, -368(%rbp)               ## 4-byte Spill
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	movzbl	-3(%rcx,%r11), %r14d
	movl	%r14d, -312(%rbp)               ## 4-byte Spill
	movzbl	-1(%rcx,%r11), %r14d
	movl	%r14d, -336(%rbp)               ## 4-byte Spill
	leal	-8(%rdx), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shll	%cl, -336(%rbp)                 ## 4-byte Folded Spill
	orl	-312(%rbp), %r15d               ## 4-byte Folded Reload
	movl	-368(%rbp), %r14d               ## 4-byte Reload
	orl	%r15d, %r14d
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	movzbl	(%rcx,%r11), %r15d
	movl	%edx, %ecx
	shll	%cl, %r15d
	orl	-336(%rbp), %r15d               ## 4-byte Folded Reload
	orl	%r14d, %r15d
	addq	$4, %r11
	addl	$32, %edx
	cmpq	%r11, %r13
	jne	LBB3_148
## %bb.149:                             ##   in Loop: Header=BB3_123 Depth=1
	movq	-352(%rbp), %r13                ## 8-byte Reload
	testq	%r13, %r13
	movq	-376(%rbp), %r14                ## 8-byte Reload
	je	LBB3_152
LBB3_150:                               ##   in Loop: Header=BB3_123 Depth=1
	leal	(,%r11,8), %ecx
	addq	%r11, %r12
	addq	%r12, %r14
	xorl	%edx, %edx
LBB3_151:                               ##   Parent Loop BB3_123 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r14,%rdx), %r11d
	shll	%cl, %r11d
	orl	%r11d, %r15d
	incq	%rdx
	addl	$8, %ecx
	cmpq	%rdx, %r13
	jne	LBB3_151
	jmp	LBB3_152
LBB3_3:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp36:                                 ## EH_LABEL
	leaq	L_.str.1(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_157:
	callq	___stack_chk_fail
LBB3_23:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp51:                                 ## EH_LABEL
	leaq	L_.str.4(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_58:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp39:                                 ## EH_LABEL
	leaq	L_.str.6(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_11:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp48:                                 ## EH_LABEL
	leaq	L_.str.2(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_18:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp45:                                 ## EH_LABEL
	leaq	L_.str.3(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_26:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp42:                                 ## EH_LABEL
	leaq	L_.str.5(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ## EH_LABEL
LBB3_4:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB3_27:
Ltmp44:                                 ## EH_LABEL
	jmp	LBB3_6
LBB3_19:
Ltmp47:                                 ## EH_LABEL
	jmp	LBB3_6
LBB3_12:
Ltmp50:                                 ## EH_LABEL
	jmp	LBB3_6
LBB3_59:
Ltmp41:                                 ## EH_LABEL
	jmp	LBB3_6
LBB3_24:
Ltmp53:                                 ## EH_LABEL
	jmp	LBB3_6
LBB3_5:
Ltmp38:                                 ## EH_LABEL
LBB3_6:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception3:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3      ## >> Call Site 1 <<
	.uleb128 Ltmp36-Lfunc_begin3            ##   Call between Lfunc_begin3 and Ltmp36
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin3            ## >> Call Site 2 <<
	.uleb128 Ltmp37-Ltmp36                  ##   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin3            ##     jumps to Ltmp38
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin3            ## >> Call Site 3 <<
	.uleb128 Ltmp51-Ltmp37                  ##   Call between Ltmp37 and Ltmp51
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin3            ## >> Call Site 4 <<
	.uleb128 Ltmp52-Ltmp51                  ##   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin3            ##     jumps to Ltmp53
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin3            ## >> Call Site 5 <<
	.uleb128 Ltmp39-Ltmp52                  ##   Call between Ltmp52 and Ltmp39
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin3            ## >> Call Site 6 <<
	.uleb128 Ltmp40-Ltmp39                  ##   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin3            ##     jumps to Ltmp41
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin3            ## >> Call Site 7 <<
	.uleb128 Ltmp48-Ltmp40                  ##   Call between Ltmp40 and Ltmp48
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin3            ## >> Call Site 8 <<
	.uleb128 Ltmp49-Ltmp48                  ##   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin3            ##     jumps to Ltmp50
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin3            ## >> Call Site 9 <<
	.uleb128 Ltmp45-Ltmp49                  ##   Call between Ltmp49 and Ltmp45
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin3            ## >> Call Site 10 <<
	.uleb128 Ltmp46-Ltmp45                  ##   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin3            ##     jumps to Ltmp47
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin3            ## >> Call Site 11 <<
	.uleb128 Ltmp42-Ltmp46                  ##   Call between Ltmp46 and Ltmp42
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin3            ## >> Call Site 12 <<
	.uleb128 Ltmp43-Ltmp42                  ##   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin3            ##     jumps to Ltmp44
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin3            ## >> Call Site 13 <<
	.uleb128 Lfunc_end3-Ltmp43              ##   Call between Ltmp43 and Lfunc_end3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end3:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
__ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE: ## @_ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception4
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdx, %r8
	movq	%rdi, %r15
	xorl	%r13d, %r13d
	xorl	%ebx, %ebx
	xorl	%eax, %eax
	movq	%rsi, -48(%rbp)                 ## 8-byte Spill
	jmp	LBB4_1
	.p2align	4
LBB4_7:                                 ##   in Loop: Header=BB4_1 Depth=1
	movb	%r10b, (%r8,%rbx)
	incq	%rbx
	movq	%rcx, %rax
	movl	%r10d, %r13d
	cmpq	$256, %rbx                      ## imm = 0x100
	jae	LBB4_25
LBB4_1:                                 ## =>This Inner Loop Header: Depth=1
	movq	%rax, %rcx
	shrq	%rcx
	cmpq	%rsi, %rcx
	jae	LBB4_2
## %bb.6:                               ##   in Loop: Header=BB4_1 Depth=1
	leal	(,%rax,4), %edx
	andb	$4, %dl
	movzbl	(%r15,%rcx), %r10d
	movl	%edx, %ecx
	shrb	%cl, %r10b
	andb	$15, %r10b
	leaq	1(%rax), %rcx
	cmpb	$12, %r10b
	jbe	LBB4_7
## %bb.8:                               ##   in Loop: Header=BB4_1 Depth=1
	cmpb	$13, %r10b
	je	LBB4_9
## %bb.11:                              ##   in Loop: Header=BB4_1 Depth=1
	movq	%rcx, %r9
	shrq	%r9
	cmpq	%rsi, %r9
	jae	LBB4_12
## %bb.14:                              ##   in Loop: Header=BB4_1 Depth=1
	shll	$2, %ecx
	movzbl	(%r15,%r9), %r12d
	andb	$4, %cl
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r12
	andl	$15, %r12d
	leaq	2(%rax), %r14
	cmpb	$15, %r10b
	jne	LBB4_19
## %bb.15:                              ##   in Loop: Header=BB4_1 Depth=1
	shrq	%r14
	cmpq	%rsi, %r14
	jae	LBB4_16
## %bb.18:                              ##   in Loop: Header=BB4_1 Depth=1
	movzbl	(%r15,%r14), %esi
	movl	%edx, %ecx
	shrb	%cl, %sil
	addq	$3, %rax
	shlb	$4, %sil
	orb	%r12b, %sil
	movzbl	%sil, %r12d
	addq	$19, %r12
	movq	%rax, %r14
	jmp	LBB4_20
	.p2align	4
LBB4_19:                                ##   in Loop: Header=BB4_1 Depth=1
	addq	$3, %r12
LBB4_20:                                ##   in Loop: Header=BB4_1 Depth=1
	movl	$256, %eax                      ## imm = 0x100
	subl	%ebx, %eax
	cmpl	%eax, %r12d
	ja	LBB4_21
## %bb.23:                              ##   in Loop: Header=BB4_1 Depth=1
	leaq	(%r8,%rbx), %rdi
	movzbl	%r13b, %esi
	movq	%r12, %rdx
	movq	%rbx, -56(%rbp)                 ## 8-byte Spill
	movq	%r8, %rbx
	callq	_memset
	movq	%rbx, %r8
	movq	-56(%rbp), %rbx                 ## 8-byte Reload
	addq	%r12, %rbx
	movq	%r14, %rax
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	cmpq	$256, %rbx                      ## imm = 0x100
	jb	LBB4_1
LBB4_25:
	cmpq	$257, %rax                      ## imm = 0x101
	jae	LBB4_26
## %bb.28:
	testb	$1, %al
	je	LBB4_32
## %bb.29:
	movq	%rax, %rcx
	shrq	%rcx
	cmpb	$16, (%r15,%rcx)
	jae	LBB4_30
LBB4_32:
	incq	%rax
	shrq	%rax
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB4_2:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp54:                                 ## EH_LABEL
	leaq	L_.str.26(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ## EH_LABEL
	jmp	LBB4_3
LBB4_9:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp66:                                 ## EH_LABEL
	leaq	L_.str.22(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ## EH_LABEL
	jmp	LBB4_3
LBB4_21:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp63:                                 ## EH_LABEL
	leaq	L_.str.23(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ## EH_LABEL
	jmp	LBB4_3
LBB4_12:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp57:                                 ## EH_LABEL
	leaq	L_.str.26(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ## EH_LABEL
	jmp	LBB4_3
LBB4_16:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp60:                                 ## EH_LABEL
	leaq	L_.str.26(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ## EH_LABEL
LBB4_3:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB4_26:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp69:                                 ## EH_LABEL
	leaq	L_.str.24(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp70:                                 ## EH_LABEL
	jmp	LBB4_3
LBB4_30:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp72:                                 ## EH_LABEL
	leaq	L_.str.25(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp73:                                 ## EH_LABEL
	jmp	LBB4_3
LBB4_31:
Ltmp74:                                 ## EH_LABEL
	jmp	LBB4_5
LBB4_27:
Ltmp71:                                 ## EH_LABEL
	jmp	LBB4_5
LBB4_17:
Ltmp62:                                 ## EH_LABEL
	jmp	LBB4_5
LBB4_13:
Ltmp59:                                 ## EH_LABEL
	jmp	LBB4_5
LBB4_22:
Ltmp65:                                 ## EH_LABEL
	jmp	LBB4_5
LBB4_10:
Ltmp68:                                 ## EH_LABEL
	jmp	LBB4_5
LBB4_4:
Ltmp56:                                 ## EH_LABEL
LBB4_5:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end4:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table4:
Lexception4:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end4-Lcst_begin4
Lcst_begin4:
	.uleb128 Lfunc_begin4-Lfunc_begin4      ## >> Call Site 1 <<
	.uleb128 Ltmp54-Lfunc_begin4            ##   Call between Lfunc_begin4 and Ltmp54
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin4            ## >> Call Site 2 <<
	.uleb128 Ltmp55-Ltmp54                  ##   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin4            ##     jumps to Ltmp56
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin4            ## >> Call Site 3 <<
	.uleb128 Ltmp66-Ltmp55                  ##   Call between Ltmp55 and Ltmp66
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin4            ## >> Call Site 4 <<
	.uleb128 Ltmp67-Ltmp66                  ##   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin4            ##     jumps to Ltmp68
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin4            ## >> Call Site 5 <<
	.uleb128 Ltmp63-Ltmp67                  ##   Call between Ltmp67 and Ltmp63
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin4            ## >> Call Site 6 <<
	.uleb128 Ltmp64-Ltmp63                  ##   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin4            ##     jumps to Ltmp65
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin4            ## >> Call Site 7 <<
	.uleb128 Ltmp57-Ltmp64                  ##   Call between Ltmp64 and Ltmp57
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin4            ## >> Call Site 8 <<
	.uleb128 Ltmp58-Ltmp57                  ##   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin4            ##     jumps to Ltmp59
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin4            ## >> Call Site 9 <<
	.uleb128 Ltmp60-Ltmp58                  ##   Call between Ltmp58 and Ltmp60
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin4            ## >> Call Site 10 <<
	.uleb128 Ltmp61-Ltmp60                  ##   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin4            ##     jumps to Ltmp62
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin4            ## >> Call Site 11 <<
	.uleb128 Ltmp69-Ltmp61                  ##   Call between Ltmp61 and Ltmp69
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp69-Lfunc_begin4            ## >> Call Site 12 <<
	.uleb128 Ltmp70-Ltmp69                  ##   Call between Ltmp69 and Ltmp70
	.uleb128 Ltmp71-Lfunc_begin4            ##     jumps to Ltmp71
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp70-Lfunc_begin4            ## >> Call Site 13 <<
	.uleb128 Ltmp72-Ltmp70                  ##   Call between Ltmp70 and Ltmp72
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp72-Lfunc_begin4            ## >> Call Site 14 <<
	.uleb128 Ltmp73-Ltmp72                  ##   Call between Ltmp72 and Ltmp73
	.uleb128 Ltmp74-Lfunc_begin4            ##     jumps to Ltmp74
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp73-Lfunc_begin4            ## >> Call Site 15 <<
	.uleb128 Lfunc_end4-Ltmp73              ##   Call between Ltmp73 and Lfunc_end4
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end4:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
__ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv: ## @_ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
Lfunc_begin5:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception5
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	16(%rdi), %rcx
	shlq	$3, %rcx
	movl	32(%rdi), %eax
	subq	%rax, %rcx
	leaq	7(%rcx), %rax
	shrq	$3, %rax
	cmpq	8(%rdi), %rax
	jne	LBB5_1
## %bb.5:
	andq	$7, %rcx
	je	LBB5_9
## %bb.6:
	movq	(%rdi), %rdx
	movzbl	-1(%rdx,%rax), %eax
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %eax
	testl	%eax, %eax
	jne	LBB5_7
LBB5_9:
	popq	%rbx
	popq	%r14
	popq	%rbp
	retq
LBB5_1:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp75:                                 ## EH_LABEL
	leaq	L_.str.27(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp76:                                 ## EH_LABEL
	jmp	LBB5_2
LBB5_7:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp78:                                 ## EH_LABEL
	leaq	L_.str.28(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp79:                                 ## EH_LABEL
LBB5_2:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB5_8:
Ltmp80:                                 ## EH_LABEL
	jmp	LBB5_4
LBB5_3:
Ltmp77:                                 ## EH_LABEL
LBB5_4:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end5:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table5:
Lexception5:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end5-Lcst_begin5
Lcst_begin5:
	.uleb128 Lfunc_begin5-Lfunc_begin5      ## >> Call Site 1 <<
	.uleb128 Ltmp75-Lfunc_begin5            ##   Call between Lfunc_begin5 and Ltmp75
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp75-Lfunc_begin5            ## >> Call Site 2 <<
	.uleb128 Ltmp76-Ltmp75                  ##   Call between Ltmp75 and Ltmp76
	.uleb128 Ltmp77-Lfunc_begin5            ##     jumps to Ltmp77
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp76-Lfunc_begin5            ## >> Call Site 3 <<
	.uleb128 Ltmp78-Ltmp76                  ##   Call between Ltmp76 and Ltmp78
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp78-Lfunc_begin5            ## >> Call Site 4 <<
	.uleb128 Ltmp79-Ltmp78                  ##   Call between Ltmp78 and Ltmp79
	.uleb128 Ltmp80-Lfunc_begin5            ##     jumps to Ltmp80
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp79-Lfunc_begin5            ## >> Call Site 5 <<
	.uleb128 Lfunc_end5-Ltmp79              ##   Call between Ltmp79 and Lfunc_end5
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end5:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_ ## -- Begin function _ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_
	.p2align	4
__ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_: ## @_ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_
Lfunc_begin6:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception6
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$9032, %rsp                     ## imm = 0x2348
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	cmpq	$2097161, %rsi                  ## imm = 0x200009
	jae	LBB6_1
## %bb.5:
	movq	%r8, %r15
	movq	%rsi, %rbx
	leaq	1024(,%rsi,2), %rax
	cmpq	%rax, %r8
	jb	LBB6_7
## %bb.6:
	movq	%rcx, %r13
	leaq	16(%rbp), %rcx
	leaq	(%rbx,%rbx), %rax
	cmpq	%rax, 8(%rcx)
	jb	LBB6_7
## %bb.9:
	movq	%rdx, %r12
	movq	%rdi, %r14
	leaq	-9000(%rbp), %rdi
	movl	$8176, %esi                     ## imm = 0x1FF0
	callq	___bzero
	movl	$60, %eax
	movabsq	$1099545117183, %rcx            ## imm = 0x10001FF01FF
	.p2align	4
LBB6_10:                                ## =>This Inner Loop Header: Depth=1
	movq	%rcx, -9060(%rbp,%rax)
	movq	$0, -9052(%rbp,%rax)
	movq	%rcx, -9044(%rbp,%rax)
	movq	$0, -9036(%rbp,%rax)
	movq	%rcx, -9028(%rbp,%rax)
	movq	$0, -9020(%rbp,%rax)
	cmpq	$8188, %rax                     ## imm = 0x1FFC
	je	LBB6_12
## %bb.11:                              ##   in Loop: Header=BB6_10 Depth=1
	movq	%rcx, -9012(%rbp,%rax)
	movq	$0, -9004(%rbp,%rax)
	addq	$64, %rax
	jmp	LBB6_10
LBB6_12:
	leaq	-824(%rbp), %rdi
	movl	$768, %esi                      ## imm = 0x300
	callq	___bzero
	movq	$1, -56(%rbp)
	leaq	-9000(%rbp), %rsi
	movq	%r12, %rdi
	callq	__ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
	testq	%rbx, %rbx
	je	LBB6_16
## %bb.13:
	xorl	%eax, %eax
	.p2align	4
LBB6_14:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%r14,%rax), %ecx
	cmpb	$0, (%r12,%rcx)
	je	LBB6_18
## %bb.15:                              ##   in Loop: Header=BB6_14 Depth=1
	incq	%rax
	cmpq	%rax, %rbx
	jne	LBB6_14
LBB6_16:
	movq	%r13, %rcx
	movb	$-79, (%r13)
	movb	%bl, 1(%r13)
	movb	%bh, 2(%rcx)
	movl	%ebx, %eax
	shrl	$16, %eax
	movb	%al, 3(%r13)
	movb	$0, 4(%r13)
	leaq	5(%r13), %rsi
	movl	$128, %edx
	movq	%r12, %rdi
	callq	__ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
	movq	%rax, %r12
	addq	$5, %rax
	subq	%rax, %r15
	leaq	(%r12,%r13), %r8
	addq	$5, %r8
	leaq	16(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -9032(%rbp)
	movq	%rbx, -9024(%rbp)
	addq	%rbx, %rax
	movq	%rax, -9016(%rbp)
	movq	%rbx, -9008(%rbp)
	movups	-9016(%rbp), %xmm0
	movups	%xmm0, 16(%rsp)
	movups	-9032(%rbp), %xmm0
	movups	%xmm0, (%rsp)
	leaq	-9000(%rbp), %rdi
	movq	%rbx, %rcx
	xorl	%esi, %esi
	movq	%r14, %rdx
	movq	%r15, %r9
	callq	__ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
	movq	___stack_chk_guard@GOTPCREL(%rip), %rcx
	movq	(%rcx), %rcx
	cmpq	-48(%rbp), %rcx
	jne	LBB6_20
## %bb.17:
	addq	%r12, %rax
	addq	$5, %rax
	addq	$9032, %rsp                     ## imm = 0x2348
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB6_18:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp87:                                 ## EH_LABEL
	leaq	L_.str.10(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp88:                                 ## EH_LABEL
LBB6_2:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB6_1:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp81:                                 ## EH_LABEL
	leaq	L_.str.8(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp82:                                 ## EH_LABEL
	jmp	LBB6_2
LBB6_7:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp84:                                 ## EH_LABEL
	leaq	L_.str.9(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp85:                                 ## EH_LABEL
	jmp	LBB6_2
LBB6_20:
	callq	___stack_chk_fail
LBB6_8:
Ltmp86:                                 ## EH_LABEL
	jmp	LBB6_4
LBB6_3:
Ltmp83:                                 ## EH_LABEL
	jmp	LBB6_4
LBB6_19:
Ltmp89:                                 ## EH_LABEL
LBB6_4:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end6:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table6:
Lexception6:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end6-Lcst_begin6
Lcst_begin6:
	.uleb128 Lfunc_begin6-Lfunc_begin6      ## >> Call Site 1 <<
	.uleb128 Ltmp87-Lfunc_begin6            ##   Call between Lfunc_begin6 and Ltmp87
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp87-Lfunc_begin6            ## >> Call Site 2 <<
	.uleb128 Ltmp88-Ltmp87                  ##   Call between Ltmp87 and Ltmp88
	.uleb128 Ltmp89-Lfunc_begin6            ##     jumps to Ltmp89
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp88-Lfunc_begin6            ## >> Call Site 3 <<
	.uleb128 Ltmp81-Ltmp88                  ##   Call between Ltmp88 and Ltmp81
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp81-Lfunc_begin6            ## >> Call Site 4 <<
	.uleb128 Ltmp82-Ltmp81                  ##   Call between Ltmp81 and Ltmp82
	.uleb128 Ltmp83-Lfunc_begin6            ##     jumps to Ltmp83
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp82-Lfunc_begin6            ## >> Call Site 5 <<
	.uleb128 Ltmp84-Ltmp82                  ##   Call between Ltmp82 and Ltmp84
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp84-Lfunc_begin6            ## >> Call Site 6 <<
	.uleb128 Ltmp85-Ltmp84                  ##   Call between Ltmp84 and Ltmp85
	.uleb128 Ltmp86-Lfunc_begin6            ##     jumps to Ltmp86
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp85-Lfunc_begin6            ## >> Call Site 7 <<
	.uleb128 Lfunc_end6-Ltmp85              ##   Call between Ltmp85 and Lfunc_end6
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end6:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
__ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE: ## @_ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
Lfunc_begin7:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception7
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$520, %rsp                      ## imm = 0x208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	addq	$8432, %rsi                     ## imm = 0x20F0
	callq	__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	xorl	%eax, %eax
	jmp	LBB7_1
	.p2align	4
LBB7_17:                                ##   in Loop: Header=BB7_1 Depth=1
	movzwl	%si, %ecx
	shll	$4, %ecx
	movw	%ax, 4(%rbx,%rcx)
LBB7_18:                                ##   in Loop: Header=BB7_1 Depth=1
	incq	%rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB7_7
LBB7_1:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB7_3 Depth 2
	movzbl	(%r14,%rax), %ecx
	testl	%ecx, %ecx
	je	LBB7_18
## %bb.2:                               ##   in Loop: Header=BB7_1 Depth=1
	xorl	%esi, %esi
	xorl	%edx, %edx
	jmp	LBB7_3
	.p2align	4
LBB7_16:                                ##   in Loop: Header=BB7_3 Depth=2
	incl	%edx
	cmpl	%edx, %ecx
	je	LBB7_17
LBB7_3:                                 ##   Parent Loop BB7_1 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	8432(%rbx,%rax,2), %r8d
	xorl	%edi, %edi
	btl	%edx, %r8d
	setb	%dil
	movzwl	%si, %r8d
	shll	$4, %r8d
	addq	%rbx, %r8
	movzwl	(%r8,%rdi,2), %esi
	cmpl	$511, %esi                      ## imm = 0x1FF
	jne	LBB7_16
## %bb.4:                               ##   in Loop: Header=BB7_3 Depth=2
	movq	8944(%rbx), %rsi
	cmpq	$511, %rsi                      ## imm = 0x1FF
	jae	LBB7_5
## %bb.15:                              ##   in Loop: Header=BB7_3 Depth=2
	movw	%si, (%r8,%rdi,2)
	leal	1(%rdx), %edi
	movq	%rsi, %r8
	shlq	$4, %r8
	movl	%edi, 8(%rbx,%r8)
	movq	%rsi, %rdi
	incq	%rdi
	movq	%rdi, 8944(%rbx)
	jmp	LBB7_16
LBB7_7:
	movq	8944(%rbx), %r14
	testq	%r14, %r14
	je	LBB7_31
## %bb.8:
	movq	%r14, %rax
	shlq	$4, %rax
	addq	%rbx, %rax
	addq	$-16, %rax
	xorl	%ecx, %ecx
	jmp	LBB7_9
	.p2align	4
LBB7_25:                                ##   in Loop: Header=BB7_9 Depth=1
	incq	%rcx
	addq	$-16, %rax
	cmpq	%rcx, %r14
	je	LBB7_26
LBB7_9:                                 ## =>This Inner Loop Header: Depth=1
	cmpw	$256, 4(%rax)                   ## imm = 0x100
	jne	LBB7_25
## %bb.10:                              ##   in Loop: Header=BB7_9 Depth=1
	movzwl	(%rax), %edi
	cmpq	%rdi, %r14
	jbe	LBB7_12
## %bb.11:                              ##   in Loop: Header=BB7_9 Depth=1
	movzwl	2(%rax), %edx
	cmpq	%rdx, %r14
	jbe	LBB7_12
## %bb.20:                              ##   in Loop: Header=BB7_9 Depth=1
	shll	$4, %edi
	leaq	(%rbx,%rdi), %rsi
	cmpw	$256, 4(%rbx,%rdi)              ## imm = 0x100
	jne	LBB7_22
## %bb.21:                              ##   in Loop: Header=BB7_9 Depth=1
	cmpl	$0, 12(%rsi)
	je	LBB7_25
LBB7_22:                                ##   in Loop: Header=BB7_9 Depth=1
	shll	$4, %edx
	addq	%rbx, %rdx
	cmpw	$256, 4(%rdx)                   ## imm = 0x100
	sete	%dil
	movl	12(%rdx), %edx
	testl	%edx, %edx
	sete	%r8b
	testb	%r8b, %dil
	jne	LBB7_25
## %bb.23:                              ##   in Loop: Header=BB7_9 Depth=1
	cmpl	%edx, 12(%rsi)
	jne	LBB7_25
## %bb.24:                              ##   in Loop: Header=BB7_9 Depth=1
	incl	%edx
	movl	%edx, 12(%rax)
	jmp	LBB7_25
LBB7_26:
	leaq	-558(%rbp), %rdi
	movl	$510, %esi                      ## imm = 0x1FE
	callq	___bzero
	movb	$1, -559(%rbp)
	leaq	8176(%rbx), %rax
	xorl	%edx, %edx
	xorl	%esi, %esi
	jmp	LBB7_27
LBB7_30:                                ##   in Loop: Header=BB7_27 Depth=1
	movzwl	(%rdi), %ecx
	movb	$1, -559(%rbp,%rcx)
	movzwl	2(%rdi), %ecx
	movb	$1, -559(%rbp,%rcx)
	.p2align	4
LBB7_48:                                ##   in Loop: Header=BB7_27 Depth=1
	incq	%rdx
	cmpq	%r14, %rdx
	jae	LBB7_31
LBB7_27:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB7_37 Depth 2
                                        ##       Child Loop BB7_40 Depth 3
                                        ##       Child Loop BB7_42 Depth 3
	cmpb	$1, -559(%rbp,%rdx)
	jne	LBB7_48
## %bb.28:                              ##   in Loop: Header=BB7_27 Depth=1
	movq	%rdx, %rdi
	shlq	$4, %rdi
	addq	%rbx, %rdi
	cmpw	$256, 4(%rdi)                   ## imm = 0x100
	jne	LBB7_48
## %bb.29:                              ##   in Loop: Header=BB7_27 Depth=1
	movl	12(%rdi), %ecx
	testq	%rcx, %rcx
	je	LBB7_30
## %bb.33:                              ##   in Loop: Header=BB7_27 Depth=1
	movl	$1, %r8d
                                        ## kill: def $cl killed $cl killed $rcx
	shlq	%cl, %r8
	movl	$256, %ecx                      ## imm = 0x100
	subq	%rsi, %rcx
	cmpq	%rcx, %r8
	ja	LBB7_34
## %bb.36:                              ##   in Loop: Header=BB7_27 Depth=1
	movw	%si, 6(%rdi)
	leaq	(%rax,%rsi), %rcx
	xorl	%r9d, %r9d
	.p2align	4
LBB7_37:                                ##   Parent Loop BB7_27 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB7_40 Depth 3
                                        ##       Child Loop BB7_42 Depth 3
	movl	12(%rdi), %r14d
	movq	%rdx, %r15
	testl	%r14d, %r14d
	je	LBB7_43
## %bb.38:                              ##   in Loop: Header=BB7_37 Depth=2
	movl	%r14d, %r10d
	andl	$3, %r10d
	xorl	%r11d, %r11d
	movq	%rdx, %r15
	cmpl	$4, %r14d
	jb	LBB7_42
## %bb.39:                              ##   in Loop: Header=BB7_37 Depth=2
	andl	$-4, %r14d
	xorl	%r11d, %r11d
	movq	%rdx, %r15
	.p2align	4
LBB7_40:                                ##   Parent Loop BB7_27 Depth=1
                                        ##     Parent Loop BB7_37 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	shlq	$4, %r15
	addq	%rbx, %r15
	xorl	%r12d, %r12d
	btl	%r11d, %r9d
	setb	%r12b
	movzwl	(%r15,%r12,2), %r15d
	shll	$4, %r15d
	addq	%rbx, %r15
	leal	1(%r11), %r12d
	movzbl	%r12b, %r12d
	xorl	%r13d, %r13d
	btl	%r12d, %r9d
	setb	%r13b
	movzwl	(%r15,%r13,2), %r15d
	shll	$4, %r15d
	addq	%rbx, %r15
	leal	2(%r11), %r12d
	movzbl	%r12b, %r12d
	xorl	%r13d, %r13d
	btl	%r12d, %r9d
	setb	%r13b
	movzwl	(%r15,%r13,2), %r15d
	shll	$4, %r15d
	addq	%rbx, %r15
	leal	3(%r11), %r12d
	movzbl	%r12b, %r12d
	xorl	%r13d, %r13d
	btl	%r12d, %r9d
	setb	%r13b
	movzwl	(%r15,%r13,2), %r15d
	addl	$4, %r11d
	cmpl	%r14d, %r11d
	jne	LBB7_40
## %bb.41:                              ##   in Loop: Header=BB7_37 Depth=2
	testl	%r10d, %r10d
	je	LBB7_43
	.p2align	4
LBB7_42:                                ##   Parent Loop BB7_27 Depth=1
                                        ##     Parent Loop BB7_37 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	shlq	$4, %r15
	addq	%rbx, %r15
	xorl	%r14d, %r14d
	btl	%r11d, %r9d
	setb	%r14b
	movzwl	(%r15,%r14,2), %r15d
	incl	%r11d
	decl	%r10d
	jne	LBB7_42
LBB7_43:                                ##   in Loop: Header=BB7_37 Depth=2
	shlq	$4, %r15
	movzwl	4(%rbx,%r15), %r10d
	cmpl	$256, %r10d                     ## imm = 0x100
	jae	LBB7_44
## %bb.46:                              ##   in Loop: Header=BB7_37 Depth=2
	movb	%r10b, (%rcx,%r9)
	incl	%r9d
	cmpq	%r9, %r8
	ja	LBB7_37
## %bb.47:                              ##   in Loop: Header=BB7_27 Depth=1
	addq	%r8, %rsi
	movq	8944(%rbx), %r14
	jmp	LBB7_48
LBB7_31:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB7_49
## %bb.32:
	addq	$520, %rsp                      ## imm = 0x208
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB7_5:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp90:                                 ## EH_LABEL
	leaq	L_.str.29(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp91:                                 ## EH_LABEL
	jmp	LBB7_6
LBB7_44:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp96:                                 ## EH_LABEL
	leaq	L_.str.32(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp97:                                 ## EH_LABEL
LBB7_6:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB7_12:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp93:                                 ## EH_LABEL
	leaq	L_.str.30(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp94:                                 ## EH_LABEL
	jmp	LBB7_6
LBB7_34:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp99:                                 ## EH_LABEL
	leaq	L_.str.31(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp100:                                ## EH_LABEL
	jmp	LBB7_6
LBB7_49:
	callq	___stack_chk_fail
LBB7_35:
Ltmp101:                                ## EH_LABEL
	jmp	LBB7_14
LBB7_19:
Ltmp95:                                 ## EH_LABEL
	jmp	LBB7_14
LBB7_45:
Ltmp98:                                 ## EH_LABEL
	jmp	LBB7_14
LBB7_13:
Ltmp92:                                 ## EH_LABEL
LBB7_14:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end7:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table7:
Lexception7:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end7-Lcst_begin7
Lcst_begin7:
	.uleb128 Lfunc_begin7-Lfunc_begin7      ## >> Call Site 1 <<
	.uleb128 Ltmp90-Lfunc_begin7            ##   Call between Lfunc_begin7 and Ltmp90
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp90-Lfunc_begin7            ## >> Call Site 2 <<
	.uleb128 Ltmp91-Ltmp90                  ##   Call between Ltmp90 and Ltmp91
	.uleb128 Ltmp92-Lfunc_begin7            ##     jumps to Ltmp92
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp91-Lfunc_begin7            ## >> Call Site 3 <<
	.uleb128 Ltmp96-Ltmp91                  ##   Call between Ltmp91 and Ltmp96
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp96-Lfunc_begin7            ## >> Call Site 4 <<
	.uleb128 Ltmp97-Ltmp96                  ##   Call between Ltmp96 and Ltmp97
	.uleb128 Ltmp98-Lfunc_begin7            ##     jumps to Ltmp98
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp97-Lfunc_begin7            ## >> Call Site 5 <<
	.uleb128 Ltmp93-Ltmp97                  ##   Call between Ltmp97 and Ltmp93
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp93-Lfunc_begin7            ## >> Call Site 6 <<
	.uleb128 Ltmp94-Ltmp93                  ##   Call between Ltmp93 and Ltmp94
	.uleb128 Ltmp95-Lfunc_begin7            ##     jumps to Ltmp95
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp94-Lfunc_begin7            ## >> Call Site 7 <<
	.uleb128 Ltmp99-Ltmp94                  ##   Call between Ltmp94 and Ltmp99
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp99-Lfunc_begin7            ## >> Call Site 8 <<
	.uleb128 Ltmp100-Ltmp99                 ##   Call between Ltmp99 and Ltmp100
	.uleb128 Ltmp101-Lfunc_begin7           ##     jumps to Ltmp101
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp100-Lfunc_begin7           ## >> Call Site 9 <<
	.uleb128 Lfunc_end7-Ltmp100             ##   Call between Ltmp100 and Lfunc_end7
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end7:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
__ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_: ## @_ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
Lfunc_begin8:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception8
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %rbx
	movq	%rsi, %r13
	shlq	$4, %r13
	cmpw	$256, 4(%rdi,%r13)              ## imm = 0x100
	setne	%al
	testq	%rcx, %rcx
	sete	%cl
	orb	%al, %cl
	je	LBB8_2
## %bb.1:
	xorl	%r11d, %r11d
	jmp	LBB8_18
LBB8_2:
	movq	%r8, %r10
	movq	%rdx, %r12
	leaq	32(%rbp), %rax
	leaq	16(%rbp), %rcx
	addq	%rdi, %r13
	movq	(%rcx), %rdx
	movq	8(%rcx), %r8
	movq	(%rax), %rcx
	movq	8(%rax), %rsi
	movq	$0, -88(%rbp)                   ## 8-byte Folded Spill
	xorl	%r11d, %r11d
	movq	%rdi, -80(%rbp)                 ## 8-byte Spill
	.p2align	4
LBB8_3:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB8_10 Depth 2
                                        ##     Child Loop BB8_20 Depth 2
	movq	%rcx, -56(%rbp)                 ## 8-byte Spill
	movq	%rsi, -64(%rbp)                 ## 8-byte Spill
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movl	12(%r13), %r15d
	cmpl	$1, %r15d
	adcl	$0, %r15d
	movq	%rbx, %r14
	imulq	%r15, %r14
	addq	$7, %r14
	shrq	$3, %r14
	movq	%r9, %rcx
	subq	%r14, %rcx
	movq	%rcx, -120(%rbp)                ## 8-byte Spill
	jb	LBB8_4
## %bb.7:                               ##   in Loop: Header=BB8_3 Depth=1
	movq	%r11, -96(%rbp)                 ## 8-byte Spill
	movq	%r9, -112(%rbp)                 ## 8-byte Spill
	testq	%r14, %r14
	movq	%rdx, -104(%rbp)                ## 8-byte Spill
	je	LBB8_9
## %bb.8:                               ##   in Loop: Header=BB8_3 Depth=1
	movq	%r10, %rdi
	movq	%r14, %rsi
	movq	%r10, -48(%rbp)                 ## 8-byte Spill
	callq	___bzero
	movq	-104(%rbp), %rdx                ## 8-byte Reload
	movq	-48(%rbp), %r10                 ## 8-byte Reload
LBB8_9:                                 ##   in Loop: Header=BB8_3 Depth=1
	movq	%r14, -48(%rbp)                 ## 8-byte Spill
	movl	$-1, %eax
	movl	%r15d, %ecx
	shll	%cl, %eax
	notl	%eax
	xorl	%r11d, %r11d
	xorl	%r14d, %r14d
	xorl	%esi, %esi
	jmp	LBB8_10
	.p2align	4
LBB8_12:                                ##   in Loop: Header=BB8_10 Depth=2
	movl	%edi, %ecx
	addq	%rcx, %r14
	incq	%rsi
	addq	%r15, %r11
	cmpq	%rsi, %rbx
	je	LBB8_13
LBB8_10:                                ##   Parent Loop BB8_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r12,%rsi), %ecx
	movq	-80(%rbp), %rdi                 ## 8-byte Reload
	movzwl	8432(%rdi,%rcx,2), %edi
	movzbl	8(%r13), %ecx
	shrl	%cl, %edi
	andl	%eax, %edi
	movl	%r11d, %ecx
	andl	$7, %ecx
	movl	%edi, %r8d
	shll	%cl, %r8d
	movq	%r11, %r9
	shrq	$3, %r9
	orb	%r8b, (%r10,%r9)
	addq	%r15, %rcx
	cmpq	$9, %rcx
	jb	LBB8_12
## %bb.11:                              ##   in Loop: Header=BB8_10 Depth=2
	shrl	$8, %r8d
	orb	%r8b, 1(%r10,%r9)
	jmp	LBB8_12
	.p2align	4
LBB8_13:                                ##   in Loop: Header=BB8_3 Depth=1
	cmpl	$0, 12(%r13)
	jne	LBB8_14
## %bb.19:                              ##   in Loop: Header=BB8_3 Depth=1
	movq	%rbx, %r15
	subq	%r14, %r15
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	%r15, %r9
	movq	-80(%rbp), %rdi                 ## 8-byte Reload
	jmp	LBB8_20
	.p2align	4
LBB8_22:                                ##   in Loop: Header=BB8_20 Depth=2
	movb	%sil, (%rdx,%r9)
	incq	%r9
	incq	%rax
	cmpq	%rax, %rbx
	je	LBB8_15
LBB8_20:                                ##   Parent Loop BB8_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r12,%rax), %esi
	movzwl	8432(%rdi,%rsi,2), %r11d
	movl	8(%r13), %r8d
	btl	%r8d, %r11d
	jb	LBB8_22
## %bb.21:                              ##   in Loop: Header=BB8_20 Depth=2
	movb	%sil, (%rdx,%rcx)
	incq	%rcx
	incq	%rax
	cmpq	%rax, %rbx
	jne	LBB8_20
LBB8_15:                                ##   in Loop: Header=BB8_3 Depth=1
	movzwl	(%r13), %esi
	movq	-48(%rbp), %r12                 ## 8-byte Reload
	leaq	(%r10,%r12), %r8
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	movq	%rax, -152(%rbp)
	movq	%r15, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	%r15, -128(%rbp)
	movups	-136(%rbp), %xmm0
	movups	%xmm0, 16(%rsp)
	movups	-152(%rbp), %xmm0
	movups	%xmm0, (%rsp)
	movq	%r15, %rcx
	movq	-120(%rbp), %r9                 ## 8-byte Reload
	movq	%r10, %rbx
	callq	__ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
	movq	-80(%rbp), %rdi                 ## 8-byte Reload
	addq	%r12, %rax
	movzwl	2(%r13), %r13d
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	subq	%r15, %rdx
	movq	-104(%rbp), %r12                ## 8-byte Reload
	addq	%r15, %r12
	movq	-64(%rbp), %rcx                 ## 8-byte Reload
	subq	%r15, %rcx
	cmpq	$-1, %r14
	movq	%rdx, %rsi
	cmovneq	%r14, %rsi
	movq	%rcx, %r8
	cmovneq	%r14, %r8
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	addq	%r15, %rdx
	movq	-96(%rbp), %r11                 ## 8-byte Reload
	addq	%rax, %r11
	shll	$4, %r13d
	cmpw	$256, 4(%rdi,%r13)              ## imm = 0x100
	jne	LBB8_17
## %bb.16:                              ##   in Loop: Header=BB8_3 Depth=1
	movq	-112(%rbp), %r9                 ## 8-byte Reload
	subq	%rax, %r9
	movq	%rbx, %r10
	addq	%rax, %r10
	addq	%rdi, %r13
	movq	%r12, %rcx
	movq	%rsi, %rbx
	testq	%rsi, %rsi
	jne	LBB8_3
	jmp	LBB8_17
LBB8_14:
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	%rax, -88(%rbp)                 ## 8-byte Spill
	movq	-72(%rbp), %r8                  ## 8-byte Reload
	movq	-64(%rbp), %rsi                 ## 8-byte Reload
	movq	-96(%rbp), %r11                 ## 8-byte Reload
LBB8_17:
	addq	-88(%rbp), %r11                 ## 8-byte Folded Reload
	leaq	16(%rbp), %rcx
	movq	%rdx, (%rcx)
	leaq	32(%rbp), %rax
	movq	%r12, (%rax)
	movq	%r8, 8(%rcx)
	movq	%rsi, 8(%rax)
LBB8_18:
	movq	%r11, %rax
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB8_4:
	leaq	16(%rbp), %rcx
	movq	%rdx, (%rcx)
	leaq	32(%rbp), %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movq	%rdx, (%rax)
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	movq	%rdx, 8(%rcx)
	movq	-64(%rbp), %rcx                 ## 8-byte Reload
	movq	%rcx, 8(%rax)
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp102:                                ## EH_LABEL
	leaq	L_.str.33(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp103:                                ## EH_LABEL
## %bb.5:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB8_6:
Ltmp104:                                ## EH_LABEL
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end8:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table8:
Lexception8:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end8-Lcst_begin8
Lcst_begin8:
	.uleb128 Lfunc_begin8-Lfunc_begin8      ## >> Call Site 1 <<
	.uleb128 Ltmp102-Lfunc_begin8           ##   Call between Lfunc_begin8 and Ltmp102
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp102-Lfunc_begin8           ## >> Call Site 2 <<
	.uleb128 Ltmp103-Ltmp102                ##   Call between Ltmp102 and Ltmp103
	.uleb128 Ltmp104-Lfunc_begin8           ##     jumps to Ltmp104
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp103-Lfunc_begin8           ## >> Call Site 3 <<
	.uleb128 Lfunc_end8-Ltmp103             ##   Call between Ltmp103 and Lfunc_end8
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end8:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_ ## -- Begin function _ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_
	.p2align	4
__ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_: ## @_ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_
Lfunc_begin9:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception9
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$9272, %rsp                     ## imm = 0x2438
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	cmpq	$5, %rsi
	jb	LBB9_2
## %bb.1:
	movq	%rdi, %r13
	cmpb	$-79, (%rdi)
	jne	LBB9_2
## %bb.6:
	movq	%rcx, %rbx
	cmpq	$2097160, %rcx                  ## imm = 0x200008
	ja	LBB9_8
## %bb.7:
	movl	1(%r13), %eax
	cmpq	%rax, %rbx
	jne	LBB9_8
## %bb.10:
	movq	%r8, -9264(%rbp)                ## 8-byte Spill
	movq	%rdx, -9272(%rbp)               ## 8-byte Spill
	cmpq	%rbx, %r9
	jb	LBB9_11
## %bb.13:
	movq	%rsi, %r15
	xorps	%xmm0, %xmm0
	movaps	%xmm0, -64(%rbp)
	movaps	%xmm0, -80(%rbp)
	movaps	%xmm0, -96(%rbp)
	movaps	%xmm0, -112(%rbp)
	movaps	%xmm0, -128(%rbp)
	movaps	%xmm0, -144(%rbp)
	movaps	%xmm0, -160(%rbp)
	movaps	%xmm0, -176(%rbp)
	movaps	%xmm0, -192(%rbp)
	movaps	%xmm0, -208(%rbp)
	movaps	%xmm0, -224(%rbp)
	movaps	%xmm0, -240(%rbp)
	movaps	%xmm0, -256(%rbp)
	movaps	%xmm0, -272(%rbp)
	movaps	%xmm0, -288(%rbp)
	movaps	%xmm0, -304(%rbp)
	leaq	-5(%rsi), %r14
	leaq	5(%r13), %rdi
	leaq	-304(%rbp), %rdx
	movq	%r14, %rsi
	callq	__ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
	movq	%rax, %r12
	leaq	-9256(%rbp), %rdi
	movl	$8176, %esi                     ## imm = 0x1FF0
	callq	___bzero
	movl	$60, %eax
	movabsq	$1099545117183, %rcx            ## imm = 0x10001FF01FF
	.p2align	4
LBB9_14:                                ## =>This Inner Loop Header: Depth=1
	movq	%rcx, -9316(%rbp,%rax)
	movq	$0, -9308(%rbp,%rax)
	movq	%rcx, -9300(%rbp,%rax)
	movq	$0, -9292(%rbp,%rax)
	movq	%rcx, -9284(%rbp,%rax)
	movq	$0, -9276(%rbp,%rax)
	cmpq	$8188, %rax                     ## imm = 0x1FFC
	je	LBB9_16
## %bb.15:                              ##   in Loop: Header=BB9_14 Depth=1
	movq	%rcx, -9268(%rbp,%rax)
	movq	$0, -9260(%rbp,%rax)
	addq	$64, %rax
	jmp	LBB9_14
LBB9_16:
	leaq	-1080(%rbp), %rdi
	movl	$768, %esi                      ## imm = 0x300
	callq	___bzero
	movq	$1, -312(%rbp)
	leaq	-304(%rbp), %rdi
	leaq	-9256(%rbp), %rsi
	callq	__ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
	leaq	5(%r12), %rax
	subq	%rax, %r15
	leaq	(%r12,%r13), %rdx
	addq	$5, %rdx
	movq	-9264(%rbp), %rax               ## 8-byte Reload
	movq	%rax, -9288(%rbp)
	movq	%rbx, -9280(%rbp)
	movups	-9288(%rbp), %xmm0
	movups	%xmm0, (%rsp)
	leaq	-9256(%rbp), %rdi
	xorl	%esi, %esi
	movq	%r15, %rcx
	movq	-9272(%rbp), %r8                ## 8-byte Reload
	movq	%rbx, %r9
	callq	__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
	subq	%r12, %r14
	cmpq	%r14, %rax
	jne	LBB9_17
## %bb.19:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB9_21
## %bb.20:
	addq	$9272, %rsp                     ## imm = 0x2438
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB9_2:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %r14
Ltmp105:                                ## EH_LABEL
	leaq	L_.str.11(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp106:                                ## EH_LABEL
	jmp	LBB9_3
LBB9_8:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %r14
Ltmp108:                                ## EH_LABEL
	leaq	L_.str.12(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp109:                                ## EH_LABEL
	jmp	LBB9_3
LBB9_11:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %r14
Ltmp114:                                ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp115:                                ## EH_LABEL
	jmp	LBB9_3
LBB9_17:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %r14
Ltmp111:                                ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp112:                                ## EH_LABEL
LBB9_3:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%r14, %rdi
	callq	___cxa_throw
LBB9_21:
	callq	___stack_chk_fail
LBB9_18:
Ltmp113:                                ## EH_LABEL
	jmp	LBB9_5
LBB9_12:
Ltmp116:                                ## EH_LABEL
	jmp	LBB9_5
LBB9_9:
Ltmp110:                                ## EH_LABEL
	jmp	LBB9_5
LBB9_4:
Ltmp107:                                ## EH_LABEL
LBB9_5:
	movq	%rax, %rbx
	movq	%r14, %rdi
	callq	___cxa_free_exception
	movq	%rbx, %rdi
	callq	__Unwind_Resume
Lfunc_end9:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table9:
Lexception9:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end9-Lcst_begin9
Lcst_begin9:
	.uleb128 Lfunc_begin9-Lfunc_begin9      ## >> Call Site 1 <<
	.uleb128 Ltmp105-Lfunc_begin9           ##   Call between Lfunc_begin9 and Ltmp105
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp105-Lfunc_begin9           ## >> Call Site 2 <<
	.uleb128 Ltmp106-Ltmp105                ##   Call between Ltmp105 and Ltmp106
	.uleb128 Ltmp107-Lfunc_begin9           ##     jumps to Ltmp107
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp106-Lfunc_begin9           ## >> Call Site 3 <<
	.uleb128 Ltmp108-Ltmp106                ##   Call between Ltmp106 and Ltmp108
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp108-Lfunc_begin9           ## >> Call Site 4 <<
	.uleb128 Ltmp109-Ltmp108                ##   Call between Ltmp108 and Ltmp109
	.uleb128 Ltmp110-Lfunc_begin9           ##     jumps to Ltmp110
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp109-Lfunc_begin9           ## >> Call Site 5 <<
	.uleb128 Ltmp114-Ltmp109                ##   Call between Ltmp109 and Ltmp114
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp114-Lfunc_begin9           ## >> Call Site 6 <<
	.uleb128 Ltmp115-Ltmp114                ##   Call between Ltmp114 and Ltmp115
	.uleb128 Ltmp116-Lfunc_begin9           ##     jumps to Ltmp116
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp115-Lfunc_begin9           ## >> Call Site 7 <<
	.uleb128 Ltmp111-Ltmp115                ##   Call between Ltmp115 and Ltmp111
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp111-Lfunc_begin9           ## >> Call Site 8 <<
	.uleb128 Ltmp112-Ltmp111                ##   Call between Ltmp111 and Ltmp112
	.uleb128 Ltmp113-Lfunc_begin9           ##     jumps to Ltmp113
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp112-Lfunc_begin9           ## >> Call Site 9 <<
	.uleb128 Lfunc_end9-Ltmp112             ##   Call between Ltmp112 and Lfunc_end9
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end9:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
LCPI10_0:
	.space	16,85
LCPI10_1:
	.space	16,51
LCPI10_2:
	.space	16,15
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4
__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_: ## @_ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
Lfunc_begin10:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception10
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -48(%rbp)                  ## 8-byte Spill
	testq	%r9, %r9
	je	LBB10_18
## %bb.1:
	shlq	$4, %rsi
	addq	%rdi, %rsi
	cmpw	$256, 4(%rsi)                   ## imm = 0x100
	jne	LBB10_145
## %bb.2:
	movq	%rcx, %r14
	movl	12(%rsi), %r11d
	cmpl	$1, %r11d
	movl	%r11d, %ecx
	adcl	$0, %ecx
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	imulq	%rcx, %rax
	addq	$7, %rax
	movq	%rax, %r12
	shrq	$3, %r12
	movq	%r14, %r10
	subq	%r12, %r10
	jb	LBB10_146
## %bb.3:
	imull	-48(%rbp), %ecx                 ## 4-byte Folded Reload
	andl	$7, %ecx
	je	LBB10_5
## %bb.4:
	movzbl	-1(%rdx,%r12), %ebx
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %ebx
	testl	%ebx, %ebx
	jne	LBB10_147
LBB10_5:
	testl	%r11d, %r11d
	je	LBB10_20
## %bb.6:
	decl	%r11d
	cmpl	$7, %r11d
	ja	LBB10_149
## %bb.7:
	movzwl	6(%rsi), %eax
	addq	%rdi, %rax
	addq	$8176, %rax                     ## imm = 0x1FF0
	leaq	LJTI10_0(%rip), %rcx
	movslq	(%rcx,%r11,4), %rsi
	addq	%rcx, %rsi
	jmpq	*%rsi
LBB10_8:
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_129
## %bb.9:
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	leaq	-8(%rcx), %rsi
	shrq	$3, %rsi
	incq	%rsi
	xorl	%ecx, %ecx
	xorl	%edi, %edi
	.p2align	4
LBB10_10:                               ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdx,%rdi), %r10d
	movl	%r10d, %r11d
	andl	$1, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, (%r8,%rcx)
	btl	$1, %r10d
	movq	%rax, %r11
	adcq	$0, %r11
	movzbl	(%r11), %r11d
	movb	%r11b, 1(%r8,%rcx)
	btl	$2, %r10d
	movq	%rax, %r11
	adcq	$0, %r11
	movzbl	(%r11), %r11d
	movb	%r11b, 2(%r8,%rcx)
	btl	$3, %r10d
	movq	%rax, %r11
	adcq	$0, %r11
	movzbl	(%r11), %r11d
	movb	%r11b, 3(%r8,%rcx)
	btl	$4, %r10d
	movq	%rax, %r11
	adcq	$0, %r11
	movzbl	(%r11), %r11d
	movb	%r11b, 4(%r8,%rcx)
	btl	$5, %r10d
	movq	%rax, %r11
	adcq	$0, %r11
	movzbl	(%r11), %r11d
	movb	%r11b, 5(%r8,%rcx)
	btl	$6, %r10d
	movq	%rax, %r11
	adcq	$0, %r11
	movzbl	(%r11), %r11d
	movb	%r11b, 6(%r8,%rcx)
	shrl	$7, %r10d
	movzbl	(%rax,%r10), %r10d
	movb	%r10b, 7(%r8,%rcx)
	addq	$8, %rcx
	incq	%rdi
	cmpq	%rdi, %rsi
	jne	LBB10_10
## %bb.11:
	cmpq	%rcx, -48(%rbp)                 ## 8-byte Folded Reload
	jbe	LBB10_130
	jmp	LBB10_12
LBB10_18:
	xorl	%eax, %eax
	jmp	LBB10_19
LBB10_20:
	leaq	(%rdx,%r12), %rcx
	testq	%r12, %r12
	movq	%r14, -88(%rbp)                 ## 8-byte Spill
	je	LBB10_23
## %bb.21:
	cmpq	$32, %rax
	jae	LBB10_24
## %bb.22:
	xorl	%r13d, %r13d
	movq	%rdx, %rax
	jmp	LBB10_27
LBB10_23:
	xorl	%r13d, %r13d
	jmp	LBB10_28
LBB10_24:
	movabsq	$2305843009213693951, %r11      ## imm = 0x1FFFFFFFFFFFFFFF
	addq	$-3, %r11
	andq	%r12, %r11
	leaq	(%rdx,%r11), %rax
	pxor	%xmm0, %xmm0
	xorl	%ebx, %ebx
	movdqa	LCPI10_0(%rip), %xmm2           ## xmm2 = [85,85,85,85,85,85,85,85,85,85,85,85,85,85,85,85]
	movdqa	LCPI10_1(%rip), %xmm3           ## xmm3 = [51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51]
	movdqa	LCPI10_2(%rip), %xmm5           ## xmm5 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	pxor	%xmm4, %xmm4
	pxor	%xmm1, %xmm1
	.p2align	4
LBB10_25:                               ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rbx), %r9d
	movd	%r9d, %xmm7
	movzwl	2(%rdx,%rbx), %r9d
	movd	%r9d, %xmm6
	punpcklbw	%xmm0, %xmm7            ## xmm7 = xmm7[0],xmm0[0],xmm7[1],xmm0[1],xmm7[2],xmm0[2],xmm7[3],xmm0[3],xmm7[4],xmm0[4],xmm7[5],xmm0[5],xmm7[6],xmm0[6],xmm7[7],xmm0[7]
	punpcklwd	%xmm0, %xmm7            ## xmm7 = xmm7[0],xmm0[0],xmm7[1],xmm0[1],xmm7[2],xmm0[2],xmm7[3],xmm0[3]
	punpckldq	%xmm0, %xmm7            ## xmm7 = xmm7[0],xmm0[0],xmm7[1],xmm0[1]
	movdqa	%xmm7, %xmm8
	psrlw	$1, %xmm8
	pand	%xmm2, %xmm8
	psubb	%xmm8, %xmm7
	movdqa	%xmm7, %xmm8
	pand	%xmm3, %xmm8
	psrlw	$2, %xmm7
	pand	%xmm3, %xmm7
	paddb	%xmm8, %xmm7
	movdqa	%xmm7, %xmm8
	psrlw	$4, %xmm8
	paddb	%xmm7, %xmm8
	pand	%xmm5, %xmm8
	psadbw	%xmm0, %xmm8
	paddq	%xmm8, %xmm4
	punpcklbw	%xmm0, %xmm6            ## xmm6 = xmm6[0],xmm0[0],xmm6[1],xmm0[1],xmm6[2],xmm0[2],xmm6[3],xmm0[3],xmm6[4],xmm0[4],xmm6[5],xmm0[5],xmm6[6],xmm0[6],xmm6[7],xmm0[7]
	punpcklwd	%xmm0, %xmm6            ## xmm6 = xmm6[0],xmm0[0],xmm6[1],xmm0[1],xmm6[2],xmm0[2],xmm6[3],xmm0[3]
	punpckldq	%xmm0, %xmm6            ## xmm6 = xmm6[0],xmm0[0],xmm6[1],xmm0[1]
	movdqa	%xmm6, %xmm7
	psrlw	$1, %xmm7
	pand	%xmm2, %xmm7
	psubb	%xmm7, %xmm6
	movdqa	%xmm6, %xmm7
	pand	%xmm3, %xmm7
	psrlw	$2, %xmm6
	pand	%xmm3, %xmm6
	paddb	%xmm7, %xmm6
	movdqa	%xmm6, %xmm7
	psrlw	$4, %xmm7
	paddb	%xmm6, %xmm7
	pand	%xmm5, %xmm7
	psadbw	%xmm0, %xmm7
	paddq	%xmm7, %xmm1
	addq	$4, %rbx
	cmpq	%rbx, %r11
	jne	LBB10_25
## %bb.26:
	paddq	%xmm4, %xmm1
	pshufd	$238, %xmm1, %xmm0              ## xmm0 = xmm1[2,3,2,3]
	paddq	%xmm1, %xmm0
	movq	%xmm0, %r13
	cmpq	%r11, %r12
	je	LBB10_28
	.p2align	4
LBB10_27:                               ## =>This Inner Loop Header: Depth=1
	movzbl	(%rax), %r9d
	imull	$134480385, %r9d, %r9d          ## imm = 0x8040201
	shrl	$3, %r9d
	andl	$286331153, %r9d                ## imm = 0x11111111
	imull	$286331153, %r9d, %r9d          ## imm = 0x11111111
	shrl	$28, %r9d
	addq	%r9, %r13
	incq	%rax
	cmpq	%rcx, %rax
	jne	LBB10_27
LBB10_28:
	leaq	16(%rbp), %r9
	movq	-48(%rbp), %r15                 ## 8-byte Reload
	subq	%r13, %r15
	movzwl	(%rsi), %r11d
	movl	%r11d, %r14d
	shll	$4, %r14d
	movzwl	2(%rsi), %ebx
	shll	$4, %ebx
	addq	%rdi, %rbx
	cmpw	$256, 4(%rdi,%r14)              ## imm = 0x100
	movq	%r12, %rax
	movq	%rdx, -72(%rbp)                 ## 8-byte Spill
	movq	%r8, -64(%rbp)                  ## 8-byte Spill
	jne	LBB10_29
## %bb.33:
	movq	(%r9), %rax
	movq	%r8, -136(%rbp)
	movq	%r15, -128(%rbp)
	movdqu	-136(%rbp), %xmm0
	movdqu	%xmm0, (%rsp)
	movq	%r12, -56(%rbp)                 ## 8-byte Spill
	movq	%rdi, %r12
	movq	%rsi, -80(%rbp)                 ## 8-byte Spill
	movq	%r11, %rsi
	movq	%rcx, %rdx
	movq	%r10, %rcx
	movq	%rax, %r8
	movq	%r15, %r9
	callq	__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
	leaq	16(%rbp), %r9
	movq	-80(%rbp), %rsi                 ## 8-byte Reload
	movq	%r12, %rdi
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	movq	-64(%rbp), %r8                  ## 8-byte Reload
	addq	%r12, %rax
	addq	%rdi, %r14
	cmpw	$256, 4(%rbx)                   ## imm = 0x100
	je	LBB10_34
LBB10_30:
	movzwl	4(%r14), %ecx
	cmpl	$256, %ecx                      ## imm = 0x100
	jne	LBB10_35
LBB10_31:
	movzwl	4(%rbx), %esi
	leaq	16(%rbp), %rdi
	movq	(%rdi), %rcx
	cmpl	$256, %esi                      ## imm = 0x100
	jne	LBB10_37
## %bb.32:
	movq	8(%rdi), %r10
	subq	%r15, %r10
	cmpq	$-1, %r13
	cmovneq	%r13, %r10
	leaq	(%rcx,%r15), %r11
	movq	%r8, -104(%rbp)
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	movq	%rsi, -96(%rbp)
	movdqu	-104(%rbp), %xmm0
	movdqu	%xmm0, (%rsp)
	movq	%rdx, %rdi
	movq	%r12, %rsi
	movq	%rcx, %rdx
	movq	%r15, %rcx
	movq	%r11, %r8
	movq	%r10, %r9
	movq	%rax, %rbx
	callq	__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	movq	%rbx, %rax
	jmp	LBB10_19
LBB10_29:
	addq	%rdi, %r14
	cmpw	$256, 4(%rbx)                   ## imm = 0x100
	jne	LBB10_30
LBB10_34:
	movzwl	2(%rsi), %esi
	movq	-88(%rbp), %rcx                 ## 8-byte Reload
	subq	%rax, %rcx
	leaq	(%rdx,%rax), %r10
	movq	%r10, -56(%rbp)                 ## 8-byte Spill
	movq	8(%r9), %r10
	subq	%r15, %r10
	cmpq	$-1, %r13
	cmovneq	%r13, %r10
	movq	(%r9), %r11
	addq	%r15, %r11
	leaq	(%r8,%r15), %r9
	movq	%r9, -120(%rbp)
	movq	%r13, -112(%rbp)
	movdqu	-120(%rbp), %xmm0
	movdqu	%xmm0, (%rsp)
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movq	%r11, %r8
	movq	%r10, %r9
	movq	%rax, -56(%rbp)                 ## 8-byte Spill
	callq	__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	movq	-64(%rbp), %r8                  ## 8-byte Reload
	movq	%rax, %rcx
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	addq	%rcx, %rax
	movzwl	4(%r14), %ecx
	cmpl	$256, %ecx                      ## imm = 0x100
	je	LBB10_31
LBB10_35:
	leaq	16(%rbp), %rsi
	addq	(%rsi), %r15
	cmpq	$1, -48(%rbp)                   ## 8-byte Folded Reload
	jne	LBB10_39
## %bb.36:
	xorl	%esi, %esi
	xorl	%edi, %edi
	jmp	LBB10_47
LBB10_37:
	cmpq	$1, -48(%rbp)                   ## 8-byte Folded Reload
	jne	LBB10_108
## %bb.38:
	xorl	%edi, %edi
	xorl	%r10d, %r10d
	jmp	LBB10_116
LBB10_39:
	movq	-48(%rbp), %r10                 ## 8-byte Reload
	andq	$-2, %r10
	xorl	%esi, %esi
	xorl	%edi, %edi
	jmp	LBB10_41
	.p2align	4
LBB10_45:                               ##   in Loop: Header=BB10_41 Depth=1
	movl	%ecx, %r11d
	movb	%r11b, 1(%r8,%rdi)
	addq	$2, %rdi
	cmpq	%rdi, %r10
	je	LBB10_46
LBB10_41:                               ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %r11
	shrq	$3, %r11
	movzbl	(%rdx,%r11), %r9d
	movl	%edi, %ebx
	andl	$6, %ebx
	btl	%ebx, %r9d
	jae	LBB10_43
## %bb.42:                              ##   in Loop: Header=BB10_41 Depth=1
	movzbl	(%r15,%rsi), %ebx
	incq	%rsi
	jmp	LBB10_44
	.p2align	4
LBB10_43:                               ##   in Loop: Header=BB10_41 Depth=1
	movl	%ecx, %ebx
LBB10_44:                               ##   in Loop: Header=BB10_41 Depth=1
	movb	%bl, (%r8,%rdi)
	movzbl	(%rdx,%r11), %r9d
	leal	1(%rdi), %r11d
	movzbl	%r11b, %r11d
	andl	$7, %r11d
	btl	%r11d, %r9d
	jae	LBB10_45
## %bb.40:                              ##   in Loop: Header=BB10_41 Depth=1
	movzbl	(%r15,%rsi), %r11d
	incq	%rsi
	movb	%r11b, 1(%r8,%rdi)
	addq	$2, %rdi
	cmpq	%rdi, %r10
	jne	LBB10_41
LBB10_46:
	testb	$1, -48(%rbp)                   ## 1-byte Folded Reload
	je	LBB10_19
LBB10_47:
	movq	%rdi, %r9
	shrq	$3, %r9
	movzbl	(%rdx,%r9), %edx
	movl	%edi, %r9d
	andl	$7, %r9d
	btl	%r9d, %edx
	jae	LBB10_49
## %bb.48:
	movzbl	(%r15,%rsi), %ecx
LBB10_49:
	movb	%cl, (%r8,%rdi)
	jmp	LBB10_19
LBB10_50:
	movq	%r12, -56(%rbp)                 ## 8-byte Spill
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_119
## %bb.51:
	leaq	4(%rdx), %rcx
	xorl	%esi, %esi
	movq	-48(%rbp), %r9                  ## 8-byte Reload
	.p2align	4
LBB10_52:                               ## =>This Inner Loop Header: Depth=1
	movzbl	-4(%rcx), %r13d
	movzbl	-3(%rcx), %r15d
	movl	%r15d, %r12d
	shll	$8, %r12d
	movzbl	-2(%rcx), %edi
	shll	$16, %edi
	movzbl	-1(%rcx), %ebx
	movl	%ebx, %r14d
	shll	$24, %r14d
	movzbl	(%rcx), %r10d
	movq	%r10, %r11
	shlq	$32, %r11
	orq	%r14, %r11
	orl	%edi, %r14d
	addl	%r12d, %edi
	orl	%r13d, %r12d
	andl	$31, %r13d
	movzbl	(%rax,%r13), %r13d
	movb	%r13b, (%r8,%rsi)
	shrl	$5, %r12d
	andl	$31, %r12d
	movzbl	(%rax,%r12), %r12d
	movb	%r12b, 1(%r8,%rsi)
	shrl	$2, %r15d
	andl	$31, %r15d
	movzbl	(%rax,%r15), %r15d
	movb	%r15b, 2(%r8,%rsi)
	shrl	$15, %edi
	andl	$31, %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, 3(%r8,%rsi)
	shrl	$20, %r14d
	andl	$31, %r14d
	movzbl	(%rax,%r14), %edi
	movb	%dil, 4(%r8,%rsi)
	shrl	%ebx
	andl	$31, %ebx
	movzbl	(%rax,%rbx), %edi
	movb	%dil, 5(%r8,%rsi)
	shrq	$30, %r11
	andl	$31, %r11d
	movzbl	(%rax,%r11), %edi
	movb	%dil, 6(%r8,%rsi)
	shrl	$3, %r10d
	movzbl	(%rax,%r10), %edi
	movb	%dil, 7(%r8,%rsi)
	addq	$8, %rsi
	addq	$-8, %r9
	addq	$5, %rcx
	cmpq	$7, %r9
	ja	LBB10_52
## %bb.53:
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_120
	jmp	LBB10_54
LBB10_58:
	movq	%r12, %r9
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_122
## %bb.59:
	leaq	2(%rdx), %rcx
	xorl	%esi, %esi
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	.p2align	4
LBB10_60:                               ## =>This Inner Loop Header: Depth=1
	movzbl	-2(%rcx), %r14d
	movzbl	-1(%rcx), %ebx
	movl	%ebx, %r15d
	shll	$8, %r15d
	movzbl	(%rcx), %r10d
	movl	%r10d, %r11d
	shll	$16, %r11d
	orl	%r15d, %r11d
	orl	%r14d, %r15d
	movl	%r14d, %r12d
	andl	$7, %r12d
	movzbl	(%rax,%r12), %r12d
	movb	%r12b, (%r8,%rsi)
	shrl	$3, %r14d
	andl	$7, %r14d
	movzbl	(%rax,%r14), %r14d
	movb	%r14b, 1(%r8,%rsi)
	shrl	$6, %r15d
	andl	$7, %r15d
	movzbl	(%rax,%r15), %r14d
	movb	%r14b, 2(%r8,%rsi)
	movl	%ebx, %r14d
	shrl	%r14d
	andl	$7, %r14d
	movzbl	(%rax,%r14), %r14d
	movb	%r14b, 3(%r8,%rsi)
	shrl	$4, %ebx
	andl	$7, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, 4(%r8,%rsi)
	shrl	$15, %r11d
	andl	$7, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 5(%r8,%rsi)
	movl	%r10d, %r11d
	shrl	$2, %r11d
	andl	$7, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 6(%r8,%rsi)
	shrl	$5, %r10d
	movzbl	(%rax,%r10), %r10d
	movb	%r10b, 7(%r8,%rsi)
	addq	$8, %rsi
	addq	$-8, %rdi
	addq	$3, %rcx
	cmpq	$7, %rdi
	ja	LBB10_60
## %bb.61:
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_124
	jmp	LBB10_62
LBB10_66:
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_125
## %bb.67:
	leaq	3(%rdx), %rcx
	xorl	%esi, %esi
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	.p2align	4
LBB10_68:                               ## =>This Inner Loop Header: Depth=1
	movzbl	-3(%rcx), %ebx
	movzbl	-2(%rcx), %r14d
	movzbl	-1(%rcx), %r11d
	movzbl	(%rcx), %r10d
	movl	%ebx, %r15d
	andl	$15, %r15d
	movzbl	(%rax,%r15), %r15d
	movb	%r15b, (%r8,%rsi)
	shrl	$4, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, 1(%r8,%rsi)
	movl	%r14d, %ebx
	andl	$15, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, 2(%r8,%rsi)
	shrl	$4, %r14d
	movzbl	(%rax,%r14), %ebx
	movb	%bl, 3(%r8,%rsi)
	movl	%r11d, %ebx
	andl	$15, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, 4(%r8,%rsi)
	shrl	$4, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 5(%r8,%rsi)
	movl	%r10d, %r11d
	andl	$15, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 6(%r8,%rsi)
	shrl	$4, %r10d
	movzbl	(%rax,%r10), %r10d
	movb	%r10b, 7(%r8,%rsi)
	addq	$8, %rsi
	addq	$-8, %rdi
	addq	$4, %rcx
	cmpq	$7, %rdi
	ja	LBB10_68
## %bb.69:
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	jbe	LBB10_130
	jmp	LBB10_70
LBB10_74:
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_127
## %bb.75:
	xorl	%ecx, %ecx
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	.p2align	4
LBB10_76:                               ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdx,%rcx), %edi
	movzbl	1(%rdx,%rcx), %r9d
	movzbl	2(%rdx,%rcx), %r10d
	movzbl	3(%rdx,%rcx), %r11d
	movzwl	4(%rdx,%rcx), %ebx
	movzwl	6(%rdx,%rcx), %r14d
	movzbl	(%rax,%rdi), %edi
	movb	%dil, (%r8,%rcx)
	movzbl	(%rax,%r9), %edi
	movb	%dil, 1(%r8,%rcx)
	movzbl	(%rax,%r10), %edi
	movb	%dil, 2(%r8,%rcx)
	movzbl	(%rax,%r11), %edi
	movb	%dil, 3(%r8,%rcx)
	movzbl	%bl, %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, 4(%r8,%rcx)
	shrl	$8, %ebx
	movzbl	(%rax,%rbx), %edi
	movb	%dil, 5(%r8,%rcx)
	movzbl	%r14b, %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, 6(%r8,%rcx)
	shrl	$8, %r14d
	movzbl	(%rax,%r14), %edi
	movb	%dil, 7(%r8,%rcx)
	addq	$8, %rcx
	addq	$-8, %rsi
	cmpq	$7, %rsi
	ja	LBB10_76
## %bb.77:
	movq	%rcx, %rdi
	subq	-48(%rbp), %rdi                 ## 8-byte Folded Reload
	jae	LBB10_130
	jmp	LBB10_78
LBB10_84:
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_131
## %bb.85:
	leaq	1(%rdx), %rcx
	xorl	%esi, %esi
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	.p2align	4
LBB10_86:                               ## =>This Inner Loop Header: Depth=1
	movzbl	-1(%rcx), %r11d
	movzbl	(%rcx), %r10d
	movl	%r11d, %ebx
	andl	$3, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, (%r8,%rsi)
	movl	%r11d, %ebx
	shrl	$2, %ebx
	andl	$3, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, 1(%r8,%rsi)
	movl	%r11d, %ebx
	shrl	$4, %ebx
	andl	$3, %ebx
	movzbl	(%rax,%rbx), %ebx
	movb	%bl, 2(%r8,%rsi)
	shrl	$6, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 3(%r8,%rsi)
	movl	%r10d, %r11d
	andl	$3, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 4(%r8,%rsi)
	movl	%r10d, %r11d
	shrl	$2, %r11d
	andl	$3, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 5(%r8,%rsi)
	movl	%r10d, %r11d
	shrl	$4, %r11d
	andl	$3, %r11d
	movzbl	(%rax,%r11), %r11d
	movb	%r11b, 6(%r8,%rsi)
	shrl	$6, %r10d
	movzbl	(%rax,%r10), %r10d
	movb	%r10b, 7(%r8,%rsi)
	addq	$8, %rsi
	addq	$-8, %rdi
	addq	$2, %rcx
	cmpq	$7, %rdi
	ja	LBB10_86
## %bb.87:
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	jbe	LBB10_130
	jmp	LBB10_88
LBB10_92:
	movq	%r12, -56(%rbp)                 ## 8-byte Spill
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_133
## %bb.93:
	leaq	5(%rdx), %rcx
	xorl	%esi, %esi
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	.p2align	4
LBB10_94:                               ## =>This Inner Loop Header: Depth=1
	movzbl	-5(%rcx), %r13d
	movzbl	-4(%rcx), %r12d
	shll	$8, %r12d
	movzbl	-3(%rcx), %r15d
	movzbl	-2(%rcx), %ebx
	movl	%ebx, %r9d
	shll	$24, %r9d
	movzbl	-1(%rcx), %r14d
	shlq	$32, %r14
	movzbl	(%rcx), %r10d
	movq	%r10, %r11
	shlq	$40, %r11
	orq	%r14, %r11
	orq	%r9, %r14
	movl	%r15d, %r9d
	shll	$16, %r9d
	orl	%r12d, %r9d
	orl	%r13d, %r12d
	andl	$63, %r13d
	movzbl	(%rax,%r13), %r13d
	movb	%r13b, (%r8,%rsi)
	shrl	$6, %r12d
	andl	$63, %r12d
	movzbl	(%rax,%r12), %r12d
	movb	%r12b, 1(%r8,%rsi)
	shrl	$12, %r9d
	andl	$63, %r9d
	movzbl	(%rax,%r9), %r9d
	movb	%r9b, 2(%r8,%rsi)
	shrl	$2, %r15d
	movzbl	(%rax,%r15), %r9d
	movb	%r9b, 3(%r8,%rsi)
	andl	$63, %ebx
	movzbl	(%rax,%rbx), %r9d
	movb	%r9b, 4(%r8,%rsi)
	shrq	$30, %r14
	andl	$63, %r14d
	movzbl	(%rax,%r14), %r9d
	movb	%r9b, 5(%r8,%rsi)
	shrq	$36, %r11
	andl	$63, %r11d
	movzbl	(%rax,%r11), %r9d
	movb	%r9b, 6(%r8,%rsi)
	shrl	$2, %r10d
	movzbl	(%rax,%r10), %r9d
	movb	%r9b, 7(%r8,%rsi)
	addq	$8, %rsi
	addq	$-8, %rdi
	addq	$6, %rcx
	cmpq	$7, %rdi
	ja	LBB10_94
## %bb.95:
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_120
	jmp	LBB10_96
LBB10_100:
	movq	%r12, -56(%rbp)                 ## 8-byte Spill
	cmpq	$8, -48(%rbp)                   ## 8-byte Folded Reload
	jb	LBB10_136
## %bb.101:
	xorl	%esi, %esi
	movq	%rdx, %rcx
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	.p2align	4
LBB10_102:                              ## =>This Inner Loop Header: Depth=1
	movzbl	(%rcx), %r9d
	movzwl	1(%rcx), %r14d
	movl	%r14d, %r12d
	shll	$8, %r12d
	movzwl	3(%rcx), %r11d
	movq	%r11, %r13
	shlq	$24, %r13
	leal	(%r12,%r13), %r15d
	orl	%r9d, %r12d
	movzwl	5(%rcx), %r10d
	movq	%r10, %rbx
	shlq	$40, %rbx
	orq	%r13, %rbx
	andl	$127, %r9d
	movzbl	(%rax,%r9), %r9d
	movb	%r9b, (%r8,%rsi)
	shrl	$7, %r12d
	andl	$127, %r12d
	movzbl	(%rax,%r12), %r9d
	movb	%r9b, 1(%r8,%rsi)
	shrl	$6, %r14d
	andl	$127, %r14d
	movzbl	(%rax,%r14), %r9d
	movb	%r9b, 2(%r8,%rsi)
	shrl	$21, %r15d
	andl	$127, %r15d
	movzbl	(%rax,%r15), %r9d
	movb	%r9b, 3(%r8,%rsi)
	shrl	$4, %r11d
	andl	$127, %r11d
	movzbl	(%rax,%r11), %r9d
	movb	%r9b, 4(%r8,%rsi)
	shrq	$35, %rbx
	andl	$127, %ebx
	movzbl	(%rax,%rbx), %r9d
	movb	%r9b, 5(%r8,%rsi)
	movl	%r10d, %r9d
	shrl	$2, %r9d
	andl	$127, %r9d
	movzbl	(%rax,%r9), %r9d
	movb	%r9b, 6(%r8,%rsi)
	shrl	$9, %r10d
	movzbl	(%rax,%r10), %r9d
	movb	%r9b, 7(%r8,%rsi)
	addq	$8, %rsi
	addq	$-8, %rdi
	addq	$7, %rcx
	cmpq	$7, %rdi
	ja	LBB10_102
## %bb.103:
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_120
	jmp	LBB10_104
LBB10_108:
	movq	-48(%rbp), %r11                 ## 8-byte Reload
	andq	$-2, %r11
	xorl	%edi, %edi
	xorl	%r10d, %r10d
	jmp	LBB10_110
	.p2align	4
LBB10_109:                              ##   in Loop: Header=BB10_110 Depth=1
	movzbl	(%rcx,%rdi), %ebx
	incq	%rdi
	movb	%bl, 1(%r8,%r10)
	addq	$2, %r10
	cmpq	%r10, %r11
	je	LBB10_115
LBB10_110:                              ## =>This Inner Loop Header: Depth=1
	movq	%r10, %rbx
	shrq	$3, %rbx
	movzbl	(%rdx,%rbx), %r9d
	movl	%r10d, %r14d
	andl	$6, %r14d
	btl	%r14d, %r9d
	jae	LBB10_112
## %bb.111:                             ##   in Loop: Header=BB10_110 Depth=1
	movl	%esi, %r14d
	jmp	LBB10_113
	.p2align	4
LBB10_112:                              ##   in Loop: Header=BB10_110 Depth=1
	movzbl	(%rcx,%rdi), %r14d
	incq	%rdi
LBB10_113:                              ##   in Loop: Header=BB10_110 Depth=1
	movb	%r14b, (%r8,%r10)
	movzbl	(%rdx,%rbx), %r9d
	leal	1(%r10), %ebx
	movzbl	%bl, %ebx
	andl	$7, %ebx
	btl	%ebx, %r9d
	jae	LBB10_109
## %bb.114:                             ##   in Loop: Header=BB10_110 Depth=1
	movl	%esi, %ebx
	movb	%bl, 1(%r8,%r10)
	addq	$2, %r10
	cmpq	%r10, %r11
	jne	LBB10_110
LBB10_115:
	testb	$1, -48(%rbp)                   ## 1-byte Folded Reload
	je	LBB10_19
LBB10_116:
	movq	%r10, %r9
	shrq	$3, %r9
	movzbl	(%rdx,%r9), %edx
	movl	%r10d, %r9d
	andl	$7, %r9d
	btl	%r9d, %edx
	jb	LBB10_118
## %bb.117:
	movzbl	(%rcx,%rdi), %esi
LBB10_118:
	movb	%sil, (%r8,%r10)
	jmp	LBB10_19
LBB10_119:
	xorl	%esi, %esi
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_120
LBB10_54:
	leaq	(%rsi,%rsi,4), %rdi
	movq	-56(%rbp), %rbx                 ## 8-byte Reload
	jmp	LBB10_56
	.p2align	4
LBB10_55:                               ##   in Loop: Header=BB10_56 Depth=1
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %r10d
	andl	$31, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	incq	%rsi
	addq	$5, %rdi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_121
LBB10_56:                               ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %r11
	shrq	$3, %r11
	movzbl	(%rdx,%r11), %r10d
	movl	%edi, %ecx
	andl	$7, %ecx
	cmpq	$4, %rcx
	jb	LBB10_55
## %bb.57:                              ##   in Loop: Header=BB10_56 Depth=1
	movzbl	1(%rdx,%r11), %r9d
	shll	$8, %r9d
	orl	%r10d, %r9d
	movl	%r9d, %r10d
	jmp	LBB10_55
LBB10_122:
	xorl	%esi, %esi
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_124
LBB10_62:
	leaq	(%rsi,%rsi,2), %rdi
	jmp	LBB10_64
	.p2align	4
LBB10_63:                               ##   in Loop: Header=BB10_64 Depth=1
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %r10d
	andl	$7, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	incq	%rsi
	addq	$3, %rdi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_124
LBB10_64:                               ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %r11
	shrq	$3, %r11
	movzbl	(%rdx,%r11), %r10d
	movl	%edi, %ecx
	andl	$7, %ecx
	cmpq	$6, %rcx
	jb	LBB10_63
## %bb.65:                              ##   in Loop: Header=BB10_64 Depth=1
	movzbl	1(%rdx,%r11), %r11d
	shll	$8, %r11d
	orl	%r10d, %r11d
	movl	%r11d, %r10d
	jmp	LBB10_63
LBB10_124:
	movq	%r9, %rax
	jmp	LBB10_19
LBB10_125:
	xorl	%esi, %esi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	jbe	LBB10_130
LBB10_70:
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
                                        ## kill: def $ecx killed $ecx killed $rcx
	subl	%esi, %ecx
	leaq	1(%rsi), %rdi
	testb	$1, %cl
	je	LBB10_72
## %bb.71:
	leaq	(,%rsi,4), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%rdx,%r10), %r10d
	andb	$4, %cl
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %r10d
	andl	$15, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	movq	%rdi, %rsi
LBB10_72:
	cmpq	%rdi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_130
## %bb.139:
	leaq	(,%rsi,4), %rdi
	.p2align	4
LBB10_140:                              ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %rcx
	shrq	$3, %rcx
	movzbl	(%rdx,%rcx), %r10d
	movl	%edi, %ecx
	andb	$4, %cl
	shrl	%cl, %r10d
	andl	$15, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	leaq	4(%rdi), %rcx
	shrq	$3, %rcx
	movzbl	(%rdx,%rcx), %r10d
	movl	%edi, %ecx
	notb	%cl
	andb	$4, %cl
	shrl	%cl, %r10d
	andl	$15, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, 1(%r8,%rsi)
	addq	$2, %rsi
	addq	$8, %rdi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	jne	LBB10_140
	jmp	LBB10_130
LBB10_127:
	xorl	%ecx, %ecx
	movq	%rcx, %rdi
	subq	-48(%rbp), %rdi                 ## 8-byte Folded Reload
	jae	LBB10_130
LBB10_78:
	movabsq	$2305843009213693951, %rsi      ## imm = 0x1FFFFFFFFFFFFFFF
	movq	-48(%rbp), %r10                 ## 8-byte Reload
                                        ## kill: def $r10d killed $r10d killed $r10 def $r10
	subl	%ecx, %r10d
	andl	$3, %r10d
	je	LBB10_80
	.p2align	4
LBB10_79:                               ## =>This Inner Loop Header: Depth=1
	movq	%rcx, %r9
	andq	%rsi, %r9
	movzbl	(%rdx,%r9), %r9d
	movzbl	(%rax,%r9), %r9d
	movb	%r9b, (%r8,%rcx)
	incq	%rcx
	decq	%r10
	jne	LBB10_79
LBB10_80:
	cmpq	$-4, %rdi
	ja	LBB10_130
	.p2align	4
LBB10_82:                               ## =>This Inner Loop Header: Depth=1
	movq	%rcx, %rdi
	andq	%rsi, %rdi
	movzbl	(%rdx,%rdi), %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, (%r8,%rcx)
	leaq	1(%rcx), %rdi
	andq	%rsi, %rdi
	movzbl	(%rdx,%rdi), %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, 1(%r8,%rcx)
	leaq	2(%rcx), %rdi
	andq	%rsi, %rdi
	movzbl	(%rdx,%rdi), %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, 2(%r8,%rcx)
	leaq	3(%rcx), %rdi
	andq	%rsi, %rdi
	movzbl	(%rdx,%rdi), %edi
	movzbl	(%rax,%rdi), %edi
	movb	%dil, 3(%r8,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, -48(%rbp)                 ## 8-byte Folded Reload
	jne	LBB10_82
	jmp	LBB10_130
LBB10_129:
	xorl	%ecx, %ecx
	cmpq	%rcx, -48(%rbp)                 ## 8-byte Folded Reload
	jbe	LBB10_130
LBB10_12:
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	movl	%esi, %edi
	subl	%ecx, %edi
	leaq	1(%rcx), %rsi
	testb	$1, %dil
	je	LBB10_14
## %bb.13:
	movq	%rcx, %rdi
	shrq	$3, %rdi
	movzbl	(%rdx,%rdi), %edi
	movl	%ecx, %r10d
	andl	$7, %r10d
	btl	%r10d, %edi
	movq	%rax, %rdi
	adcq	$0, %rdi
	movzbl	(%rdi), %edi
	movb	%dil, (%r8,%rcx)
	movq	%rsi, %rcx
LBB10_14:
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_130
	.p2align	4
LBB10_16:                               ## =>This Inner Loop Header: Depth=1
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%rdx,%rsi), %esi
	movl	%ecx, %edi
	andl	$7, %edi
	btl	%edi, %esi
	movq	%rax, %rsi
	adcq	$0, %rsi
	movzbl	(%rsi), %esi
	movb	%sil, (%r8,%rcx)
	leaq	1(%rcx), %rsi
	movq	%rsi, %rdi
	shrq	$3, %rdi
	movzbl	(%rdx,%rdi), %edi
	andl	$7, %esi
	btl	%esi, %edi
	movq	%rax, %rsi
	adcq	$0, %rsi
	movzbl	(%rsi), %esi
	movb	%sil, 1(%r8,%rcx)
	addq	$2, %rcx
	cmpq	%rcx, -48(%rbp)                 ## 8-byte Folded Reload
	jne	LBB10_16
	jmp	LBB10_130
LBB10_131:
	xorl	%esi, %esi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	jbe	LBB10_130
LBB10_88:
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
                                        ## kill: def $ecx killed $ecx killed $rcx
	subl	%esi, %ecx
	leaq	1(%rsi), %rdi
	testb	$1, %cl
	je	LBB10_90
## %bb.89:
	leaq	(%rsi,%rsi), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%rdx,%r10), %r10d
	andb	$6, %cl
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %r10d
	andl	$3, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	movq	%rdi, %rsi
LBB10_90:
	cmpq	%rdi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_130
## %bb.142:
	leaq	(%rsi,%rsi), %rdi
	.p2align	4
LBB10_143:                              ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %rcx
	shrq	$3, %rcx
	movzbl	(%rdx,%rcx), %r10d
	movl	%edi, %ecx
	andb	$6, %cl
	shrl	%cl, %r10d
	andl	$3, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	leaq	2(%rdi), %rcx
	shrq	$3, %rcx
	movzbl	(%rdx,%rcx), %r10d
	leal	2(%rdi), %ecx
	andb	$6, %cl
                                        ## kill: def $cl killed $cl killed $ecx
	shrl	%cl, %r10d
	andl	$3, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, 1(%r8,%rsi)
	addq	$2, %rsi
	addq	$4, %rdi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	jne	LBB10_143
LBB10_130:
	movq	%r12, %rax
	jmp	LBB10_19
LBB10_133:
	xorl	%esi, %esi
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_120
LBB10_96:
	leaq	(%rsi,%rsi), %rcx
	leaq	(%rcx,%rcx,2), %rdi
	movq	-56(%rbp), %rbx                 ## 8-byte Reload
	jmp	LBB10_98
	.p2align	4
LBB10_97:                               ##   in Loop: Header=BB10_98 Depth=1
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %r10d
	andl	$63, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	incq	%rsi
	addq	$6, %rdi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_121
LBB10_98:                               ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %r11
	shrq	$3, %r11
	movzbl	(%rdx,%r11), %r10d
	movl	%edi, %ecx
	andl	$6, %ecx
	cmpq	$3, %rcx
	jb	LBB10_97
## %bb.99:                              ##   in Loop: Header=BB10_98 Depth=1
	movzbl	1(%rdx,%r11), %r9d
	shll	$8, %r9d
	orl	%r10d, %r9d
	movl	%r9d, %r10d
	jmp	LBB10_97
LBB10_136:
	xorl	%esi, %esi
	cmpq	-48(%rbp), %rsi                 ## 8-byte Folded Reload
	jae	LBB10_120
LBB10_104:
	leaq	(,%rsi,8), %rdi
	subq	%rsi, %rdi
	movq	-56(%rbp), %rbx                 ## 8-byte Reload
	jmp	LBB10_106
	.p2align	4
LBB10_105:                              ##   in Loop: Header=BB10_106 Depth=1
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %r10d
	andl	$127, %r10d
	movzbl	(%rax,%r10), %ecx
	movb	%cl, (%r8,%rsi)
	incq	%rsi
	addq	$7, %rdi
	cmpq	%rsi, -48(%rbp)                 ## 8-byte Folded Reload
	je	LBB10_121
LBB10_106:                              ## =>This Inner Loop Header: Depth=1
	movq	%rdi, %r11
	shrq	$3, %r11
	movzbl	(%rdx,%r11), %r10d
	movl	%edi, %ecx
	andl	$7, %ecx
	cmpq	$2, %rcx
	jb	LBB10_105
## %bb.107:                             ##   in Loop: Header=BB10_106 Depth=1
	movzbl	1(%rdx,%r11), %r9d
	shll	$8, %r9d
	orl	%r10d, %r9d
	movl	%r9d, %r10d
	jmp	LBB10_105
LBB10_120:
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	jmp	LBB10_19
LBB10_121:
	movq	%rbx, %rax
LBB10_19:
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB10_145:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp117:                                ## EH_LABEL
	leaq	L_.str.34(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp118:                                ## EH_LABEL
	jmp	LBB10_148
LBB10_146:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp126:                                ## EH_LABEL
	leaq	L_.str.35(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp127:                                ## EH_LABEL
	jmp	LBB10_148
LBB10_147:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp120:                                ## EH_LABEL
	leaq	L_.str.36(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp121:                                ## EH_LABEL
LBB10_148:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB10_149:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp123:                                ## EH_LABEL
	leaq	L_.str.37(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp124:                                ## EH_LABEL
	jmp	LBB10_148
LBB10_150:
Ltmp125:                                ## EH_LABEL
	jmp	LBB10_154
LBB10_151:
Ltmp122:                                ## EH_LABEL
	jmp	LBB10_154
LBB10_152:
Ltmp128:                                ## EH_LABEL
	jmp	LBB10_154
LBB10_153:
Ltmp119:                                ## EH_LABEL
LBB10_154:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end10:
	.cfi_endproc
	.p2align	2
	.data_region jt32
L10_0_set_8 = LBB10_8-LJTI10_0
L10_0_set_84 = LBB10_84-LJTI10_0
L10_0_set_58 = LBB10_58-LJTI10_0
L10_0_set_66 = LBB10_66-LJTI10_0
L10_0_set_50 = LBB10_50-LJTI10_0
L10_0_set_92 = LBB10_92-LJTI10_0
L10_0_set_100 = LBB10_100-LJTI10_0
L10_0_set_74 = LBB10_74-LJTI10_0
LJTI10_0:
	.long	L10_0_set_8
	.long	L10_0_set_84
	.long	L10_0_set_58
	.long	L10_0_set_66
	.long	L10_0_set_50
	.long	L10_0_set_92
	.long	L10_0_set_100
	.long	L10_0_set_74
	.end_data_region
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table10:
Lexception10:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end10-Lcst_begin10
Lcst_begin10:
	.uleb128 Lfunc_begin10-Lfunc_begin10    ## >> Call Site 1 <<
	.uleb128 Ltmp117-Lfunc_begin10          ##   Call between Lfunc_begin10 and Ltmp117
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp117-Lfunc_begin10          ## >> Call Site 2 <<
	.uleb128 Ltmp118-Ltmp117                ##   Call between Ltmp117 and Ltmp118
	.uleb128 Ltmp119-Lfunc_begin10          ##     jumps to Ltmp119
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp118-Lfunc_begin10          ## >> Call Site 3 <<
	.uleb128 Ltmp126-Ltmp118                ##   Call between Ltmp118 and Ltmp126
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp126-Lfunc_begin10          ## >> Call Site 4 <<
	.uleb128 Ltmp127-Ltmp126                ##   Call between Ltmp126 and Ltmp127
	.uleb128 Ltmp128-Lfunc_begin10          ##     jumps to Ltmp128
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp127-Lfunc_begin10          ## >> Call Site 5 <<
	.uleb128 Ltmp120-Ltmp127                ##   Call between Ltmp127 and Ltmp120
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp120-Lfunc_begin10          ## >> Call Site 6 <<
	.uleb128 Ltmp121-Ltmp120                ##   Call between Ltmp120 and Ltmp121
	.uleb128 Ltmp122-Lfunc_begin10          ##     jumps to Ltmp122
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp121-Lfunc_begin10          ## >> Call Site 7 <<
	.uleb128 Ltmp123-Ltmp121                ##   Call between Ltmp121 and Ltmp123
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp123-Lfunc_begin10          ## >> Call Site 8 <<
	.uleb128 Ltmp124-Ltmp123                ##   Call between Ltmp123 and Ltmp124
	.uleb128 Ltmp125-Lfunc_begin10          ##     jumps to Ltmp125
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp124-Lfunc_begin10          ## >> Call Site 9 <<
	.uleb128 Lfunc_end10-Ltmp124            ##   Call between Ltmp124 and Lfunc_end10
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end10:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE ## -- Begin function _ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.weak_def_can_be_hidden	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.p2align	4
__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE: ## @_ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
Lfunc_begin11:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception11
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$16392, %rsp                    ## imm = 0x4008
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %rbx
	movl	%edx, %r13d
	leaq	-257(%rsi), %rdx
	movl	$1, %eax
	movl	%r13d, %ecx
	shll	%cl, %eax
	cmpq	$-255, %rdx
	jb	LBB11_3
## %bb.1:
	leal	-13(%r13), %ecx
	cmpl	$-12, %ecx
	jb	LBB11_3
## %bb.2:
	movq	%rsi, %r14
	cmpq	%rax, %rsi
	ja	LBB11_3
## %bb.7:
	movq	%rdi, %r15
	leaq	-4144(%rbp), %rdi
	movl	$4096, %esi                     ## imm = 0x1000
	callq	___bzero
	leaq	-16432(%rbp), %r12
	movl	$12288, %esi                    ## imm = 0x3000
	movq	%r12, %rdi
	callq	___bzero
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 240(%rbx)
	movdqu	%xmm0, 224(%rbx)
	movdqu	%xmm0, 208(%rbx)
	movdqu	%xmm0, 192(%rbx)
	movdqu	%xmm0, 176(%rbx)
	movdqu	%xmm0, 160(%rbx)
	movdqu	%xmm0, 144(%rbx)
	movdqu	%xmm0, 128(%rbx)
	movdqu	%xmm0, 112(%rbx)
	movdqu	%xmm0, 96(%rbx)
	movdqu	%xmm0, 80(%rbx)
	movdqu	%xmm0, 64(%rbx)
	movdqu	%xmm0, 48(%rbx)
	movdqu	%xmm0, 32(%rbx)
	movdqu	%xmm0, 16(%rbx)
	movdqu	%xmm0, (%rbx)
	cmpq	$4, %r14
	ja	LBB11_18
## %bb.8:
	xorl	%eax, %eax
	jmp	LBB11_9
LBB11_18:
	movl	%r14d, %eax
	andl	$3, %eax
	movl	$4, %ecx
	cmovneq	%rax, %rcx
	movq	%r14, %rax
	subq	%rcx, %rax
	xorl	%ecx, %ecx
	.p2align	4
LBB11_19:                               ## =>This Inner Loop Header: Depth=1
	movups	(%r15,%rcx,8), %xmm0
	movups	16(%r15,%rcx,8), %xmm1
	shufps	$136, %xmm1, %xmm0              ## xmm0 = xmm0[0,2],xmm1[0,2]
	movups	%xmm0, -4144(%rbp,%rcx,4)
	movd	4(%r15,%rcx,8), %xmm0           ## xmm0 = mem[0],zero,zero,zero
	pinsrw	$1, 12(%r15,%rcx,8), %xmm0
	pinsrw	$2, 20(%r15,%rcx,8), %xmm0
	pinsrw	$3, 28(%r15,%rcx,8), %xmm0
	movq	%xmm0, -16432(%rbp,%rcx,2)
	addq	$4, %rcx
	cmpq	%rcx, %rax
	jne	LBB11_19
	.p2align	4
LBB11_9:                                ## =>This Inner Loop Header: Depth=1
	movl	(%r15,%rax,8), %ecx
	movl	%ecx, -4144(%rbp,%rax,4)
	movzwl	4(%r15,%rax,8), %ecx
	movw	%cx, -16432(%rbp,%rax,2)
	incq	%rax
	cmpq	%rax, %r14
	jne	LBB11_9
## %bb.10:
	movl	%r13d, %r9d
	cmpl	$2, %r13d
	jb	LBB11_26
## %bb.11:
	movl	$1, %ecx
	leaq	-15408(%rbp), %rdx
	movq	%r14, %rsi
	movq	%r9, -48(%rbp)                  ## 8-byte Spill
	jmp	LBB11_12
	.p2align	4
LBB11_23:                               ##   in Loop: Header=BB11_12 Depth=1
	incq	%rcx
	addq	$1024, %rdx                     ## imm = 0x400
	movq	-48(%rbp), %r9                  ## 8-byte Reload
	cmpq	%r9, %rcx
	je	LBB11_24
LBB11_12:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB11_13 Depth 2
	movl	%ecx, %eax
	andl	$1, %eax
	shll	$11, %eax
	leaq	(%rax,%rbp), %rdi
	addq	$-4144, %rdi                    ## imm = 0xEFD0
	movl	%ecx, %eax
	notl	%eax
	andl	$1, %eax
	shll	$11, %eax
	leaq	(%rax,%rbp), %r8
	addq	$-4144, %r8                     ## imm = 0xEFD0
	movq	%rsi, %r9
	shrq	%r9
	setne	%al
	movb	$1, %r13b
	xorl	%esi, %esi
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	jmp	LBB11_13
	.p2align	4
LBB11_21:                               ##   in Loop: Header=BB11_13 Depth=2
	movl	%r12d, (%rdi,%rsi,4)
	leal	256(,%r10,2), %eax
	movw	%ax, (%rdx,%rsi,2)
	incq	%r10
LBB11_22:                               ##   in Loop: Header=BB11_13 Depth=2
	incq	%rsi
	cmpq	%r14, %r11
	setb	%r13b
	cmpq	%r9, %r10
	setb	%al
	movl	%r13d, %r12d
	orb	%al, %r12b
	je	LBB11_23
LBB11_13:                               ##   Parent Loop BB11_12 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	xorl	%r12d, %r12d
	testb	$1, %al
	je	LBB11_15
## %bb.14:                              ##   in Loop: Header=BB11_13 Depth=2
	movl	4(%r8,%r10,8), %r12d
	addl	(%r8,%r10,8), %r12d
	testb	$1, %r13b
	je	LBB11_15
## %bb.20:                              ##   in Loop: Header=BB11_13 Depth=2
	movl	(%r15,%r11,8), %eax
	cmpl	%r12d, %eax
	ja	LBB11_21
	jmp	LBB11_17
	.p2align	4
LBB11_15:                               ##   in Loop: Header=BB11_13 Depth=2
	cmpq	%r9, %r10
	jne	LBB11_21
## %bb.16:                              ##   in Loop: Header=BB11_13 Depth=2
	movl	(%r15,%r11,8), %eax
LBB11_17:                               ##   in Loop: Header=BB11_13 Depth=2
	movl	%eax, (%rdi,%rsi,4)
	movzwl	4(%r15,%r11,8), %eax
	movw	%ax, (%rdx,%rsi,2)
	incq	%r11
	jmp	LBB11_22
LBB11_26:
	leaq	-2(,%r14,2), %rdi
	cmpq	%r14, %rdi
	jbe	LBB11_27
LBB11_25:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp129:                                ## EH_LABEL
	leaq	L_.str.17(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp130:                                ## EH_LABEL
	jmp	LBB11_4
LBB11_24:
	leaq	-2(,%r14,2), %rdi
	cmpq	%rsi, %rdi
	leaq	-16432(%rbp), %r12
	ja	LBB11_25
LBB11_27:
	movq	%r9, %rax
	shlq	$10, %rax
	leaq	(%rax,%r12), %rcx
	addq	$-1024, %rcx                    ## imm = 0xFC00
	jmp	LBB11_28
LBB11_33:                               ##   in Loop: Header=BB11_28 Depth=1
	incb	(%rbx,%rax)
LBB11_34:                               ##   in Loop: Header=BB11_28 Depth=1
	addq	%rdx, %rdx
LBB11_35:                               ##   in Loop: Header=BB11_28 Depth=1
	decq	%r9
	addq	$-1024, %rcx                    ## imm = 0xFC00
	movq	%rdx, %rdi
	testl	%r9d, %r9d
	je	LBB11_36
LBB11_28:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB11_38 Depth 2
	testq	%rdi, %rdi
	je	LBB11_29
## %bb.37:                              ##   in Loop: Header=BB11_28 Depth=1
	movq	%rdi, %r8
	andq	$-2, %r8
	xorl	%esi, %esi
	xorl	%edx, %edx
	jmp	LBB11_38
	.p2align	4
LBB11_43:                               ##   in Loop: Header=BB11_38 Depth=2
	incb	(%rbx,%rax)
	addq	$2, %rsi
	cmpq	%rsi, %r8
	je	LBB11_30
LBB11_38:                               ##   Parent Loop BB11_28 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%rcx,%rsi,2), %eax
	cmpq	$255, %rax
	ja	LBB11_40
## %bb.39:                              ##   in Loop: Header=BB11_38 Depth=2
	incb	(%rbx,%rax)
	movzwl	2(%rcx,%rsi,2), %eax
	cmpq	$256, %rax                      ## imm = 0x100
	jb	LBB11_43
	jmp	LBB11_42
	.p2align	4
LBB11_40:                               ##   in Loop: Header=BB11_38 Depth=2
	incq	%rdx
	movzwl	2(%rcx,%rsi,2), %eax
	cmpq	$256, %rax                      ## imm = 0x100
	jb	LBB11_43
LBB11_42:                               ##   in Loop: Header=BB11_38 Depth=2
	incq	%rdx
	addq	$2, %rsi
	cmpq	%rsi, %r8
	jne	LBB11_38
LBB11_30:                               ##   in Loop: Header=BB11_28 Depth=1
	testb	$1, %dil
	je	LBB11_34
## %bb.31:                              ##   in Loop: Header=BB11_28 Depth=1
	movzwl	(%rcx,%rsi,2), %eax
	cmpq	$256, %rax                      ## imm = 0x100
	jb	LBB11_33
## %bb.32:                              ##   in Loop: Header=BB11_28 Depth=1
	incq	%rdx
	jmp	LBB11_34
	.p2align	4
LBB11_29:                               ##   in Loop: Header=BB11_28 Depth=1
	xorl	%edx, %edx
	jmp	LBB11_35
LBB11_36:
	addq	$16392, %rsp                    ## imm = 0x4008
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB11_3:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp132:                                ## EH_LABEL
	leaq	L_.str.16(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp133:                                ## EH_LABEL
LBB11_4:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB11_45:
Ltmp131:                                ## EH_LABEL
	jmp	LBB11_6
LBB11_5:
Ltmp134:                                ## EH_LABEL
LBB11_6:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end11:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table11:
Lexception11:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end11-Lcst_begin11
Lcst_begin11:
	.uleb128 Lfunc_begin11-Lfunc_begin11    ## >> Call Site 1 <<
	.uleb128 Ltmp129-Lfunc_begin11          ##   Call between Lfunc_begin11 and Ltmp129
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp129-Lfunc_begin11          ## >> Call Site 2 <<
	.uleb128 Ltmp130-Ltmp129                ##   Call between Ltmp129 and Ltmp130
	.uleb128 Ltmp131-Lfunc_begin11          ##     jumps to Ltmp131
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp130-Lfunc_begin11          ## >> Call Site 3 <<
	.uleb128 Ltmp132-Ltmp130                ##   Call between Ltmp130 and Ltmp132
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp132-Lfunc_begin11          ## >> Call Site 4 <<
	.uleb128 Ltmp133-Ltmp132                ##   Call between Ltmp132 and Ltmp133
	.uleb128 Ltmp134-Lfunc_begin11          ##     jumps to Ltmp134
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp133-Lfunc_begin11          ## >> Call Site 5 <<
	.uleb128 Lfunc_end11-Ltmp133            ##   Call between Ltmp133 and Lfunc_end11
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end11:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb: ## @_ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%ecx, -44(%rbp)                 ## 4-byte Spill
	movq	%rdx, %r12
	movq	%rsi, %r15
	movq	%rdi, %rbx
LBB12_1:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB12_2 Depth 2
                                        ##       Child Loop BB12_116 Depth 3
                                        ##       Child Loop BB12_119 Depth 3
                                        ##       Child Loop BB12_122 Depth 3
                                        ##       Child Loop BB12_123 Depth 3
                                        ##         Child Loop BB12_125 Depth 4
                                        ##         Child Loop BB12_126 Depth 4
                                        ##       Child Loop BB12_131 Depth 3
                                        ##       Child Loop BB12_137 Depth 3
                                        ##       Child Loop BB12_134 Depth 3
                                        ##       Child Loop BB12_140 Depth 3
                                        ##         Child Loop BB12_141 Depth 4
                                        ##         Child Loop BB12_142 Depth 4
	leaq	-8(%r15), %rax
	movq	%rax, -56(%rbp)                 ## 8-byte Spill
	leaq	-16(%r15), %rax
	movq	%rax, -88(%rbp)                 ## 8-byte Spill
	leaq	-24(%r15), %rax
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
LBB12_2:                                ##   Parent Loop BB12_1 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB12_116 Depth 3
                                        ##       Child Loop BB12_119 Depth 3
                                        ##       Child Loop BB12_122 Depth 3
                                        ##       Child Loop BB12_123 Depth 3
                                        ##         Child Loop BB12_125 Depth 4
                                        ##         Child Loop BB12_126 Depth 4
                                        ##       Child Loop BB12_131 Depth 3
                                        ##       Child Loop BB12_137 Depth 3
                                        ##       Child Loop BB12_134 Depth 3
                                        ##       Child Loop BB12_140 Depth 3
                                        ##         Child Loop BB12_141 Depth 4
                                        ##         Child Loop BB12_142 Depth 4
	movq	%rbx, %r13
	movq	%r15, %rcx
	subq	%rbx, %rcx
	sarq	$3, %rcx
	cmpq	$5, %rcx
	jbe	LBB12_3
## %bb.21:                              ##   in Loop: Header=BB12_2 Depth=2
	cmpq	$23, %rcx
	jle	LBB12_22
## %bb.38:                              ##   in Loop: Header=BB12_2 Depth=2
	testq	%r12, %r12
	je	LBB12_39
## %bb.70:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	%rcx, %rax
	andq	$-2, %rax
	leaq	(,%rax,4), %rax
	addq	%r13, %rax
	movl	-8(%r15), %edx
	movzwl	-4(%r15), %esi
	cmpq	$129, %rcx
	jb	LBB12_104
## %bb.71:                              ##   in Loop: Header=BB12_2 Depth=2
	movl	(%rax), %ecx
	movzwl	4(%rax), %edi
	xorl	%r8d, %r8d
	cmpw	4(%r13), %di
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	(%r13), %ecx
	setb	%r9b
	cmovel	%r8d, %r9d
	xorl	%r8d, %r8d
	cmpw	%di, %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	%ecx, %edx
	setb	%sil
	cmovel	%r8d, %esi
	testb	%r9b, %r9b
	je	LBB12_72
## %bb.75:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rcx
	testb	%sil, %sil
	je	LBB12_77
## %bb.76:                              ##   in Loop: Header=BB12_2 Depth=2
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%r13)
	movl	(%rsi), %edx
	movl	%edx, (%r13)
	movq	%rcx, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%rsi)
	movl	%ecx, (%rsi)
	jmp	LBB12_79
	.p2align	4
LBB12_104:                              ##   in Loop: Header=BB12_2 Depth=2
	movl	(%r13), %ecx
	movzwl	4(%r13), %edi
	xorl	%r8d, %r8d
	cmpw	4(%rax), %di
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	(%rax), %ecx
	setb	%r9b
	cmovel	%r8d, %r9d
	xorl	%r8d, %r8d
	cmpw	%di, %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	%ecx, %edx
	setb	%sil
	cmovel	%r8d, %esi
	testb	%r9b, %r9b
	je	LBB12_105
## %bb.108:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rax), %rcx
	testb	%sil, %sil
	je	LBB12_110
## %bb.109:                             ##   in Loop: Header=BB12_2 Depth=2
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movq	%rcx, %rax
	shrq	$32, %rax
	movw	%ax, 4(%rsi)
	movl	%ecx, (%rsi)
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	je	LBB12_113
	jmp	LBB12_130
LBB12_72:                               ##   in Loop: Header=BB12_2 Depth=2
	testb	%sil, %sil
	je	LBB12_79
## %bb.73:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rax), %rcx
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	movl	(%rax), %ecx
	movzwl	4(%rax), %edx
	xorl	%esi, %esi
	cmpw	4(%r13), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r13), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB12_79
## %bb.74:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movl	%ecx, (%rax)
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	jmp	LBB12_79
LBB12_105:                              ##   in Loop: Header=BB12_2 Depth=2
	testb	%sil, %sil
	je	LBB12_112
## %bb.106:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rcx
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%r13)
	movl	(%rsi), %edx
	movl	%edx, (%r13)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	movl	(%r13), %ecx
	movzwl	4(%r13), %edx
	xorl	%esi, %esi
	cmpw	4(%rax), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%rax), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB12_112
## %bb.107:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rax), %rcx
	movzwl	4(%r13), %edx
	movw	%dx, 4(%rax)
	movl	(%r13), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%r13)
	shrq	$32, %rcx
	movw	%cx, 4(%r13)
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	je	LBB12_113
	jmp	LBB12_130
LBB12_77:                               ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movq	%rcx, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%rax)
	movl	%ecx, (%rax)
	xorl	%esi, %esi
	cmpw	%dx, -4(%r15)
	setb	%sil
	xorl	%edx, %edx
	cmpl	%ecx, -8(%r15)
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB12_79
## %bb.78:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rax), %rcx
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	.p2align	4
LBB12_79:                               ##   in Loop: Header=BB12_2 Depth=2
	movl	-8(%rax), %esi
	movzwl	-4(%rax), %edi
	xorl	%ecx, %ecx
	cmpw	12(%r13), %di
	setb	%cl
	xorl	%r8d, %r8d
	cmpl	8(%r13), %esi
	leaq	8(%r13), %rdx
	setb	%r8b
	cmovel	%ecx, %r8d
	leaq	-8(%rax), %rcx
	xorl	%r9d, %r9d
	cmpw	%di, -12(%r15)
	setb	%r9b
	xorl	%edi, %edi
	cmpl	%esi, -16(%r15)
	setb	%dil
	cmovel	%r9d, %edi
	testb	%r8b, %r8b
	je	LBB12_80
## %bb.83:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rdx), %rsi
	testb	%dil, %dil
	je	LBB12_85
## %bb.84:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	-88(%rbp), %r8                  ## 8-byte Reload
	movzwl	4(%r8), %edi
	movw	%di, 4(%rdx)
	movl	(%r8), %edi
	movl	%edi, (%rdx)
	movq	%rsi, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%r8)
	movl	%esi, (%r8)
	jmp	LBB12_87
LBB12_80:                               ##   in Loop: Header=BB12_2 Depth=2
	testb	%dil, %dil
	je	LBB12_87
## %bb.81:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	-8(%rax), %rsi
	movq	-88(%rbp), %r8                  ## 8-byte Reload
	movzwl	4(%r8), %edi
	movw	%di, 4(%rcx)
	movl	(%r8), %edi
	movl	%edi, (%rcx)
	movl	%esi, (%r8)
	shrq	$32, %rsi
	movw	%si, 4(%r8)
	movl	-8(%rax), %esi
	movzwl	-4(%rax), %edi
	xorl	%r8d, %r8d
	cmpw	12(%r13), %di
	setb	%r8b
	xorl	%edi, %edi
	cmpl	8(%r13), %esi
	setb	%dil
	cmovel	%r8d, %edi
	cmpb	$1, %dil
	jne	LBB12_87
## %bb.82:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rdx), %rsi
	movzwl	4(%rcx), %edi
	movw	%di, 4(%rdx)
	movl	(%rcx), %edi
	movl	%edi, (%rdx)
	movl	%esi, (%rcx)
	shrq	$32, %rsi
	movw	%si, 4(%rcx)
	jmp	LBB12_87
LBB12_110:                              ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%r13), %edx
	movw	%dx, 4(%rax)
	movl	(%r13), %edx
	movl	%edx, (%rax)
	movq	%rcx, %rax
	shrq	$32, %rax
	movw	%ax, 4(%r13)
	movl	%ecx, (%r13)
	xorl	%edx, %edx
	cmpw	%ax, -4(%r15)
	setb	%dl
	xorl	%eax, %eax
	cmpl	%ecx, -8(%r15)
	setb	%al
	cmovel	%edx, %eax
	cmpb	$1, %al
	jne	LBB12_112
## %bb.111:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rax
	leaq	-8(%r15), %rdx
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%r13)
	movl	(%rdx), %ecx
	movl	%ecx, (%r13)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	.p2align	4
LBB12_112:                              ##   in Loop: Header=BB12_2 Depth=2
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	je	LBB12_113
	jmp	LBB12_130
LBB12_85:                               ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%rcx), %edi
	movw	%di, 4(%rdx)
	movl	(%rcx), %edi
	movl	%edi, (%rdx)
	movq	%rsi, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%rcx)
	movl	%esi, (%rcx)
	xorl	%edi, %edi
	cmpw	%dx, -12(%r15)
	setb	%dil
	xorl	%edx, %edx
	cmpl	%esi, -16(%r15)
	setb	%dl
	cmovel	%edi, %edx
	cmpb	$1, %dl
	jne	LBB12_87
## %bb.86:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rcx), %rdx
	movq	-88(%rbp), %rdi                 ## 8-byte Reload
	movzwl	4(%rdi), %esi
	movw	%si, 4(%rcx)
	movl	(%rdi), %esi
	movl	%esi, (%rcx)
	movl	%edx, (%rdi)
	shrq	$32, %rdx
	movw	%dx, 4(%rdi)
	.p2align	4
LBB12_87:                               ##   in Loop: Header=BB12_2 Depth=2
	movl	8(%rax), %edi
	movzwl	12(%rax), %r8d
	xorl	%edx, %edx
	cmpw	20(%r13), %r8w
	setb	%dl
	xorl	%r9d, %r9d
	cmpl	16(%r13), %edi
	leaq	16(%r13), %rsi
	setb	%r9b
	cmovel	%edx, %r9d
	leaq	8(%rax), %rdx
	xorl	%r10d, %r10d
	cmpw	%r8w, -20(%r15)
	setb	%r10b
	xorl	%r8d, %r8d
	cmpl	%edi, -24(%r15)
	setb	%r8b
	cmovel	%r10d, %r8d
	testb	%r9b, %r9b
	je	LBB12_88
## %bb.91:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rsi), %rdi
	testb	%r8b, %r8b
	je	LBB12_93
## %bb.92:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	-80(%rbp), %r9                  ## 8-byte Reload
	movzwl	4(%r9), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%r9), %r8d
	movl	%r8d, (%rsi)
	movq	%rdi, %rsi
	shrq	$32, %rsi
	movw	%si, 4(%r9)
	movl	%edi, (%r9)
	jmp	LBB12_95
LBB12_88:                               ##   in Loop: Header=BB12_2 Depth=2
	testb	%r8b, %r8b
	je	LBB12_95
## %bb.89:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	8(%rax), %rdi
	movq	-80(%rbp), %r9                  ## 8-byte Reload
	movzwl	4(%r9), %r8d
	movw	%r8w, 4(%rdx)
	movl	(%r9), %r8d
	movl	%r8d, (%rdx)
	movl	%edi, (%r9)
	shrq	$32, %rdi
	movw	%di, 4(%r9)
	movl	8(%rax), %edi
	movzwl	12(%rax), %r8d
	xorl	%r9d, %r9d
	cmpw	20(%r13), %r8w
	setb	%r9b
	xorl	%r8d, %r8d
	cmpl	16(%r13), %edi
	setb	%r8b
	cmovel	%r9d, %r8d
	cmpb	$1, %r8b
	jne	LBB12_95
## %bb.90:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rsi), %rdi
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movl	%edi, (%rdx)
	shrq	$32, %rdi
	movw	%di, 4(%rdx)
	jmp	LBB12_95
LBB12_93:                               ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movq	%rdi, %rsi
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	movl	%edi, (%rdx)
	xorl	%r8d, %r8d
	cmpw	%si, -20(%r15)
	setb	%r8b
	xorl	%esi, %esi
	cmpl	%edi, -24(%r15)
	setb	%sil
	cmovel	%r8d, %esi
	cmpb	$1, %sil
	jne	LBB12_95
## %bb.94:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rdx), %rsi
	movq	-80(%rbp), %r8                  ## 8-byte Reload
	movzwl	4(%r8), %edi
	movw	%di, 4(%rdx)
	movl	(%r8), %edi
	movl	%edi, (%rdx)
	movl	%esi, (%r8)
	shrq	$32, %rsi
	movw	%si, 4(%r8)
	.p2align	4
LBB12_95:                               ##   in Loop: Header=BB12_2 Depth=2
	movl	(%rax), %r11d
	movzwl	4(%rax), %r10d
	movl	-8(%rax), %esi
	movzwl	-4(%rax), %edi
	xorl	%r8d, %r8d
	cmpw	%di, %r10w
	setb	%r8b
	xorl	%ebx, %ebx
	cmpl	%esi, %r11d
	setb	%bl
	cmovel	%r8d, %ebx
	movl	8(%rax), %r8d
	movzwl	12(%rax), %r9d
	xorl	%r14d, %r14d
	cmpw	%r10w, %r9w
	setb	%r14b
	xorl	%r10d, %r10d
	cmpl	%r11d, %r8d
	setb	%r10b
	cmovel	%r14d, %r10d
	testb	%bl, %bl
	je	LBB12_96
## %bb.99:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rcx), %rsi
	testb	%r10b, %r10b
	je	LBB12_101
## %bb.100:                             ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%rdx), %edi
	movw	%di, 4(%rcx)
	movl	(%rdx), %edi
	movl	%edi, (%rcx)
	movq	%rsi, %rcx
	shrq	$32, %rcx
	movw	%cx, 4(%rdx)
	movl	%esi, (%rdx)
	jmp	LBB12_103
LBB12_96:                               ##   in Loop: Header=BB12_2 Depth=2
	testb	%r10b, %r10b
	je	LBB12_103
## %bb.97:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rax), %r8
	movzwl	4(%rdx), %r9d
	movw	%r9w, 4(%rax)
	movl	(%rdx), %edx
	movl	%edx, (%rax)
	movl	%r8d, 8(%rax)
	shrq	$32, %r8
	movw	%r8w, 12(%rax)
	xorl	%r8d, %r8d
	cmpw	%di, %r9w
	setb	%r8b
	xorl	%edi, %edi
	cmpl	%esi, %edx
	setb	%dil
	cmovel	%r8d, %edi
	cmpb	$1, %dil
	jne	LBB12_103
## %bb.98:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	-8(%rax), %rdx
	movzwl	4(%rax), %esi
	movw	%si, 4(%rcx)
	movl	(%rax), %esi
	movl	%esi, (%rcx)
	movl	%edx, (%rax)
	shrq	$32, %rdx
	movw	%dx, 4(%rax)
	jmp	LBB12_103
LBB12_101:                              ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%rax), %edi
	movw	%di, 4(%rcx)
	movl	(%rax), %edi
	movl	%edi, (%rcx)
	movq	%rsi, %rcx
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	movl	%esi, (%rax)
	xorl	%edi, %edi
	cmpw	%cx, %r9w
	setb	%dil
	xorl	%ecx, %ecx
	cmpl	%esi, %r8d
	setb	%cl
	cmovnel	%ecx, %edi
	cmpb	$1, %dil
	jne	LBB12_103
## %bb.102:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	(%rax), %rcx
	movzwl	4(%rdx), %esi
	movw	%si, 4(%rax)
	movl	(%rdx), %edx
	movl	%edx, (%rax)
	movl	%ecx, 8(%rax)
	shrq	$32, %rcx
	movw	%cx, 12(%rax)
	.p2align	4
LBB12_103:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movl	%ecx, (%rax)
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	jne	LBB12_130
LBB12_113:                              ##   in Loop: Header=BB12_2 Depth=2
	movl	-8(%r13), %eax
	movzwl	-4(%r13), %ecx
	xorl	%edx, %edx
	cmpw	4(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	testb	%cl, %cl
	je	LBB12_114
LBB12_130:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rax
	movl	%eax, %ecx
	shrq	$32, %rax
	xorl	%edi, %edi
	.p2align	4
LBB12_131:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%edx, %edx
	cmpw	%ax, 12(%r13,%rdi)
	setb	%dl
	xorl	%esi, %esi
	cmpl	%ecx, 8(%r13,%rdi)
	setb	%sil
	cmovel	%edx, %esi
	addq	$8, %rdi
	testb	%sil, %sil
	jne	LBB12_131
## %bb.132:                             ##   in Loop: Header=BB12_2 Depth=2
	leaq	(%rdi,%r13), %rdx
	movq	%r15, %rsi
	cmpq	$8, %rdi
	jne	LBB12_137
## %bb.133:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	%r15, %rdi
	.p2align	4
LBB12_134:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	cmpq	%rdi, %rdx
	jae	LBB12_135
## %bb.136:                             ##   in Loop: Header=BB12_134 Depth=3
	leaq	-8(%rdi), %rsi
	xorl	%r8d, %r8d
	cmpw	%ax, -4(%rdi)
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	%ecx, -8(%rdi)
	setb	%r9b
	cmovel	%r8d, %r9d
	movq	%rsi, %rdi
	testb	%r9b, %r9b
	je	LBB12_134
	jmp	LBB12_138
	.p2align	4
LBB12_137:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%edi, %edi
	cmpw	%ax, -4(%rsi)
	setb	%dil
	xorl	%r8d, %r8d
	cmpl	%ecx, -8(%rsi)
	leaq	-8(%rsi), %rsi
	setb	%r8b
	cmovel	%edi, %r8d
	cmpb	$1, %r8b
	jne	LBB12_137
LBB12_138:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	%rdx, %rbx
	cmpq	%rsi, %rdx
	jb	LBB12_139
	jmp	LBB12_144
LBB12_135:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	%rdi, %rsi
	movq	%rdx, %rbx
	cmpq	%rsi, %rdx
	jae	LBB12_144
LBB12_139:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	%rdx, %rbx
	movq	%rsi, %rdi
	.p2align	4
LBB12_140:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Loop Header: Depth=3
                                        ##         Child Loop BB12_141 Depth 4
                                        ##         Child Loop BB12_142 Depth 4
	movq	(%rbx), %r8
	movzwl	4(%rdi), %r9d
	movw	%r9w, 4(%rbx)
	movl	(%rdi), %r9d
	movl	%r9d, (%rbx)
	movl	%r8d, (%rdi)
	shrq	$32, %r8
	movw	%r8w, 4(%rdi)
	.p2align	4
LBB12_141:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ##       Parent Loop BB12_140 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%r8d, %r8d
	cmpw	%ax, 12(%rbx)
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	%ecx, 8(%rbx)
	leaq	8(%rbx), %rbx
	setb	%r9b
	cmovel	%r8d, %r9d
	testb	%r9b, %r9b
	jne	LBB12_141
	.p2align	4
LBB12_142:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ##       Parent Loop BB12_140 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%r8d, %r8d
	cmpw	%ax, -4(%rdi)
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	%ecx, -8(%rdi)
	leaq	-8(%rdi), %rdi
	setb	%r9b
	cmovel	%r8d, %r9d
	cmpb	$1, %r9b
	jne	LBB12_142
## %bb.143:                             ##   in Loop: Header=BB12_140 Depth=3
	cmpq	%rdi, %rbx
	jb	LBB12_140
LBB12_144:                              ##   in Loop: Header=BB12_2 Depth=2
	leaq	-8(%rbx), %r8
	cmpq	%r8, %r13
	je	LBB12_146
## %bb.145:                             ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%r8), %edi
	movw	%di, 4(%r13)
	movl	(%r8), %edi
	movl	%edi, (%r13)
LBB12_146:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	%r13, -64(%rbp)                 ## 8-byte Spill
	movl	%ecx, -8(%rbx)
	movw	%ax, -4(%rbx)
	cmpq	%rsi, %rdx
	jb	LBB12_150
## %bb.147:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	%r12, -72(%rbp)                 ## 8-byte Spill
	movq	-64(%rbp), %rdi                 ## 8-byte Reload
	movq	%r8, %r14
	movq	%r8, %rsi
	callq	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	movl	%eax, %r12d
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	testb	%al, %al
	jne	LBB12_148
## %bb.149:                             ##   in Loop: Header=BB12_2 Depth=2
	testb	%r12b, %r12b
	movq	-72(%rbp), %r12                 ## 8-byte Reload
	movq	%r14, %r8
	jne	LBB12_2
LBB12_150:                              ##   in Loop: Header=BB12_2 Depth=2
	movzbl	-44(%rbp), %ecx                 ## 1-byte Folded Reload
	movq	-64(%rbp), %rdi                 ## 8-byte Reload
	movq	%r8, %rsi
	movq	%r12, %rdx
	callq	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	movl	$0, -44(%rbp)                   ## 4-byte Folded Spill
	jmp	LBB12_2
LBB12_114:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	(%r13), %rax
	movl	%eax, %ecx
	shrq	$32, %rax
	xorl	%edx, %edx
	cmpw	%ax, -4(%r15)
	seta	%dl
	xorl	%esi, %esi
	cmpl	%ecx, -8(%r15)
	seta	%sil
	cmovnel	%esi, %edx
	testb	%dl, %dl
	je	LBB12_115
## %bb.118:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	%r13, %rbx
	.p2align	4
LBB12_119:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%edx, %edx
	cmpw	%ax, 12(%rbx)
	seta	%dl
	xorl	%esi, %esi
	cmpl	%ecx, 8(%rbx)
	seta	%sil
	leaq	8(%rbx), %rbx
	cmovel	%edx, %esi
	testb	%sil, %sil
	je	LBB12_119
	jmp	LBB12_120
LBB12_115:                              ##   in Loop: Header=BB12_2 Depth=2
	leaq	8(%r13), %rdx
	.p2align	4
LBB12_116:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	%rdx, %rbx
	cmpq	%r15, %rdx
	jae	LBB12_120
## %bb.117:                             ##   in Loop: Header=BB12_116 Depth=3
	xorl	%edx, %edx
	cmpw	%ax, 4(%rbx)
	seta	%dl
	xorl	%esi, %esi
	cmpl	%ecx, (%rbx)
	seta	%sil
	cmovel	%edx, %esi
	leaq	8(%rbx), %rdx
	cmpb	$1, %sil
	jne	LBB12_116
LBB12_120:                              ##   in Loop: Header=BB12_2 Depth=2
	movq	%r15, %rdx
	cmpq	%r15, %rbx
	jae	LBB12_123
## %bb.121:                             ##   in Loop: Header=BB12_2 Depth=2
	movq	%r15, %rdx
	.p2align	4
LBB12_122:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%esi, %esi
	cmpw	%ax, -4(%rdx)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%ecx, -8(%rdx)
	seta	%dil
	leaq	-8(%rdx), %rdx
	cmovel	%esi, %edi
	testb	%dil, %dil
	jne	LBB12_122
	jmp	LBB12_123
	.p2align	4
LBB12_124:                              ##   in Loop: Header=BB12_123 Depth=3
	movq	(%rbx), %rsi
	movzwl	4(%rdx), %edi
	movw	%di, 4(%rbx)
	movl	(%rdx), %edi
	movl	%edi, (%rbx)
	movl	%esi, (%rdx)
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	.p2align	4
LBB12_125:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ##       Parent Loop BB12_123 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%esi, %esi
	cmpw	%ax, 12(%rbx)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%ecx, 8(%rbx)
	seta	%dil
	leaq	8(%rbx), %rbx
	cmovel	%esi, %edi
	cmpb	$1, %dil
	jne	LBB12_125
	.p2align	4
LBB12_126:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ##       Parent Loop BB12_123 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%esi, %esi
	cmpw	%ax, -4(%rdx)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%ecx, -8(%rdx)
	seta	%dil
	leaq	-8(%rdx), %rdx
	cmovel	%esi, %edi
	testb	%dil, %dil
	jne	LBB12_126
LBB12_123:                              ##   Parent Loop BB12_1 Depth=1
                                        ##     Parent Loop BB12_2 Depth=2
                                        ## =>    This Loop Header: Depth=3
                                        ##         Child Loop BB12_125 Depth 4
                                        ##         Child Loop BB12_126 Depth 4
	cmpq	%rdx, %rbx
	jb	LBB12_124
## %bb.127:                             ##   in Loop: Header=BB12_2 Depth=2
	leaq	-8(%rbx), %rdx
	cmpq	%rdx, %r13
	je	LBB12_129
## %bb.128:                             ##   in Loop: Header=BB12_2 Depth=2
	movzwl	4(%rdx), %esi
	movw	%si, 4(%r13)
	movl	(%rdx), %edx
	movl	%edx, (%r13)
LBB12_129:                              ##   in Loop: Header=BB12_2 Depth=2
	movl	%ecx, -8(%rbx)
	movw	%ax, -4(%rbx)
	movl	$0, -44(%rbp)                   ## 4-byte Folded Spill
	jmp	LBB12_2
LBB12_148:                              ##   in Loop: Header=BB12_1 Depth=1
	testb	%r12b, %r12b
	movq	-72(%rbp), %r12                 ## 8-byte Reload
	movq	%r14, %r15
	movq	-64(%rbp), %rbx                 ## 8-byte Reload
	je	LBB12_1
	jmp	LBB12_20
LBB12_3:
	leaq	LJTI12_0(%rip), %rax
	movslq	(%rax,%rcx,4), %rcx
	addq	%rax, %rcx
	jmpq	*%rcx
LBB12_20:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB12_6:
	movl	8(%r13), %ecx
	movzwl	12(%r13), %edx
	xorl	%eax, %eax
	cmpw	4(%r13), %dx
	setb	%al
	xorl	%esi, %esi
	cmpl	(%r13), %ecx
	setb	%sil
	cmovel	%eax, %esi
	leaq	8(%r13), %rax
	xorl	%edi, %edi
	cmpw	%dx, -4(%r15)
	setb	%dil
	xorl	%edx, %edx
	cmpl	%ecx, -8(%r15)
	setb	%dl
	cmovel	%edi, %edx
	testb	%sil, %sil
	je	LBB12_7
## %bb.10:
	movq	(%r13), %rcx
	testb	%dl, %dl
	je	LBB12_12
## %bb.11:
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movzwl	4(%rdx), %eax
	movw	%ax, 4(%r13)
	movl	(%rdx), %eax
	movl	%eax, (%r13)
	movq	%rcx, %rax
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	movl	%ecx, (%rdx)
	jmp	LBB12_20
LBB12_4:
	movl	-8(%r15), %eax
	movzwl	-4(%r15), %ecx
	xorl	%edx, %edx
	cmpw	4(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB12_20
## %bb.5:
	movq	(%r13), %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%r13)
	movl	(%rdx), %ecx
	movl	%ecx, (%r13)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	jmp	LBB12_20
LBB12_15:
	leaq	8(%r13), %r14
	leaq	16(%r13), %r12
	leaq	24(%r13), %rbx
	movq	%r13, %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	movq	%rbx, %rcx
	callq	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	movl	-8(%r15), %eax
	movzwl	-4(%r15), %ecx
	xorl	%edx, %edx
	cmpw	28(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	24(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB12_20
## %bb.16:
	movq	24(%r13), %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%rbx)
	movl	(%rdx), %ecx
	movl	%ecx, (%rbx)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	movl	24(%r13), %eax
	movzwl	28(%r13), %ecx
	xorl	%edx, %edx
	cmpw	20(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	16(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB12_20
## %bb.17:
	movq	16(%r13), %rax
	movzwl	4(%rbx), %ecx
	movw	%cx, 4(%r12)
	movl	(%rbx), %ecx
	movl	%ecx, (%r12)
	movl	%eax, 24(%r13)
	shrq	$32, %rax
	movw	%ax, 28(%r13)
	movl	16(%r13), %eax
	movzwl	20(%r13), %ecx
	xorl	%edx, %edx
	cmpw	12(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	8(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB12_20
## %bb.18:
	movq	8(%r13), %rax
	movzwl	4(%r12), %ecx
	movw	%cx, 4(%r14)
	movl	(%r12), %ecx
	movl	%ecx, (%r14)
	movl	%eax, 16(%r13)
	shrq	$32, %rax
	movw	%ax, 20(%r13)
	movl	8(%r13), %eax
	movzwl	12(%r13), %ecx
	xorl	%edx, %edx
	cmpw	4(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB12_20
## %bb.19:
	movq	(%r13), %rax
	movzwl	4(%r14), %ecx
	movw	%cx, 4(%r13)
	movl	(%r14), %ecx
	movl	%ecx, (%r13)
	movl	%eax, 8(%r13)
	shrq	$32, %rax
	movw	%ax, 12(%r13)
	jmp	LBB12_20
LBB12_14:
	leaq	8(%r13), %rsi
	leaq	16(%r13), %rdx
	movq	%r13, %rdi
	movq	-56(%rbp), %rcx                 ## 8-byte Reload
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_ ## TAILCALL
LBB12_22:
	cmpq	%r15, %r13
	sete	%cl
	leaq	8(%r13), %rdx
	cmpq	%r15, %rdx
	sete	%al
	orb	%cl, %al
	cmpb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	jne	LBB12_32
## %bb.23:
	testb	%al, %al
	jne	LBB12_20
## %bb.24:
	xorl	%eax, %eax
	movq	%r13, %rdi
	jmp	LBB12_25
LBB12_29:                               ##   in Loop: Header=BB12_25 Depth=1
	movq	%r13, %r9
LBB12_30:                               ##   in Loop: Header=BB12_25 Depth=1
	movl	%esi, (%r9)
	movw	%dx, 4(%r9)
LBB12_31:                               ##   in Loop: Header=BB12_25 Depth=1
	leaq	8(%rcx), %rdx
	addq	$8, %rax
	movq	%rcx, %rdi
	cmpq	%r15, %rdx
	je	LBB12_20
LBB12_25:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB12_27 Depth 2
	movq	%rdx, %rcx
	movl	8(%rdi), %edx
	movzwl	12(%rdi), %esi
	xorl	%r8d, %r8d
	cmpw	4(%rdi), %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	(%rdi), %edx
	setb	%sil
	cmovel	%r8d, %esi
	cmpb	$1, %sil
	jne	LBB12_31
## %bb.26:                              ##   in Loop: Header=BB12_25 Depth=1
	movq	8(%rdi), %rdx
	movl	%edx, %esi
	shrq	$32, %rdx
	movzwl	4(%rdi), %r8d
	movw	%r8w, 4(%rcx)
	movl	(%rdi), %r8d
	movl	%r8d, (%rcx)
	movq	%rax, %r8
	movq	%r13, %r9
	cmpq	%r13, %rdi
	je	LBB12_30
	.p2align	4
LBB12_27:                               ##   Parent Loop BB12_25 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	xorl	%edi, %edi
	cmpw	%dx, -4(%r13,%r8)
	seta	%dil
	xorl	%r10d, %r10d
	cmpl	%esi, -8(%r13,%r8)
	seta	%r10b
	leaq	(%r13,%r8), %r9
	cmovel	%edi, %r10d
	testb	%r10b, %r10b
	je	LBB12_30
## %bb.28:                              ##   in Loop: Header=BB12_27 Depth=2
	leaq	(%r8,%r13), %rdi
	addq	$-8, %rdi
	movzwl	4(%rdi), %r10d
	movw	%r10w, 4(%r9)
	movl	(%rdi), %edi
	movl	%edi, (%r9)
	addq	$-8, %r8
	jne	LBB12_27
	jmp	LBB12_29
LBB12_39:
	cmpq	%r15, %r13
	je	LBB12_20
## %bb.40:
	leaq	-2(%rcx), %r12
	shrq	%r12
	movq	%r12, %rax
	jmp	LBB12_41
	.p2align	4
LBB12_54:                               ##   in Loop: Header=BB12_41 Depth=1
	leaq	(,%r9,8), %rax
	addq	%r13, %rax
	movl	%edx, (%rax)
	movw	%di, 4(%rax)
	movq	-72(%rbp), %rax                 ## 8-byte Reload
LBB12_55:                               ##   in Loop: Header=BB12_41 Depth=1
	subq	$1, %rax
	jb	LBB12_56
LBB12_41:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB12_47 Depth 2
	cmpq	%rax, %r12
	jb	LBB12_55
## %bb.42:                              ##   in Loop: Header=BB12_41 Depth=1
	leaq	1(,%rax,2), %rsi
	leaq	2(,%rax,2), %r9
	cmpq	%rcx, %r9
	jae	LBB12_43
## %bb.44:                              ##   in Loop: Header=BB12_41 Depth=1
	leaq	(%rax,%rax), %r10
	movl	(%r13,%rsi,8), %edi
	movl	4(%r13,%rsi,8), %r8d
	movl	16(%r13,%r10,8), %r11d
	movl	20(%r13,%r10,8), %r10d
	xorl	%ebx, %ebx
	cmpw	%r10w, %r8w
	setb	%bl
	xorl	%r14d, %r14d
	cmpl	%r11d, %edi
	setb	%r14b
	cmovnel	%r14d, %ebx
	testb	%bl, %bl
	cmovneq	%r9, %rsi
	cmovnel	%r11d, %edi
	cmovnel	%r10d, %r8d
	jmp	LBB12_45
	.p2align	4
LBB12_43:                               ##   in Loop: Header=BB12_41 Depth=1
	movl	(%r13,%rsi,8), %edi
	movzwl	4(%r13,%rsi,8), %r8d
LBB12_45:                               ##   in Loop: Header=BB12_41 Depth=1
	xorl	%r9d, %r9d
	cmpw	4(%r13,%rax,8), %r8w
	setb	%r9b
	xorl	%r8d, %r8d
	cmpl	(%r13,%rax,8), %edi
	setb	%r8b
	cmovel	%r9d, %r8d
	testb	%r8b, %r8b
	jne	LBB12_55
## %bb.46:                              ##   in Loop: Header=BB12_41 Depth=1
	movq	(%r13,%rax,8), %rdi
	movl	%edi, %edx
	shrq	$32, %rdi
	movq	%rax, -72(%rbp)                 ## 8-byte Spill
	movq	%rax, %r10
	movl	%edx, -64(%rbp)                 ## 4-byte Spill
	jmp	LBB12_47
	.p2align	4
LBB12_52:                               ##   in Loop: Header=BB12_47 Depth=2
	movq	%r11, %rsi
	movq	%r8, %r15
	movq	%rdi, %r12
	movq	%rdx, %rdi
	movl	-64(%rbp), %edx                 ## 4-byte Reload
LBB12_53:                               ##   in Loop: Header=BB12_47 Depth=2
	xorl	%eax, %eax
	cmpw	%di, %bx
	setb	%al
	xorl	%r11d, %r11d
	cmpl	%edx, %r10d
	setb	%r11b
	cmovel	%eax, %r11d
	movq	%r9, %r10
	cmpb	$1, %r11b
	je	LBB12_54
LBB12_47:                               ##   Parent Loop BB12_41 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rsi, %r9
	movzwl	4(%r13,%rsi,8), %esi
	movw	%si, 4(%r13,%r10,8)
	movl	(%r13,%r9,8), %esi
	movl	%esi, (%r13,%r10,8)
	cmpq	%r9, %r12
	jl	LBB12_54
## %bb.48:                              ##   in Loop: Header=BB12_47 Depth=2
	leaq	1(,%r9,2), %rsi
	leaq	2(,%r9,2), %r11
	cmpq	%rcx, %r11
	jge	LBB12_49
## %bb.50:                              ##   in Loop: Header=BB12_47 Depth=2
	movq	%rdi, %rdx
	movq	%r12, %rdi
	movq	%r15, %r8
	leaq	(%r9,%r9), %rbx
	movl	(%r13,%rsi,8), %r14d
	movl	4(%r13,%rsi,8), %r12d
	movl	16(%r13,%rbx,8), %r10d
	movl	20(%r13,%rbx,8), %ebx
	xorl	%r15d, %r15d
	cmpw	%bx, %r12w
	setb	%r15b
	xorl	%eax, %eax
	cmpl	%r10d, %r14d
	setb	%al
	cmovnel	%eax, %r15d
	testb	%r15b, %r15b
	jne	LBB12_52
## %bb.51:                              ##   in Loop: Header=BB12_47 Depth=2
	movq	%rsi, %r11
	movl	%r14d, %r10d
	movl	%r12d, %ebx
	jmp	LBB12_52
	.p2align	4
LBB12_49:                               ##   in Loop: Header=BB12_47 Depth=2
	movl	(%r13,%rsi,8), %r10d
	movzwl	4(%r13,%rsi,8), %ebx
	jmp	LBB12_53
	.p2align	4
LBB12_62:                               ##   in Loop: Header=BB12_56 Depth=1
	movl	%edx, (%rax)
	shrq	$32, %rdx
	movw	%dx, 4(%rax)
LBB12_69:                               ##   in Loop: Header=BB12_56 Depth=1
	cmpq	$2, %rcx
	leaq	-1(%rcx), %rcx
	jle	LBB12_20
LBB12_56:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB12_57 Depth 2
                                        ##     Child Loop BB12_66 Depth 2
	movq	(%r13), %rdx
	leaq	-2(%rcx), %rsi
	shrq	%rsi
	movq	%r13, %rdi
	xorl	%r10d, %r10d
	jmp	LBB12_57
	.p2align	4
LBB12_60:                               ##   in Loop: Header=BB12_57 Depth=2
	movzwl	4(%rax), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rax), %r9d
	movl	%r9d, (%rdi)
	movq	%rax, %rdi
	movq	%r8, %r10
	cmpq	%rsi, %r8
	jg	LBB12_61
LBB12_57:                               ##   Parent Loop BB12_56 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	leaq	(%rdi,%r10,8), %rax
	addq	$8, %rax
	leaq	1(,%r10,2), %r8
	leaq	2(,%r10,2), %r9
	cmpq	%rcx, %r9
	jge	LBB12_60
## %bb.58:                              ##   in Loop: Header=BB12_57 Depth=2
	leaq	(%rdi,%r10,8), %r10
	movl	8(%r10), %r11d
	movzwl	12(%r10), %ebx
	xorl	%r14d, %r14d
	cmpw	20(%r10), %bx
	setb	%r14b
	xorl	%ebx, %ebx
	cmpl	16(%r10), %r11d
	setb	%bl
	cmovel	%r14d, %ebx
	testb	%bl, %bl
	je	LBB12_60
## %bb.59:                              ##   in Loop: Header=BB12_57 Depth=2
	addq	$16, %r10
	movq	%r10, %rax
	movq	%r9, %r8
	jmp	LBB12_60
	.p2align	4
LBB12_61:                               ##   in Loop: Header=BB12_56 Depth=1
	addq	$-8, %r15
	cmpq	%r15, %rax
	je	LBB12_62
## %bb.63:                              ##   in Loop: Header=BB12_56 Depth=1
	movzwl	4(%r15), %esi
	movw	%si, 4(%rax)
	movl	(%r15), %esi
	movl	%esi, (%rax)
	movq	%rdx, %rsi
	shrq	$32, %rsi
	movw	%si, 4(%r15)
	movl	%edx, (%r15)
	movq	%rax, %rdx
	subq	%r13, %rdx
	addq	$8, %rdx
	sarq	$3, %rdx
	cmpq	$2, %rdx
	jl	LBB12_69
## %bb.64:                              ##   in Loop: Header=BB12_56 Depth=1
	addq	$-2, %rdx
	shrq	%rdx
	movl	(%r13,%rdx,8), %esi
	movzwl	4(%r13,%rdx,8), %edi
	xorl	%r8d, %r8d
	cmpw	4(%rax), %di
	setb	%r8b
	xorl	%edi, %edi
	cmpl	(%rax), %esi
	setb	%dil
	cmovel	%r8d, %edi
	cmpb	$1, %dil
	jne	LBB12_69
## %bb.65:                              ##   in Loop: Header=BB12_56 Depth=1
	leaq	(,%rdx,8), %r8
	addq	%r13, %r8
	movq	(%rax), %rsi
	movl	%esi, %edi
	shrq	$32, %rsi
	.p2align	4
LBB12_66:                               ##   Parent Loop BB12_56 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rax, %r9
	movq	%r8, %rax
	movzwl	4(%r8), %r8d
	movw	%r8w, 4(%r9)
	movl	(%rax), %r8d
	movl	%r8d, (%r9)
	testq	%rdx, %rdx
	je	LBB12_68
## %bb.67:                              ##   in Loop: Header=BB12_66 Depth=2
	decq	%rdx
	shrq	%rdx
	leaq	(,%rdx,8), %r8
	addq	%r13, %r8
	xorl	%r9d, %r9d
	cmpw	%si, 4(%r13,%rdx,8)
	setb	%r9b
	xorl	%r10d, %r10d
	cmpl	%edi, (%r13,%rdx,8)
	setb	%r10b
	cmovel	%r9d, %r10d
	testb	%r10b, %r10b
	jne	LBB12_66
LBB12_68:                               ##   in Loop: Header=BB12_56 Depth=1
	movl	%edi, (%rax)
	movw	%si, 4(%rax)
	jmp	LBB12_69
LBB12_7:
	testb	%dl, %dl
	je	LBB12_20
## %bb.8:
	movq	8(%r13), %rcx
	movq	-56(%rbp), %rsi                 ## 8-byte Reload
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	movl	8(%r13), %ecx
	movzwl	12(%r13), %edx
	xorl	%esi, %esi
	cmpw	4(%r13), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r13), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB12_20
## %bb.9:
	movq	(%r13), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %eax
	movl	%eax, (%r13)
	movl	%ecx, 8(%r13)
	shrq	$32, %rcx
	movw	%cx, 12(%r13)
	jmp	LBB12_20
LBB12_32:
	testb	%al, %al
	je	LBB12_33
	jmp	LBB12_20
	.p2align	4
LBB12_37:                               ##   in Loop: Header=BB12_33 Depth=1
	leaq	8(%rax), %rdx
	movq	%rax, %r13
	cmpq	%r15, %rdx
	je	LBB12_20
LBB12_33:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB12_35 Depth 2
	movq	%rdx, %rax
	movl	8(%r13), %ecx
	movzwl	12(%r13), %edx
	xorl	%esi, %esi
	cmpw	4(%r13), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r13), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB12_37
## %bb.34:                              ##   in Loop: Header=BB12_33 Depth=1
	movq	(%rax), %rcx
	movl	%ecx, %edx
	shrq	$32, %rcx
	.p2align	4
LBB12_35:                               ##   Parent Loop BB12_33 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	4(%r13), %esi
	movw	%si, 12(%r13)
	movl	(%r13), %esi
	movl	%esi, 8(%r13)
	xorl	%esi, %esi
	cmpw	%cx, -4(%r13)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%edx, -8(%r13)
	seta	%dil
	leaq	-8(%r13), %r13
	cmovel	%esi, %edi
	testb	%dil, %dil
	jne	LBB12_35
## %bb.36:                              ##   in Loop: Header=BB12_33 Depth=1
	movl	%edx, 8(%r13)
	movw	%cx, 12(%r13)
	jmp	LBB12_37
LBB12_12:
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movl	%ecx, %edx
	movl	%ecx, 8(%r13)
	shrq	$32, %rcx
	movw	%cx, 12(%r13)
	xorl	%esi, %esi
	cmpw	%cx, -4(%r15)
	setb	%sil
	xorl	%ecx, %ecx
	cmpl	%edx, -8(%r15)
	setb	%cl
	cmovel	%esi, %ecx
	cmpb	$1, %cl
	jne	LBB12_20
## %bb.13:
	movq	(%rax), %rcx
	movq	-56(%rbp), %rsi                 ## 8-byte Reload
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	jmp	LBB12_20
	.cfi_endproc
	.p2align	2
	.data_region jt32
L12_0_set_20 = LBB12_20-LJTI12_0
L12_0_set_4 = LBB12_4-LJTI12_0
L12_0_set_6 = LBB12_6-LJTI12_0
L12_0_set_14 = LBB12_14-LJTI12_0
L12_0_set_15 = LBB12_15-LJTI12_0
LJTI12_0:
	.long	L12_0_set_20
	.long	L12_0_set_20
	.long	L12_0_set_4
	.long	L12_0_set_6
	.long	L12_0_set_14
	.long	L12_0_set_15
	.end_data_region
                                        ## -- End function
	.p2align	4                               ## -- Begin function _ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_: ## @_ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	movl	(%rsi), %r9d
	movzwl	4(%rsi), %r10d
	xorl	%eax, %eax
	cmpw	4(%rdi), %r10w
	setb	%al
	xorl	%r11d, %r11d
	cmpl	(%rdi), %r9d
	setb	%r11b
	cmovel	%eax, %r11d
	movl	(%rdx), %eax
	movzwl	4(%rdx), %r8d
	xorl	%ebx, %ebx
	cmpw	%r10w, %r8w
	setb	%bl
	xorl	%r10d, %r10d
	cmpl	%r9d, %eax
	setb	%r10b
	cmovel	%ebx, %r10d
	testb	%r11b, %r11b
	je	LBB13_1
## %bb.4:
	movq	(%rdi), %r9
	testb	%r10b, %r10b
	je	LBB13_6
## %bb.5:
	movzwl	4(%rdx), %eax
	movw	%ax, 4(%rdi)
	movl	(%rdx), %eax
	movl	%eax, (%rdi)
	movq	%r9, %r8
	shrq	$32, %r8
	movw	%r8w, 4(%rdx)
	movl	%r9d, (%rdx)
	movl	%r9d, %eax
	jmp	LBB13_8
LBB13_1:
	testb	%r10b, %r10b
	je	LBB13_8
## %bb.2:
	movq	(%rsi), %rax
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movl	%eax, (%rdx)
	movq	%rax, %r8
	shrq	$32, %r8
	movw	%r8w, 4(%rdx)
	movl	(%rsi), %r9d
	movzwl	4(%rsi), %r10d
	xorl	%r11d, %r11d
	cmpw	4(%rdi), %r10w
	setb	%r11b
	xorl	%r10d, %r10d
	cmpl	(%rdi), %r9d
	setb	%r10b
	cmovel	%r11d, %r10d
	cmpb	$1, %r10b
	jne	LBB13_8
## %bb.3:
	movq	(%rdi), %rax
	movzwl	4(%rsi), %r8d
	movw	%r8w, 4(%rdi)
	movl	(%rsi), %r8d
	movl	%r8d, (%rdi)
	movl	%eax, (%rsi)
	shrq	$32, %rax
	movw	%ax, 4(%rsi)
	movl	(%rdx), %eax
	movzwl	4(%rdx), %r8d
	jmp	LBB13_8
LBB13_6:
	movzwl	4(%rsi), %eax
	movw	%ax, 4(%rdi)
	movl	(%rsi), %eax
	movl	%eax, (%rdi)
	movq	%r9, %r10
	shrq	$32, %r10
	movw	%r10w, 4(%rsi)
	movl	%r9d, (%rsi)
	movl	(%rdx), %eax
	movzwl	4(%rdx), %r8d
	xorl	%r11d, %r11d
	cmpw	%r10w, %r8w
	setb	%r11b
	xorl	%r10d, %r10d
	cmpl	%r9d, %eax
	setb	%r10b
	cmovel	%r11d, %r10d
	cmpb	$1, %r10b
	jne	LBB13_8
## %bb.7:
	movq	(%rsi), %rax
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movl	%eax, (%rdx)
	movq	%rax, %r8
	shrq	$32, %r8
	movw	%r8w, 4(%rdx)
LBB13_8:
	xorl	%r9d, %r9d
	cmpw	%r8w, 4(%rcx)
	setb	%r9b
	xorl	%r8d, %r8d
	cmpl	%eax, (%rcx)
	setb	%r8b
	cmovel	%r9d, %r8d
	cmpb	$1, %r8b
	jne	LBB13_12
## %bb.9:
	movq	(%rdx), %rax
	movzwl	4(%rcx), %r8d
	movw	%r8w, 4(%rdx)
	movl	(%rcx), %r8d
	movl	%r8d, (%rdx)
	movl	%eax, (%rcx)
	shrq	$32, %rax
	movw	%ax, 4(%rcx)
	movl	(%rdx), %eax
	movzwl	4(%rdx), %ecx
	xorl	%r8d, %r8d
	cmpw	4(%rsi), %cx
	setb	%r8b
	xorl	%ecx, %ecx
	cmpl	(%rsi), %eax
	setb	%cl
	cmovel	%r8d, %ecx
	cmpb	$1, %cl
	jne	LBB13_12
## %bb.10:
	movq	(%rsi), %rax
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%rsi)
	movl	(%rdx), %ecx
	movl	%ecx, (%rsi)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	movl	(%rsi), %eax
	movzwl	4(%rsi), %ecx
	xorl	%edx, %edx
	cmpw	4(%rdi), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%rdi), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB13_12
## %bb.11:
	movq	(%rdi), %rax
	movzwl	4(%rsi), %ecx
	movw	%cx, 4(%rdi)
	movl	(%rsi), %ecx
	movl	%ecx, (%rdi)
	movl	%eax, (%rsi)
	shrq	$32, %rax
	movw	%ax, 4(%rsi)
LBB13_12:
	popq	%rbx
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4                               ## -- Begin function _ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_: ## @_ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rcx
	subq	%rdi, %rcx
	sarq	$3, %rcx
	movb	$1, %al
	cmpq	$5, %rcx
	ja	LBB14_19
## %bb.1:
	leaq	LJTI14_0(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
LBB14_2:
	movl	-8(%rsi), %ecx
	movzwl	-4(%rsi), %edx
	xorl	%r8d, %r8d
	cmpw	4(%rdi), %dx
	setb	%r8b
	xorl	%edx, %edx
	cmpl	(%rdi), %ecx
	setb	%dl
	cmovel	%r8d, %edx
	cmpb	$1, %dl
	jne	LBB14_37
## %bb.3:
	addq	$-8, %rsi
	movq	(%rdi), %rcx
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rdi)
	movl	(%rsi), %edx
	movl	%edx, (%rdi)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	jmp	LBB14_37
LBB14_4:
	movl	8(%rdi), %r8d
	movzwl	12(%rdi), %r9d
	xorl	%edx, %edx
	cmpw	4(%rdi), %r9w
	setb	%dl
	xorl	%r10d, %r10d
	cmpl	(%rdi), %r8d
	leaq	8(%rdi), %rcx
	setb	%r10b
	cmovel	%edx, %r10d
	leaq	-8(%rsi), %rdx
	xorl	%r11d, %r11d
	cmpw	%r9w, -4(%rsi)
	setb	%r11b
	xorl	%r9d, %r9d
	cmpl	%r8d, -8(%rsi)
	setb	%r9b
	cmovel	%r11d, %r9d
	testb	%r10b, %r10b
	je	LBB14_5
## %bb.8:
	movq	(%rdi), %r8
	testb	%r9b, %r9b
	je	LBB14_10
## %bb.9:
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%rdi)
	movl	(%rdx), %ecx
	movl	%ecx, (%rdi)
	movq	%r8, %rcx
	shrq	$32, %rcx
	movw	%cx, 4(%rdx)
	movl	%r8d, (%rdx)
	jmp	LBB14_37
LBB14_13:
	leaq	8(%rdi), %rbx
	leaq	16(%rdi), %r14
	leaq	24(%rdi), %r15
	movq	%rdi, %r12
	movq	%rsi, %r13
	movq	%rbx, %rsi
	movq	%r14, %rdx
	movq	%r15, %rcx
	callq	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	movl	-8(%r13), %ecx
	movzwl	-4(%r13), %edx
	xorl	%esi, %esi
	cmpw	28(%r12), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	24(%r12), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB14_14
## %bb.15:
	movq	%r13, %rax
	addq	$-8, %rax
	movq	24(%r12), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r15)
	movl	(%rax), %edx
	movl	%edx, (%r15)
	movl	%ecx, (%rax)
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	movl	24(%r12), %eax
	movzwl	28(%r12), %ecx
	xorl	%edx, %edx
	cmpw	20(%r12), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	16(%r12), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	movb	$1, %al
	jne	LBB14_37
## %bb.16:
	movq	16(%r12), %rcx
	movzwl	4(%r15), %edx
	movw	%dx, 4(%r14)
	movl	(%r15), %edx
	movl	%edx, (%r14)
	movl	%ecx, 24(%r12)
	shrq	$32, %rcx
	movw	%cx, 28(%r12)
	movl	16(%r12), %ecx
	movzwl	20(%r12), %edx
	xorl	%esi, %esi
	cmpw	12(%r12), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	8(%r12), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB14_37
## %bb.17:
	movq	8(%r12), %rcx
	movzwl	4(%r14), %edx
	movw	%dx, 4(%rbx)
	movl	(%r14), %edx
	movl	%edx, (%rbx)
	movl	%ecx, 16(%r12)
	shrq	$32, %rcx
	movw	%cx, 20(%r12)
	movl	8(%r12), %ecx
	movzwl	12(%r12), %edx
	xorl	%esi, %esi
	cmpw	4(%r12), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r12), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB14_37
## %bb.18:
	movq	(%r12), %rcx
	movzwl	4(%rbx), %edx
	movw	%dx, 4(%r12)
	movl	(%rbx), %edx
	movl	%edx, (%r12)
	movl	%ecx, 8(%r12)
	shrq	$32, %rcx
	movw	%cx, 12(%r12)
	jmp	LBB14_37
LBB14_19:
	leaq	16(%rdi), %rcx
	movl	8(%rdi), %r14d
	movzwl	12(%rdi), %ebx
	movl	(%rdi), %r8d
	movzwl	4(%rdi), %r9d
	xorl	%edx, %edx
	cmpw	%r9w, %bx
	setb	%dl
	xorl	%r15d, %r15d
	cmpl	%r8d, %r14d
	setb	%r15b
	cmovel	%edx, %r15d
	leaq	8(%rdi), %rdx
	movl	16(%rdi), %r10d
	movzwl	20(%rdi), %r11d
	xorl	%r12d, %r12d
	cmpw	%bx, %r11w
	setb	%r12b
	xorl	%ebx, %ebx
	cmpl	%r14d, %r10d
	setb	%bl
	cmovel	%r12d, %ebx
	testb	%r15b, %r15b
	je	LBB14_20
## %bb.23:
	movq	(%rdi), %r8
	testb	%bl, %bl
	je	LBB14_25
## %bb.24:
	movzwl	4(%rcx), %edx
	movw	%dx, 4(%rdi)
	movl	(%rcx), %edx
	movl	%edx, (%rdi)
	movl	%r8d, 16(%rdi)
	shrq	$32, %r8
	movw	%r8w, 20(%rdi)
	jmp	LBB14_27
LBB14_12:
	leaq	8(%rdi), %rax
	leaq	16(%rdi), %rdx
	addq	$-8, %rsi
	movq	%rsi, %rcx
	movq	%rax, %rsi
	callq	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	movb	$1, %al
	jmp	LBB14_37
LBB14_5:
	testb	%r9b, %r9b
	je	LBB14_37
## %bb.6:
	movq	8(%rdi), %rsi
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rcx)
	movl	(%rdx), %r8d
	movl	%r8d, (%rcx)
	movl	%esi, (%rdx)
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	movl	8(%rdi), %edx
	movzwl	12(%rdi), %esi
	xorl	%r8d, %r8d
	cmpw	4(%rdi), %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	(%rdi), %edx
	setb	%sil
	cmovel	%r8d, %esi
	cmpb	$1, %sil
	jne	LBB14_37
## %bb.7:
	movq	(%rdi), %rdx
	movzwl	4(%rcx), %esi
	movw	%si, 4(%rdi)
	movl	(%rcx), %ecx
	movl	%ecx, (%rdi)
	movl	%edx, 8(%rdi)
	shrq	$32, %rdx
	movw	%dx, 12(%rdi)
	jmp	LBB14_37
LBB14_14:
	movb	$1, %al
	jmp	LBB14_37
LBB14_20:
	testb	%bl, %bl
	je	LBB14_27
## %bb.21:
	movq	8(%rdi), %r10
	movzwl	4(%rcx), %r11d
	movw	%r11w, 4(%rdx)
	movl	(%rcx), %r11d
	movl	%r11d, (%rdx)
	movl	%r10d, 16(%rdi)
	shrq	$32, %r10
	movw	%r10w, 20(%rdi)
	xorl	%r10d, %r10d
	cmpw	%r9w, 12(%rdi)
	setb	%r10b
	xorl	%r9d, %r9d
	cmpl	%r8d, 8(%rdi)
	setb	%r9b
	cmovel	%r10d, %r9d
	cmpb	$1, %r9b
	jne	LBB14_27
## %bb.22:
	movq	(%rdi), %r8
	movzwl	4(%rdx), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rdx), %edx
	movl	%edx, (%rdi)
	movl	%r8d, 8(%rdi)
	shrq	$32, %r8
	movw	%r8w, 12(%rdi)
	jmp	LBB14_27
LBB14_10:
	movzwl	4(%rcx), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rcx), %r9d
	movl	%r9d, (%rdi)
	movl	%r8d, %r9d
	movl	%r8d, 8(%rdi)
	shrq	$32, %r8
	movw	%r8w, 12(%rdi)
	xorl	%edi, %edi
	cmpw	%r8w, -4(%rsi)
	setb	%dil
	xorl	%r8d, %r8d
	cmpl	%r9d, -8(%rsi)
	setb	%r8b
	cmovel	%edi, %r8d
	cmpb	$1, %r8b
	jne	LBB14_37
## %bb.11:
	movq	(%rcx), %rsi
	movzwl	4(%rdx), %edi
	movw	%di, 4(%rcx)
	movl	(%rdx), %edi
	movl	%edi, (%rcx)
	movl	%esi, (%rdx)
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	jmp	LBB14_37
LBB14_25:
	movzwl	4(%rdx), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rdx), %r9d
	movl	%r9d, (%rdi)
	movl	%r8d, %r9d
	movl	%r8d, 8(%rdi)
	shrq	$32, %r8
	movw	%r8w, 12(%rdi)
	xorl	%ebx, %ebx
	cmpw	%r8w, %r11w
	setb	%bl
	xorl	%r8d, %r8d
	cmpl	%r9d, %r10d
	setb	%r8b
	cmovnel	%r8d, %ebx
	cmpb	$1, %bl
	jne	LBB14_27
## %bb.26:
	movq	(%rdx), %r8
	movzwl	4(%rcx), %r9d
	movw	%r9w, 4(%rdx)
	movl	(%rcx), %r9d
	movl	%r9d, (%rdx)
	movl	%r8d, (%rcx)
	shrq	$32, %r8
	movw	%r8w, 4(%rcx)
LBB14_27:
	leaq	24(%rdi), %rdx
	cmpq	%rsi, %rdx
	je	LBB14_37
## %bb.28:
	xorl	%r8d, %r8d
	movl	$16, %r9d
	jmp	LBB14_29
	.p2align	4
LBB14_33:                               ##   in Loop: Header=BB14_29 Depth=1
	movq	%rdi, %rbx
LBB14_34:                               ##   in Loop: Header=BB14_29 Depth=1
	movl	%r11d, (%rbx)
	movw	%r10w, 4(%rbx)
	incl	%r8d
	cmpl	$8, %r8d
	je	LBB14_35
LBB14_36:                               ##   in Loop: Header=BB14_29 Depth=1
	movq	%rdx, %rcx
	addq	$8, %rdx
	addq	$8, %r9
	cmpq	%rsi, %rdx
	je	LBB14_37
LBB14_29:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB14_31 Depth 2
	movl	(%rdx), %r10d
	movzwl	4(%rdx), %r11d
	xorl	%ebx, %ebx
	cmpw	4(%rcx), %r11w
	setb	%bl
	xorl	%r11d, %r11d
	cmpl	(%rcx), %r10d
	setb	%r11b
	cmovel	%ebx, %r11d
	cmpb	$1, %r11b
	jne	LBB14_36
## %bb.30:                              ##   in Loop: Header=BB14_29 Depth=1
	movq	(%rdx), %r10
	movl	%r10d, %r11d
	shrq	$32, %r10
	movzwl	4(%rcx), %ebx
	movw	%bx, 4(%rdx)
	movl	(%rcx), %ecx
	movl	%ecx, (%rdx)
	movq	%r9, %rcx
	.p2align	4
LBB14_31:                               ##   Parent Loop BB14_29 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	xorl	%r14d, %r14d
	cmpw	%r10w, -4(%rdi,%rcx)
	seta	%r14b
	xorl	%r15d, %r15d
	cmpl	%r11d, -8(%rdi,%rcx)
	seta	%r15b
	leaq	(%rdi,%rcx), %rbx
	cmovel	%r14d, %r15d
	testb	%r15b, %r15b
	je	LBB14_34
## %bb.32:                              ##   in Loop: Header=BB14_31 Depth=2
	leaq	(%rdi,%rcx), %r14
	addq	$-8, %r14
	movzwl	4(%r14), %r15d
	movw	%r15w, 4(%rbx)
	movl	(%r14), %r14d
	movl	%r14d, (%rbx)
	addq	$-8, %rcx
	jne	LBB14_31
	jmp	LBB14_33
LBB14_35:
	addq	$8, %rdx
	cmpq	%rsi, %rdx
	sete	%al
LBB14_37:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
	.p2align	2
	.data_region jt32
L14_0_set_37 = LBB14_37-LJTI14_0
L14_0_set_2 = LBB14_2-LJTI14_0
L14_0_set_4 = LBB14_4-LJTI14_0
L14_0_set_12 = LBB14_12-LJTI14_0
L14_0_set_13 = LBB14_13-LJTI14_0
LJTI14_0:
	.long	L14_0_set_37
	.long	L14_0_set_37
	.long	L14_0_set_2
	.long	L14_0_set_4
	.long	L14_0_set_12
	.long	L14_0_set_13
	.end_data_region
                                        ## -- End function
	.section	__TEXT,__cstring,cstring_literals
L_.str:                                 ## @.str
	.asciz	"Huffman capacity"

L_.str.1:                               ## @.str.1
	.asciz	"Huffman output extent"

L_.str.2:                               ## @.str.2
	.asciz	"Huffman stored extent"

L_.str.3:                               ## @.str.3
	.asciz	"Huffman constant extent"

L_.str.4:                               ## @.str.4
	.asciz	"Huffman coding"

L_.str.5:                               ## @.str.5
	.asciz	"Huffman coded extent"

L_.str.6:                               ## @.str.6
	.asciz	"Huffman stream extent"

L_.str.8:                               ## @.str.8
	.asciz	"layout input bound"

L_.str.9:                               ## @.str.9
	.asciz	"layout encode storage"

L_.str.10:                              ## @.str.10
	.asciz	"layout input symbol"

L_.str.11:                              ## @.str.11
	.asciz	"layout header"

L_.str.12:                              ## @.str.12
	.asciz	"layout size"

L_.str.13:                              ## @.str.13
	.asciz	"layout decode workspace"

L_.str.14:                              ## @.str.14
	.asciz	"layout trailing bytes"

L_.str.15:                              ## @.str.15
	.asciz	"Huffman nondegenerate population"

L_.str.16:                              ## @.str.16
	.asciz	"package-merge shape"

L_.str.17:                              ## @.str.17
	.asciz	"package-merge feasibility"

L_.str.18:                              ## @.str.18
	.asciz	"Huffman code length"

L_.str.19:                              ## @.str.19
	.asciz	"Huffman prefix population"

L_.str.20:                              ## @.str.20
	.asciz	"Huffman complete tree"

L_.str.21:                              ## @.str.21
	.asciz	"Huffman table capacity"

L_.str.22:                              ## @.str.22
	.asciz	"Huffman reserved table token"

L_.str.23:                              ## @.str.23
	.asciz	"Huffman table run"

L_.str.24:                              ## @.str.24
	.asciz	"Huffman table bound"

L_.str.25:                              ## @.str.25
	.asciz	"Huffman table padding"

L_.str.26:                              ## @.str.26
	.asciz	"Huffman table extent"

L_.str.27:                              ## @.str.27
	.asciz	"Huffman exact byte extent"

L_.str.28:                              ## @.str.28
	.asciz	"Huffman bit padding"

L_.str.29:                              ## @.str.29
	.asciz	"layout tree capacity"

L_.str.30:                              ## @.str.30
	.asciz	"layout tree children"

L_.str.31:                              ## @.str.31
	.asciz	"flat map capacity"

L_.str.32:                              ## @.str.32
	.asciz	"flat map leaf"

L_.str.33:                              ## @.str.33
	.asciz	"layout emit capacity"

L_.str.34:                              ## @.str.34
	.asciz	"nonconstant reconstruction"

L_.str.35:                              ## @.str.35
	.asciz	"node bit extent"

L_.str.36:                              ## @.str.36
	.asciz	"node padding"

L_.str.37:                              ## @.str.37
	.asciz	"flat width"

.subsections_via_symbols
