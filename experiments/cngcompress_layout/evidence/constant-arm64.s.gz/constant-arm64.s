	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE
lCPI0_0:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_1:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE
	.p2align	6
__ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE: ; @_ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	mov	w8, #255                        ; =0xff
	.p2align	6, , 4
; %bb.1:
	cmp	w5, #1
	csel	w10, w8, wzr, eq
	cmp	x7, #8
	b.lo	LBB0_31
; %bb.2:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w11, w4
	mov	x12, #72340172838076673         ; =0x101010101010101
	mul	x11, x11, x12
Lloh0:
	adrp	x12, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x12, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x12, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x12, lCPI0_1@PAGEOFF]
	movi.2d	v2, #0x000000000000ff
	mov	w12, #4                         ; =0x4
	dup.2d	v3, x12
	mov	w13, #40                        ; =0x28
	mov	x14, #-1                        ; =0xffffffffffffffff
Lloh4:
	adrp	x15, __ZN18cngcompress_layout12_GLOBAL__N_19expansionE@PAGE
Lloh5:
	add	x15, x15, __ZN18cngcompress_layout12_GLOBAL__N_19expansionE@PAGEOFF
	b	LBB0_5
LBB0_3:                                 ;   in Loop: Header=BB0_5 Depth=1
	mov	x16, x11
LBB0_4:                                 ;   in Loop: Header=BB0_5 Depth=1
	str	x16, [x6, x9]
	add	x9, x9, #8
	sub	x16, x7, x9
	cmp	x16, #7
	b.ls	LBB0_32
LBB0_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_26 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
	lsr	x16, x9, #3
	ldrb	w17, [x0, x16]
	eor	w16, w10, w17
	cmp	w16, #255
	b.ne	LBB0_8
; %bb.6:                                ;   in Loop: Header=BB0_5 Depth=1
	sub	x1, x3, x8
	cmp	x1, #7
	b.ls	LBB0_11
; %bb.7:                                ;   in Loop: Header=BB0_5 Depth=1
	ldr	x16, [x2, x8]
	add	x8, x8, #8
	b	LBB0_4
LBB0_8:                                 ;   in Loop: Header=BB0_5 Depth=1
	cmp	w10, w17
	b.eq	LBB0_3
; %bb.9:                                ;   in Loop: Header=BB0_5 Depth=1
	sub	x1, x3, x8
	cmp	x1, #7
	b.ls	LBB0_13
; %bb.10:                               ;   in Loop: Header=BB0_5 Depth=1
	ldr	x19, [x2, x8]
	b	LBB0_30
LBB0_11:                                ;   in Loop: Header=BB0_5 Depth=1
	cmp	x3, x8
	b.ne	LBB0_15
; %bb.12:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	x16, #0                         ; =0x0
	add	x8, x8, #8
	b	LBB0_4
LBB0_13:                                ;   in Loop: Header=BB0_5 Depth=1
	cmp	x3, x8
	b.ne	LBB0_17
; %bb.14:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	x19, #0                         ; =0x0
	b	LBB0_30
LBB0_15:                                ;   in Loop: Header=BB0_5 Depth=1
	cmp	x1, #4
	b.hs	LBB0_19
; %bb.16:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	x17, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	b	LBB0_22
LBB0_17:                                ;   in Loop: Header=BB0_5 Depth=1
	cmp	x1, #4
	b.hs	LBB0_25
; %bb.18:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	x17, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	b	LBB0_28
LBB0_19:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x16, x2, x8
	and	x17, x1, #0x4
	movi.2d	v4, #0000000000000000
	and	x19, x1, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB0_20:                                ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x16], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	add.2d	v7, v7, v3
	add.2d	v5, v5, v3
	subs	x19, x19, #4
	b.ne	LBB0_20
; %bb.21:                               ;   in Loop: Header=BB0_5 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x16, d4
	cmp	x1, x17
	b.eq	LBB0_24
LBB0_22:                                ;   in Loop: Header=BB0_5 Depth=1
	sub	x1, x3, x17
	sub	x1, x1, x8
	lsl	x19, x17, #3
	add	x17, x8, x17
	add	x17, x2, x17
LBB0_23:                                ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w20, [x17], #1
	lsl	x20, x20, x19
	orr	x16, x20, x16
	add	x19, x19, #8
	subs	x1, x1, #1
	b.ne	LBB0_23
LBB0_24:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x8, x8, #8
	b	LBB0_4
LBB0_25:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x19, x2, x8
	and	x17, x1, #0x4
	movi.2d	v4, #0000000000000000
	and	x20, x1, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB0_26:                                ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x19], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	dup.2d	v16, x12
	add.2d	v7, v7, v16
	add.2d	v5, v5, v16
	subs	x20, x20, #4
	b.ne	LBB0_26
; %bb.27:                               ;   in Loop: Header=BB0_5 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x19, d4
	cmp	x1, x17
	b.eq	LBB0_30
LBB0_28:                                ;   in Loop: Header=BB0_5 Depth=1
	sub	x1, x3, x17
	sub	x1, x1, x8
	lsl	x20, x17, #3
	add	x17, x8, x17
	add	x17, x2, x17
LBB0_29:                                ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w21, [x17], #1
	lsl	x21, x21, x20
	orr	x19, x21, x19
	add	x20, x20, #8
	subs	x1, x1, #1
	b.ne	LBB0_29
LBB0_30:                                ;   in Loop: Header=BB0_5 Depth=1
	umaddl	x16, w16, w13, x15
	ldr	w17, [x16, #32]
	lsl	w1, w17, #3
	lsl	x1, x14, x1
	bic	x1, x19, x1
	ldp	x19, x20, [x16]
	and	x19, x1, x19
	eor	x1, x19, x1
	orr	x1, x1, x19, lsl #32
	and	x19, x1, x20
	eor	x1, x19, x1
	orr	x1, x1, x19, lsl #16
	ldp	x19, x16, [x16, #16]
	and	x19, x1, x19
	eor	x1, x19, x1
	bic	x16, x11, x16
	orr	x16, x16, x19, lsl #8
	orr	x16, x16, x1
	add	x8, x8, x17
	b	LBB0_4
LBB0_31:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
LBB0_32:
	cmp	x9, x7
	b.lo	LBB0_34
	b	LBB0_36
LBB0_33:                                ;   in Loop: Header=BB0_34 Depth=1
	ldrb	w10, [x2, x8]
	add	x8, x8, #1
	strb	w10, [x6, x9]
	add	x9, x9, #1
	cmp	x7, x9
	b.eq	LBB0_36
LBB0_34:                                ; =>This Inner Loop Header: Depth=1
	lsr	x10, x9, #3
	ldrb	w10, [x0, x10]
	and	w11, w9, #0x7
	lsr	w10, w10, w11
	and	w10, w10, #0x1
	cmp	w10, w5
	b.ne	LBB0_33
; %bb.35:                               ;   in Loop: Header=BB0_34 Depth=1
	mov	x10, x4
	strb	w10, [x6, x9]
	add	x9, x9, #1
	cmp	x7, x9
	b.ne	LBB0_34
LBB0_36:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @_ZN18cngcompress_layout12_GLOBAL__N_19expansionE
__ZN18cngcompress_layout12_GLOBAL__N_19expansionE:
	.space	40
	.space	24
	.quad	255                             ; 0xff
	.long	1                               ; 0x1
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.long	1                               ; 0x1
	.space	4
	.space	24
	.quad	65535                           ; 0xffff
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.long	1                               ; 0x1
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	16711935                        ; 0xff00ff
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	16776960                        ; 0xffff00
	.long	2                               ; 0x2
	.space	4
	.space	24
	.quad	16777215                        ; 0xffffff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.long	1                               ; 0x1
	.space	4
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4278190335                      ; 0xff0000ff
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	4278255360                      ; 0xff00ff00
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4278255615                      ; 0xff00ffff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294902015                      ; 0xffff00ff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294967040                      ; 0xffffff00
	.long	3                               ; 0x3
	.space	4
	.space	24
	.quad	4294967295                      ; 0xffffffff
	.long	4                               ; 0x4
	.space	4
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.long	1                               ; 0x1
	.space	4
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	1095216660735                   ; 0xff000000ff
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	1095216725760                   ; 0xff0000ff00
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1095216726015                   ; 0xff0000ffff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	1095233372160                   ; 0xff00ff0000
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	1095233372415                   ; 0xff00ff00ff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	1095233437440                   ; 0xff00ffff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	1095233437695                   ; 0xff00ffffff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	1099494850560                   ; 0xffff000000
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	1099494850815                   ; 0xffff0000ff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	1099494915840                   ; 0xffff00ff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	1099494916095                   ; 0xffff00ffff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	1099511562495                   ; 0xffffff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	1099511627520                   ; 0xffffffff00
	.long	4                               ; 0x4
	.space	4
	.space	24
	.quad	1099511627775                   ; 0xffffffffff
	.long	5                               ; 0x5
	.space	4
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.long	1                               ; 0x1
	.space	4
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.long	2                               ; 0x2
	.space	4
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	280375465148160                 ; 0xff000000ff00
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465148415                 ; 0xff000000ffff
	.long	3                               ; 0x3
	.space	4
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	280375481794560                 ; 0xff0000ff0000
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	280375481794815                 ; 0xff0000ff00ff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	280375481859840                 ; 0xff0000ffff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	280375481860095                 ; 0xff0000ffffff
	.long	4                               ; 0x4
	.space	4
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	280379743272960                 ; 0xff00ff000000
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	280379743273215                 ; 0xff00ff0000ff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	280379743338240                 ; 0xff00ff00ff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	280379743338495                 ; 0xff00ff00ffff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	280379759984640                 ; 0xff00ffff0000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	280379759984895                 ; 0xff00ffff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	280379760049920                 ; 0xff00ffffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	280379760050175                 ; 0xff00ffffffff
	.long	5                               ; 0x5
	.space	4
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.long	2                               ; 0x2
	.space	4
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	281470681743615                 ; 0xffff000000ff
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	281470681808640                 ; 0xffff0000ff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281470681808895                 ; 0xffff0000ffff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	281470698455040                 ; 0xffff00ff0000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	281470698455295                 ; 0xffff00ff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	281470698520320                 ; 0xffff00ffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	281470698520575                 ; 0xffff00ffffff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	281474959933440                 ; 0xffffff000000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	281474959933695                 ; 0xffffff0000ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	281474959998720                 ; 0xffffff00ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	281474959998975                 ; 0xffffff00ffff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	281474976645375                 ; 0xffffffff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	281474976710400                 ; 0xffffffffff00
	.long	5                               ; 0x5
	.space	4
	.space	24
	.quad	281474976710655                 ; 0xffffffffffff
	.long	6                               ; 0x6
	.space	4
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.long	1                               ; 0x1
	.space	4
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71776119061217535               ; 0xff0000000000ff
	.long	2                               ; 0x2
	.space	4
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	71776119061282560               ; 0xff00000000ff00
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.long	3                               ; 0x3
	.space	4
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	71776119077929215               ; 0xff000000ff00ff
	.long	3                               ; 0x3
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	71776119077994240               ; 0xff000000ffff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.long	4                               ; 0x4
	.space	4
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	71776123339407360               ; 0xff0000ff000000
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	71776123339472640               ; 0xff0000ff00ff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	71776123339472895               ; 0xff0000ff00ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	71776123356119040               ; 0xff0000ffff0000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	71776123356119295               ; 0xff0000ffff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	71776123356184320               ; 0xff0000ffffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184575               ; 0xff0000ffffffff
	.long	5                               ; 0x5
	.space	4
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71777214277877760               ; 0xff00ff00000000
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	71777214277878015               ; 0xff00ff000000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	71777214277943040               ; 0xff00ff0000ff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71777214277943295               ; 0xff00ff0000ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	71777214294589440               ; 0xff00ff00ff0000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	71777214294589695               ; 0xff00ff00ff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	71777214294654720               ; 0xff00ff00ffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	71777214294654975               ; 0xff00ff00ffffff
	.long	5                               ; 0x5
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	71777218556067840               ; 0xff00ffff000000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71777218556068095               ; 0xff00ffff0000ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	71777218556133120               ; 0xff00ffff00ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	71777218556133375               ; 0xff00ffff00ffff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71777218572779520               ; 0xff00ffffff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	71777218572779775               ; 0xff00ffffff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	71777218572844800               ; 0xff00ffffffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	71777218572845055               ; 0xff00ffffffffff
	.long	6                               ; 0x6
	.space	4
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.long	2                               ; 0x2
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72056494526300415               ; 0xffff00000000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	72056494526365440               ; 0xffff000000ff00
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	72056494526365695               ; 0xffff000000ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	72056494543011840               ; 0xffff0000ff0000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	72056494543012095               ; 0xffff0000ff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	72056494543077120               ; 0xffff0000ffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	72056494543077375               ; 0xffff0000ffffff
	.long	5                               ; 0x5
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	72056498804490240               ; 0xffff00ff000000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	72056498804490495               ; 0xffff00ff0000ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	72056498804555520               ; 0xffff00ff00ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	72056498804555775               ; 0xffff00ff00ffff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	72056498821201920               ; 0xffff00ffff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	72056498821202175               ; 0xffff00ffff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	72056498821267200               ; 0xffff00ffffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	72056498821267455               ; 0xffff00ffffffff
	.long	6                               ; 0x6
	.space	4
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.long	3                               ; 0x3
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	72057589742960895               ; 0xffffff000000ff
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	72057589743025920               ; 0xffffff0000ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	72057589743026175               ; 0xffffff0000ffff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	72057589759672320               ; 0xffffff00ff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	72057589759672575               ; 0xffffff00ff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	72057589759737600               ; 0xffffff00ffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	72057589759737855               ; 0xffffff00ffffff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	72057594021150720               ; 0xffffffff000000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	72057594021150975               ; 0xffffffff0000ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	255                             ; 0xff
	.quad	72057594021216000               ; 0xffffffff00ff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	72057594021216255               ; 0xffffffff00ffff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	72057594037862655               ; 0xffffffffff00ff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	72057594037927680               ; 0xffffffffffff00
	.long	6                               ; 0x6
	.space	4
	.space	24
	.quad	72057594037927935               ; 0xffffffffffffff
	.long	7                               ; 0x7
	.space	4
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-72057594037927936              ; 0xff00000000000000
	.long	1                               ; 0x1
	.space	4
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	-72057594037927681              ; 0xff000000000000ff
	.long	2                               ; 0x2
	.space	4
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	-72057594037862656              ; 0xff0000000000ff00
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-72057594037862401              ; 0xff0000000000ffff
	.long	3                               ; 0x3
	.space	4
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	-72057594021216256              ; 0xff00000000ff0000
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	-72057594021216001              ; 0xff00000000ff00ff
	.long	3                               ; 0x3
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	-72057594021150976              ; 0xff00000000ffff00
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	-72057594021150721              ; 0xff00000000ffffff
	.long	4                               ; 0x4
	.space	4
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16711680                        ; 0xff0000
	.quad	-72057589759737856              ; 0xff000000ff000000
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-72057589759737601              ; 0xff000000ff0000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	-72057589759672576              ; 0xff000000ff00ff00
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	-72057589759672321              ; 0xff000000ff00ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-72057589743026176              ; 0xff000000ffff0000
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	-72057589743025921              ; 0xff000000ffff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	-72057589742960896              ; 0xff000000ffffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-72057589742960641              ; 0xff000000ffffffff
	.long	5                               ; 0x5
	.space	4
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	-72056498821267456              ; 0xff0000ff00000000
	.long	2                               ; 0x2
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	-72056498821267201              ; 0xff0000ff000000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	-72056498821202176              ; 0xff0000ff0000ff00
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	-72056498821201921              ; 0xff0000ff0000ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	-72056498804555776              ; 0xff0000ff00ff0000
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	-72056498804555521              ; 0xff0000ff00ff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	-72056498804490496              ; 0xff0000ff00ffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	-72056498804490241              ; 0xff0000ff00ffffff
	.long	5                               ; 0x5
	.space	4
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	-72056494543077376              ; 0xff0000ffff000000
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	-72056494543077121              ; 0xff0000ffff0000ff
	.long	4                               ; 0x4
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	-72056494543012096              ; 0xff0000ffff00ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	-72056494543011841              ; 0xff0000ffff00ffff
	.long	5                               ; 0x5
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	-72056494526365696              ; 0xff0000ffffff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	-72056494526365441              ; 0xff0000ffffff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	-72056494526300416              ; 0xff0000ffffffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	-72056494526300161              ; 0xff0000ffffffffff
	.long	6                               ; 0x6
	.space	4
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	-71777218572845056              ; 0xff00ff0000000000
	.long	2                               ; 0x2
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71777218572844801              ; 0xff00ff00000000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	-71777218572779776              ; 0xff00ff000000ff00
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	-71777218572779521              ; 0xff00ff000000ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71777218556133376              ; 0xff00ff0000ff0000
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	-71777218556133121              ; 0xff00ff0000ff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	-71777218556068096              ; 0xff00ff0000ffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71777218556067841              ; 0xff00ff0000ffffff
	.long	5                               ; 0x5
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	-71777214294654976              ; 0xff00ff00ff000000
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	-71777214294654721              ; 0xff00ff00ff0000ff
	.long	4                               ; 0x4
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	-71777214294589696              ; 0xff00ff00ff00ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	-71777214294589441              ; 0xff00ff00ff00ffff
	.long	5                               ; 0x5
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	-71777214277943296              ; 0xff00ff00ffff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	-71777214277943041              ; 0xff00ff00ffff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	-71777214277878016              ; 0xff00ff00ffffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	-71777214277877761              ; 0xff00ff00ffffffff
	.long	6                               ; 0x6
	.space	4
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71776123356184576              ; 0xff00ffff00000000
	.long	3                               ; 0x3
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	-71776123356184321              ; 0xff00ffff000000ff
	.long	4                               ; 0x4
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	-71776123356119296              ; 0xff00ffff0000ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71776123356119041              ; 0xff00ffff0000ffff
	.long	5                               ; 0x5
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	-71776123339472896              ; 0xff00ffff00ff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	-71776123339472641              ; 0xff00ffff00ff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	-71776123339407616              ; 0xff00ffff00ffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	-71776123339407361              ; 0xff00ffff00ffffff
	.long	6                               ; 0x6
	.space	4
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	-71776119077994496              ; 0xff00ffffff000000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71776119077994241              ; 0xff00ffffff0000ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	-71776119077929216              ; 0xff00ffffff00ff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	-71776119077928961              ; 0xff00ffffff00ffff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71776119061282816              ; 0xff00ffffffff0000
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	-71776119061282561              ; 0xff00ffffffff00ff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	-71776119061217536              ; 0xff00ffffffffff00
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	-71776119061217281              ; 0xff00ffffffffffff
	.long	7                               ; 0x7
	.space	4
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	-281474976710656                ; 0xffff000000000000
	.long	2                               ; 0x2
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-281474976710401                ; 0xffff0000000000ff
	.long	3                               ; 0x3
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	-281474976645376                ; 0xffff00000000ff00
	.long	3                               ; 0x3
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	-281474976645121                ; 0xffff00000000ffff
	.long	4                               ; 0x4
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-281474959998976                ; 0xffff000000ff0000
	.long	3                               ; 0x3
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	-281474959998721                ; 0xffff000000ff00ff
	.long	4                               ; 0x4
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	-281474959933696                ; 0xffff000000ffff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-281474959933441                ; 0xffff000000ffffff
	.long	5                               ; 0x5
	.space	4
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	-281470698520576                ; 0xffff0000ff000000
	.long	3                               ; 0x3
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	-281470698520321                ; 0xffff0000ff0000ff
	.long	4                               ; 0x4
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	-281470698455296                ; 0xffff0000ff00ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	-281470698455041                ; 0xffff0000ff00ffff
	.long	5                               ; 0x5
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	-281470681808896                ; 0xffff0000ffff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	-281470681808641                ; 0xffff0000ffff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	-281470681743616                ; 0xffff0000ffffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	-281470681743361                ; 0xffff0000ffffffff
	.long	6                               ; 0x6
	.space	4
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-280379760050176                ; 0xffff00ff00000000
	.long	3                               ; 0x3
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	-280379760049921                ; 0xffff00ff000000ff
	.long	4                               ; 0x4
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	-280379759984896                ; 0xffff00ff0000ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-280379759984641                ; 0xffff00ff0000ffff
	.long	5                               ; 0x5
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	-280379743338496                ; 0xffff00ff00ff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	-280379743338241                ; 0xffff00ff00ff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	-280379743273216                ; 0xffff00ff00ffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	-280379743272961                ; 0xffff00ff00ffffff
	.long	6                               ; 0x6
	.space	4
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	-280375481860096                ; 0xffff00ffff000000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-280375481859841                ; 0xffff00ffff0000ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	-280375481794816                ; 0xffff00ffff00ff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	-280375481794561                ; 0xffff00ffff00ffff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-280375465148416                ; 0xffff00ffffff0000
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	-280375465148161                ; 0xffff00ffffff00ff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	-280375465083136                ; 0xffff00ffffffff00
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	-280375465082881                ; 0xffff00ffffffffff
	.long	7                               ; 0x7
	.space	4
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	-1099511627776                  ; 0xffffff0000000000
	.long	3                               ; 0x3
	.space	4
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	-1099511627521                  ; 0xffffff00000000ff
	.long	4                               ; 0x4
	.space	4
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	-1099511562496                  ; 0xffffff000000ff00
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	-1099511562241                  ; 0xffffff000000ffff
	.long	5                               ; 0x5
	.space	4
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	-1099494916096                  ; 0xffffff0000ff0000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	-1099494915841                  ; 0xffffff0000ff00ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	-1099494850816                  ; 0xffffff0000ffff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	0                               ; 0x0
	.quad	-1099494850561                  ; 0xffffff0000ffffff
	.long	6                               ; 0x6
	.space	4
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	-1095233437696                  ; 0xffffff00ff000000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	-1095233437441                  ; 0xffffff00ff0000ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	-1095233372416                  ; 0xffffff00ff00ff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	-1095233372161                  ; 0xffffff00ff00ffff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	-1095216726016                  ; 0xffffff00ffff0000
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16776960                        ; 0xffff00
	.quad	-1095216725761                  ; 0xffffff00ffff00ff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	-1095216660736                  ; 0xffffff00ffffff00
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	-1095216660481                  ; 0xffffff00ffffffff
	.long	7                               ; 0x7
	.space	4
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	-4294967296                     ; 0xffffffff00000000
	.long	4                               ; 0x4
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	-4294967041                     ; 0xffffffff000000ff
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	-4294902016                     ; 0xffffffff0000ff00
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	-4294901761                     ; 0xffffffff0000ffff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	-4278255616                     ; 0xffffffff00ff0000
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	-4278255361                     ; 0xffffffff00ff00ff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.quad	-4278190336                     ; 0xffffffff00ffff00
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	-4278190081                     ; 0xffffffff00ffffff
	.long	7                               ; 0x7
	.space	4
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	-16777216                       ; 0xffffffffff000000
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	-16776961                       ; 0xffffffffff0000ff
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	-16711936                       ; 0xffffffffff00ff00
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	-16711681                       ; 0xffffffffff00ffff
	.long	7                               ; 0x7
	.space	4
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.quad	-65536                          ; 0xffffffffffff0000
	.long	6                               ; 0x6
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	-65281                          ; 0xffffffffffff00ff
	.long	7                               ; 0x7
	.space	4
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	-256                            ; 0xffffffffffffff00
	.long	7                               ; 0x7
	.space	4
	.space	24
	.quad	-1                              ; 0xffffffffffffffff
	.long	8                               ; 0x8
	.space	4

.subsections_via_symbols
