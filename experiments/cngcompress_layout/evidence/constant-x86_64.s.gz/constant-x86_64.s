	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.globl	__ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE ## -- Begin function _ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE: ## @_ZN18cngcompress_layout20merge_constant_wordsENSt3__14spanIKhLm18446744073709551615EEES3_hjNS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	leaq	16(%rbp), %rsi
	xorl	%ebx, %ebx
	cmpl	$1, %r9d
	movl	$255, %r13d
	cmovnel	%ebx, %r13d
	movq	24(%rbp), %r15
	cmpq	$8, %r15
	movl	%r8d, -48(%rbp)                 ## 4-byte Spill
	jb	LBB0_32
## %bb.1:
	movl	%r8d, %eax
	movabsq	$72340172838076673, %r8         ## imm = 0x101010101010101
	imulq	%rax, %r8
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movq	(%rsi), %rax
	movq	%rax, -96(%rbp)                 ## 8-byte Spill
	leaq	3(%rdx), %rax
	movq	%rax, -56(%rbp)                 ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	movq	%rdx, -64(%rbp)                 ## 8-byte Spill
	movq	%r15, -88(%rbp)                 ## 8-byte Spill
	movq	%rcx, -80(%rbp)                 ## 8-byte Spill
	jmp	LBB0_6
	.p2align	4
LBB0_2:                                 ##   in Loop: Header=BB0_6 Depth=1
	movq	(%rdx,%r14), %r12
LBB0_3:                                 ##   in Loop: Header=BB0_6 Depth=1
	addq	$8, %r14
LBB0_4:                                 ##   in Loop: Header=BB0_6 Depth=1
	movq	-88(%rbp), %r15                 ## 8-byte Reload
	movq	-80(%rbp), %rcx                 ## 8-byte Reload
LBB0_5:                                 ##   in Loop: Header=BB0_6 Depth=1
	movq	-96(%rbp), %rax                 ## 8-byte Reload
	movq	%r12, (%rax,%rbx)
	addq	$8, %rbx
	movq	%r15, %rax
	subq	%rbx, %rax
	cmpq	$7, %rax
	jbe	LBB0_33
LBB0_6:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_27 Depth 2
                                        ##     Child Loop BB0_30 Depth 2
                                        ##     Child Loop BB0_19 Depth 2
                                        ##     Child Loop BB0_22 Depth 2
	movq	%rbx, %rax
	shrq	$3, %rax
	movzbl	(%rdi,%rax), %eax
	movl	%r13d, %r12d
	xorl	%eax, %r12d
	cmpl	$255, %r12d
	jne	LBB0_10
## %bb.7:                               ##   in Loop: Header=BB0_6 Depth=1
	movq	%rcx, %r15
	subq	%r14, %r15
	cmpq	$7, %r15
	ja	LBB0_2
## %bb.8:                               ##   in Loop: Header=BB0_6 Depth=1
	cmpq	%r14, %rcx
	jne	LBB0_14
## %bb.9:                               ##   in Loop: Header=BB0_6 Depth=1
	xorl	%r12d, %r12d
	jmp	LBB0_3
	.p2align	4
LBB0_10:                                ##   in Loop: Header=BB0_6 Depth=1
	cmpl	%eax, %r13d
	jne	LBB0_12
## %bb.11:                              ##   in Loop: Header=BB0_6 Depth=1
	movq	-72(%rbp), %r12                 ## 8-byte Reload
	jmp	LBB0_5
	.p2align	4
LBB0_12:                                ##   in Loop: Header=BB0_6 Depth=1
	movq	%rcx, %rax
	subq	%r14, %rax
	cmpq	$7, %rax
	jbe	LBB0_16
## %bb.13:                              ##   in Loop: Header=BB0_6 Depth=1
	movq	(%rdx,%r14), %r8
	jmp	LBB0_31
LBB0_14:                                ##   in Loop: Header=BB0_6 Depth=1
	movl	%r15d, %r8d
	andl	$3, %r8d
	movq	%r14, %rax
	subq	%rcx, %rax
	cmpq	$-4, %rax
	jbe	LBB0_18
## %bb.15:                              ##   in Loop: Header=BB0_6 Depth=1
	xorl	%esi, %esi
	xorl	%r12d, %r12d
	jmp	LBB0_21
LBB0_16:                                ##   in Loop: Header=BB0_6 Depth=1
	cmpq	%r14, %rcx
	jne	LBB0_24
## %bb.17:                              ##   in Loop: Header=BB0_6 Depth=1
	xorl	%r8d, %r8d
	jmp	LBB0_31
LBB0_18:                                ##   in Loop: Header=BB0_6 Depth=1
	andl	$4, %r15d
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	addq	%r14, %rax
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%r12d, %r12d
	.p2align	4
LBB0_19:                                ##   Parent Loop BB0_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%rax,%rsi), %r11d
	movl	%r10d, %ecx
	shlq	%cl, %r11
	movzbl	-2(%rax,%rsi), %edx
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdx
	orq	%r11, %r12
	movzbl	-1(%rax,%rsi), %r11d
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r11
	orq	%rdx, %r11
	orq	%r12, %r11
	movzbl	(%rax,%rsi), %r12d
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r12
	orq	%r11, %r12
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r15
	jne	LBB0_19
## %bb.20:                              ##   in Loop: Header=BB0_6 Depth=1
	testq	%r8, %r8
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	je	LBB0_3
LBB0_21:                                ##   in Loop: Header=BB0_6 Depth=1
	leaq	(%rdx,%r14), %rax
	addq	%rsi, %rax
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB0_22:                                ##   Parent Loop BB0_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rax,%r10), %r11d
	movl	%esi, %ecx
	shlq	%cl, %r11
	orq	%r11, %r12
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %r8
	jne	LBB0_22
	jmp	LBB0_3
LBB0_24:                                ##   in Loop: Header=BB0_6 Depth=1
	movl	%eax, %r15d
	andl	$3, %r15d
	movq	%r14, %rsi
	subq	%rcx, %rsi
	cmpq	$-4, %rsi
	jbe	LBB0_26
## %bb.25:                              ##   in Loop: Header=BB0_6 Depth=1
	xorl	%esi, %esi
	xorl	%r8d, %r8d
	jmp	LBB0_29
LBB0_26:                                ##   in Loop: Header=BB0_6 Depth=1
	movl	%r9d, -44(%rbp)                 ## 4-byte Spill
	andl	$4, %eax
	movq	-56(%rbp), %rcx                 ## 8-byte Reload
	leaq	(%rcx,%r14), %r9
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%r8d, %r8d
	.p2align	4
LBB0_27:                                ##   Parent Loop BB0_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%r9,%rsi), %edx
	movl	%r10d, %ecx
	shlq	%cl, %rdx
	movzbl	-2(%r9,%rsi), %r11d
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r11
	orq	%rdx, %r8
	movzbl	-1(%r9,%rsi), %edx
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdx
	orq	%r11, %rdx
	orq	%r8, %rdx
	movzbl	(%r9,%rsi), %r8d
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r8
	orq	%rdx, %r8
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %rax
	jne	LBB0_27
## %bb.28:                              ##   in Loop: Header=BB0_6 Depth=1
	testq	%r15, %r15
	movl	-44(%rbp), %r9d                 ## 4-byte Reload
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	je	LBB0_31
LBB0_29:                                ##   in Loop: Header=BB0_6 Depth=1
	leaq	(%rdx,%r14), %rax
	addq	%rsi, %rax
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB0_30:                                ##   Parent Loop BB0_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rax,%r10), %r11d
	movl	%esi, %ecx
	shlq	%cl, %r11
	orq	%r11, %r8
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %r15
	jne	LBB0_30
LBB0_31:                                ##   in Loop: Header=BB0_6 Depth=1
	movl	%r12d, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	__ZN18cngcompress_layout12_GLOBAL__N_19expansionE(%rip), %rcx
	leaq	(%rcx,%rax,8), %rsi
	movl	32(%rsi), %eax
	leal	(,%rax,8), %ecx
	movq	$-1, %r10
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r10
	notq	%r10
	andq	%r8, %r10
	movq	(%rsi), %rcx
	andq	%r10, %rcx
	xorq	%rcx, %r10
	shlq	$32, %rcx
	orq	%r10, %rcx
	movq	8(%rsi), %r8
	andq	%rcx, %r8
	xorq	%r8, %rcx
	shlq	$16, %r8
	orq	%rcx, %r8
	movq	16(%rsi), %rcx
	andq	%r8, %rcx
	xorq	%rcx, %r8
	shlq	$8, %rcx
	movq	24(%rsi), %r12
	notq	%r12
	andq	-72(%rbp), %r12                 ## 8-byte Folded Reload
	orq	%rcx, %r12
	orq	%r8, %r12
	addq	%rax, %r14
	jmp	LBB0_4
LBB0_32:
	xorl	%r14d, %r14d
LBB0_33:
	cmpq	%rbx, %r15
	movl	-48(%rbp), %r10d                ## 4-byte Reload
	jbe	LBB0_46
## %bb.34:
	leaq	16(%rbp), %rax
	movq	(%rax), %rax
	movl	%r15d, %esi
	subl	%ebx, %esi
	leaq	1(%rbx), %rcx
	testb	$1, %sil
	je	LBB0_39
## %bb.35:
	movq	%rbx, %rsi
	shrq	$3, %rsi
	movzbl	(%rdi,%rsi), %esi
	movl	%ebx, %r8d
	andl	$7, %r8d
	xorl	%r11d, %r11d
	btl	%r8d, %esi
	setb	%r11b
	cmpl	%r9d, %r11d
	jne	LBB0_37
## %bb.36:
	movl	%r10d, %esi
	jmp	LBB0_38
LBB0_37:
	movzbl	(%rdx,%r14), %esi
	incq	%r14
LBB0_38:
	movb	%sil, (%rax,%rbx)
	movq	%rcx, %rbx
LBB0_39:
	cmpq	%rcx, %r15
	jne	LBB0_41
	jmp	LBB0_46
	.p2align	4
LBB0_40:                                ##   in Loop: Header=BB0_41 Depth=1
	movzbl	(%rdx,%r14), %ecx
	incq	%r14
	movb	%cl, 1(%rax,%rbx)
	addq	$2, %rbx
	cmpq	%rbx, %r15
	je	LBB0_46
LBB0_41:                                ## =>This Inner Loop Header: Depth=1
	movq	%rbx, %rcx
	shrq	$3, %rcx
	movzbl	(%rdi,%rcx), %ecx
	movl	%ebx, %r8d
	andl	$7, %r8d
	xorl	%esi, %esi
	btl	%r8d, %ecx
	setb	%sil
	cmpl	%r9d, %esi
	jne	LBB0_43
## %bb.42:                              ##   in Loop: Header=BB0_41 Depth=1
	movl	%r10d, %ecx
	jmp	LBB0_44
	.p2align	4
LBB0_43:                                ##   in Loop: Header=BB0_41 Depth=1
	movzbl	(%rdx,%r14), %ecx
	incq	%r14
LBB0_44:                                ##   in Loop: Header=BB0_41 Depth=1
	movb	%cl, (%rax,%rbx)
	leaq	1(%rbx), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%rdi,%rsi), %r8d
	andl	$7, %ecx
	xorl	%esi, %esi
	btl	%ecx, %r8d
	setb	%sil
	cmpl	%r9d, %esi
	jne	LBB0_40
## %bb.45:                              ##   in Loop: Header=BB0_41 Depth=1
	movl	%r10d, %ecx
	movb	%cl, 1(%rax,%rbx)
	addq	$2, %rbx
	cmpq	%rbx, %r15
	jne	LBB0_41
LBB0_46:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	3, 0x0                          ## @_ZN18cngcompress_layout12_GLOBAL__N_19expansionE
__ZN18cngcompress_layout12_GLOBAL__N_19expansionE:
	.space	40
	.space	24
	.quad	255                             ## 0xff
	.long	1                               ## 0x1
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.long	1                               ## 0x1
	.space	4
	.space	24
	.quad	65535                           ## 0xffff
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.long	1                               ## 0x1
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	16711935                        ## 0xff00ff
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.long	2                               ## 0x2
	.space	4
	.space	24
	.quad	16777215                        ## 0xffffff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.long	1                               ## 0x1
	.space	4
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4278190335                      ## 0xff0000ff
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	4278255360                      ## 0xff00ff00
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4278255615                      ## 0xff00ffff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294902015                      ## 0xffff00ff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294967040                      ## 0xffffff00
	.long	3                               ## 0x3
	.space	4
	.space	24
	.quad	4294967295                      ## 0xffffffff
	.long	4                               ## 0x4
	.space	4
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.long	1                               ## 0x1
	.space	4
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	1095216660735                   ## 0xff000000ff
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	1095216725760                   ## 0xff0000ff00
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1095216726015                   ## 0xff0000ffff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	1095233372160                   ## 0xff00ff0000
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	1095233372415                   ## 0xff00ff00ff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	1095233437440                   ## 0xff00ffff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	1095233437695                   ## 0xff00ffffff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	1099494850560                   ## 0xffff000000
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099494850815                   ## 0xffff0000ff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	1099494915840                   ## 0xffff00ff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	1099494916095                   ## 0xffff00ffff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	1099511562495                   ## 0xffffff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	1099511627520                   ## 0xffffffff00
	.long	4                               ## 0x4
	.space	4
	.space	24
	.quad	1099511627775                   ## 0xffffffffff
	.long	5                               ## 0x5
	.space	4
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.long	1                               ## 0x1
	.space	4
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.long	2                               ## 0x2
	.space	4
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	280375465148160                 ## 0xff000000ff00
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465148415                 ## 0xff000000ffff
	.long	3                               ## 0x3
	.space	4
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	280375481794560                 ## 0xff0000ff0000
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	280375481794815                 ## 0xff0000ff00ff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	280375481859840                 ## 0xff0000ffff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	280375481860095                 ## 0xff0000ffffff
	.long	4                               ## 0x4
	.space	4
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	280379743272960                 ## 0xff00ff000000
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	280379743273215                 ## 0xff00ff0000ff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	280379743338240                 ## 0xff00ff00ff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	280379743338495                 ## 0xff00ff00ffff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	280379759984640                 ## 0xff00ffff0000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	280379759984895                 ## 0xff00ffff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	280379760049920                 ## 0xff00ffffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	280379760050175                 ## 0xff00ffffffff
	.long	5                               ## 0x5
	.space	4
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.long	2                               ## 0x2
	.space	4
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	281470681743615                 ## 0xffff000000ff
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	281470681808640                 ## 0xffff0000ff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281470681808895                 ## 0xffff0000ffff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	281470698455040                 ## 0xffff00ff0000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	281470698455295                 ## 0xffff00ff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	281470698520320                 ## 0xffff00ffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	281470698520575                 ## 0xffff00ffffff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	281474959933440                 ## 0xffffff000000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	281474959933695                 ## 0xffffff0000ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	281474959998720                 ## 0xffffff00ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	281474959998975                 ## 0xffffff00ffff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	281474976645375                 ## 0xffffffff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	281474976710400                 ## 0xffffffffff00
	.long	5                               ## 0x5
	.space	4
	.space	24
	.quad	281474976710655                 ## 0xffffffffffff
	.long	6                               ## 0x6
	.space	4
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.long	1                               ## 0x1
	.space	4
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71776119061217535               ## 0xff0000000000ff
	.long	2                               ## 0x2
	.space	4
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	71776119061282560               ## 0xff00000000ff00
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.long	3                               ## 0x3
	.space	4
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	71776119077929215               ## 0xff000000ff00ff
	.long	3                               ## 0x3
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	71776119077994240               ## 0xff000000ffff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.long	4                               ## 0x4
	.space	4
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	71776123339407360               ## 0xff0000ff000000
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	71776123339472640               ## 0xff0000ff00ff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	71776123339472895               ## 0xff0000ff00ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	71776123356119040               ## 0xff0000ffff0000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	71776123356119295               ## 0xff0000ffff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	71776123356184320               ## 0xff0000ffffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184575               ## 0xff0000ffffffff
	.long	5                               ## 0x5
	.space	4
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71777214277877760               ## 0xff00ff00000000
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	71777214277878015               ## 0xff00ff000000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	71777214277943040               ## 0xff00ff0000ff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71777214277943295               ## 0xff00ff0000ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	71777214294589440               ## 0xff00ff00ff0000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	71777214294589695               ## 0xff00ff00ff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	71777214294654720               ## 0xff00ff00ffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	71777214294654975               ## 0xff00ff00ffffff
	.long	5                               ## 0x5
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	71777218556067840               ## 0xff00ffff000000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71777218556068095               ## 0xff00ffff0000ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	71777218556133120               ## 0xff00ffff00ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	71777218556133375               ## 0xff00ffff00ffff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71777218572779520               ## 0xff00ffffff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	71777218572779775               ## 0xff00ffffff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	71777218572844800               ## 0xff00ffffffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	71777218572845055               ## 0xff00ffffffffff
	.long	6                               ## 0x6
	.space	4
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.long	2                               ## 0x2
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	72056494526365440               ## 0xffff000000ff00
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	72056494526365695               ## 0xffff000000ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	72056494543011840               ## 0xffff0000ff0000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	72056494543012095               ## 0xffff0000ff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	72056494543077120               ## 0xffff0000ffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	72056494543077375               ## 0xffff0000ffffff
	.long	5                               ## 0x5
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	72056498804490240               ## 0xffff00ff000000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	72056498804490495               ## 0xffff00ff0000ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	72056498804555520               ## 0xffff00ff00ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	72056498804555775               ## 0xffff00ff00ffff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	72056498821201920               ## 0xffff00ffff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	72056498821202175               ## 0xffff00ffff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	72056498821267200               ## 0xffff00ffffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	72056498821267455               ## 0xffff00ffffffff
	.long	6                               ## 0x6
	.space	4
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.long	3                               ## 0x3
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	72057589742960895               ## 0xffffff000000ff
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	72057589743025920               ## 0xffffff0000ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	72057589743026175               ## 0xffffff0000ffff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	72057589759672320               ## 0xffffff00ff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	72057589759672575               ## 0xffffff00ff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	72057589759737600               ## 0xffffff00ffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	72057589759737855               ## 0xffffff00ffffff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	72057594021150720               ## 0xffffffff000000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	72057594021150975               ## 0xffffffff0000ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	72057594021216000               ## 0xffffffff00ff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	72057594021216255               ## 0xffffffff00ffff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	72057594037862655               ## 0xffffffffff00ff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	72057594037927680               ## 0xffffffffffff00
	.long	6                               ## 0x6
	.space	4
	.space	24
	.quad	72057594037927935               ## 0xffffffffffffff
	.long	7                               ## 0x7
	.space	4
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-72057594037927936              ## 0xff00000000000000
	.long	1                               ## 0x1
	.space	4
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	-72057594037927681              ## 0xff000000000000ff
	.long	2                               ## 0x2
	.space	4
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	-72057594037862656              ## 0xff0000000000ff00
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-72057594037862401              ## 0xff0000000000ffff
	.long	3                               ## 0x3
	.space	4
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	-72057594021216256              ## 0xff00000000ff0000
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	-72057594021216001              ## 0xff00000000ff00ff
	.long	3                               ## 0x3
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	-72057594021150976              ## 0xff00000000ffff00
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	-72057594021150721              ## 0xff00000000ffffff
	.long	4                               ## 0x4
	.space	4
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	-72057589759737856              ## 0xff000000ff000000
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-72057589759737601              ## 0xff000000ff0000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	-72057589759672576              ## 0xff000000ff00ff00
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	-72057589759672321              ## 0xff000000ff00ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-72057589743026176              ## 0xff000000ffff0000
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	-72057589743025921              ## 0xff000000ffff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	-72057589742960896              ## 0xff000000ffffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-72057589742960641              ## 0xff000000ffffffff
	.long	5                               ## 0x5
	.space	4
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	-72056498821267456              ## 0xff0000ff00000000
	.long	2                               ## 0x2
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	-72056498821267201              ## 0xff0000ff000000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	-72056498821202176              ## 0xff0000ff0000ff00
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	-72056498821201921              ## 0xff0000ff0000ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	-72056498804555776              ## 0xff0000ff00ff0000
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	-72056498804555521              ## 0xff0000ff00ff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	-72056498804490496              ## 0xff0000ff00ffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	-72056498804490241              ## 0xff0000ff00ffffff
	.long	5                               ## 0x5
	.space	4
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	-72056494543077376              ## 0xff0000ffff000000
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	-72056494543077121              ## 0xff0000ffff0000ff
	.long	4                               ## 0x4
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	-72056494543012096              ## 0xff0000ffff00ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	-72056494543011841              ## 0xff0000ffff00ffff
	.long	5                               ## 0x5
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	-72056494526365696              ## 0xff0000ffffff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	-72056494526365441              ## 0xff0000ffffff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	-72056494526300416              ## 0xff0000ffffffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	-72056494526300161              ## 0xff0000ffffffffff
	.long	6                               ## 0x6
	.space	4
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	-71777218572845056              ## 0xff00ff0000000000
	.long	2                               ## 0x2
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71777218572844801              ## 0xff00ff00000000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	-71777218572779776              ## 0xff00ff000000ff00
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	-71777218572779521              ## 0xff00ff000000ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71777218556133376              ## 0xff00ff0000ff0000
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	-71777218556133121              ## 0xff00ff0000ff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	-71777218556068096              ## 0xff00ff0000ffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71777218556067841              ## 0xff00ff0000ffffff
	.long	5                               ## 0x5
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	-71777214294654976              ## 0xff00ff00ff000000
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	-71777214294654721              ## 0xff00ff00ff0000ff
	.long	4                               ## 0x4
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	-71777214294589696              ## 0xff00ff00ff00ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	-71777214294589441              ## 0xff00ff00ff00ffff
	.long	5                               ## 0x5
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	-71777214277943296              ## 0xff00ff00ffff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	-71777214277943041              ## 0xff00ff00ffff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	-71777214277878016              ## 0xff00ff00ffffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	-71777214277877761              ## 0xff00ff00ffffffff
	.long	6                               ## 0x6
	.space	4
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71776123356184576              ## 0xff00ffff00000000
	.long	3                               ## 0x3
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	-71776123356184321              ## 0xff00ffff000000ff
	.long	4                               ## 0x4
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	-71776123356119296              ## 0xff00ffff0000ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71776123356119041              ## 0xff00ffff0000ffff
	.long	5                               ## 0x5
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	-71776123339472896              ## 0xff00ffff00ff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	-71776123339472641              ## 0xff00ffff00ff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	-71776123339407616              ## 0xff00ffff00ffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	-71776123339407361              ## 0xff00ffff00ffffff
	.long	6                               ## 0x6
	.space	4
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	-71776119077994496              ## 0xff00ffffff000000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71776119077994241              ## 0xff00ffffff0000ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	-71776119077929216              ## 0xff00ffffff00ff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	-71776119077928961              ## 0xff00ffffff00ffff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71776119061282816              ## 0xff00ffffffff0000
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	-71776119061282561              ## 0xff00ffffffff00ff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	-71776119061217536              ## 0xff00ffffffffff00
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	-71776119061217281              ## 0xff00ffffffffffff
	.long	7                               ## 0x7
	.space	4
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	-281474976710656                ## 0xffff000000000000
	.long	2                               ## 0x2
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-281474976710401                ## 0xffff0000000000ff
	.long	3                               ## 0x3
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	-281474976645376                ## 0xffff00000000ff00
	.long	3                               ## 0x3
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	-281474976645121                ## 0xffff00000000ffff
	.long	4                               ## 0x4
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-281474959998976                ## 0xffff000000ff0000
	.long	3                               ## 0x3
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	-281474959998721                ## 0xffff000000ff00ff
	.long	4                               ## 0x4
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	-281474959933696                ## 0xffff000000ffff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-281474959933441                ## 0xffff000000ffffff
	.long	5                               ## 0x5
	.space	4
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	-281470698520576                ## 0xffff0000ff000000
	.long	3                               ## 0x3
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	-281470698520321                ## 0xffff0000ff0000ff
	.long	4                               ## 0x4
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	-281470698455296                ## 0xffff0000ff00ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	-281470698455041                ## 0xffff0000ff00ffff
	.long	5                               ## 0x5
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	-281470681808896                ## 0xffff0000ffff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	-281470681808641                ## 0xffff0000ffff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	-281470681743616                ## 0xffff0000ffffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	-281470681743361                ## 0xffff0000ffffffff
	.long	6                               ## 0x6
	.space	4
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-280379760050176                ## 0xffff00ff00000000
	.long	3                               ## 0x3
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	-280379760049921                ## 0xffff00ff000000ff
	.long	4                               ## 0x4
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	-280379759984896                ## 0xffff00ff0000ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-280379759984641                ## 0xffff00ff0000ffff
	.long	5                               ## 0x5
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	-280379743338496                ## 0xffff00ff00ff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	-280379743338241                ## 0xffff00ff00ff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	-280379743273216                ## 0xffff00ff00ffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	-280379743272961                ## 0xffff00ff00ffffff
	.long	6                               ## 0x6
	.space	4
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	-280375481860096                ## 0xffff00ffff000000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-280375481859841                ## 0xffff00ffff0000ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	-280375481794816                ## 0xffff00ffff00ff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	-280375481794561                ## 0xffff00ffff00ffff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-280375465148416                ## 0xffff00ffffff0000
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	-280375465148161                ## 0xffff00ffffff00ff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	-280375465083136                ## 0xffff00ffffffff00
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	-280375465082881                ## 0xffff00ffffffffff
	.long	7                               ## 0x7
	.space	4
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	-1099511627776                  ## 0xffffff0000000000
	.long	3                               ## 0x3
	.space	4
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	-1099511627521                  ## 0xffffff00000000ff
	.long	4                               ## 0x4
	.space	4
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	-1099511562496                  ## 0xffffff000000ff00
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	-1099511562241                  ## 0xffffff000000ffff
	.long	5                               ## 0x5
	.space	4
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	-1099494916096                  ## 0xffffff0000ff0000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	-1099494915841                  ## 0xffffff0000ff00ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	-1099494850816                  ## 0xffffff0000ffff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	-1099494850561                  ## 0xffffff0000ffffff
	.long	6                               ## 0x6
	.space	4
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	-1095233437696                  ## 0xffffff00ff000000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	-1095233437441                  ## 0xffffff00ff0000ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	-1095233372416                  ## 0xffffff00ff00ff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	-1095233372161                  ## 0xffffff00ff00ffff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	-1095216726016                  ## 0xffffff00ffff0000
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	-1095216725761                  ## 0xffffff00ffff00ff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	-1095216660736                  ## 0xffffff00ffffff00
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	-1095216660481                  ## 0xffffff00ffffffff
	.long	7                               ## 0x7
	.space	4
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	-4294967296                     ## 0xffffffff00000000
	.long	4                               ## 0x4
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	-4294967041                     ## 0xffffffff000000ff
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	-4294902016                     ## 0xffffffff0000ff00
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	-4294901761                     ## 0xffffffff0000ffff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	-4278255616                     ## 0xffffffff00ff0000
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	-4278255361                     ## 0xffffffff00ff00ff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	-4278190336                     ## 0xffffffff00ffff00
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	-4278190081                     ## 0xffffffff00ffffff
	.long	7                               ## 0x7
	.space	4
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	-16777216                       ## 0xffffffffff000000
	.long	5                               ## 0x5
	.space	4
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	-16776961                       ## 0xffffffffff0000ff
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	-16711936                       ## 0xffffffffff00ff00
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	-16711681                       ## 0xffffffffff00ffff
	.long	7                               ## 0x7
	.space	4
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.quad	-65536                          ## 0xffffffffffff0000
	.long	6                               ## 0x6
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	-65281                          ## 0xffffffffffff00ff
	.long	7                               ## 0x7
	.space	4
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	-256                            ## 0xffffffffffffff00
	.long	7                               ## 0x7
	.space	4
	.space	24
	.quad	-1                              ## 0xffffffffffffffff
	.long	8                               ## 0x8
	.space	4

.subsections_via_symbols
