	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
lCPI0_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	6
__ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ; @_ZN16cng_layout_model6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
; %bb.0:
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #2848
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset b8, -88
	.cfi_offset b9, -96
	.cfi_offset b10, -104
	.cfi_offset b11, -112
	.cfi_offset b12, -120
	.cfi_offset b13, -128
	.cfi_offset b14, -136
	.cfi_offset b15, -144
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-136]
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x1, x8
	b.hi	LBB0_80
; %bb.1:
	mov	x20, x1
	lsl	x8, x1, #1
	add	x8, x8, #512
	cmp	x3, x8
	b.lo	LBB0_80
; %bb.2:
	mov	x19, x2
	strb	wzr, [x2]
	strb	w20, [x2, #1]
	lsr	x8, x20, #8
	strb	w8, [x2, #2]
	lsr	x8, x20, #16
	strb	w8, [x2, #3]
	strb	wzr, [x2, #4]
	cbz	x20, LBB0_16
; %bb.3:
	mov	x21, x0
	add	x22, sp, #3592
	add	x0, sp, #3592
	mov	w1, #1024                       ; =0x400
	bl	_bzero
	add	x23, sp, #520
	add	x0, sp, #520
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	mov	x8, #0                          ; =0x0
	ands	x9, x20, #0x3ffffc
	b.eq	LBB0_6
; %bb.4:
	add	x10, x23, #1024
	add	x11, x23, #2048
LBB0_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x12, x21, x8
	ldrb	w13, [x12]
	ldr	w14, [x22, x13, lsl #2]
	add	w14, w14, #1
	str	w14, [x22, x13, lsl #2]
	ldrb	w13, [x12, #1]
	ldr	w14, [x23, x13, lsl #2]
	add	w14, w14, #1
	str	w14, [x23, x13, lsl #2]
	ldrb	w13, [x12, #2]
	ldr	w14, [x10, x13, lsl #2]
	add	w14, w14, #1
	str	w14, [x10, x13, lsl #2]
	ldrb	w12, [x12, #3]
	ldr	w13, [x11, x12, lsl #2]
	add	w13, w13, #1
	str	w13, [x11, x12, lsl #2]
	add	x8, x8, #4
	cmp	x8, x9
	b.lo	LBB0_5
LBB0_6:
	subs	x9, x20, x8
	b.ls	LBB0_9
; %bb.7:
	add	x8, x21, x8
	add	x10, sp, #3592
LBB0_8:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x8], #1
	ldr	w12, [x10, x11, lsl #2]
	add	w12, w12, #1
	str	w12, [x10, x11, lsl #2]
	subs	x9, x9, #1
	b.ne	LBB0_8
LBB0_9:
	add	x23, sp, #3592
	add	x8, sp, #520
	mov	w9, #2096                       ; =0x830
	add	x10, sp, #3592
LBB0_10:                                ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	add	x11, x10, x9
	sub	x12, x11, #2096
	sub	x13, x11, #2080
	sub	x14, x11, #2064
	sub	x11, x11, #2048
	ldr	q4, [x12]
	ldr	q5, [x13]
	ldr	q6, [x14]
	ldr	q7, [x11]
	ldr	q16, [x8, #1024]
	ldr	q17, [x8, #1040]
	ldr	q18, [x8, #1056]
	ldr	q19, [x8, #1072]
	add.4s	v0, v16, v0
	add.4s	v1, v17, v1
	add.4s	v2, v18, v2
	add.4s	v3, v19, v3
	ldr	q16, [x8, #2048]
	ldr	q17, [x8, #2064]
	ldr	q18, [x8, #2080]
	ldr	q19, [x8, #2096]
	add.4s	v0, v16, v0
	add.4s	v0, v0, v4
	add.4s	v1, v17, v1
	add.4s	v1, v1, v5
	add.4s	v2, v18, v2
	add.4s	v2, v2, v6
	add.4s	v3, v19, v3
	add.4s	v3, v3, v7
	str	q0, [x12]
	str	q1, [x13]
	str	q2, [x14]
	str	q3, [x11]
	add	x9, x9, #64
	add	x8, x8, #64
	cmp	x9, #3120
	b.ne	LBB0_10
; %bb.11:
	mov	x8, #0                          ; =0x0
	dup.4s	v1, w20
	movi.2d	v0, #0000000000000000
	mov	w9, #1                          ; =0x1
	dup.2d	v16, x9
	movi.16b	v17, #16
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
Lloh3:
	adrp	x9, lCPI0_0@PAGE
Lloh4:
	ldr	q23, [x9, lCPI0_0@PAGEOFF]
	movi.2d	v20, #0000000000000000
	add	x9, sp, #3592
	movi.2d	v19, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	mov.16b	v21, v1
	mov.16b	v22, v1
	mov.16b	v25, v1
LBB0_12:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x9, x8
	ldp	q30, q29, [x10, #32]
	cmtst.4s	v31, v29, v29
	cmtst.4s	v8, v30, v30
	uzp1.8h	v9, v8, v31
	ldp	q11, q10, [x10]
	cmtst.4s	v12, v10, v10
	cmtst.4s	v13, v11, v11
	uzp1.8h	v14, v13, v12
	uzp1.16b	v9, v14, v9
	orr.16b	v4, v4, v9
	bit.16b	v2, v23, v9
	ushll2.2d	v9, v8, #0
	and.16b	v9, v9, v16
	add.2d	v24, v24, v9
	ushll2.2d	v9, v12, #0
	and.16b	v9, v9, v16
	add.2d	v19, v19, v9
	ushll2.2d	v9, v13, #0
	and.16b	v9, v9, v16
	add.2d	v7, v7, v9
	ushll2.2d	v9, v31, #0
	and.16b	v9, v9, v16
	add.2d	v26, v26, v9
	ushll.2d	v31, v31, #0
	and.16b	v31, v31, v16
	add.2d	v28, v28, v31
	ushll.2d	v31, v8, #0
	and.16b	v31, v31, v16
	add.2d	v27, v27, v31
	ushll.2d	v31, v12, #0
	and.16b	v31, v31, v16
	add.2d	v20, v20, v31
	ushll.2d	v31, v13, #0
	and.16b	v31, v31, v16
	add.2d	v18, v18, v31
	umin.4s	v1, v29, v1
	umax.4s	v6, v6, v29
	umin.4s	v25, v30, v25
	umax.4s	v5, v5, v30
	umin.4s	v22, v10, v22
	umax.4s	v0, v0, v10
	umin.4s	v21, v11, v21
	umax.4s	v3, v3, v11
	add	x8, x8, #64
	add.16b	v23, v23, v17
	cmp	x8, #1024
	b.ne	LBB0_12
; %bb.13:
	add.2d	v16, v18, v27
	add.2d	v17, v20, v28
	add.2d	v16, v16, v17
	add.2d	v7, v7, v24
	add.2d	v17, v19, v26
	add.2d	v7, v7, v17
	add.2d	v7, v16, v7
	addp.2d	d7, v7
	fmov	x8, d7
	cmp	x8, #256
	b.eq	LBB0_17
; %bb.14:
	cmp	x8, #1
	b.ne	LBB0_18
; %bb.15:
	shl.16b	v0, v4, #7
	cmlt.16b	v0, v0, #0
	addp.2d	d0, v0
	umaxv.16b	b1, v2
	fmov	w8, s1
	fmov	x9, d0
	cmp	x9, #0
	csel	w8, wzr, w8, eq
	mov	w9, #4                          ; =0x4
	strb	w9, [x19]
	strb	w8, [x19, #5]
	mov	w0, #6                          ; =0x6
	b	LBB0_78
LBB0_16:
	mov	w0, #5                          ; =0x5
	b	LBB0_78
LBB0_17:
	umin.4s	v2, v21, v25
	umin.4s	v1, v22, v1
	umin.4s	v1, v2, v1
	uminv.4s	s1, v1
	fmov	w8, s1
	umax.4s	v1, v3, v5
	umax.4s	v0, v0, v6
	umax.4s	v0, v1, v0
	umaxv.4s	s0, v0
	fmov	w9, s0
	cmp	w9, w8, lsl #1
	b.ls	LBB0_29
LBB0_18:
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #15104]
	str	q0, [sp, #15088]
	str	q0, [sp, #15072]
	str	q0, [sp, #15056]
	str	q0, [sp, #15040]
	str	q0, [sp, #15024]
	str	q0, [sp, #15008]
	str	q0, [sp, #14992]
	str	q0, [sp, #14976]
	str	q0, [sp, #14960]
	str	q0, [sp, #14944]
	str	q0, [sp, #14928]
	str	q0, [sp, #14912]
	str	q0, [sp, #14896]
	str	q0, [sp, #14880]
	str	q0, [sp, #14864]
	stp	q0, q0, [sp, #480]
	stp	q0, q0, [sp, #448]
	stp	q0, q0, [sp, #416]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #320]
	stp	q0, q0, [sp, #288]
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	add	x22, sp, #3, lsl #12            ; =12288
	add	x22, x22, #528
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #528
	mov	w1, #2048                       ; =0x800
	bl	_bzero
	mov	x8, #0                          ; =0x0
LBB0_19:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x22, x8
	str	wzr, [x9]
	str	wzr, [x9, #8]
	str	wzr, [x9, #16]
	str	wzr, [x9, #24]
	strh	wzr, [x9, #4]
	strh	wzr, [x9, #12]
	strh	wzr, [x9, #20]
	add	x8, x8, #32
	strh	wzr, [x9, #28]
	cmp	x8, #2048
	b.ne	LBB0_19
; %bb.20:
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #2580
	mov	w1, #2044                       ; =0x7fc
	bl	_bzero
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2584
	mov	w1, #4088                       ; =0xff8
	bl	_bzero
	mov	x22, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	add	x9, sp, #3592
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #528
	b	LBB0_22
LBB0_21:                                ;   in Loop: Header=BB0_22 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB0_24
LBB0_22:                                ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x9, x8, lsl #2]
	cbz	w11, LBB0_21
; %bb.23:                               ;   in Loop: Header=BB0_22 Depth=1
	add	x12, x10, x22, lsl #3
	str	w11, [x12]
	strh	w8, [x12, #4]
	add	x22, x22, #1
	b	LBB0_21
LBB0_24:
	subs	x24, x22, #1
	b.ls	LBB0_83
; %bb.25:
	add	x25, sp, #3, lsl #12            ; =12288
	add	x25, x25, #528
	add	x1, x25, x22, lsl #3
	clz	x8, x22
	lsl	x8, x8, #1
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #528
	eor	x2, x8, #0x7e
	mov	w3, #1                          ; =0x1
	bl	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	cmp	x22, #5
	b.hs	LBB0_27
; %bb.26:
	mov	x8, #0                          ; =0x0
	b	LBB0_35
LBB0_27:
	cmp	x22, #17
	b.hs	LBB0_30
; %bb.28:
	mov	x8, #0                          ; =0x0
	b	LBB0_33
LBB0_29:
	add	x0, x19, #5
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	add	x0, x20, #5
	b	LBB0_78
LBB0_30:
	ands	x8, x22, #0xf
	mov	w9, #16                         ; =0x10
	csel	x9, x9, x8, eq
	sub	x8, x22, x9
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #528
	add	x10, x10, #64
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #2580
	add	x11, x11, #32
	mov	x12, x22
LBB0_31:                                ; =>This Inner Loop Header: Depth=1
	sub	x13, x10, #40
	sub	x14, x10, #48
	ldur	q0, [x10, #-64]
	mov.s	v0[1], v0[2]
	ld1.s	{ v0 }[2], [x14]
	ld1.s	{ v0 }[3], [x13]
	sub	x13, x10, #16
	ldur	q1, [x10, #-32]
	mov.s	v1[1], v1[2]
	ld1.s	{ v1 }[2], [x13]
	sub	x13, x10, #8
	ld1.s	{ v1 }[3], [x13]
	add	x13, x10, #24
	add	x14, x10, #16
	ldr	q2, [x10]
	mov.s	v2[1], v2[2]
	ld1.s	{ v2 }[2], [x14]
	ld1.s	{ v2 }[3], [x13]
	add	x13, x10, #56
	add	x14, x10, #48
	ldr	q3, [x10, #32]
	mov.s	v3[1], v3[2]
	ld1.s	{ v3 }[2], [x14]
	ld1.s	{ v3 }[3], [x13]
	stp	q0, q1, [x11, #-32]
	stp	q2, q3, [x11], #64
	add	x10, x10, #128
	sub	x12, x12, #16
	cmp	x9, x12
	b.ne	LBB0_31
; %bb.32:
	cmp	x9, #4
	b.ls	LBB0_35
LBB0_33:
	mov	x11, x8
	ands	x8, x22, #0x3
	mov	w9, #4                          ; =0x4
	csel	x12, x9, x8, eq
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #2580
	add	x9, x8, x11, lsl #2
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #528
	add	x10, x8, x11, lsl #3
	sub	x8, x22, x12
	add	x11, x12, x11
	sub	x11, x11, x22
LBB0_34:                                ; =>This Inner Loop Header: Depth=1
	add	x12, x10, #24
	add	x13, x10, #16
	ldr	q0, [x10], #32
	mov.s	v0[1], v0[2]
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	str	q0, [x9], #16
	adds	x11, x11, #4
	b.ne	LBB0_34
LBB0_35:
	add	x9, x25, x8, lsl #3
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2580
LBB0_36:                                ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x9], #8
	str	w11, [x10, x8, lsl #2]
	add	x8, x8, #1
	cmp	x22, x8
	b.ne	LBB0_36
; %bb.37:
	str	xzr, [sp, #6672]
	str	x22, [sp, #6664]
	lsl	x8, x22, #1
	sub	x9, x8, #1
	cmp	x22, x9
	b.hs	LBB0_49
; %bb.38:
	mov	x9, #0                          ; =0x0
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2580
	add	x11, x10, x22, lsl #2
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2584
	b	LBB0_41
LBB0_39:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #2568
LBB0_40:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x16, x15, #1
	ldr	w0, [x10, x14, lsl #2]
	str	x16, [x17]
	ldr	w16, [x10, x15, lsl #2]
	add	w16, w16, w0
	str	w16, [x11, x9, lsl #2]
	str	x13, [x12, x14, lsl #3]
	str	x13, [x12, x15, lsl #3]
	add	x9, x9, #1
	cmp	x24, x9
	b.eq	LBB0_49
LBB0_41:                                ; =>This Inner Loop Header: Depth=1
	add	x13, x22, x9
	ldr	x15, [sp, #6672]
	ldr	x14, [sp, #6664]
	cmp	x15, x22
	b.hs	LBB0_44
; %bb.42:                               ;   in Loop: Header=BB0_41 Depth=1
	cmp	x13, x14
	b.eq	LBB0_45
; %bb.43:                               ;   in Loop: Header=BB0_41 Depth=1
	ldr	w16, [x10, x15, lsl #2]
	ldr	w17, [x10, x14, lsl #2]
	cmp	w16, w17
	b.ls	LBB0_45
LBB0_44:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #2568
	add	x15, x14, #1
	str	x15, [x16]
	ldr	x16, [sp, #6672]
	ldr	x15, [sp, #6664]
	cmp	x16, x22
	b.hs	LBB0_39
	b	LBB0_46
LBB0_45:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #2576
	mov	x14, x15
	add	x15, x15, #1
	str	x15, [x16]
	ldr	x16, [sp, #6672]
	ldr	x15, [sp, #6664]
	cmp	x16, x22
	b.hs	LBB0_39
LBB0_46:                                ;   in Loop: Header=BB0_41 Depth=1
	cmp	x13, x15
	b.eq	LBB0_48
; %bb.47:                               ;   in Loop: Header=BB0_41 Depth=1
	ldr	w17, [x10, x16, lsl #2]
	ldr	w0, [x10, x15, lsl #2]
	cmp	w17, w0
	b.hi	LBB0_39
LBB0_48:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #2576
	mov	x15, x16
	b	LBB0_40
LBB0_49:
	mov	x10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	sub	x8, x8, #2
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #528
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #2576
	add	x13, sp, #1, lsl #12            ; =4096
	add	x13, x13, #2584
	b	LBB0_52
LBB0_50:                                ;   in Loop: Header=BB0_52 Depth=1
	mov	w14, #0                         ; =0x0
	.p2align	6, , 4
LBB0_51:                                ;   in Loop: Header=BB0_52 Depth=1
	cmp	w9, w14
	csel	w9, w9, w14, hi
	add	x15, x11, x10, lsl #3
	ldrh	w15, [x15, #4]
	strb	w14, [x12, x15]
	add	x10, x10, #1
	cmp	x10, x22
	b.eq	LBB0_55
LBB0_52:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_54 Depth 2
	cmp	x10, x8
	b.eq	LBB0_50
; %bb.53:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w14, #0                         ; =0x0
	mov	x15, x10
LBB0_54:                                ;   Parent Loop BB0_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w14, w14, #1
	ldr	x15, [x13, x15, lsl #3]
	cmp	x15, x8
	b.ne	LBB0_54
	b	LBB0_51
LBB0_55:
	cmp	w9, #13
	b.lo	LBB0_62
; %bb.56:
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #520
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #520
	mov	w1, #2048                       ; =0x800
	bl	_bzero
	and	x8, x22, #0xfffffffffffffffe
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #528
	add	x9, x9, #8
	add	x10, x24, #8
	and	x11, x22, #0xfffffffffffffffe
LBB0_57:                                ; =>This Inner Loop Header: Depth=1
	ldur	w12, [x9, #-8]
	ldr	w13, [x9]
	ldurh	w14, [x9, #-4]
	ldrh	w15, [x9, #4]
	stur	w12, [x10, #-8]
	str	w13, [x10]
	sturh	w14, [x10, #-4]
	strh	w15, [x10, #4]
	add	x9, x9, #16
	add	x10, x10, #16
	subs	x11, x11, #2
	b.ne	LBB0_57
; %bb.58:
	subs	x8, x22, x8
	b.eq	LBB0_61
; %bb.59:
	lsl	x9, x22, #3
	and	x10, x9, #0xfffffffffffffff0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #520
	add	x9, x9, x10
	add	x9, x9, #4
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #528
	add	x10, x11, x10
	add	x10, x10, #4
LBB0_60:                                ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x10, #-4]
	ldrh	w12, [x10], #8
	stur	w11, [x9, #-4]
	strh	w12, [x9], #8
	subs	x8, x8, #1
	b.ne	LBB0_60
LBB0_61:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #520
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #2576
	mov	x1, x22
	mov	w2, #12                         ; =0xc
	bl	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
LBB0_62:
	add	x22, sp, #3, lsl #12            ; =12288
	add	x22, x22, #2576
	mov	x24, sp
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #2576
	mov	x1, sp
	bl	__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	ldr	q0, [sp, #14864]
	ldr	q1, [sp, #14880]
	ushll2.8h	v2, v0, #0
	ushll.4s	v3, v2, #0
	ushll.8h	v0, v0, #0
	ushll.4s	v6, v0, #0
	ushll2.4s	v2, v2, #0
	ushll2.4s	v0, v0, #0
	ldp	q7, q5, [x23, #32]
	ushll2.8h	v4, v1, #0
	ushll.4s	v16, v4, #0
	ushll.8h	v1, v1, #0
	ldp	q17, q18, [x23]
	ushll.4s	v19, v1, #0
	ushll2.4s	v20, v4, #0
	ushll2.4s	v1, v1, #0
	ldp	q21, q22, [x23, #96]
	mul.4s	v4, v18, v0
	mul.4s	v5, v5, v2
	mul.4s	v6, v17, v6
	ldp	q2, q0, [x23, #64]
	mul.4s	v7, v7, v3
	mul.4s	v0, v0, v1
	mul.4s	v1, v22, v20
	mul.4s	v2, v2, v19
	mul.4s	v3, v21, v16
	ldr	q16, [sp, #14896]
	ldr	q17, [sp, #14912]
	ushll2.8h	v18, v16, #0
	ldp	q19, q20, [x23, #160]
	ushll.4s	v21, v18, #0
	ushll.8h	v16, v16, #0
	ushll.4s	v22, v16, #0
	ldp	q23, q24, [x23, #128]
	ushll2.4s	v18, v18, #0
	ushll2.4s	v16, v16, #0
	ushll2.8h	v25, v17, #0
	ldp	q26, q27, [x23, #224]
	ushll.4s	v28, v25, #0
	ushll.8h	v17, v17, #0
	ushll.4s	v29, v17, #0
	ldp	q30, q31, [x23, #192]
	ushll2.4s	v25, v25, #0
	ushll2.4s	v17, v17, #0
	mul.4s	v24, v24, v16
	mul.4s	v20, v20, v18
	mul.4s	v22, v23, v22
	mul.4s	v19, v19, v21
	mul.4s	v21, v31, v17
	mul.4s	v23, v27, v25
	mul.4s	v25, v30, v29
	mul.4s	v26, v26, v28
	uaddl2.2d	v16, v4, v24
	uaddl2.2d	v17, v5, v20
	uaddl2.2d	v18, v6, v22
	uaddl2.2d	v27, v7, v19
	uaddl.2d	v24, v4, v24
	uaddl.2d	v20, v5, v20
	uaddl.2d	v6, v6, v22
	uaddl.2d	v19, v7, v19
	uaddl2.2d	v4, v0, v21
	uaddl2.2d	v5, v1, v23
	uaddl2.2d	v7, v2, v25
	uaddl2.2d	v22, v3, v26
	uaddl.2d	v21, v0, v21
	uaddl.2d	v23, v1, v23
	uaddl.2d	v2, v2, v25
	uaddl.2d	v1, v3, v26
	ldp	q3, q0, [x23, #256]
	ldp	q26, q25, [x23, #288]
	ldp	q29, q28, [x23, #320]
	ldp	q31, q30, [x23, #352]
	ldr	q8, [sp, #14928]
	ldr	q9, [sp, #14944]
	ushll.8h	v10, v8, #0
	ushll2.4s	v11, v10, #0
	ushll2.8h	v8, v8, #0
	ushll2.4s	v12, v8, #0
	ushll.4s	v10, v10, #0
	ushll.4s	v8, v8, #0
	ushll.8h	v13, v9, #0
	ushll2.4s	v14, v13, #0
	ushll2.8h	v9, v9, #0
	ushll2.4s	v15, v9, #0
	ushll.4s	v13, v13, #0
	ushll.4s	v9, v9, #0
	mul.4s	v26, v26, v8
	mul.4s	v8, v3, v10
	mul.4s	v25, v25, v12
	mul.4s	v10, v0, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw.2d	v0, v19, v26
	uaddw.2d	v3, v6, v8
	uaddw.2d	v19, v20, v25
	uaddw.2d	v20, v24, v10
	uaddw2.2d	v24, v27, v26
	uaddw2.2d	v18, v18, v8
	uaddw2.2d	v17, v17, v25
	uaddw2.2d	v25, v16, v10
	uaddw.2d	v1, v1, v31
	uaddw.2d	v6, v2, v29
	uaddw.2d	v16, v23, v30
	uaddw.2d	v21, v21, v28
	uaddw2.2d	v22, v22, v31
	uaddw2.2d	v23, v7, v29
	uaddw2.2d	v5, v5, v30
	uaddw2.2d	v26, v4, v28
	ldp	q2, q4, [x23, #416]
	ldp	q7, q27, [x23, #384]
	ldp	q28, q29, [x23, #480]
	ldp	q30, q31, [x23, #448]
	ldr	q8, [sp, #14960]
	ldr	q9, [sp, #14976]
	ushll2.8h	v10, v8, #0
	ushll.4s	v11, v10, #0
	ushll.8h	v8, v8, #0
	ushll.4s	v12, v8, #0
	ushll2.4s	v10, v10, #0
	ushll2.4s	v8, v8, #0
	ushll2.8h	v13, v9, #0
	ushll.4s	v14, v13, #0
	ushll.8h	v9, v9, #0
	ushll.4s	v15, v9, #0
	ushll2.4s	v13, v13, #0
	ushll2.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v4, v10
	mul.4s	v10, v7, v12
	mul.4s	v11, v2, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw2.2d	v2, v25, v27
	uaddw2.2d	v4, v17, v8
	uaddw2.2d	v7, v18, v10
	uaddw2.2d	v18, v24, v11
	uaddw.2d	v20, v20, v27
	uaddw.2d	v19, v19, v8
	uaddw.2d	v24, v3, v10
	uaddw.2d	v25, v0, v11
	uaddw2.2d	v0, v26, v31
	uaddw2.2d	v3, v5, v29
	uaddw2.2d	v17, v23, v30
	uaddw2.2d	v22, v22, v28
	uaddw.2d	v21, v21, v31
	uaddw.2d	v16, v16, v29
	uaddw.2d	v23, v6, v30
	uaddw.2d	v26, v1, v28
	ldp	q5, q1, [x23, #512]
	ldp	q27, q6, [x23, #544]
	ldp	q29, q28, [x23, #576]
	ldp	q31, q30, [x23, #608]
	ldr	q8, [sp, #14992]
	ldr	q9, [sp, #15008]
	ushll.8h	v10, v8, #0
	ushll2.4s	v11, v10, #0
	ushll2.8h	v8, v8, #0
	ushll2.4s	v12, v8, #0
	ushll.4s	v10, v10, #0
	ushll.4s	v8, v8, #0
	ushll.8h	v13, v9, #0
	ushll2.4s	v14, v13, #0
	ushll2.8h	v9, v9, #0
	ushll2.4s	v15, v9, #0
	ushll.4s	v13, v13, #0
	ushll.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v5, v10
	mul.4s	v10, v6, v12
	mul.4s	v11, v1, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw.2d	v1, v25, v27
	uaddw.2d	v5, v24, v8
	uaddw.2d	v6, v19, v10
	uaddw.2d	v19, v20, v11
	uaddw2.2d	v18, v18, v27
	uaddw2.2d	v20, v7, v8
	uaddw2.2d	v24, v4, v10
	uaddw2.2d	v25, v2, v11
	uaddw.2d	v2, v26, v31
	uaddw.2d	v4, v23, v29
	uaddw.2d	v7, v16, v30
	uaddw.2d	v21, v21, v28
	uaddw2.2d	v22, v22, v31
	uaddw2.2d	v17, v17, v29
	uaddw2.2d	v23, v3, v30
	uaddw2.2d	v26, v0, v28
	ldp	q0, q3, [x23, #672]
	ldp	q16, q27, [x23, #640]
	ldp	q28, q29, [x23, #736]
	ldp	q30, q31, [x23, #704]
	ldr	q8, [sp, #15024]
	ldr	q9, [sp, #15040]
	ushll2.8h	v10, v8, #0
	ushll.4s	v11, v10, #0
	ushll.8h	v8, v8, #0
	ushll.4s	v12, v8, #0
	ushll2.4s	v10, v10, #0
	ushll2.4s	v8, v8, #0
	ushll2.8h	v13, v9, #0
	ushll.4s	v14, v13, #0
	ushll.8h	v9, v9, #0
	ushll.4s	v15, v9, #0
	ushll2.4s	v13, v13, #0
	ushll2.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v3, v10
	mul.4s	v10, v16, v12
	mul.4s	v11, v0, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw2.2d	v0, v25, v27
	uaddw2.2d	v3, v24, v8
	uaddw2.2d	v16, v20, v10
	uaddw2.2d	v18, v18, v11
	uaddw.2d	v19, v19, v27
	uaddw.2d	v20, v6, v8
	uaddw.2d	v24, v5, v10
	uaddw.2d	v25, v1, v11
	uaddw2.2d	v1, v26, v31
	uaddw2.2d	v5, v23, v29
	uaddw2.2d	v6, v17, v30
	uaddw2.2d	v17, v22, v28
	uaddw.2d	v21, v21, v31
	uaddw.2d	v22, v7, v29
	uaddw.2d	v23, v4, v30
	uaddw.2d	v26, v2, v28
	ldp	q4, q2, [x23, #768]
	ldp	q27, q7, [x23, #800]
	ldp	q29, q28, [x23, #832]
	ldp	q31, q30, [x23, #864]
	ldr	q8, [sp, #15056]
	ldr	q9, [sp, #15072]
	ushll.8h	v10, v8, #0
	ushll2.4s	v11, v10, #0
	ushll2.8h	v8, v8, #0
	ushll2.4s	v12, v8, #0
	ushll.4s	v10, v10, #0
	ushll.4s	v8, v8, #0
	ushll.8h	v13, v9, #0
	ushll2.4s	v14, v13, #0
	ushll2.8h	v9, v9, #0
	ushll2.4s	v15, v9, #0
	ushll.4s	v13, v13, #0
	ushll.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v4, v10
	mul.4s	v10, v7, v12
	mul.4s	v11, v2, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw.2d	v2, v25, v27
	uaddw.2d	v4, v24, v8
	uaddw.2d	v7, v20, v10
	uaddw.2d	v19, v19, v11
	uaddw2.2d	v18, v18, v27
	uaddw2.2d	v20, v16, v8
	uaddw2.2d	v24, v3, v10
	uaddw2.2d	v25, v0, v11
	uaddw.2d	v0, v26, v31
	uaddw.2d	v3, v23, v29
	uaddw.2d	v16, v22, v30
	uaddw.2d	v21, v21, v28
	uaddw2.2d	v17, v17, v31
	uaddw2.2d	v6, v6, v29
	uaddw2.2d	v5, v5, v30
	uaddw2.2d	v1, v1, v28
	ldp	q22, q23, [x23, #928]
	ldp	q26, q27, [x23, #896]
	ldp	q28, q29, [x23, #992]
	ldp	q30, q31, [x23, #960]
	ldr	q8, [sp, #15088]
	ldr	q9, [sp, #15104]
	ushll2.8h	v10, v8, #0
	ushll.4s	v11, v10, #0
	ushll.8h	v8, v8, #0
	ushll.4s	v12, v8, #0
	ushll2.4s	v10, v10, #0
	ushll2.4s	v8, v8, #0
	ushll2.8h	v13, v9, #0
	ushll.4s	v14, v13, #0
	ushll.8h	v9, v9, #0
	ushll.4s	v15, v9, #0
	ushll2.4s	v13, v13, #0
	ushll2.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v23, v23, v10
	mul.4s	v26, v26, v12
	mul.4s	v22, v22, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw2.2d	v25, v25, v27
	uaddw2.2d	v24, v24, v23
	uaddw2.2d	v20, v20, v26
	uaddw2.2d	v18, v18, v22
	uaddw.2d	v19, v19, v27
	uaddw.2d	v7, v7, v23
	uaddw.2d	v4, v4, v26
	uaddw.2d	v2, v2, v22
	uaddw2.2d	v1, v1, v31
	uaddw2.2d	v5, v5, v29
	uaddw2.2d	v6, v6, v30
	uaddw2.2d	v17, v17, v28
	uaddw.2d	v21, v21, v31
	uaddw.2d	v16, v16, v29
	uaddw.2d	v3, v3, v30
	uaddw.2d	v0, v0, v28
	add.2d	v0, v0, v2
	add.2d	v2, v3, v4
	add.2d	v3, v16, v7
	add.2d	v4, v21, v19
	add.2d	v7, v17, v18
	add.2d	v6, v6, v20
	add.2d	v5, v5, v24
	add.2d	v1, v1, v25
	add.2d	v1, v1, v5
	add.2d	v5, v6, v7
	add.2d	v1, v5, v1
	add.2d	v3, v4, v3
	add.2d	v0, v2, v0
	add.2d	v0, v0, v3
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x23, d0
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #2576
	add	x1, x19, #5
	mov	w2, #128                        ; =0x80
	bl	__ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
	cmp	x20, #1025
	mov	w8, #4                          ; =0x4
	csinc	x8, x8, xzr, hs
	add	x13, x0, #5
	add	x9, x13, x8, lsl #2
	sub	x11, x9, #4
	add	x10, x11, x23, lsr #3
	add	x9, x20, #5
	cmp	x10, x9
	b.hs	LBB0_77
; %bb.63:
	mov	x10, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mov	w12, #2                         ; =0x2
	cmp	x20, #1025
	csel	x12, xzr, x12, lo
	lsr	x12, x20, x12
	add	x13, x19, x13
	mov	x15, x21
	mov	x16, x11
	b	LBB0_65
LBB0_64:                                ;   in Loop: Header=BB0_65 Depth=1
	sub	x10, x10, x12
	add	x15, x15, x12
	mov	x14, x17
	mov	x11, x16
	cmp	x17, x8
	b.eq	LBB0_75
LBB0_65:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_68 Depth 2
                                        ;     Child Loop BB0_72 Depth 2
	mul	x0, x14, x12
	add	x17, x14, #1
	add	x1, x0, x12
	cmp	x17, x8
	csel	x1, x20, x1, eq
	cmp	x0, x1
	b.hs	LBB0_73
; %bb.66:                               ;   in Loop: Header=BB0_65 Depth=1
	mov	w2, #0                          ; =0x0
	mov	x0, #0                          ; =0x0
	add	x1, x1, x10
	mov	x3, x15
	mov	x16, x11
	b	LBB0_68
LBB0_67:                                ;   in Loop: Header=BB0_68 Depth=2
	subs	x1, x1, #1
	b.eq	LBB0_70
LBB0_68:                                ;   Parent Loop BB0_65 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w4, [x3], #1
	ldrh	w5, [x24, x4, lsl #1]
	lsl	x5, x5, x2
	orr	x0, x5, x0
	ldrb	w4, [x22, x4]
	add	w2, w2, w4
	subs	w4, w2, #32
	b.lo	LBB0_67
; %bb.69:                               ;   in Loop: Header=BB0_68 Depth=2
	str	w0, [x19, x16]
	add	x16, x16, #4
	lsr	x0, x0, #32
	mov	x2, x4
	b	LBB0_67
LBB0_70:                                ;   in Loop: Header=BB0_65 Depth=1
	cbz	w2, LBB0_73
; %bb.71:                               ;   in Loop: Header=BB0_65 Depth=1
	add	w1, w2, #8
LBB0_72:                                ;   Parent Loop BB0_65 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	strb	w0, [x19, x16]
	add	x16, x16, #1
	lsr	x0, x0, #8
	sub	w1, w1, #8
	cmp	w1, #8
	b.hi	LBB0_72
LBB0_73:                                ;   in Loop: Header=BB0_65 Depth=1
	cmp	x17, x8
	b.eq	LBB0_64
; %bb.74:                               ;   in Loop: Header=BB0_65 Depth=1
	sub	w11, w16, w11
	str	w11, [x13, x14, lsl #2]
	b	LBB0_64
LBB0_75:
	cmp	x16, x9
	b.hs	LBB0_77
; %bb.76:
	mov	w8, #36                         ; =0x24
	strb	w8, [x19]
	mov	x0, x16
	b	LBB0_78
LBB0_77:
	add	x22, x20, #5
	add	x0, x19, #5
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	mov	x0, x22
LBB0_78:
	ldur	x8, [x29, #-136]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_82
; %bb.79:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #2848
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
LBB0_80:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp3:                                  ; EH_LABEL
Lloh8:
	adrp	x1, l_.str@PAGE
Lloh9:
	add	x1, x1, l_.str@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ; EH_LABEL
LBB0_81:
Lloh10:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh11:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh12:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh13:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB0_82:
	bl	___stack_chk_fail
LBB0_83:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp0:                                  ; EH_LABEL
Lloh14:
	adrp	x1, l_.str.15@PAGE
Lloh15:
	add	x1, x1, l_.str.15@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ; EH_LABEL
	b	LBB0_81
LBB0_84:
Ltmp2:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_85:
Ltmp5:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdr	Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdrGot	Lloh12, Lloh13
	.loh AdrpLdrGot	Lloh10, Lloh11
	.loh AdrpAdd	Lloh14, Lloh15
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ; >> Call Site 1 <<
	.uleb128 Ltmp3-Lfunc_begin0             ;   Call between Lfunc_begin0 and Ltmp3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ; >> Call Site 2 <<
	.uleb128 Ltmp4-Ltmp3                    ;   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ;     jumps to Ltmp5
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ; >> Call Site 3 <<
	.uleb128 Ltmp0-Ltmp4                    ;   Call between Ltmp4 and Ltmp0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ; >> Call Site 4 <<
	.uleb128 Ltmp1-Ltmp0                    ;   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ;     jumps to Ltmp2
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ; >> Call Site 5 <<
	.uleb128 Lfunc_end0-Ltmp1               ;   Call between Ltmp1 and Lfunc_end0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE: ; @_ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
; %bb.0:
	sub	sp, sp, #160
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, #0                          ; =0x0
	str	wzr, [sp, #112]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #80]
	str	q0, [sp, #64]
	add	x9, sp, #64
	b	LBB1_2
LBB1_1:                                 ;   in Loop: Header=BB1_2 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB1_5
LBB1_2:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x0, x8]
	cmp	w10, #13
	b.hs	LBB1_25
; %bb.3:                                ;   in Loop: Header=BB1_2 Depth=1
	cbz	w10, LBB1_1
; %bb.4:                                ;   in Loop: Header=BB1_2 Depth=1
	ldr	w11, [x9, w10, uxtw #2]
	add	w11, w11, #1
	str	w11, [x9, w10, uxtw #2]
	b	LBB1_1
LBB1_5:
	ldr	w8, [sp, #68]
	cmp	w8, #2
	b.hi	LBB1_26
; %bb.6:
	str	wzr, [sp, #16]
	lsl	w8, w8, #1
	ldr	w9, [sp, #72]
	add	w9, w8, w9
	cmp	w9, #4
	b.hi	LBB1_26
; %bb.7:
	str	w8, [sp, #20]
	lsl	w8, w9, #1
	ldr	w9, [sp, #76]
	add	w9, w8, w9
	cmp	w9, #8
	b.hi	LBB1_26
; %bb.8:
	str	w8, [sp, #24]
	lsl	w8, w9, #1
	ldr	w9, [sp, #80]
	add	w9, w8, w9
	cmp	w9, #16
	b.hi	LBB1_26
; %bb.9:
	str	w8, [sp, #28]
	lsl	w8, w9, #1
	ldr	w9, [sp, #84]
	add	w9, w8, w9
	cmp	w9, #32
	b.hi	LBB1_26
; %bb.10:
	str	w8, [sp, #32]
	lsl	w8, w9, #1
	ldr	w9, [sp, #88]
	add	w9, w8, w9
	cmp	w9, #64
	b.hi	LBB1_26
; %bb.11:
	str	w8, [sp, #36]
	lsl	w8, w9, #1
	ldr	w9, [sp, #92]
	add	w9, w8, w9
	cmp	w9, #128
	b.hi	LBB1_26
; %bb.12:
	str	w8, [sp, #40]
	lsl	w8, w9, #1
	ldr	w9, [sp, #96]
	add	w9, w8, w9
	cmp	w9, #256
	b.hi	LBB1_26
; %bb.13:
	str	w8, [sp, #44]
	lsl	w8, w9, #1
	ldr	w9, [sp, #100]
	add	w9, w8, w9
	cmp	w9, #512
	b.hi	LBB1_26
; %bb.14:
	str	w8, [sp, #48]
	lsl	w8, w9, #1
	ldr	w9, [sp, #104]
	add	w9, w8, w9
	cmp	w9, #1024
	b.hi	LBB1_26
; %bb.15:
	str	w8, [sp, #52]
	lsl	w8, w9, #1
	ldr	w9, [sp, #108]
	add	w9, w8, w9
	cmp	w9, #2048
	b.hi	LBB1_26
; %bb.16:
	str	w8, [sp, #56]
	lsl	w8, w9, #1
	ldr	w9, [sp, #112]
	add	w9, w8, w9
	cmp	w9, #1, lsl #12                 ; =4096
	b.hi	LBB1_26
; %bb.17:
	str	w8, [sp, #60]
	b.ne	LBB1_28
; %bb.18:
	mov	x8, #0                          ; =0x0
	add	x9, sp, #12
	b	LBB1_20
LBB1_19:                                ;   in Loop: Header=BB1_20 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB1_24
LBB1_20:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_22 Depth 2
	ldrb	w10, [x0, x8]
	cbz	w10, LBB1_19
; %bb.21:                               ;   in Loop: Header=BB1_20 Depth=1
	mov	w11, #0                         ; =0x0
	ldr	w12, [x9, w10, uxtw #2]
	add	w13, w12, #1
	str	w13, [x9, w10, uxtw #2]
LBB1_22:                                ;   Parent Loop BB1_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x13, x11
	and	w11, w12, #0x1
	bfi	w11, w13, #1, #16
	lsr	w12, w12, #1
	subs	w10, w10, #1
	b.ne	LBB1_22
; %bb.23:                               ;   in Loop: Header=BB1_20 Depth=1
	strh	w11, [x1, x8, lsl #1]
	b	LBB1_19
LBB1_24:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB1_25:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp6:                                  ; EH_LABEL
Lloh16:
	adrp	x1, l_.str.18@PAGE
Lloh17:
	add	x1, x1, l_.str.18@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ; EH_LABEL
	b	LBB1_27
LBB1_26:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp12:                                 ; EH_LABEL
Lloh18:
	adrp	x1, l_.str.19@PAGE
Lloh19:
	add	x1, x1, l_.str.19@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ; EH_LABEL
LBB1_27:
Lloh20:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh21:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh22:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh23:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB1_28:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp9:                                  ; EH_LABEL
Lloh24:
	adrp	x1, l_.str.20@PAGE
Lloh25:
	add	x1, x1, l_.str.20@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ; EH_LABEL
	b	LBB1_27
LBB1_29:
Ltmp11:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_30:
Ltmp14:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_31:
Ltmp8:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpLdrGot	Lloh22, Lloh23
	.loh AdrpLdrGot	Lloh20, Lloh21
	.loh AdrpAdd	Lloh24, Lloh25
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ; >> Call Site 1 <<
	.uleb128 Ltmp6-Lfunc_begin1             ;   Call between Lfunc_begin1 and Ltmp6
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin1             ; >> Call Site 2 <<
	.uleb128 Ltmp7-Ltmp6                    ;   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin1             ;     jumps to Ltmp8
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin1             ; >> Call Site 3 <<
	.uleb128 Ltmp12-Ltmp7                   ;   Call between Ltmp7 and Ltmp12
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin1            ; >> Call Site 4 <<
	.uleb128 Ltmp13-Ltmp12                  ;   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin1            ;     jumps to Ltmp14
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin1            ; >> Call Site 5 <<
	.uleb128 Ltmp9-Ltmp13                   ;   Call between Ltmp13 and Ltmp9
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin1             ; >> Call Site 6 <<
	.uleb128 Ltmp10-Ltmp9                   ;   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin1            ;     jumps to Ltmp11
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin1            ; >> Call Site 7 <<
	.uleb128 Lfunc_end1-Ltmp10              ;   Call between Ltmp10 and Lfunc_end1
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
__ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE: ; @_ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x9, #0                          ; =0x0
	mov	w12, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	lsl	x8, x2, #1
	mov	w10, #15                        ; =0xf
	mov	w11, #14                        ; =0xe
	b	LBB2_4
LBB2_1:                                 ;   in Loop: Header=BB2_4 Depth=1
	strb	w14, [x1, x15]
LBB2_2:                                 ;   in Loop: Header=BB2_4 Depth=1
	add	x16, x13, #2
LBB2_3:                                 ;   in Loop: Header=BB2_4 Depth=1
	cmp	x9, #256
	b.hs	LBB2_43
LBB2_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_7 Depth 2
	mov	x13, x9
	ldrb	w14, [x0, x9]
	cmp	x9, #255
	b.ne	LBB2_6
; %bb.5:                                ;   in Loop: Header=BB2_4 Depth=1
	mov	w9, #256                        ; =0x100
	b	LBB2_9
LBB2_6:                                 ;   in Loop: Header=BB2_4 Depth=1
	add	x9, x13, #1
LBB2_7:                                 ;   Parent Loop BB2_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w15, [x0, x9]
	cmp	w15, w14
	b.ne	LBB2_9
; %bb.8:                                ;   in Loop: Header=BB2_7 Depth=2
	add	x9, x9, #1
	cmp	x9, #256
	b.ne	LBB2_7
LBB2_9:                                 ;   in Loop: Header=BB2_4 Depth=1
	sub	x15, x9, x13
	cmp	w14, w12, uxtb
	b.ne	LBB2_17
; %bb.10:                               ;   in Loop: Header=BB2_4 Depth=1
	mov	x13, x16
	subs	x16, x15, #19
	b.lo	LBB2_22
LBB2_11:                                ;   in Loop: Header=BB2_4 Depth=1
	cmp	x13, x8
	b.hs	LBB2_44
; %bb.12:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x14, x13, #1
	tbnz	w13, #0, LBB2_36
; %bb.13:                               ;   in Loop: Header=BB2_4 Depth=1
	strb	w10, [x1, x14]
	orr	x15, x13, #0x1
	cmp	x15, x8
	b.hs	LBB2_45
; %bb.14:                               ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w15, [x1, x14]
	orr	w15, w15, w16, lsl #4
	strb	w15, [x1, x14]
	add	x14, x13, #2
	cmp	x14, x8
	b.hs	LBB2_46
; %bb.15:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x15, x16, #4
	and	w16, w15, #0xff
	cmp	w16, #16
	b.hs	LBB2_46
; %bb.16:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x14, x14, #1
	strb	w15, [x1, x14]
	add	x16, x13, #3
	b	LBB2_3
LBB2_17:                                ;   in Loop: Header=BB2_4 Depth=1
	cmp	x16, x8
	b.hs	LBB2_47
; %bb.18:                               ;   in Loop: Header=BB2_4 Depth=1
	cmp	w14, #16
	b.hs	LBB2_47
; %bb.19:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x12, x16, #1
	tbnz	w16, #0, LBB2_21
; %bb.20:                               ;   in Loop: Header=BB2_4 Depth=1
	strb	w14, [x1, x12]
	add	x13, x16, #1
	sub	x15, x15, #1
	mov	x12, x14
	subs	x16, x15, #19
	b.hs	LBB2_11
	b	LBB2_22
LBB2_21:                                ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w13, [x1, x12]
	orr	w13, w13, w14, lsl #4
	strb	w13, [x1, x12]
	add	x13, x16, #1
	sub	x15, x15, #1
	mov	x12, x14
	subs	x16, x15, #19
	b.hs	LBB2_11
LBB2_22:                                ;   in Loop: Header=BB2_4 Depth=1
	cmp	x15, #2
	b.ls	LBB2_27
; %bb.23:                               ;   in Loop: Header=BB2_4 Depth=1
	cmp	x13, x8
	b.hs	LBB2_49
; %bb.24:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x14, x13, #1
	tbnz	w13, #0, LBB2_40
; %bb.25:                               ;   in Loop: Header=BB2_4 Depth=1
	strb	w11, [x1, x14]
	orr	x16, x13, #0x1
	cmp	x16, x8
	b.hs	LBB2_50
; %bb.26:                               ;   in Loop: Header=BB2_4 Depth=1
	lsl	w15, w15, #4
	sub	w15, w15, #48
	ldrb	w16, [x1, x14]
	orr	w15, w16, w15
	strb	w15, [x1, x14]
	b	LBB2_2
LBB2_27:                                ;   in Loop: Header=BB2_4 Depth=1
	cbz	x15, LBB2_42
; %bb.28:                               ;   in Loop: Header=BB2_4 Depth=1
	cmp	w14, #15
	b.hi	LBB2_48
; %bb.29:                               ;   in Loop: Header=BB2_4 Depth=1
	subs	x16, x8, x13
	csel	x2, xzr, x16, lo
	b.ls	LBB2_48
; %bb.30:                               ;   in Loop: Header=BB2_4 Depth=1
	lsl	w17, w14, #4
	lsr	x16, x13, #1
	mov	x3, x14
	tbz	w13, #0, LBB2_32
; %bb.31:                               ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w3, [x1, x16]
	orr	w3, w3, w17
LBB2_32:                                ;   in Loop: Header=BB2_4 Depth=1
	strb	w3, [x1, x16]
	add	x16, x13, #1
	cmp	x15, #1
	b.eq	LBB2_3
; %bb.33:                               ;   in Loop: Header=BB2_4 Depth=1
	cmp	x2, #1
	b.eq	LBB2_48
; %bb.34:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x15, x16, #1
	tbnz	w13, #0, LBB2_1
; %bb.35:                               ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w14, [x1, x15]
	orr	w14, w14, w17
	b	LBB2_1
LBB2_36:                                ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w16, [x1, x14]
	orr	w16, w16, #0xf0
	strb	w16, [x1, x14]
	add	x14, x13, #1
	cmp	x14, x8
	b.hs	LBB2_45
; %bb.37:                               ;   in Loop: Header=BB2_4 Depth=1
	sub	w15, w15, #19
	and	w16, w15, #0xf
	lsr	x14, x14, #1
	strb	w16, [x1, x14]
	add	x14, x13, #2
	cmp	x14, x8
	b.hs	LBB2_46
; %bb.38:                               ;   in Loop: Header=BB2_4 Depth=1
	ubfx	w15, w15, #4, #8
	cmp	w15, #16
	b.hs	LBB2_46
; %bb.39:                               ;   in Loop: Header=BB2_4 Depth=1
	lsr	x14, x14, #1
	ldrb	w16, [x1, x14]
	orr	w15, w16, w15, lsl #4
	strb	w15, [x1, x14]
	add	x16, x13, #3
	b	LBB2_3
LBB2_40:                                ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w16, [x1, x14]
	orr	w16, w16, #0xe0
	strb	w16, [x1, x14]
	add	x14, x13, #1
	cmp	x14, x8
	b.hs	LBB2_50
; %bb.41:                               ;   in Loop: Header=BB2_4 Depth=1
	sub	w15, w15, #3
	lsr	x14, x14, #1
	strb	w15, [x1, x14]
	b	LBB2_2
LBB2_42:                                ;   in Loop: Header=BB2_4 Depth=1
	mov	x16, x13
	b	LBB2_3
LBB2_43:
	add	x8, x16, #1
	lsr	x0, x8, #1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB2_44:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp27:                                 ; EH_LABEL
Lloh26:
	adrp	x1, l_.str.21@PAGE
Lloh27:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ; EH_LABEL
	b	LBB2_51
LBB2_45:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp30:                                 ; EH_LABEL
Lloh28:
	adrp	x1, l_.str.21@PAGE
Lloh29:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ; EH_LABEL
	b	LBB2_51
LBB2_46:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp33:                                 ; EH_LABEL
Lloh30:
	adrp	x1, l_.str.21@PAGE
Lloh31:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ; EH_LABEL
	b	LBB2_51
LBB2_47:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp15:                                 ; EH_LABEL
Lloh32:
	adrp	x1, l_.str.21@PAGE
Lloh33:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ; EH_LABEL
	b	LBB2_51
LBB2_48:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp18:                                 ; EH_LABEL
Lloh34:
	adrp	x1, l_.str.21@PAGE
Lloh35:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ; EH_LABEL
	b	LBB2_51
LBB2_49:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp21:                                 ; EH_LABEL
Lloh36:
	adrp	x1, l_.str.21@PAGE
Lloh37:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ; EH_LABEL
	b	LBB2_51
LBB2_50:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp24:                                 ; EH_LABEL
Lloh38:
	adrp	x1, l_.str.21@PAGE
Lloh39:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ; EH_LABEL
LBB2_51:
Lloh40:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh41:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh42:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh43:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB2_52:
Ltmp26:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_53:
Ltmp23:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_54:
Ltmp20:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_55:
Ltmp17:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_56:
Ltmp35:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_57:
Ltmp32:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_58:
Ltmp29:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpLdrGot	Lloh42, Lloh43
	.loh AdrpLdrGot	Lloh40, Lloh41
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ; >> Call Site 1 <<
	.uleb128 Ltmp27-Lfunc_begin2            ;   Call between Lfunc_begin2 and Ltmp27
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin2            ; >> Call Site 2 <<
	.uleb128 Ltmp28-Ltmp27                  ;   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin2            ;     jumps to Ltmp29
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin2            ; >> Call Site 3 <<
	.uleb128 Ltmp30-Ltmp28                  ;   Call between Ltmp28 and Ltmp30
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin2            ; >> Call Site 4 <<
	.uleb128 Ltmp31-Ltmp30                  ;   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin2            ;     jumps to Ltmp32
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin2            ; >> Call Site 5 <<
	.uleb128 Ltmp33-Ltmp31                  ;   Call between Ltmp31 and Ltmp33
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin2            ; >> Call Site 6 <<
	.uleb128 Ltmp34-Ltmp33                  ;   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin2            ;     jumps to Ltmp35
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin2            ; >> Call Site 7 <<
	.uleb128 Ltmp15-Ltmp34                  ;   Call between Ltmp34 and Ltmp15
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin2            ; >> Call Site 8 <<
	.uleb128 Ltmp16-Ltmp15                  ;   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin2            ;     jumps to Ltmp17
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin2            ; >> Call Site 9 <<
	.uleb128 Ltmp18-Ltmp16                  ;   Call between Ltmp16 and Ltmp18
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin2            ; >> Call Site 10 <<
	.uleb128 Ltmp19-Ltmp18                  ;   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin2            ;     jumps to Ltmp20
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin2            ; >> Call Site 11 <<
	.uleb128 Ltmp21-Ltmp19                  ;   Call between Ltmp19 and Ltmp21
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin2            ; >> Call Site 12 <<
	.uleb128 Ltmp22-Ltmp21                  ;   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin2            ;     jumps to Ltmp23
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin2            ; >> Call Site 13 <<
	.uleb128 Ltmp24-Ltmp22                  ;   Call between Ltmp22 and Ltmp24
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin2            ; >> Call Site 14 <<
	.uleb128 Ltmp25-Ltmp24                  ;   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin2            ;     jumps to Ltmp26
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin2            ; >> Call Site 15 <<
	.uleb128 Lfunc_end2-Ltmp25              ;   Call between Ltmp25 and Lfunc_end2
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
lCPI3_0:
	.long	12                              ; 0xc
	.long	13                              ; 0xd
	.long	14                              ; 0xe
	.long	15                              ; 0xf
lCPI3_1:
	.long	8                               ; 0x8
	.long	9                               ; 0x9
	.long	10                              ; 0xa
	.long	11                              ; 0xb
lCPI3_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI3_3:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI3_4:
	.byte	4                               ; 0x4
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	5                               ; 0x5
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	6                               ; 0x6
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	7                               ; 0x7
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI3_5:
	.byte	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	2                               ; 0x2
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	3                               ; 0x3
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI3_6:
	.byte	8                               ; 0x8
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	9                               ; 0x9
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	10                              ; 0xa
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	11                              ; 0xb
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI3_7:
	.byte	12                              ; 0xc
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	13                              ; 0xd
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	14                              ; 0xe
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	15                              ; 0xf
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ; @_ZN16cng_layout_model6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception3
; %bb.0:
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #1344
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	mov	x20, x1
Lloh44:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh45:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh46:
	ldr	x8, [x8]
	stur	x8, [x29, #-160]
	subs	x1, x1, #5
	b.lo	LBB3_191
; %bb.1:
	mov	x19, x3
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x3, x8
	b.hi	LBB3_191
; %bb.2:
	mov	x21, x0
	ldur	w8, [x0, #1]
	cmp	x19, x8
	b.ne	LBB3_191
; %bb.3:
	ldrb	w8, [x21]
	cmp	w8, #36
	b.eq	LBB3_15
; %bb.4:
	cmp	w8, #4
	b.eq	LBB3_10
; %bb.5:
	cbnz	w8, LBB3_193
; %bb.6:
	add	x8, x19, #5
	cmp	x20, x8
	b.ne	LBB3_195
; %bb.7:
	cbz	x19, LBB3_189
; %bb.8:
	ldur	x8, [x29, #-160]
Lloh47:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh48:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh49:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB3_192
; %bb.9:
	add	x1, x21, #5
	mov	x0, x2
	mov	x2, x19
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1344
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	b	_memcpy
LBB3_10:
	cmp	x20, #6
	b.ne	LBB3_196
; %bb.11:
	cbz	x19, LBB3_196
; %bb.12:
	cmp	x19, #1
	b.lt	LBB3_189
; %bb.13:
	ldrb	w1, [x21, #5]
	ldur	x8, [x29, #-160]
Lloh50:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh51:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh52:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB3_192
; %bb.14:
	mov	x0, x2
	mov	x2, x19
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1344
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	b	_memset
LBB3_15:
	cmp	x20, #6
	b.ls	LBB3_193
; %bb.16:
	str	x2, [sp, #184]                  ; 8-byte Spill
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #25888]
	str	q0, [sp, #25872]
	str	q0, [sp, #25856]
	str	q0, [sp, #25840]
	str	q0, [sp, #25824]
	str	q0, [sp, #25808]
	str	q0, [sp, #25792]
	str	q0, [sp, #25776]
	str	q0, [sp, #25760]
	str	q0, [sp, #25744]
	str	q0, [sp, #25728]
	str	q0, [sp, #25712]
	str	q0, [sp, #25696]
	str	q0, [sp, #25680]
	str	q0, [sp, #25664]
	str	q0, [sp, #25648]
	str	q0, [sp, #25632]
	str	q0, [sp, #25616]
	str	q0, [sp, #25600]
	str	q0, [sp, #25584]
	str	q0, [sp, #25568]
	str	q0, [sp, #25552]
	str	q0, [sp, #25536]
	str	q0, [sp, #25520]
	str	q0, [sp, #25504]
	str	q0, [sp, #25488]
	str	q0, [sp, #25472]
	str	q0, [sp, #25456]
	str	q0, [sp, #25440]
	str	q0, [sp, #25424]
	str	q0, [sp, #25408]
	str	q0, [sp, #25392]
	str	q0, [sp, #25376]
	str	q0, [sp, #25360]
	str	q0, [sp, #25344]
	str	q0, [sp, #25328]
	str	q0, [sp, #25312]
	str	q0, [sp, #25296]
	str	q0, [sp, #25280]
	str	q0, [sp, #25264]
	str	q0, [sp, #25248]
	str	q0, [sp, #25232]
	str	q0, [sp, #25216]
	str	q0, [sp, #25200]
	str	q0, [sp, #25184]
	str	q0, [sp, #25168]
	str	q0, [sp, #25152]
	str	q0, [sp, #25136]
	add	x24, sp, #6, lsl #12            ; =24576
	add	x24, x24, #1072
	add	x0, x21, #5
	add	x2, sp, #6, lsl #12             ; =24576
	add	x2, x2, #1072
	bl	__ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
	add	x23, x0, #5
	mov	w8, #12                         ; =0xc
	cmp	x19, #1025
	csel	x8, xzr, x8, lo
	add	x8, x23, x8
	cmp	x20, x8
	b.lo	LBB3_197
; %bb.17:
	mov	x22, x0
	add	x25, sp, #6, lsl #12            ; =24576
	add	x25, x25, #560
	add	x0, sp, #6, lsl #12             ; =24576
	add	x0, x0, #1072
	add	x1, sp, #6, lsl #12             ; =24576
	add	x1, x1, #560
	bl	__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	add	x26, sp, #4, lsl #12            ; =16384
	add	x26, x26, #560
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #560
	mov	w1, #8192                       ; =0x2000
	bl	_bzero
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	b	LBB3_19
LBB3_18:                                ;   in Loop: Header=BB3_19 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB3_23
LBB3_19:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_22 Depth 2
	ldrb	w11, [x24, x8]
	cbz	x11, LBB3_18
; %bb.20:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrh	w10, [x25, x8, lsl #1]
	cmp	x10, #4095
	b.hi	LBB3_18
; %bb.21:                               ;   in Loop: Header=BB3_19 Depth=1
	lsl	x12, x9, x11
	orr	w11, w8, w11, lsl #8
LBB3_22:                                ;   Parent Loop BB3_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	strh	w11, [x26, x10, lsl #1]
	add	x10, x10, x12
	cmp	x10, #1, lsl #12                ; =4096
	b.lo	LBB3_22
	b	LBB3_18
LBB3_23:
	cmp	x19, #1025
	b.hs	LBB3_47
; %bb.24:
	sub	x9, x20, x23
	add	x10, x21, x23
	str	x10, [sp, #560]
	str	x9, [sp, #568]
	ldr	x0, [sp, #184]                  ; 8-byte Reload
	cbz	x19, LBB3_187
; %bb.25:
	mov	x13, #0                         ; =0x0
	mov	x17, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x12, #0                         ; =0x0
Lloh53:
	adrp	x14, lCPI3_3@PAGE
Lloh54:
	ldr	q0, [x14, lCPI3_3@PAGEOFF]
Lloh55:
	adrp	x14, lCPI3_0@PAGE
Lloh56:
	ldr	q1, [x14, lCPI3_0@PAGEOFF]
Lloh57:
	adrp	x14, lCPI3_1@PAGE
Lloh58:
	ldr	q2, [x14, lCPI3_1@PAGEOFF]
Lloh59:
	adrp	x14, lCPI3_2@PAGE
Lloh60:
	ldr	q3, [x14, lCPI3_2@PAGEOFF]
Lloh61:
	adrp	x14, lCPI3_4@PAGE
Lloh62:
	ldr	q4, [x14, lCPI3_4@PAGEOFF]
	add	x14, x22, x21
	add	x14, x14, #21
	movi.4s	v5, #4
	sub	x15, x22, x20
Lloh63:
	adrp	x16, lCPI3_5@PAGE
Lloh64:
	ldr	q6, [x16, lCPI3_5@PAGEOFF]
	add	x15, x15, #5
Lloh65:
	adrp	x16, lCPI3_6@PAGE
Lloh66:
	ldr	q7, [x16, lCPI3_6@PAGEOFF]
Lloh67:
	adrp	x16, lCPI3_7@PAGE
Lloh68:
	ldr	q16, [x16, lCPI3_7@PAGEOFF]
	movi.4s	v17, #128
	movi.4s	v18, #32
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #560
	b	LBB3_29
LBB3_26:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	w4, [x10, x17]
LBB3_27:                                ;   in Loop: Header=BB3_29 Depth=1
	mov	w17, w4
	lsl	x17, x17, x8
	orr	x11, x17, x11
	orr	w8, w8, #0x20
	mov	x17, x12
LBB3_28:                                ;   in Loop: Header=BB3_29 Depth=1
	and	x1, x11, #0xfff
	ldrh	w1, [x16, x1, lsl #1]
	strb	w1, [x0, x13]
	lsr	x1, x1, #8
	lsr	x11, x11, x1
	sub	w8, w8, w1
	add	x13, x13, #1
	cmp	x13, x19
	b.eq	LBB3_188
LBB3_29:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_38 Depth 2
                                        ;     Child Loop BB3_43 Depth 2
                                        ;     Child Loop BB3_46 Depth 2
	cmp	w8, #11
	b.hi	LBB3_28
; %bb.30:                               ;   in Loop: Header=BB3_29 Depth=1
	add	x12, x17, #4
	cmp	x12, x9
	b.ls	LBB3_26
; %bb.31:                               ;   in Loop: Header=BB3_29 Depth=1
	subs	x1, x9, x17
	b.ls	LBB3_34
; %bb.32:                               ;   in Loop: Header=BB3_29 Depth=1
	cmp	x1, #4
	b.hs	LBB3_35
; %bb.33:                               ;   in Loop: Header=BB3_29 Depth=1
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB3_45
LBB3_34:                                ;   in Loop: Header=BB3_29 Depth=1
	mov	w4, #0                          ; =0x0
	b	LBB3_27
LBB3_35:                                ;   in Loop: Header=BB3_29 Depth=1
	cmp	x1, #32
	b.hs	LBB3_37
; %bb.36:                               ;   in Loop: Header=BB3_29 Depth=1
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB3_42
LBB3_37:                                ;   in Loop: Header=BB3_29 Depth=1
	and	x3, x1, #0x1c
	and	x2, x1, #0xffffffffffffffe0
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	add	x0, x14, x17
	and	x4, x1, #0xffffffffffffffe0
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v23, #0000000000000000
	mov.16b	v26, v0
	movi.2d	v24, #0000000000000000
	mov.16b	v27, v3
	movi.2d	v25, #0000000000000000
	mov.16b	v29, v2
	movi.2d	v28, #0000000000000000
	mov.16b	v30, v1
LBB3_38:                                ;   Parent Loop BB3_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q8, [x0, #-16]
	tbl.16b	v9, { v31 }, v4
	tbl.16b	v10, { v31 }, v6
	tbl.16b	v11, { v31 }, v7
	tbl.16b	v31, { v31 }, v16
	tbl.16b	v12, { v8 }, v6
	tbl.16b	v13, { v8 }, v4
	tbl.16b	v14, { v8 }, v7
	tbl.16b	v8, { v8 }, v16
	shl.4s	v15, v30, #3
	ushl.4s	v31, v31, v15
	add.4s	v15, v15, v17
	ushl.4s	v8, v8, v15
	shl.4s	v15, v29, #3
	ushl.4s	v11, v11, v15
	add.4s	v15, v15, v17
	ushl.4s	v14, v14, v15
	shl.4s	v15, v27, #3
	ushl.4s	v9, v9, v15
	add.4s	v15, v15, v17
	ushl.4s	v13, v13, v15
	shl.4s	v15, v26, #3
	ushl.4s	v10, v10, v15
	add.4s	v15, v15, v17
	ushl.4s	v12, v12, v15
	orr.16b	v22, v9, v22
	orr.16b	v20, v10, v20
	orr.16b	v21, v11, v21
	orr.16b	v23, v31, v23
	orr.16b	v24, v12, v24
	orr.16b	v19, v13, v19
	orr.16b	v25, v14, v25
	orr.16b	v28, v8, v28
	add.4s	v26, v26, v18
	add.4s	v27, v27, v18
	add.4s	v29, v29, v18
	add	x0, x0, #32
	add.4s	v30, v30, v18
	subs	x4, x4, #32
	b.ne	LBB3_38
; %bb.39:                               ;   in Loop: Header=BB3_29 Depth=1
	orr.16b	v19, v19, v22
	orr.16b	v22, v28, v23
	orr.16b	v20, v24, v20
	orr.16b	v21, v25, v21
	orr.16b	v20, v20, v21
	orr.16b	v19, v19, v22
	orr.16b	v19, v20, v19
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x0, d19
	lsr	x4, x0, #32
	orr	w4, w0, w4
	cmp	x1, x2
	b.ne	LBB3_41
; %bb.40:                               ;   in Loop: Header=BB3_29 Depth=1
	ldr	x0, [sp, #184]                  ; 8-byte Reload
	b	LBB3_27
LBB3_41:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x0, [sp, #184]                  ; 8-byte Reload
	cbz	x3, LBB3_45
LBB3_42:                                ;   in Loop: Header=BB3_29 Depth=1
	mov	x5, x2
	and	x2, x1, #0xfffffffffffffffc
	movi.2d	v19, #0000000000000000
	mov.s	v19[0], w4
	dup.4s	v20, w5
	orr.16b	v20, v20, v0
	sub	x3, x5, x2
	add	x4, x17, x5
	add	x4, x10, x4
LBB3_43:                                ;   Parent Loop BB3_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s21, [x4], #4
	ushll.8h	v21, v21, #0
	ushll.4s	v21, v21, #0
	shl.4s	v22, v20, #3
	ushl.4s	v21, v21, v22
	orr.16b	v19, v21, v19
	add.4s	v20, v20, v5
	adds	x3, x3, #4
	b.ne	LBB3_43
; %bb.44:                               ;   in Loop: Header=BB3_29 Depth=1
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x3, d19
	lsr	x4, x3, #32
	orr	w4, w3, w4
	cmp	x1, x2
	b.eq	LBB3_27
LBB3_45:                                ;   in Loop: Header=BB3_29 Depth=1
	add	x3, x2, x17
	add	x17, x3, x15
	lsl	w1, w2, #3
	add	x2, x10, x3
LBB3_46:                                ;   Parent Loop BB3_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w3, [x2], #1
	lsl	w3, w3, w1
	orr	w4, w3, w4
	add	w1, w1, #8
	adds	x17, x17, #1
	b.lo	LBB3_46
	b	LBB3_27
LBB3_47:
	add	x24, sp, #560
	add	x0, sp, #560
	mov	w1, #16384                      ; =0x4000
	bl	_bzero
	mov	x8, #0                          ; =0x0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #560
	ldr	x6, [sp, #184]                  ; 8-byte Reload
	b	LBB3_50
LBB3_48:                                ;   in Loop: Header=BB3_50 Depth=1
	lsl	w11, w11, #16
	mov	w12, #16777216                  ; =0x1000000
LBB3_49:                                ;   in Loop: Header=BB3_50 Depth=1
	and	w10, w10, #0xff
	orr	w10, w10, w12
	orr	w10, w11, w10
	str	w10, [x24, x8, lsl #2]
	add	x8, x8, #1
	cmp	x8, #1, lsl #12                 ; =4096
	b.eq	LBB3_52
LBB3_50:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x9, x8, lsl #1]
	lsr	x11, x10, #8
	lsr	x12, x8, x11
	ldrh	w12, [x9, x12, lsl #1]
	add	w13, w11, w12, lsr #8
	cmp	w13, #12
	b.hi	LBB3_48
; %bb.51:                               ;   in Loop: Header=BB3_50 Depth=1
	lsl	w11, w13, #16
	bfi	w11, w12, #8, #8
	mov	w12, #33554432                  ; =0x2000000
	b	LBB3_49
LBB3_52:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #528]
	stp	q0, q0, [sp, #496]
	stp	q0, q0, [sp, #464]
	stp	q0, q0, [sp, #432]
	stp	q0, q0, [sp, #400]
	add	x24, x22, #17
	add	x8, x21, x23
	ldr	w10, [x8]
	sub	x9, x20, x24
	str	x10, [sp, #256]                 ; 8-byte Spill
	cmp	x9, x10
	stp	q0, q0, [sp, #304]
	b.lo	LBB3_194
; %bb.53:
	lsr	x26, x19, #2
	add	x10, x21, x24
	add	x9, x21, x24
	str	x9, [sp, #208]                  ; 8-byte Spill
	ldr	x9, [sp, #256]                  ; 8-byte Reload
	stp	x10, x9, [sp, #400]
	stp	x6, x26, [sp, #336]
	ldr	w10, [x8, #4]
	add	x9, x24, x9
	sub	x11, x20, x9
	cmp	x11, x10
	b.lo	LBB3_194
; %bb.54:
	add	x12, x21, x9
	add	x11, x21, x9
	str	x11, [sp, #216]                 ; 8-byte Spill
	stp	x12, x10, [sp, #440]
	add	x11, x6, x26
	add	x12, x6, x26
	str	x12, [sp, #272]                 ; 8-byte Spill
	stp	x11, x26, [sp, #352]
	ldr	w12, [x8, #8]
	add	x8, x9, x10
	sub	x9, x20, x8
	cmp	x9, x12
	b.lo	LBB3_194
; %bb.55:
	mov	x3, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	w16, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x25, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	x30, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x28, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	w17, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	x7, #0                          ; =0x0
	sub	x9, x26, x26, lsl #2
	add	x11, x9, x19
	add	x27, x21, x8
	add	x9, x21, x8
	str	x9, [sp, #200]                  ; 8-byte Spill
	stp	x27, x12, [sp, #480]
	lsl	x27, x26, #1
	add	x9, x6, x27
	stp	x9, x26, [sp, #368]
	add	x8, x8, x12
	str	x10, [sp, #176]                 ; 8-byte Spill
	sub	x10, x20, x8
	add	x8, x21, x8
	str	x8, [sp, #192]                  ; 8-byte Spill
	str	x8, [sp, #520]
	str	x10, [sp, #240]                 ; 8-byte Spill
	str	x10, [sp, #528]
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x8, x27, x26
	sub	x19, x19, x8
	cmn	x11, #1
	csel	x19, x19, x11, eq
	add	x11, x6, x8
	stp	x11, x19, [sp, #384]
	add	x8, x22, x21
	add	x8, x8, #33
	str	x8, [sp, #64]                   ; 8-byte Spill
	add	x8, x21, x24
	str	x8, [sp, #120]                  ; 8-byte Spill
	ldr	x27, [sp, #256]                 ; 8-byte Reload
	add	x8, x22, x27
	add	x24, x8, x21
	add	x24, x24, #33
	add	x22, x22, x10
	add	x21, x27, x21
	add	x21, x22, x21
	add	x22, x21, #33
	stp	x22, x24, [sp, #48]             ; 16-byte Folded Spill
	add	x22, x21, #17
	str	x22, [sp, #112]                 ; 8-byte Spill
	add	x21, x21, x12
	add	x22, x10, x12
	add	x8, x8, x22
Lloh69:
	adrp	x22, lCPI3_4@PAGE
Lloh70:
	ldr	q12, [x22, lCPI3_4@PAGEOFF]
Lloh71:
	adrp	x22, lCPI3_5@PAGE
Lloh72:
	ldr	q0, [x22, lCPI3_5@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Spill
Lloh73:
	adrp	x22, lCPI3_6@PAGE
Lloh74:
	ldr	q0, [x22, lCPI3_6@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Spill
	add	x22, x21, #33
	str	x22, [sp, #40]                  ; 8-byte Spill
	add	x21, x21, #17
	str	x21, [sp, #104]                 ; 8-byte Spill
	sub	x8, x8, x20
Lloh75:
	adrp	x20, lCPI3_7@PAGE
Lloh76:
	ldr	q0, [x20, lCPI3_7@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
	add	x8, x8, #17
	str	x8, [sp, #96]                   ; 8-byte Spill
Lloh77:
	adrp	x8, lCPI3_3@PAGE
Lloh78:
	ldr	q0, [x8, lCPI3_3@PAGEOFF]
	movi.4s	v1, #4
Lloh79:
	adrp	x8, lCPI3_0@PAGE
Lloh80:
	ldr	q2, [x8, lCPI3_0@PAGEOFF]
Lloh81:
	adrp	x8, lCPI3_1@PAGE
Lloh82:
	ldr	q3, [x8, lCPI3_1@PAGEOFF]
Lloh83:
	adrp	x8, lCPI3_2@PAGE
Lloh84:
	ldr	q4, [x8, lCPI3_2@PAGEOFF]
	movi.4s	v5, #128
	movi.4s	v6, #32
	neg	x8, x27
	str	x8, [sp, #88]                   ; 8-byte Spill
	neg	x8, x10
	str	x8, [sp, #80]                   ; 8-byte Spill
	str	x12, [sp, #224]                 ; 8-byte Spill
	neg	x8, x12
	str	x8, [sp, #72]                   ; 8-byte Spill
	add	x21, sp, #560
	b	LBB3_59
LBB3_56:                                ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #192]                  ; 8-byte Reload
	ldr	w8, [x8, x25]
LBB3_57:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w8, w8
	lsl	x8, x8, x14
	orr	x13, x8, x13
	orr	w14, w14, #0x20
	mov	x25, x27
LBB3_58:                                ;   in Loop: Header=BB3_59 Depth=1
	lsr	x8, x22, #16
	ubfx	x27, x22, #16, #8
	lsr	x1, x1, x8
	sub	w16, w16, w27
	add	x7, x7, x22, lsr #24
	lsr	x8, x20, #16
	ubfx	x22, x20, #16, #8
	lsr	x2, x2, x8
	sub	w0, w0, w22
	add	x4, x4, x20, lsr #24
	lsr	x8, x24, #16
	ubfx	x20, x24, #16, #8
	lsr	x15, x15, x8
	sub	w17, w17, w20
	add	x5, x5, x24, lsr #24
	and	x8, x13, #0xfff
	ldr	w8, [x21, x8, lsl #2]
	lsr	x20, x8, #16
	ubfx	x22, x8, #16, #8
	lsr	x13, x13, x20
	sub	w14, w14, w22
	strh	w8, [x11, x3]
	sub	x20, x26, x7
	add	x3, x3, x8, lsr #24
	cmp	x20, #1
	b.ls	LBB3_140
LBB3_59:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_105 Depth 2
                                        ;     Child Loop BB3_124 Depth 2
                                        ;     Child Loop BB3_127 Depth 2
                                        ;     Child Loop BB3_109 Depth 2
                                        ;     Child Loop BB3_130 Depth 2
                                        ;     Child Loop BB3_133 Depth 2
                                        ;     Child Loop BB3_113 Depth 2
                                        ;     Child Loop BB3_136 Depth 2
                                        ;     Child Loop BB3_139 Depth 2
                                        ;     Child Loop BB3_101 Depth 2
                                        ;     Child Loop BB3_118 Depth 2
                                        ;     Child Loop BB3_121 Depth 2
	sub	x8, x26, x4
	cmp	x8, #2
	b.lo	LBB3_140
; %bb.60:                               ;   in Loop: Header=BB3_59 Depth=1
	sub	x8, x26, x5
	cmp	x8, #2
	b.lo	LBB3_140
; %bb.61:                               ;   in Loop: Header=BB3_59 Depth=1
	sub	x8, x19, x3
	cmp	x8, #2
	b.lo	LBB3_140
; %bb.62:                               ;   in Loop: Header=BB3_59 Depth=1
	cmp	w16, #11
	b.ls	LBB3_66
; %bb.63:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x8, x1, #0xfff
	ldr	w22, [x21, x8, lsl #2]
	strh	w22, [x6, x7]
	cmp	w0, #11
	b.ls	LBB3_69
LBB3_64:                                ;   in Loop: Header=BB3_59 Depth=1
	and	x8, x2, #0xfff
	ldr	w20, [x21, x8, lsl #2]
	ldr	x8, [sp, #272]                  ; 8-byte Reload
	strh	w20, [x8, x4]
	cmp	w17, #11
	b.ls	LBB3_72
LBB3_65:                                ;   in Loop: Header=BB3_59 Depth=1
	and	x8, x15, #0xfff
	ldr	w24, [x21, x8, lsl #2]
	strh	w24, [x9, x5]
	cmp	w14, #11
	b.hi	LBB3_58
	b	LBB3_75
LBB3_66:                                ;   in Loop: Header=BB3_59 Depth=1
	add	x20, x30, #4
	ldr	x8, [sp, #256]                  ; 8-byte Reload
	cmp	x20, x8
	b.hi	LBB3_79
; %bb.67:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #208]                  ; 8-byte Reload
	ldr	w27, [x8, x30]
LBB3_68:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w8, w27
	lsl	x8, x8, x16
	orr	x1, x8, x1
	orr	w16, w16, #0x20
	mov	x30, x20
	and	x8, x1, #0xfff
	ldr	w22, [x21, x8, lsl #2]
	strh	w22, [x6, x7]
	cmp	w0, #11
	b.hi	LBB3_64
LBB3_69:                                ;   in Loop: Header=BB3_59 Depth=1
	add	x20, x23, #4
	cmp	x20, x10
	b.hi	LBB3_82
; %bb.70:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #216]                  ; 8-byte Reload
	ldr	w27, [x8, x23]
LBB3_71:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w8, w27
	lsl	x8, x8, x0
	orr	x2, x8, x2
	orr	w0, w0, #0x20
	mov	x23, x20
	and	x8, x2, #0xfff
	ldr	w20, [x21, x8, lsl #2]
	ldr	x8, [sp, #272]                  ; 8-byte Reload
	strh	w20, [x8, x4]
	cmp	w17, #11
	b.hi	LBB3_65
LBB3_72:                                ;   in Loop: Header=BB3_59 Depth=1
	add	x24, x28, #4
	ldr	x8, [sp, #224]                  ; 8-byte Reload
	cmp	x24, x8
	b.hi	LBB3_85
; %bb.73:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #200]                  ; 8-byte Reload
	ldr	w27, [x8, x28]
LBB3_74:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w8, w27
	lsl	x8, x8, x17
	orr	x15, x8, x15
	orr	w17, w17, #0x20
	mov	x28, x24
	and	x8, x15, #0xfff
	ldr	w24, [x21, x8, lsl #2]
	strh	w24, [x9, x5]
	cmp	w14, #11
	b.hi	LBB3_58
LBB3_75:                                ;   in Loop: Header=BB3_59 Depth=1
	add	x27, x25, #4
	ldr	x8, [sp, #240]                  ; 8-byte Reload
	cmp	x27, x8
	b.ls	LBB3_56
; %bb.76:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #240]                  ; 8-byte Reload
	subs	x8, x8, x25
	b.ls	LBB3_88
; %bb.77:                               ;   in Loop: Header=BB3_59 Depth=1
	cmp	x8, #4
	str	x9, [sp, #8]                    ; 8-byte Spill
	b.hs	LBB3_92
; %bb.78:                               ;   in Loop: Header=BB3_59 Depth=1
	str	xzr, [sp, #32]                  ; 8-byte Spill
	mov	w8, #0                          ; =0x0
	b	LBB3_120
LBB3_79:                                ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #256]                  ; 8-byte Reload
	subs	x22, x8, x30
	b.ls	LBB3_89
; %bb.80:                               ;   in Loop: Header=BB3_59 Depth=1
	cmp	x22, #4
	b.hs	LBB3_94
; %bb.81:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x24, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB3_126
LBB3_82:                                ;   in Loop: Header=BB3_59 Depth=1
	subs	x24, x10, x23
	b.ls	LBB3_90
; %bb.83:                               ;   in Loop: Header=BB3_59 Depth=1
	cmp	x24, #4
	b.hs	LBB3_96
; %bb.84:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB3_132
LBB3_85:                                ;   in Loop: Header=BB3_59 Depth=1
	subs	x12, x8, x28
	b.ls	LBB3_91
; %bb.86:                               ;   in Loop: Header=BB3_59 Depth=1
	cmp	x12, #4
	b.hs	LBB3_98
; %bb.87:                               ;   in Loop: Header=BB3_59 Depth=1
	str	xzr, [sp, #32]                  ; 8-byte Spill
	mov	w27, #0                         ; =0x0
	b	LBB3_138
LBB3_88:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w8, #0                          ; =0x0
	b	LBB3_57
LBB3_89:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB3_68
LBB3_90:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB3_71
LBB3_91:                                ;   in Loop: Header=BB3_59 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB3_74
LBB3_92:                                ;   in Loop: Header=BB3_59 Depth=1
	cmp	x8, #32
	str	x8, [sp, #24]                   ; 8-byte Spill
	b.hs	LBB3_100
; %bb.93:                               ;   in Loop: Header=BB3_59 Depth=1
	str	xzr, [sp, #32]                  ; 8-byte Spill
	mov	w8, #0                          ; =0x0
	b	LBB3_117
LBB3_94:                                ;   in Loop: Header=BB3_59 Depth=1
	cmp	x22, #32
	b.hs	LBB3_104
; %bb.95:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x24, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB3_123
LBB3_96:                                ;   in Loop: Header=BB3_59 Depth=1
	cmp	x24, #32
	b.hs	LBB3_108
; %bb.97:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB3_129
LBB3_98:                                ;   in Loop: Header=BB3_59 Depth=1
	cmp	x12, #32
	b.hs	LBB3_112
; %bb.99:                               ;   in Loop: Header=BB3_59 Depth=1
	str	xzr, [sp, #32]                  ; 8-byte Spill
	mov	w27, #0                         ; =0x0
	b	LBB3_135
LBB3_100:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x10, x8, #0x1c
	str	x10, [sp, #16]                  ; 8-byte Spill
	and	x10, x8, #0xffffffffffffffe0
	str	x10, [sp, #32]                  ; 8-byte Spill
	mov	x10, x8
	ldr	x8, [sp, #40]                   ; 8-byte Reload
	add	x6, x8, x25
Lloh85:
	adrp	x8, lCPI3_0@PAGE
Lloh86:
	ldr	q7, [x8, lCPI3_0@PAGEOFF]
Lloh87:
	adrp	x8, lCPI3_1@PAGE
Lloh88:
	ldr	q16, [x8, lCPI3_1@PAGEOFF]
	movi.2d	v17, #0000000000000000
	and	x10, x10, #0xffffffffffffffe0
Lloh89:
	adrp	x8, lCPI3_2@PAGE
Lloh90:
	ldr	q20, [x8, lCPI3_2@PAGEOFF]
	movi.2d	v18, #0000000000000000
	movi.2d	v21, #0000000000000000
Lloh91:
	adrp	x8, lCPI3_3@PAGE
Lloh92:
	ldr	q24, [x8, lCPI3_3@PAGEOFF]
	movi.2d	v19, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	ldp	q14, q13, [sp, #144]            ; 32-byte Folded Reload
	ldr	q15, [sp, #128]                 ; 16-byte Reload
LBB3_101:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q28, [x6, #-16]
	tbl.16b	v29, { v27 }, v12
	tbl.16b	v30, { v27 }, v13
	tbl.16b	v31, { v27 }, v14
	tbl.16b	v27, { v27 }, v15
	tbl.16b	v8, { v28 }, v13
	tbl.16b	v9, { v28 }, v12
	tbl.16b	v10, { v28 }, v14
	tbl.16b	v28, { v28 }, v15
	shl.4s	v11, v7, #3
	ushl.4s	v27, v27, v11
	add.4s	v11, v11, v5
	ushl.4s	v28, v28, v11
	shl.4s	v11, v16, #3
	ushl.4s	v31, v31, v11
	add.4s	v11, v11, v5
	ushl.4s	v10, v10, v11
	shl.4s	v11, v20, #3
	ushl.4s	v29, v29, v11
	add.4s	v11, v11, v5
	ushl.4s	v9, v9, v11
	shl.4s	v11, v24, #3
	ushl.4s	v30, v30, v11
	add.4s	v11, v11, v5
	ushl.4s	v8, v8, v11
	orr.16b	v21, v29, v21
	orr.16b	v18, v30, v18
	orr.16b	v19, v31, v19
	orr.16b	v22, v27, v22
	orr.16b	v23, v8, v23
	orr.16b	v17, v9, v17
	orr.16b	v25, v10, v25
	orr.16b	v26, v28, v26
	add.4s	v24, v24, v6
	add.4s	v20, v20, v6
	add.4s	v16, v16, v6
	add	x6, x6, #32
	add.4s	v7, v7, v6
	subs	x10, x10, #32
	b.ne	LBB3_101
; %bb.102:                              ;   in Loop: Header=BB3_59 Depth=1
	orr.16b	v7, v17, v21
	orr.16b	v16, v26, v22
	orr.16b	v17, v23, v18
	orr.16b	v18, v25, v19
	orr.16b	v17, v17, v18
	orr.16b	v7, v7, v16
	orr.16b	v7, v17, v7
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x6, x8, #32
	orr	w8, w8, w6
	ldp	x10, x6, [sp, #24]              ; 16-byte Folded Reload
	cmp	x10, x6
	b.ne	LBB3_116
; %bb.103:                              ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	b	LBB3_57
LBB3_104:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x12, x22, #0x1c
	and	x24, x22, #0xffffffe0
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	ldr	x8, [sp, #64]                   ; 8-byte Reload
	add	x6, x8, x30
	and	x27, x22, #0xffffffe0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v19, #0000000000000000
	mov.16b	v22, v0
	movi.2d	v20, #0000000000000000
	mov.16b	v23, v4
	movi.2d	v21, #0000000000000000
	mov.16b	v25, v3
	movi.2d	v24, #0000000000000000
	mov.16b	v26, v2
	ldp	q14, q13, [sp, #144]            ; 32-byte Folded Reload
	ldr	q15, [sp, #128]                 ; 16-byte Reload
LBB3_105:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q28, [x6, #-16]
	tbl.16b	v29, { v27 }, v12
	tbl.16b	v30, { v27 }, v13
	tbl.16b	v31, { v27 }, v14
	tbl.16b	v27, { v27 }, v15
	tbl.16b	v8, { v28 }, v13
	tbl.16b	v9, { v28 }, v12
	tbl.16b	v10, { v28 }, v14
	tbl.16b	v28, { v28 }, v15
	shl.4s	v11, v26, #3
	ushl.4s	v27, v27, v11
	add.4s	v11, v11, v5
	ushl.4s	v28, v28, v11
	shl.4s	v11, v25, #3
	ushl.4s	v31, v31, v11
	add.4s	v11, v11, v5
	ushl.4s	v10, v10, v11
	shl.4s	v11, v23, #3
	ushl.4s	v29, v29, v11
	add.4s	v11, v11, v5
	ushl.4s	v9, v9, v11
	shl.4s	v11, v22, #3
	ushl.4s	v30, v30, v11
	add.4s	v11, v11, v5
	ushl.4s	v8, v8, v11
	orr.16b	v18, v29, v18
	orr.16b	v16, v30, v16
	orr.16b	v17, v31, v17
	orr.16b	v19, v27, v19
	orr.16b	v20, v8, v20
	orr.16b	v7, v9, v7
	orr.16b	v21, v10, v21
	orr.16b	v24, v28, v24
	add.4s	v22, v22, v6
	add.4s	v23, v23, v6
	add.4s	v25, v25, v6
	add	x6, x6, #32
	add.4s	v26, v26, v6
	subs	x27, x27, #32
	b.ne	LBB3_105
; %bb.106:                              ;   in Loop: Header=BB3_59 Depth=1
	orr.16b	v7, v7, v18
	orr.16b	v18, v24, v19
	orr.16b	v16, v20, v16
	orr.16b	v17, v21, v17
	orr.16b	v16, v16, v17
	orr.16b	v7, v7, v18
	orr.16b	v7, v16, v7
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x6, x8, #32
	orr	w27, w8, w6
	cmp	x22, x24
	b.ne	LBB3_122
; %bb.107:                              ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	b	LBB3_68
LBB3_108:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x10, x24, #0x1c
	str	x10, [sp, #32]                  ; 8-byte Spill
	and	x12, x24, #0xffffffe0
	ldr	x8, [sp, #56]                   ; 8-byte Reload
	add	x6, x8, x23
Lloh93:
	adrp	x8, lCPI3_0@PAGE
Lloh94:
	ldr	q7, [x8, lCPI3_0@PAGEOFF]
Lloh95:
	adrp	x8, lCPI3_1@PAGE
Lloh96:
	ldr	q16, [x8, lCPI3_1@PAGEOFF]
	movi.2d	v17, #0000000000000000
	mov	x10, x24
	and	x27, x24, #0xffffffe0
Lloh97:
	adrp	x8, lCPI3_2@PAGE
Lloh98:
	ldr	q20, [x8, lCPI3_2@PAGEOFF]
	movi.2d	v18, #0000000000000000
	movi.2d	v21, #0000000000000000
Lloh99:
	adrp	x8, lCPI3_3@PAGE
Lloh100:
	ldr	q24, [x8, lCPI3_3@PAGEOFF]
	movi.2d	v19, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	ldp	q14, q13, [sp, #144]            ; 32-byte Folded Reload
	ldr	q15, [sp, #128]                 ; 16-byte Reload
LBB3_109:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q28, [x6, #-16]
	tbl.16b	v29, { v27 }, v12
	tbl.16b	v30, { v27 }, v13
	tbl.16b	v31, { v27 }, v14
	tbl.16b	v27, { v27 }, v15
	tbl.16b	v8, { v28 }, v13
	tbl.16b	v9, { v28 }, v12
	tbl.16b	v10, { v28 }, v14
	tbl.16b	v28, { v28 }, v15
	shl.4s	v11, v7, #3
	ushl.4s	v27, v27, v11
	add.4s	v11, v11, v5
	ushl.4s	v28, v28, v11
	shl.4s	v11, v16, #3
	ushl.4s	v31, v31, v11
	add.4s	v11, v11, v5
	ushl.4s	v10, v10, v11
	shl.4s	v11, v20, #3
	ushl.4s	v29, v29, v11
	add.4s	v11, v11, v5
	ushl.4s	v9, v9, v11
	shl.4s	v11, v24, #3
	ushl.4s	v30, v30, v11
	add.4s	v11, v11, v5
	ushl.4s	v8, v8, v11
	orr.16b	v21, v29, v21
	orr.16b	v18, v30, v18
	orr.16b	v19, v31, v19
	orr.16b	v22, v27, v22
	orr.16b	v23, v8, v23
	orr.16b	v17, v9, v17
	orr.16b	v25, v10, v25
	orr.16b	v26, v28, v26
	add.4s	v24, v24, v6
	add.4s	v20, v20, v6
	add.4s	v16, v16, v6
	add	x6, x6, #32
	add.4s	v7, v7, v6
	subs	x27, x27, #32
	b.ne	LBB3_109
; %bb.110:                              ;   in Loop: Header=BB3_59 Depth=1
	orr.16b	v7, v17, v21
	orr.16b	v16, v26, v22
	orr.16b	v17, v23, v18
	orr.16b	v18, v25, v19
	orr.16b	v17, v17, v18
	orr.16b	v7, v7, v16
	orr.16b	v7, v17, v7
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x6, x8, #32
	orr	w27, w8, w6
	cmp	x10, x12
	b.ne	LBB3_128
; %bb.111:                              ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	b	LBB3_71
LBB3_112:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x8, x12, #0x1c
	and	x10, x12, #0xffffffe0
	stp	x8, x10, [sp, #24]              ; 16-byte Folded Spill
	ldr	x8, [sp, #48]                   ; 8-byte Reload
	add	x6, x8, x28
Lloh101:
	adrp	x8, lCPI3_0@PAGE
Lloh102:
	ldr	q7, [x8, lCPI3_0@PAGEOFF]
Lloh103:
	adrp	x8, lCPI3_1@PAGE
Lloh104:
	ldr	q16, [x8, lCPI3_1@PAGEOFF]
	movi.2d	v17, #0000000000000000
	mov	x10, x12
	and	x27, x12, #0xffffffe0
Lloh105:
	adrp	x8, lCPI3_2@PAGE
Lloh106:
	ldr	q20, [x8, lCPI3_2@PAGEOFF]
	movi.2d	v18, #0000000000000000
	movi.2d	v21, #0000000000000000
Lloh107:
	adrp	x8, lCPI3_3@PAGE
Lloh108:
	ldr	q24, [x8, lCPI3_3@PAGEOFF]
	movi.2d	v19, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	ldp	q14, q13, [sp, #144]            ; 32-byte Folded Reload
	ldr	q15, [sp, #128]                 ; 16-byte Reload
LBB3_113:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q28, [x6, #-16]
	tbl.16b	v29, { v27 }, v12
	tbl.16b	v30, { v27 }, v13
	tbl.16b	v31, { v27 }, v14
	tbl.16b	v27, { v27 }, v15
	tbl.16b	v8, { v28 }, v13
	tbl.16b	v9, { v28 }, v12
	tbl.16b	v10, { v28 }, v14
	tbl.16b	v28, { v28 }, v15
	shl.4s	v11, v7, #3
	ushl.4s	v27, v27, v11
	add.4s	v11, v11, v5
	ushl.4s	v28, v28, v11
	shl.4s	v11, v16, #3
	ushl.4s	v31, v31, v11
	add.4s	v11, v11, v5
	ushl.4s	v10, v10, v11
	shl.4s	v11, v20, #3
	ushl.4s	v29, v29, v11
	add.4s	v11, v11, v5
	ushl.4s	v9, v9, v11
	shl.4s	v11, v24, #3
	ushl.4s	v30, v30, v11
	add.4s	v11, v11, v5
	ushl.4s	v8, v8, v11
	orr.16b	v21, v29, v21
	orr.16b	v18, v30, v18
	orr.16b	v19, v31, v19
	orr.16b	v22, v27, v22
	orr.16b	v23, v8, v23
	orr.16b	v17, v9, v17
	orr.16b	v25, v10, v25
	orr.16b	v26, v28, v26
	add.4s	v24, v24, v6
	add.4s	v20, v20, v6
	add.4s	v16, v16, v6
	add	x6, x6, #32
	add.4s	v7, v7, v6
	subs	x27, x27, #32
	b.ne	LBB3_113
; %bb.114:                              ;   in Loop: Header=BB3_59 Depth=1
	orr.16b	v7, v17, v21
	orr.16b	v16, v26, v22
	orr.16b	v17, v23, v18
	orr.16b	v18, v25, v19
	orr.16b	v17, v17, v18
	orr.16b	v7, v7, v16
	orr.16b	v7, v17, v7
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x6, x8, #32
	orr	w27, w8, w6
	mov	x12, x10
	ldr	x10, [sp, #32]                  ; 8-byte Reload
	cmp	x12, x10
	b.ne	LBB3_134
; %bb.115:                              ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	b	LBB3_74
LBB3_116:                               ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	ldr	x12, [sp, #16]                  ; 8-byte Reload
	cbz	x12, LBB3_120
LBB3_117:                               ;   in Loop: Header=BB3_59 Depth=1
	ldp	x12, x9, [sp, #24]              ; 16-byte Folded Reload
	and	x12, x12, #0xfffffffffffffffc
	movi.2d	v7, #0000000000000000
	mov.s	v7[0], w8
	dup.4s	v16, w9
	orr.16b	v16, v16, v0
	str	x12, [sp, #32]                  ; 8-byte Spill
	sub	x8, x9, x12
	str	x8, [sp, #16]                   ; 8-byte Spill
	add	x8, x9, x25
	ldr	x12, [sp, #104]                 ; 8-byte Reload
	add	x8, x12, x8
	ldr	x12, [sp, #16]                  ; 8-byte Reload
LBB3_118:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s17, [x8], #4
	ushll.8h	v17, v17, #0
	ushll.4s	v17, v17, #0
	shl.4s	v18, v16, #3
	ushl.4s	v17, v17, v18
	orr.16b	v7, v17, v7
	add.4s	v16, v16, v1
	adds	x12, x12, #4
	b.ne	LBB3_118
; %bb.119:                              ;   in Loop: Header=BB3_59 Depth=1
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x9, d7
	lsr	x8, x9, #32
	orr	w8, w9, w8
	ldp	x12, x9, [sp, #24]              ; 16-byte Folded Reload
	cmp	x12, x9
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	b.eq	LBB3_57
LBB3_120:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Reload
	add	x25, x9, x25
	ldr	x12, [sp, #96]                  ; 8-byte Reload
	add	x12, x25, x12
	str	x12, [sp, #24]                  ; 8-byte Spill
	lsl	w12, w9, #3
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	str	w12, [sp, #32]                  ; 4-byte Spill
	ldr	x12, [sp, #104]                 ; 8-byte Reload
	add	x12, x12, x25
LBB3_121:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w25, [x12], #1
	str	x12, [sp, #16]                  ; 8-byte Spill
	ldr	w12, [sp, #32]                  ; 4-byte Reload
	lsl	w25, w25, w12
	orr	w8, w25, w8
	add	w12, w12, #8
	str	w12, [sp, #32]                  ; 4-byte Spill
	ldr	x12, [sp, #24]                  ; 8-byte Reload
	adds	x12, x12, #1
	str	x12, [sp, #24]                  ; 8-byte Spill
	ldr	x12, [sp, #16]                  ; 8-byte Reload
	b.lo	LBB3_121
	b	LBB3_57
LBB3_122:                               ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	cbz	x12, LBB3_126
LBB3_123:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x8, x22, #0xfffffffc
	movi.2d	v7, #0000000000000000
	mov.s	v7[0], w27
	dup.4s	v16, w24
	orr.16b	v16, v16, v0
	sub	x8, x24, x8
	add	x24, x24, x30
	ldr	x12, [sp, #120]                 ; 8-byte Reload
	add	x27, x12, x24
LBB3_124:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s17, [x27], #4
	ushll.8h	v17, v17, #0
	ushll.4s	v17, v17, #0
	shl.4s	v18, v16, #3
	ushl.4s	v17, v17, v18
	orr.16b	v7, v17, v7
	add.4s	v16, v16, v1
	adds	x8, x8, #4
	b.ne	LBB3_124
; %bb.125:                              ;   in Loop: Header=BB3_59 Depth=1
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x24, x8, #32
	orr	w27, w8, w24
	and	x24, x22, #0xfffffffc
	cmp	x22, x24
	b.eq	LBB3_68
LBB3_126:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x22, x24
	add	x24, x24, x30
	ldr	x8, [sp, #88]                   ; 8-byte Reload
	add	x8, x24, x8
	lsl	w22, w22, #3
	ldr	x12, [sp, #120]                 ; 8-byte Reload
	add	x24, x12, x24
LBB3_127:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w30, [x24], #1
	lsl	w30, w30, w22
	orr	w27, w30, w27
	add	w22, w22, #8
	adds	x8, x8, #1
	b.lo	LBB3_127
	b	LBB3_68
LBB3_128:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x24, x10
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Reload
	cbz	x8, LBB3_132
LBB3_129:                               ;   in Loop: Header=BB3_59 Depth=1
	and	x8, x24, #0xfffffffc
	movi.2d	v7, #0000000000000000
	mov.s	v7[0], w27
	dup.4s	v16, w12
	orr.16b	v16, v16, v0
	stp	x8, x24, [sp, #24]              ; 16-byte Folded Spill
	sub	x8, x12, x8
	add	x24, x12, x23
	ldr	x27, [sp, #216]                 ; 8-byte Reload
	add	x27, x27, x24
LBB3_130:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s17, [x27], #4
	ushll.8h	v17, v17, #0
	ushll.4s	v17, v17, #0
	shl.4s	v18, v16, #3
	ushl.4s	v17, v17, v18
	orr.16b	v7, v17, v7
	add.4s	v16, v16, v1
	adds	x8, x8, #4
	b.ne	LBB3_130
; %bb.131:                              ;   in Loop: Header=BB3_59 Depth=1
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x24, x8, #32
	orr	w27, w8, w24
	ldp	x12, x8, [sp, #24]              ; 16-byte Folded Reload
	cmp	x8, x12
	b.eq	LBB3_71
LBB3_132:                               ;   in Loop: Header=BB3_59 Depth=1
	mov	x24, x12
	add	x12, x12, x23
	str	x12, [sp, #32]                  ; 8-byte Spill
	ldr	x8, [sp, #80]                   ; 8-byte Reload
	add	x12, x12, x8
	lsl	w23, w24, #3
	ldr	x8, [sp, #216]                  ; 8-byte Reload
	ldr	x24, [sp, #32]                  ; 8-byte Reload
	add	x24, x8, x24
LBB3_133:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [x24], #1
	lsl	w8, w8, w23
	orr	w27, w8, w27
	add	w23, w23, #8
	adds	x12, x12, #1
	b.lo	LBB3_133
	b	LBB3_71
LBB3_134:                               ;   in Loop: Header=BB3_59 Depth=1
	ldp	x10, x6, [sp, #176]             ; 16-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Reload
	cbz	x8, LBB3_138
LBB3_135:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Reload
	stp	x8, x12, [sp, #16]              ; 16-byte Folded Spill
	and	x8, x12, #0xfffffffc
	movi.2d	v7, #0000000000000000
	mov.s	v7[0], w27
	ldr	x12, [sp, #16]                  ; 8-byte Reload
	dup.4s	v16, w12
	orr.16b	v16, v16, v0
	str	x8, [sp, #32]                   ; 8-byte Spill
	sub	x8, x12, x8
	add	x27, x12, x28
	ldr	x12, [sp, #112]                 ; 8-byte Reload
	add	x27, x12, x27
LBB3_136:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s17, [x27], #4
	ushll.8h	v17, v17, #0
	ushll.4s	v17, v17, #0
	shl.4s	v18, v16, #3
	ushl.4s	v17, v17, v18
	orr.16b	v7, v17, v7
	add.4s	v16, v16, v1
	adds	x8, x8, #4
	b.ne	LBB3_136
; %bb.137:                              ;   in Loop: Header=BB3_59 Depth=1
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x8, d7
	lsr	x27, x8, #32
	orr	w27, w8, w27
	ldp	x8, x12, [sp, #24]              ; 16-byte Folded Reload
	cmp	x8, x12
	b.eq	LBB3_74
LBB3_138:                               ;   in Loop: Header=BB3_59 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Reload
	add	x28, x8, x28
	ldr	x12, [sp, #72]                  ; 8-byte Reload
	add	x12, x28, x12
	stp	x28, x12, [sp, #16]             ; 16-byte Folded Spill
	lsl	w28, w8, #3
	ldr	x12, [sp, #112]                 ; 8-byte Reload
	ldr	x8, [sp, #16]                   ; 8-byte Reload
	add	x8, x12, x8
	ldr	x12, [sp, #24]                  ; 8-byte Reload
LBB3_139:                               ;   Parent Loop BB3_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w28, [sp, #24]                  ; 4-byte Spill
	str	x8, [sp, #32]                   ; 8-byte Spill
	mov	x28, x8
	ldrb	w8, [x28], #1
	str	x28, [sp, #32]                  ; 8-byte Spill
	ldr	w28, [sp, #24]                  ; 4-byte Reload
	lsl	w8, w8, w28
	orr	w27, w8, w27
	ldr	x8, [sp, #32]                   ; 8-byte Reload
	add	w28, w28, #8
	adds	x12, x12, #1
	b.lo	LBB3_139
	b	LBB3_74
LBB3_140:
	mov	x19, #0                         ; =0x0
	stp	x5, x3, [sp, #320]
	stp	x7, x4, [sp, #304]
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	ldr	x8, [sp, #256]                  ; 8-byte Reload
	stp	x9, x8, [sp, #400]
	stp	x30, x1, [sp, #416]
	str	w16, [sp, #432]
	ldp	x11, x8, [sp, #216]             ; 16-byte Folded Reload
	stp	x11, x10, [sp, #440]
	stp	x23, x2, [sp, #456]
	str	w0, [sp, #472]
	ldr	x9, [sp, #200]                  ; 8-byte Reload
	stp	x9, x8, [sp, #480]
	stp	x28, x15, [sp, #496]
	str	w17, [sp, #512]
	ldr	x8, [sp, #192]                  ; 8-byte Reload
	str	x8, [sp, #520]
	ldr	x8, [sp, #240]                  ; 8-byte Reload
	str	x8, [sp, #528]
	str	x25, [sp, #536]
	str	x13, [sp, #544]
	str	w14, [sp, #552]
	add	x20, sp, #336
	add	x21, sp, #304
	mov	w22, #40                        ; =0x28
	add	x23, sp, #400
Lloh109:
	adrp	x8, lCPI3_3@PAGE
Lloh110:
	ldr	q0, [x8, lCPI3_3@PAGEOFF]
	str	q0, [sp, #272]                  ; 16-byte Spill
Lloh111:
	adrp	x8, lCPI3_0@PAGE
Lloh112:
	ldr	q0, [x8, lCPI3_0@PAGEOFF]
	str	q0, [sp, #256]                  ; 16-byte Spill
Lloh113:
	adrp	x8, lCPI3_1@PAGE
Lloh114:
	ldr	q0, [x8, lCPI3_1@PAGEOFF]
	str	q0, [sp, #240]                  ; 16-byte Spill
	add	x24, sp, #560
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #560
Lloh115:
	adrp	x8, lCPI3_2@PAGE
Lloh116:
	ldr	q0, [x8, lCPI3_2@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Spill
	str	q12, [sp, #288]                 ; 16-byte Spill
	b	LBB3_144
LBB3_141:                               ;   in Loop: Header=BB3_144 Depth=1
	ldr	x13, [x10, #24]
LBB3_142:                               ;   in Loop: Header=BB3_144 Depth=1
	and	x11, x13, #0xfff
	ldrh	w11, [x25, x11, lsl #1]
	ldr	x8, [x8]
	strb	w11, [x8, x9]
	lsr	x8, x11, #8
	ldr	x9, [x10, #24]
	lsr	x9, x9, x8
	str	x9, [x10, #24]
	ldr	w9, [x10, #32]
	sub	w8, w9, w8
	str	w8, [x10, #32]
LBB3_143:                               ;   in Loop: Header=BB3_144 Depth=1
	madd	x0, x19, x22, x23
	bl	__ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
	add	x19, x19, #1
	cmp	x19, #4
	ldr	q12, [sp, #288]                 ; 16-byte Reload
	b.eq	LBB3_189
LBB3_144:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_150 Depth 2
                                        ;       Child Loop BB3_159 Depth 3
                                        ;       Child Loop BB3_163 Depth 3
                                        ;       Child Loop BB3_166 Depth 3
                                        ;     Child Loop BB3_179 Depth 2
                                        ;     Child Loop BB3_183 Depth 2
                                        ;     Child Loop BB3_186 Depth 2
	add	x8, x20, x19, lsl #4
	ldr	x10, [x8, #8]
	ldr	x9, [x21, x19, lsl #3]
	sub	x11, x10, x9
	cmp	x11, #2
	b.hs	LBB3_146
; %bb.145:                              ;   in Loop: Header=BB3_144 Depth=1
	str	x9, [x21, x19, lsl #3]
	cmp	x9, x10
	b.hs	LBB3_143
	b	LBB3_168
LBB3_146:                               ;   in Loop: Header=BB3_144 Depth=1
	madd	x11, x19, x22, x23
	ldr	x12, [x8]
	ldr	w13, [x11, #32]
	ldr	x14, [x11, #24]
	b	LBB3_150
LBB3_147:                               ;   in Loop: Header=BB3_150 Depth=2
	ldr	x17, [x11]
	ldr	w4, [x17, x16]
LBB3_148:                               ;   in Loop: Header=BB3_150 Depth=2
	mov	w16, w4
	lsl	x16, x16, x13
	orr	x14, x16, x14
	str	x15, [x11, #16]
	orr	w13, w13, #0x20
LBB3_149:                               ;   in Loop: Header=BB3_150 Depth=2
	and	x15, x14, #0xfff
	ldr	w15, [x24, x15, lsl #2]
	lsr	x16, x15, #16
	ubfx	x17, x15, #16, #8
	lsr	x14, x14, x16
	sub	w13, w13, w17
	strh	w15, [x12, x9]
	add	x9, x9, x15, lsr #24
	sub	x15, x10, x9
	cmp	x15, #1
	b.ls	LBB3_167
LBB3_150:                               ;   Parent Loop BB3_144 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_159 Depth 3
                                        ;       Child Loop BB3_163 Depth 3
                                        ;       Child Loop BB3_166 Depth 3
	cmp	w13, #11
	b.hi	LBB3_149
; %bb.151:                              ;   in Loop: Header=BB3_150 Depth=2
	ldp	x17, x16, [x11, #8]
	add	x15, x16, #4
	cmp	x15, x17
	b.ls	LBB3_147
; %bb.152:                              ;   in Loop: Header=BB3_150 Depth=2
	subs	x1, x17, x16
	b.ls	LBB3_155
; %bb.153:                              ;   in Loop: Header=BB3_150 Depth=2
	ldr	x0, [x11]
	cmp	x1, #4
	b.hs	LBB3_156
; %bb.154:                              ;   in Loop: Header=BB3_150 Depth=2
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB3_165
LBB3_155:                               ;   in Loop: Header=BB3_150 Depth=2
	mov	w4, #0                          ; =0x0
	b	LBB3_148
LBB3_156:                               ;   in Loop: Header=BB3_150 Depth=2
	cmp	x1, #32
	b.hs	LBB3_158
; %bb.157:                              ;   in Loop: Header=BB3_150 Depth=2
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB3_162
LBB3_158:                               ;   in Loop: Header=BB3_150 Depth=2
	and	x3, x1, #0x1c
	and	x2, x1, #0xffffffffffffffe0
	add	x4, x0, x16
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	add	x4, x4, #16
	and	x5, x1, #0xffffffffffffffe0
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldp	q19, q7, [sp, #256]             ; 32-byte Folded Reload
	movi.2d	v6, #0000000000000000
	ldp	q17, q18, [sp, #224]            ; 32-byte Folded Reload
	movi.2d	v16, #0000000000000000
	ldp	q30, q29, [sp, #144]            ; 32-byte Folded Reload
	ldr	q31, [sp, #128]                 ; 16-byte Reload
	movi.4s	v8, #128
	movi.4s	v9, #32
LBB3_159:                               ;   Parent Loop BB3_144 Depth=1
                                        ;     Parent Loop BB3_150 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q20, q21, [x4, #-16]
	tbl.16b	v22, { v20 }, v12
	tbl.16b	v23, { v20 }, v29
	tbl.16b	v24, { v20 }, v30
	tbl.16b	v20, { v20 }, v31
	tbl.16b	v25, { v21 }, v29
	tbl.16b	v26, { v21 }, v12
	tbl.16b	v27, { v21 }, v30
	tbl.16b	v21, { v21 }, v31
	shl.4s	v28, v19, #3
	ushl.4s	v20, v20, v28
	add.4s	v28, v28, v8
	ushl.4s	v21, v21, v28
	shl.4s	v28, v18, #3
	ushl.4s	v24, v24, v28
	add.4s	v28, v28, v8
	ushl.4s	v27, v27, v28
	shl.4s	v28, v17, #3
	ushl.4s	v22, v22, v28
	add.4s	v28, v28, v8
	ushl.4s	v26, v26, v28
	shl.4s	v28, v7, #3
	ushl.4s	v23, v23, v28
	add.4s	v28, v28, v8
	ushl.4s	v25, v25, v28
	orr.16b	v3, v22, v3
	orr.16b	v1, v23, v1
	orr.16b	v2, v24, v2
	orr.16b	v4, v20, v4
	orr.16b	v5, v25, v5
	orr.16b	v0, v26, v0
	orr.16b	v6, v27, v6
	orr.16b	v16, v21, v16
	add.4s	v7, v7, v9
	add.4s	v17, v17, v9
	add.4s	v18, v18, v9
	add	x4, x4, #32
	add.4s	v19, v19, v9
	subs	x5, x5, #32
	b.ne	LBB3_159
; %bb.160:                              ;   in Loop: Header=BB3_150 Depth=2
	orr.16b	v0, v0, v3
	orr.16b	v3, v16, v4
	orr.16b	v1, v5, v1
	orr.16b	v2, v6, v2
	orr.16b	v1, v1, v2
	orr.16b	v0, v0, v3
	orr.16b	v0, v1, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x4, d0
	lsr	x5, x4, #32
	orr	w4, w4, w5
	cmp	x1, x2
	b.eq	LBB3_148
; %bb.161:                              ;   in Loop: Header=BB3_150 Depth=2
	cbz	x3, LBB3_165
LBB3_162:                               ;   in Loop: Header=BB3_150 Depth=2
	mov	x5, x2
	and	x2, x1, #0xfffffffffffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w4
	dup.4s	v1, w5
	ldr	q2, [sp, #272]                  ; 16-byte Reload
	orr.16b	v1, v1, v2
	sub	x3, x5, x2
	add	x4, x5, x16
	add	x4, x0, x4
	movi.4s	v4, #4
LBB3_163:                               ;   Parent Loop BB3_144 Depth=1
                                        ;     Parent Loop BB3_150 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	s2, [x4], #4
	ushll.8h	v2, v2, #0
	ushll.4s	v2, v2, #0
	shl.4s	v3, v1, #3
	ushl.4s	v2, v2, v3
	orr.16b	v0, v2, v0
	add.4s	v1, v1, v4
	adds	x3, x3, #4
	b.ne	LBB3_163
; %bb.164:                              ;   in Loop: Header=BB3_150 Depth=2
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x3, d0
	lsr	x4, x3, #32
	orr	w4, w3, w4
	cmp	x1, x2
	b.eq	LBB3_148
LBB3_165:                               ;   in Loop: Header=BB3_150 Depth=2
	add	x1, x2, x16
	sub	x16, x1, x17
	lsl	w17, w2, #3
	add	x0, x0, x1
LBB3_166:                               ;   Parent Loop BB3_144 Depth=1
                                        ;     Parent Loop BB3_150 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w1, [x0], #1
	lsl	w1, w1, w17
	orr	w4, w1, w4
	add	w17, w17, #8
	adds	x16, x16, #1
	b.lo	LBB3_166
	b	LBB3_148
LBB3_167:                               ;   in Loop: Header=BB3_144 Depth=1
	str	w13, [x11, #32]
	str	x14, [x11, #24]
	str	x9, [x21, x19, lsl #3]
	cmp	x9, x10
	b.hs	LBB3_143
LBB3_168:                               ;   in Loop: Header=BB3_144 Depth=1
	madd	x10, x19, x22, x23
	ldr	w11, [x10, #32]
	cmp	w11, #12
	b.hs	LBB3_141
; %bb.169:                              ;   in Loop: Header=BB3_144 Depth=1
	ldp	x14, x13, [x10, #8]
	add	x12, x13, #4
	cmp	x12, x14
	movi.4s	v4, #4
	b.hi	LBB3_172
; %bb.170:                              ;   in Loop: Header=BB3_144 Depth=1
	ldr	x14, [x10]
	ldr	w1, [x14, x13]
LBB3_171:                               ;   in Loop: Header=BB3_144 Depth=1
	mov	w13, w1
	lsl	x13, x13, x11
	ldr	x14, [x10, #24]
	orr	x13, x13, x14
	stp	x12, x13, [x10, #16]
	orr	w11, w11, #0x20
	str	w11, [x10, #32]
	b	LBB3_142
LBB3_172:                               ;   in Loop: Header=BB3_144 Depth=1
	subs	x16, x14, x13
	b.ls	LBB3_175
; %bb.173:                              ;   in Loop: Header=BB3_144 Depth=1
	ldr	x15, [x10]
	cmp	x16, #4
	b.hs	LBB3_176
; %bb.174:                              ;   in Loop: Header=BB3_144 Depth=1
	mov	x17, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB3_185
LBB3_175:                               ;   in Loop: Header=BB3_144 Depth=1
	mov	w1, #0                          ; =0x0
	b	LBB3_171
LBB3_176:                               ;   in Loop: Header=BB3_144 Depth=1
	cmp	x16, #32
	b.hs	LBB3_178
; %bb.177:                              ;   in Loop: Header=BB3_144 Depth=1
	mov	x17, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB3_182
LBB3_178:                               ;   in Loop: Header=BB3_144 Depth=1
	and	x0, x16, #0x1c
	and	x17, x16, #0xffffffffffffffe0
	add	x1, x15, x13
	add	x1, x1, #16
Lloh117:
	adrp	x2, lCPI3_0@PAGE
Lloh118:
	ldr	q0, [x2, lCPI3_0@PAGEOFF]
Lloh119:
	adrp	x2, lCPI3_1@PAGE
Lloh120:
	ldr	q1, [x2, lCPI3_1@PAGEOFF]
Lloh121:
	adrp	x2, lCPI3_2@PAGE
Lloh122:
	ldr	q2, [x2, lCPI3_2@PAGEOFF]
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
Lloh123:
	adrp	x2, lCPI3_3@PAGE
Lloh124:
	ldr	q6, [x2, lCPI3_3@PAGEOFF]
	and	x2, x16, #0xffffffffffffffe0
	movi.2d	v7, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	ldr	q29, [sp, #288]                 ; 16-byte Reload
	ldp	q31, q30, [sp, #144]            ; 32-byte Folded Reload
	ldr	q8, [sp, #128]                  ; 16-byte Reload
	movi.4s	v9, #128
	movi.4s	v10, #32
LBB3_179:                               ;   Parent Loop BB3_144 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q20, q21, [x1, #-16]
	tbl.16b	v22, { v20 }, v29
	tbl.16b	v23, { v20 }, v30
	tbl.16b	v24, { v20 }, v31
	tbl.16b	v20, { v20 }, v8
	tbl.16b	v25, { v21 }, v30
	tbl.16b	v26, { v21 }, v29
	tbl.16b	v27, { v21 }, v31
	tbl.16b	v21, { v21 }, v8
	shl.4s	v28, v0, #3
	ushl.4s	v20, v20, v28
	add.4s	v28, v28, v9
	ushl.4s	v21, v21, v28
	shl.4s	v28, v1, #3
	ushl.4s	v24, v24, v28
	add.4s	v28, v28, v9
	ushl.4s	v27, v27, v28
	shl.4s	v28, v2, #3
	ushl.4s	v22, v22, v28
	add.4s	v28, v28, v9
	ushl.4s	v26, v26, v28
	shl.4s	v28, v6, #3
	ushl.4s	v23, v23, v28
	add.4s	v28, v28, v9
	ushl.4s	v25, v25, v28
	orr.16b	v7, v22, v7
	orr.16b	v4, v23, v4
	orr.16b	v5, v24, v5
	orr.16b	v16, v20, v16
	orr.16b	v17, v25, v17
	orr.16b	v3, v26, v3
	orr.16b	v18, v27, v18
	orr.16b	v19, v21, v19
	add.4s	v6, v6, v10
	add.4s	v2, v2, v10
	add.4s	v1, v1, v10
	add	x1, x1, #32
	add.4s	v0, v0, v10
	subs	x2, x2, #32
	b.ne	LBB3_179
; %bb.180:                              ;   in Loop: Header=BB3_144 Depth=1
	orr.16b	v0, v3, v7
	orr.16b	v1, v19, v16
	orr.16b	v2, v17, v4
	orr.16b	v3, v18, v5
	orr.16b	v2, v2, v3
	orr.16b	v0, v0, v1
	orr.16b	v0, v2, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x1, d0
	lsr	x2, x1, #32
	orr	w1, w1, w2
	cmp	x16, x17
	b.eq	LBB3_171
; %bb.181:                              ;   in Loop: Header=BB3_144 Depth=1
	movi.4s	v4, #4
	cbz	x0, LBB3_185
LBB3_182:                               ;   in Loop: Header=BB3_144 Depth=1
	mov	x2, x17
	and	x17, x16, #0xfffffffffffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	dup.4s	v1, w2
	ldr	q2, [sp, #272]                  ; 16-byte Reload
	orr.16b	v1, v1, v2
	sub	x0, x2, x17
	add	x1, x2, x13
	add	x1, x15, x1
LBB3_183:                               ;   Parent Loop BB3_144 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s2, [x1], #4
	ushll.8h	v2, v2, #0
	ushll.4s	v2, v2, #0
	shl.4s	v3, v1, #3
	ushl.4s	v2, v2, v3
	orr.16b	v0, v2, v0
	add.4s	v1, v1, v4
	adds	x0, x0, #4
	b.ne	LBB3_183
; %bb.184:                              ;   in Loop: Header=BB3_144 Depth=1
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x0, d0
	lsr	x1, x0, #32
	orr	w1, w0, w1
	cmp	x16, x17
	b.eq	LBB3_171
LBB3_185:                               ;   in Loop: Header=BB3_144 Depth=1
	add	x16, x17, x13
	sub	x13, x16, x14
	lsl	w14, w17, #3
	add	x15, x15, x16
LBB3_186:                               ;   Parent Loop BB3_144 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w16, [x15], #1
	lsl	w16, w16, w14
	orr	w1, w16, w1
	add	w14, w14, #8
	adds	x13, x13, #1
	b.lo	LBB3_186
	b	LBB3_171
LBB3_187:
	mov	w8, #0                          ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
LBB3_188:
	str	x11, [sp, #584]
	str	x12, [sp, #576]
	str	w8, [sp, #592]
	add	x0, sp, #560
	bl	__ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
LBB3_189:
	ldur	x8, [x29, #-160]
Lloh125:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh126:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh127:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB3_192
; %bb.190:
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1344
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB3_191:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp36:                                 ; EH_LABEL
Lloh128:
	adrp	x1, l_.str.1@PAGE
Lloh129:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ; EH_LABEL
	b	LBB3_198
LBB3_192:
	bl	___stack_chk_fail
LBB3_193:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp51:                                 ; EH_LABEL
Lloh130:
	adrp	x1, l_.str.4@PAGE
Lloh131:
	add	x1, x1, l_.str.4@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ; EH_LABEL
	b	LBB3_198
LBB3_194:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp39:                                 ; EH_LABEL
Lloh132:
	adrp	x1, l_.str.6@PAGE
Lloh133:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ; EH_LABEL
	b	LBB3_198
LBB3_195:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp48:                                 ; EH_LABEL
Lloh134:
	adrp	x1, l_.str.2@PAGE
Lloh135:
	add	x1, x1, l_.str.2@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ; EH_LABEL
	b	LBB3_198
LBB3_196:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp45:                                 ; EH_LABEL
Lloh136:
	adrp	x1, l_.str.3@PAGE
Lloh137:
	add	x1, x1, l_.str.3@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ; EH_LABEL
	b	LBB3_198
LBB3_197:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp42:                                 ; EH_LABEL
Lloh138:
	adrp	x1, l_.str.5@PAGE
Lloh139:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ; EH_LABEL
LBB3_198:
Lloh140:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh141:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh142:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh143:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB3_199:
Ltmp44:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_200:
Ltmp47:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_201:
Ltmp50:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_202:
Ltmp41:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_203:
Ltmp53:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_204:
Ltmp38:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh44, Lloh45, Lloh46
	.loh AdrpLdrGotLdr	Lloh47, Lloh48, Lloh49
	.loh AdrpLdrGotLdr	Lloh50, Lloh51, Lloh52
	.loh AdrpLdr	Lloh67, Lloh68
	.loh AdrpAdrp	Lloh65, Lloh67
	.loh AdrpLdr	Lloh65, Lloh66
	.loh AdrpAdrp	Lloh63, Lloh65
	.loh AdrpLdr	Lloh63, Lloh64
	.loh AdrpLdr	Lloh61, Lloh62
	.loh AdrpAdrp	Lloh59, Lloh61
	.loh AdrpLdr	Lloh59, Lloh60
	.loh AdrpAdrp	Lloh57, Lloh59
	.loh AdrpLdr	Lloh57, Lloh58
	.loh AdrpAdrp	Lloh55, Lloh57
	.loh AdrpLdr	Lloh55, Lloh56
	.loh AdrpAdrp	Lloh53, Lloh55
	.loh AdrpLdr	Lloh53, Lloh54
	.loh AdrpLdr	Lloh83, Lloh84
	.loh AdrpAdrp	Lloh81, Lloh83
	.loh AdrpLdr	Lloh81, Lloh82
	.loh AdrpAdrp	Lloh79, Lloh81
	.loh AdrpLdr	Lloh79, Lloh80
	.loh AdrpAdrp	Lloh77, Lloh79
	.loh AdrpLdr	Lloh77, Lloh78
	.loh AdrpLdr	Lloh75, Lloh76
	.loh AdrpLdr	Lloh73, Lloh74
	.loh AdrpAdrp	Lloh71, Lloh73
	.loh AdrpLdr	Lloh71, Lloh72
	.loh AdrpAdrp	Lloh69, Lloh71
	.loh AdrpLdr	Lloh69, Lloh70
	.loh AdrpLdr	Lloh91, Lloh92
	.loh AdrpAdrp	Lloh89, Lloh91
	.loh AdrpLdr	Lloh89, Lloh90
	.loh AdrpAdrp	Lloh87, Lloh89
	.loh AdrpLdr	Lloh87, Lloh88
	.loh AdrpAdrp	Lloh85, Lloh87
	.loh AdrpLdr	Lloh85, Lloh86
	.loh AdrpLdr	Lloh99, Lloh100
	.loh AdrpAdrp	Lloh97, Lloh99
	.loh AdrpLdr	Lloh97, Lloh98
	.loh AdrpAdrp	Lloh95, Lloh97
	.loh AdrpLdr	Lloh95, Lloh96
	.loh AdrpAdrp	Lloh93, Lloh95
	.loh AdrpLdr	Lloh93, Lloh94
	.loh AdrpLdr	Lloh107, Lloh108
	.loh AdrpAdrp	Lloh105, Lloh107
	.loh AdrpLdr	Lloh105, Lloh106
	.loh AdrpAdrp	Lloh103, Lloh105
	.loh AdrpLdr	Lloh103, Lloh104
	.loh AdrpAdrp	Lloh101, Lloh103
	.loh AdrpLdr	Lloh101, Lloh102
	.loh AdrpLdr	Lloh115, Lloh116
	.loh AdrpAdrp	Lloh113, Lloh115
	.loh AdrpLdr	Lloh113, Lloh114
	.loh AdrpAdrp	Lloh111, Lloh113
	.loh AdrpLdr	Lloh111, Lloh112
	.loh AdrpAdrp	Lloh109, Lloh111
	.loh AdrpLdr	Lloh109, Lloh110
	.loh AdrpLdr	Lloh123, Lloh124
	.loh AdrpAdrp	Lloh121, Lloh123
	.loh AdrpLdr	Lloh121, Lloh122
	.loh AdrpAdrp	Lloh119, Lloh121
	.loh AdrpLdr	Lloh119, Lloh120
	.loh AdrpAdrp	Lloh117, Lloh119
	.loh AdrpLdr	Lloh117, Lloh118
	.loh AdrpLdrGotLdr	Lloh125, Lloh126, Lloh127
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpLdrGot	Lloh142, Lloh143
	.loh AdrpLdrGot	Lloh140, Lloh141
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception3:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3      ; >> Call Site 1 <<
	.uleb128 Ltmp36-Lfunc_begin3            ;   Call between Lfunc_begin3 and Ltmp36
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin3            ; >> Call Site 2 <<
	.uleb128 Ltmp37-Ltmp36                  ;   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin3            ;     jumps to Ltmp38
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin3            ; >> Call Site 3 <<
	.uleb128 Ltmp51-Ltmp37                  ;   Call between Ltmp37 and Ltmp51
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin3            ; >> Call Site 4 <<
	.uleb128 Ltmp52-Ltmp51                  ;   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin3            ;     jumps to Ltmp53
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin3            ; >> Call Site 5 <<
	.uleb128 Ltmp39-Ltmp52                  ;   Call between Ltmp52 and Ltmp39
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin3            ; >> Call Site 6 <<
	.uleb128 Ltmp40-Ltmp39                  ;   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin3            ;     jumps to Ltmp41
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin3            ; >> Call Site 7 <<
	.uleb128 Ltmp48-Ltmp40                  ;   Call between Ltmp40 and Ltmp48
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin3            ; >> Call Site 8 <<
	.uleb128 Ltmp49-Ltmp48                  ;   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin3            ;     jumps to Ltmp50
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin3            ; >> Call Site 9 <<
	.uleb128 Ltmp45-Ltmp49                  ;   Call between Ltmp49 and Ltmp45
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin3            ; >> Call Site 10 <<
	.uleb128 Ltmp46-Ltmp45                  ;   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin3            ;     jumps to Ltmp47
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin3            ; >> Call Site 11 <<
	.uleb128 Ltmp42-Ltmp46                  ;   Call between Ltmp46 and Ltmp42
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin3            ; >> Call Site 12 <<
	.uleb128 Ltmp43-Ltmp42                  ;   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin3            ;     jumps to Ltmp44
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin3            ; >> Call Site 13 <<
	.uleb128 Lfunc_end3-Ltmp43              ;   Call between Ltmp43 and Lfunc_end3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end3:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
__ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE: ; @_ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception4
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	mov	x25, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	w26, #256                       ; =0x100
	b	LBB4_2
LBB4_1:                                 ;   in Loop: Header=BB4_2 Depth=1
	strb	w9, [x20, x25]
	add	x25, x25, #1
	mov	x24, x10
	mov	x22, x9
	cmp	x25, #256
	b.hs	LBB4_12
LBB4_2:                                 ; =>This Inner Loop Header: Depth=1
	lsr	x9, x24, #1
	cmp	x9, x21
	b.hs	LBB4_16
; %bb.3:                                ;   in Loop: Header=BB4_2 Depth=1
	ubfiz	w8, w24, #2, #1
	ldrb	w9, [x19, x9]
	lsr	w9, w9, w8
	and	w9, w9, #0xf
	add	x10, x24, #1
	cmp	w9, #12
	b.ls	LBB4_1
; %bb.4:                                ;   in Loop: Header=BB4_2 Depth=1
	cmp	w9, #13
	b.eq	LBB4_17
; %bb.5:                                ;   in Loop: Header=BB4_2 Depth=1
	lsr	x11, x10, #1
	cmp	x11, x21
	b.hs	LBB4_19
; %bb.6:                                ;   in Loop: Header=BB4_2 Depth=1
	ubfiz	x10, x10, #2, #1
	ldrb	w11, [x19, x11]
	lsr	x10, x11, x10
	and	x10, x10, #0xf
	add	x11, x24, #2
	cmp	w9, #15
	b.ne	LBB4_9
; %bb.7:                                ;   in Loop: Header=BB4_2 Depth=1
	lsr	x9, x11, #1
	cmp	x9, x21
	b.hs	LBB4_20
; %bb.8:                                ;   in Loop: Header=BB4_2 Depth=1
	ldrb	w9, [x19, x9]
	lsr	w8, w9, w8
	add	x24, x24, #3
	orr	w8, w10, w8, lsl #4
	and	x8, x8, #0xff
	add	x23, x8, #19
	b	LBB4_10
LBB4_9:                                 ;   in Loop: Header=BB4_2 Depth=1
	add	x23, x10, #3
	mov	x24, x11
LBB4_10:                                ;   in Loop: Header=BB4_2 Depth=1
	sub	x8, x26, x25
	cmp	x23, x8
	b.hi	LBB4_18
; %bb.11:                               ;   in Loop: Header=BB4_2 Depth=1
	add	x0, x20, x25
	mov	x1, x22
	mov	x2, x23
	bl	_memset
	add	x25, x23, x25
	cmp	x25, #256
	b.lo	LBB4_2
LBB4_12:
	cmp	x24, #257
	b.hs	LBB4_22
; %bb.13:
	tbz	w24, #0, LBB4_15
; %bb.14:
	lsr	x8, x24, #1
	ldrb	w8, [x19, x8]
	cmp	w8, #16
	b.hs	LBB4_23
LBB4_15:
	add	x8, x24, #1
	lsr	x0, x8, #1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB4_16:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp54:                                 ; EH_LABEL
Lloh144:
	adrp	x1, l_.str.26@PAGE
Lloh145:
	add	x1, x1, l_.str.26@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ; EH_LABEL
	b	LBB4_21
LBB4_17:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp66:                                 ; EH_LABEL
Lloh146:
	adrp	x1, l_.str.22@PAGE
Lloh147:
	add	x1, x1, l_.str.22@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ; EH_LABEL
	b	LBB4_21
LBB4_18:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp63:                                 ; EH_LABEL
Lloh148:
	adrp	x1, l_.str.23@PAGE
Lloh149:
	add	x1, x1, l_.str.23@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ; EH_LABEL
	b	LBB4_21
LBB4_19:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp57:                                 ; EH_LABEL
Lloh150:
	adrp	x1, l_.str.26@PAGE
Lloh151:
	add	x1, x1, l_.str.26@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ; EH_LABEL
	b	LBB4_21
LBB4_20:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp60:                                 ; EH_LABEL
Lloh152:
	adrp	x1, l_.str.26@PAGE
Lloh153:
	add	x1, x1, l_.str.26@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ; EH_LABEL
LBB4_21:
Lloh154:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh155:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh156:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh157:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB4_22:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp69:                                 ; EH_LABEL
Lloh158:
	adrp	x1, l_.str.24@PAGE
Lloh159:
	add	x1, x1, l_.str.24@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp70:                                 ; EH_LABEL
	b	LBB4_21
LBB4_23:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp72:                                 ; EH_LABEL
Lloh160:
	adrp	x1, l_.str.25@PAGE
Lloh161:
	add	x1, x1, l_.str.25@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp73:                                 ; EH_LABEL
	b	LBB4_21
LBB4_24:
Ltmp74:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_25:
Ltmp71:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_26:
Ltmp62:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_27:
Ltmp59:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_28:
Ltmp65:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_29:
Ltmp68:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_30:
Ltmp56:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpLdrGot	Lloh156, Lloh157
	.loh AdrpLdrGot	Lloh154, Lloh155
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh160, Lloh161
Lfunc_end4:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table4:
Lexception4:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end4-Lcst_begin4
Lcst_begin4:
	.uleb128 Lfunc_begin4-Lfunc_begin4      ; >> Call Site 1 <<
	.uleb128 Ltmp54-Lfunc_begin4            ;   Call between Lfunc_begin4 and Ltmp54
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin4            ; >> Call Site 2 <<
	.uleb128 Ltmp55-Ltmp54                  ;   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin4            ;     jumps to Ltmp56
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin4            ; >> Call Site 3 <<
	.uleb128 Ltmp66-Ltmp55                  ;   Call between Ltmp55 and Ltmp66
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin4            ; >> Call Site 4 <<
	.uleb128 Ltmp67-Ltmp66                  ;   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin4            ;     jumps to Ltmp68
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin4            ; >> Call Site 5 <<
	.uleb128 Ltmp63-Ltmp67                  ;   Call between Ltmp67 and Ltmp63
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin4            ; >> Call Site 6 <<
	.uleb128 Ltmp64-Ltmp63                  ;   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin4            ;     jumps to Ltmp65
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin4            ; >> Call Site 7 <<
	.uleb128 Ltmp57-Ltmp64                  ;   Call between Ltmp64 and Ltmp57
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin4            ; >> Call Site 8 <<
	.uleb128 Ltmp58-Ltmp57                  ;   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin4            ;     jumps to Ltmp59
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin4            ; >> Call Site 9 <<
	.uleb128 Ltmp60-Ltmp58                  ;   Call between Ltmp58 and Ltmp60
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin4            ; >> Call Site 10 <<
	.uleb128 Ltmp61-Ltmp60                  ;   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin4            ;     jumps to Ltmp62
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin4            ; >> Call Site 11 <<
	.uleb128 Ltmp69-Ltmp61                  ;   Call between Ltmp61 and Ltmp69
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp69-Lfunc_begin4            ; >> Call Site 12 <<
	.uleb128 Ltmp70-Ltmp69                  ;   Call between Ltmp69 and Ltmp70
	.uleb128 Ltmp71-Lfunc_begin4            ;     jumps to Ltmp71
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp70-Lfunc_begin4            ; >> Call Site 13 <<
	.uleb128 Ltmp72-Ltmp70                  ;   Call between Ltmp70 and Ltmp72
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp72-Lfunc_begin4            ; >> Call Site 14 <<
	.uleb128 Ltmp73-Ltmp72                  ;   Call between Ltmp72 and Ltmp73
	.uleb128 Ltmp74-Lfunc_begin4            ;     jumps to Ltmp74
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp73-Lfunc_begin4            ; >> Call Site 15 <<
	.uleb128 Lfunc_end4-Ltmp73              ;   Call between Ltmp73 and Lfunc_end4
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end4:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
__ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv: ; @_ZNK16cng_layout_model12_GLOBAL__N_16Reader6finishEv
Lfunc_begin5:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception5
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldp	x10, x8, [x0, #8]
	lsl	x8, x8, #3
	ldr	w9, [x0, #32]
	sub	x9, x8, x9
	add	x8, x9, #7
	lsr	x8, x8, #3
	cmp	x8, x10
	b.ne	LBB5_4
; %bb.1:
	ands	x9, x9, #0x7
	b.eq	LBB5_3
; %bb.2:
	ldr	x10, [x0]
	add	x8, x10, x8
	ldurb	w8, [x8, #-1]
	lsr	w8, w8, w9
	cbnz	w8, LBB5_5
LBB5_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB5_4:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp75:                                 ; EH_LABEL
Lloh162:
	adrp	x1, l_.str.27@PAGE
Lloh163:
	add	x1, x1, l_.str.27@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp76:                                 ; EH_LABEL
	b	LBB5_6
LBB5_5:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp78:                                 ; EH_LABEL
Lloh164:
	adrp	x1, l_.str.28@PAGE
Lloh165:
	add	x1, x1, l_.str.28@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp79:                                 ; EH_LABEL
LBB5_6:
Lloh166:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh167:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh168:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh169:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB5_7:
Ltmp80:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB5_8:
Ltmp77:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpLdrGot	Lloh168, Lloh169
	.loh AdrpLdrGot	Lloh166, Lloh167
Lfunc_end5:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table5:
Lexception5:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end5-Lcst_begin5
Lcst_begin5:
	.uleb128 Lfunc_begin5-Lfunc_begin5      ; >> Call Site 1 <<
	.uleb128 Ltmp75-Lfunc_begin5            ;   Call between Lfunc_begin5 and Ltmp75
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp75-Lfunc_begin5            ; >> Call Site 2 <<
	.uleb128 Ltmp76-Ltmp75                  ;   Call between Ltmp75 and Ltmp76
	.uleb128 Ltmp77-Lfunc_begin5            ;     jumps to Ltmp77
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp76-Lfunc_begin5            ; >> Call Site 3 <<
	.uleb128 Ltmp78-Ltmp76                  ;   Call between Ltmp76 and Ltmp78
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp78-Lfunc_begin5            ; >> Call Site 4 <<
	.uleb128 Ltmp79-Ltmp78                  ;   Call between Ltmp78 and Ltmp79
	.uleb128 Ltmp80-Lfunc_begin5            ;     jumps to Ltmp80
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp79-Lfunc_begin5            ; >> Call Site 5 <<
	.uleb128 Lfunc_end5-Ltmp79              ;   Call between Ltmp79 and Lfunc_end5
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end5:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function _ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_
lCPI6_0:
	.short	511                             ; 0x1ff
	.short	511                             ; 0x1ff
	.short	256                             ; 0x100
	.short	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_
	.p2align	2
__ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_: ; @_ZN18cngcompress_layout6encodeENSt3__14spanIKhLm18446744073709551615EEERKNS0_5arrayIhLm256EEENS1_IhLm18446744073709551615EEES8_
Lfunc_begin6:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception6
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #784
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh170:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh171:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh172:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	mov	w8, #9                          ; =0x9
	movk	w8, #32, lsl #16
	cmp	x1, x8
	b.hs	LBB6_12
; %bb.1:
	mov	x23, x4
	mov	x20, x1
	lsl	x8, x1, #1
	add	x9, x8, #1024
	cmp	x4, x9
	ccmp	x6, x8, #0, hs
	b.lo	LBB6_13
; %bb.2:
	mov	x19, x5
	mov	x21, x3
	mov	x24, x2
	mov	x22, x0
	add	x25, sp, #16
	add	x0, sp, #16
	mov	w1, #8176                       ; =0x1ff0
	bl	_bzero
	mov	x8, #-8128                      ; =0xffffffffffffe040
Lloh173:
	adrp	x9, lCPI6_0@PAGE
Lloh174:
	ldr	d0, [x9, lCPI6_0@PAGEOFF]
	movi.2d	v1, #0000000000000000
LBB6_3:                                 ; =>This Inner Loop Header: Depth=1
	add	x9, x25, x8
	str	d0, [x9, #8128]
	str	d0, [x9, #8144]
	str	d0, [x9, #8160]
	str	d0, [x9, #8176]
	str	d1, [x9, #8136]
	str	d1, [x9, #8152]
	str	d1, [x9, #8168]
	str	d1, [x9, #8184]
	adds	x8, x8, #64
	b.ne	LBB6_3
; %bb.4:
	str	d0, [sp, #8144]
	movi.2d	v1, #0000000000000000
	str	d1, [sp, #8152]
	str	d0, [sp, #8160]
	str	d1, [sp, #8168]
	str	d0, [sp, #8176]
	str	d1, [sp, #8184]
	mov	w8, #8176                       ; =0x1ff0
	add	x9, sp, #16
	add	x0, x9, x8
	mov	w1, #768                        ; =0x300
	bl	_bzero
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #8960]
	add	x1, sp, #16
	mov	x0, x24
	bl	__ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
	cbz	x20, LBB6_8
; %bb.5:
	mov	x8, x20
	mov	x9, x22
LBB6_6:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	ldrb	w10, [x24, x10]
	cbz	w10, LBB6_10
; %bb.7:                                ;   in Loop: Header=BB6_6 Depth=1
	subs	x8, x8, #1
	b.ne	LBB6_6
LBB6_8:
	mov	w8, #177                        ; =0xb1
	strb	w8, [x21]
	strb	w20, [x21, #1]
	lsr	x8, x20, #8
	strb	w8, [x21, #2]
	lsr	x8, x20, #16
	strb	w8, [x21, #3]
	strb	wzr, [x21, #4]
	add	x1, x21, #5
	mov	x0, x24
	mov	w2, #128                        ; =0x80
	bl	__ZN16cng_layout_model12_GLOBAL__N_113write_lengthsERKNSt3__15arrayIhLm256EEENS1_4spanIhLm18446744073709551615EEE
	add	x24, x0, #5
	sub	x5, x23, x24
	add	x8, x19, x20
	stp	x8, x20, [sp]
	add	x0, sp, #16
	add	x4, x21, x24
	mov	x1, #0                          ; =0x0
	mov	x2, x22
	mov	x3, x20
	mov	x6, x19
	mov	x7, x20
	bl	__ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
	ldur	x8, [x29, #-72]
Lloh175:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh176:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh177:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB6_14
; %bb.9:
	add	x0, x24, x0
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #784
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB6_10:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp87:                                 ; EH_LABEL
Lloh178:
	adrp	x1, l_.str.10@PAGE
Lloh179:
	add	x1, x1, l_.str.10@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp88:                                 ; EH_LABEL
LBB6_11:
Lloh180:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh181:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh182:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh183:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB6_12:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp81:                                 ; EH_LABEL
Lloh184:
	adrp	x1, l_.str.8@PAGE
Lloh185:
	add	x1, x1, l_.str.8@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp82:                                 ; EH_LABEL
	b	LBB6_11
LBB6_13:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp84:                                 ; EH_LABEL
Lloh186:
	adrp	x1, l_.str.9@PAGE
Lloh187:
	add	x1, x1, l_.str.9@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp85:                                 ; EH_LABEL
	b	LBB6_11
LBB6_14:
	bl	___stack_chk_fail
LBB6_15:
Ltmp86:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB6_16:
Ltmp83:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB6_17:
Ltmp89:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh170, Lloh171, Lloh172
	.loh AdrpLdr	Lloh173, Lloh174
	.loh AdrpLdrGotLdr	Lloh175, Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpLdrGot	Lloh182, Lloh183
	.loh AdrpLdrGot	Lloh180, Lloh181
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh186, Lloh187
Lfunc_end6:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table6:
Lexception6:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end6-Lcst_begin6
Lcst_begin6:
	.uleb128 Lfunc_begin6-Lfunc_begin6      ; >> Call Site 1 <<
	.uleb128 Ltmp87-Lfunc_begin6            ;   Call between Lfunc_begin6 and Ltmp87
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp87-Lfunc_begin6            ; >> Call Site 2 <<
	.uleb128 Ltmp88-Ltmp87                  ;   Call between Ltmp87 and Ltmp88
	.uleb128 Ltmp89-Lfunc_begin6            ;     jumps to Ltmp89
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp88-Lfunc_begin6            ; >> Call Site 3 <<
	.uleb128 Ltmp81-Ltmp88                  ;   Call between Ltmp88 and Ltmp81
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp81-Lfunc_begin6            ; >> Call Site 4 <<
	.uleb128 Ltmp82-Ltmp81                  ;   Call between Ltmp81 and Ltmp82
	.uleb128 Ltmp83-Lfunc_begin6            ;     jumps to Ltmp83
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp82-Lfunc_begin6            ; >> Call Site 5 <<
	.uleb128 Ltmp84-Ltmp82                  ;   Call between Ltmp82 and Ltmp84
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp84-Lfunc_begin6            ; >> Call Site 6 <<
	.uleb128 Ltmp85-Ltmp84                  ;   Call between Ltmp84 and Ltmp85
	.uleb128 Ltmp86-Lfunc_begin6            ;     jumps to Ltmp86
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp85-Lfunc_begin6            ; >> Call Site 7 <<
	.uleb128 Lfunc_end6-Ltmp85              ;   Call between Ltmp85 and Lfunc_end6
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end6:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
__ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE: ; @_ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
Lfunc_begin7:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception7
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x19, x1
	mov	x20, x0
	add	x22, sp, #9
Lloh188:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh189:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh190:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w8, #8432                       ; =0x20f0
	add	x21, x1, x8
	mov	x1, x21
	bl	__ZN16cng_layout_model12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	mov	x8, #0                          ; =0x0
	b	LBB7_3
LBB7_1:                                 ;   in Loop: Header=BB7_3 Depth=1
	add	x9, x19, x11, lsl #4
	strh	w8, [x9, #4]
LBB7_2:                                 ;   in Loop: Header=BB7_3 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB7_9
LBB7_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_6 Depth 2
	ldrb	w9, [x20, x8]
	cbz	w9, LBB7_2
; %bb.4:                                ;   in Loop: Header=BB7_3 Depth=1
	mov	w10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	b	LBB7_6
LBB7_5:                                 ;   in Loop: Header=BB7_6 Depth=2
	add	w10, w10, #1
	cmp	w9, w10
	b.eq	LBB7_1
LBB7_6:                                 ;   Parent Loop BB7_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w12, [x21, x8, lsl #1]
	lsr	w12, w12, w10
	and	w12, w12, #0x1
	add	x13, x19, x11, lsl #4
	ldrh	w11, [x13, w12, uxtw #1]
	cmp	w11, #511
	b.ne	LBB7_5
; %bb.7:                                ;   in Loop: Header=BB7_6 Depth=2
	ldr	x11, [x19, #8944]
	cmp	x11, #511
	b.hs	LBB7_36
; %bb.8:                                ;   in Loop: Header=BB7_6 Depth=2
	strh	w11, [x13, w12, uxtw #1]
	add	w12, w10, #1
	add	x13, x19, x11, lsl #4
	str	w12, [x13, #8]
	add	x12, x11, #1
	str	x12, [x19, #8944]
	b	LBB7_5
LBB7_9:
	ldr	x11, [x19, #8944]
	cbz	x11, LBB7_34
; %bb.10:
	add	x8, x19, x11, lsl #4
	sub	x8, x8, #16
	mov	x9, x11
	b	LBB7_12
LBB7_11:                                ;   in Loop: Header=BB7_12 Depth=1
	sub	x8, x8, #16
	sub	x9, x9, #1
	cbz	x9, LBB7_20
LBB7_12:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x8, #4]
	cmp	w10, #256
	b.ne	LBB7_11
; %bb.13:                               ;   in Loop: Header=BB7_12 Depth=1
	ldrh	w10, [x8]
	cmp	x11, x10
	b.ls	LBB7_39
; %bb.14:                               ;   in Loop: Header=BB7_12 Depth=1
	ldrh	w12, [x8, #2]
	cmp	x11, x12
	b.ls	LBB7_39
; %bb.15:                               ;   in Loop: Header=BB7_12 Depth=1
	add	x10, x19, x10, lsl #4
	ldrh	w13, [x10, #4]
	cmp	w13, #256
	b.ne	LBB7_17
; %bb.16:                               ;   in Loop: Header=BB7_12 Depth=1
	ldr	w13, [x10, #12]
	cbz	w13, LBB7_11
LBB7_17:                                ;   in Loop: Header=BB7_12 Depth=1
	add	x12, x19, x12, lsl #4
	ldrh	w13, [x12, #4]
	ldr	w12, [x12, #12]
	cmp	w13, #256
	ccmp	w12, #0, #0, eq
	b.eq	LBB7_11
; %bb.18:                               ;   in Loop: Header=BB7_12 Depth=1
	ldr	w10, [x10, #12]
	cmp	w10, w12
	b.ne	LBB7_11
; %bb.19:                               ;   in Loop: Header=BB7_12 Depth=1
	add	w10, w12, #1
	str	w10, [x8, #12]
	b	LBB7_11
LBB7_20:
	mov	x8, #0                          ; =0x0
	add	x10, sp, #9
	add	x12, x10, #495
	movi.2d	v0, #0000000000000000
	str	q0, [x12]
	add	x12, x10, #1
	stp	q0, q0, [x12, #464]
	stp	q0, q0, [x12, #432]
	stp	q0, q0, [x12, #400]
	stp	q0, q0, [x12, #368]
	stp	q0, q0, [x12, #336]
	stp	q0, q0, [x12, #304]
	stp	q0, q0, [x12, #272]
	str	q0, [x12, #256]
	stur	q0, [x22, #241]
	stur	q0, [x22, #225]
	stur	q0, [x22, #209]
	stur	q0, [x22, #193]
	stur	q0, [x22, #177]
	stur	q0, [x22, #161]
	stur	q0, [x22, #145]
	stur	q0, [x22, #129]
	stur	q0, [sp, #122]
	stur	q0, [sp, #106]
	stur	q0, [sp, #90]
	stur	q0, [sp, #74]
	stur	q0, [sp, #58]
	stur	q0, [sp, #42]
	stur	q0, [sp, #26]
	mov	w12, #1                         ; =0x1
	stur	q0, [sp, #10]
	mov	w13, #8176                      ; =0x1ff0
	add	x13, x19, x13
	mov	w14, #256                       ; =0x100
	strb	w12, [sp, #9]
	b	LBB7_23
LBB7_21:                                ;   in Loop: Header=BB7_23 Depth=1
	ldrh	w16, [x15]
	strb	w12, [x10, x16]
	ldrh	w15, [x15, #2]
	strb	w12, [x10, x15]
LBB7_22:                                ;   in Loop: Header=BB7_23 Depth=1
	add	x8, x8, #1
	cmp	x8, x11
	b.hs	LBB7_34
LBB7_23:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_28 Depth 2
                                        ;       Child Loop BB7_30 Depth 3
	ldrb	w15, [x10, x8]
	cbz	w15, LBB7_22
; %bb.24:                               ;   in Loop: Header=BB7_23 Depth=1
	add	x15, x19, x8, lsl #4
	ldrh	w16, [x15, #4]
	cmp	w16, #256
	b.ne	LBB7_22
; %bb.25:                               ;   in Loop: Header=BB7_23 Depth=1
	ldr	w16, [x15, #12]
	cbz	w16, LBB7_21
; %bb.26:                               ;   in Loop: Header=BB7_23 Depth=1
	lsl	x11, x12, x16
	sub	x16, x14, x9
	cmp	x11, x16
	b.hi	LBB7_40
; %bb.27:                               ;   in Loop: Header=BB7_23 Depth=1
	mov	x16, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	strh	w9, [x15, #6]
	add	x17, x13, x9
LBB7_28:                                ;   Parent Loop BB7_23 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB7_30 Depth 3
	ldr	w1, [x15, #12]
	mov	x2, x8
	cbz	w1, LBB7_31
; %bb.29:                               ;   in Loop: Header=BB7_28 Depth=2
	mov	w3, #0                          ; =0x0
	mov	x2, x8
LBB7_30:                                ;   Parent Loop BB7_23 Depth=1
                                        ;     Parent Loop BB7_28 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x2, x19, x2, lsl #4
	lsr	w4, w0, w3
	and	w4, w4, #0x1
	ldrh	w2, [x2, w4, uxtw #1]
	add	w3, w3, #1
	cmp	w1, w3
	b.ne	LBB7_30
LBB7_31:                                ;   in Loop: Header=BB7_28 Depth=2
	add	x1, x19, x2, lsl #4
	ldrh	w1, [x1, #4]
	cmp	w1, #256
	b.hs	LBB7_37
; %bb.32:                               ;   in Loop: Header=BB7_28 Depth=2
	strb	w1, [x17, x16]
	add	w16, w0, #1
	mov	x0, x16
	cmp	x11, x16
	b.hi	LBB7_28
; %bb.33:                               ;   in Loop: Header=BB7_23 Depth=1
	add	x9, x11, x9
	ldr	x11, [x19, #8944]
	b	LBB7_22
LBB7_34:
	ldur	x8, [x29, #-56]
Lloh191:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh192:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh193:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_41
; %bb.35:
	add	sp, sp, #528
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB7_36:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp90:                                 ; EH_LABEL
Lloh194:
	adrp	x1, l_.str.29@PAGE
Lloh195:
	add	x1, x1, l_.str.29@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp91:                                 ; EH_LABEL
	b	LBB7_38
LBB7_37:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp96:                                 ; EH_LABEL
Lloh196:
	adrp	x1, l_.str.32@PAGE
Lloh197:
	add	x1, x1, l_.str.32@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp97:                                 ; EH_LABEL
LBB7_38:
Lloh198:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh199:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh200:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh201:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB7_39:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp93:                                 ; EH_LABEL
Lloh202:
	adrp	x1, l_.str.30@PAGE
Lloh203:
	add	x1, x1, l_.str.30@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp94:                                 ; EH_LABEL
	b	LBB7_38
LBB7_40:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp99:                                 ; EH_LABEL
Lloh204:
	adrp	x1, l_.str.31@PAGE
Lloh205:
	add	x1, x1, l_.str.31@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp100:                                ; EH_LABEL
	b	LBB7_38
LBB7_41:
	bl	___stack_chk_fail
LBB7_42:
Ltmp101:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB7_43:
Ltmp95:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB7_44:
Ltmp98:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB7_45:
Ltmp92:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh188, Lloh189, Lloh190
	.loh AdrpLdrGotLdr	Lloh191, Lloh192, Lloh193
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpLdrGot	Lloh200, Lloh201
	.loh AdrpLdrGot	Lloh198, Lloh199
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh204, Lloh205
Lfunc_end7:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table7:
Lexception7:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end7-Lcst_begin7
Lcst_begin7:
	.uleb128 Lfunc_begin7-Lfunc_begin7      ; >> Call Site 1 <<
	.uleb128 Ltmp90-Lfunc_begin7            ;   Call between Lfunc_begin7 and Ltmp90
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp90-Lfunc_begin7            ; >> Call Site 2 <<
	.uleb128 Ltmp91-Ltmp90                  ;   Call between Ltmp90 and Ltmp91
	.uleb128 Ltmp92-Lfunc_begin7            ;     jumps to Ltmp92
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp91-Lfunc_begin7            ; >> Call Site 3 <<
	.uleb128 Ltmp96-Ltmp91                  ;   Call between Ltmp91 and Ltmp96
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp96-Lfunc_begin7            ; >> Call Site 4 <<
	.uleb128 Ltmp97-Ltmp96                  ;   Call between Ltmp96 and Ltmp97
	.uleb128 Ltmp98-Lfunc_begin7            ;     jumps to Ltmp98
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp97-Lfunc_begin7            ; >> Call Site 5 <<
	.uleb128 Ltmp93-Ltmp97                  ;   Call between Ltmp97 and Ltmp93
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp93-Lfunc_begin7            ; >> Call Site 6 <<
	.uleb128 Ltmp94-Ltmp93                  ;   Call between Ltmp93 and Ltmp94
	.uleb128 Ltmp95-Lfunc_begin7            ;     jumps to Ltmp95
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp94-Lfunc_begin7            ; >> Call Site 7 <<
	.uleb128 Ltmp99-Ltmp94                  ;   Call between Ltmp94 and Ltmp99
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp99-Lfunc_begin7            ; >> Call Site 8 <<
	.uleb128 Ltmp100-Ltmp99                 ;   Call between Ltmp99 and Ltmp100
	.uleb128 Ltmp101-Lfunc_begin7           ;     jumps to Ltmp101
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp100-Lfunc_begin7           ; >> Call Site 9 <<
	.uleb128 Lfunc_end7-Ltmp100             ;   Call between Ltmp100 and Lfunc_end7
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end7:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
__ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_: ; @_ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
Lfunc_begin8:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception8
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x23, x0, x1, lsl #4
	ldrh	w8, [x23, #4]
	cmp	x3, #0
	mov	w9, #256                        ; =0x100
	ccmp	w8, w9, #0, ne
	b.eq	LBB8_2
; %bb.1:
	mov	x0, #0                          ; =0x0
	b	LBB8_19
LBB8_2:
	mov	x22, x6
	mov	x20, x4
	mov	x25, x3
	mov	x26, x2
	mov	x9, #0                          ; =0x0
	ldp	x19, x1, [x29, #16]
	mov	w8, #8432                       ; =0x20f0
	str	x0, [sp, #24]                   ; 8-byte Spill
	add	x24, x0, x8
	b	LBB8_4
LBB8_3:                                 ;   in Loop: Header=BB8_4 Depth=1
	ldrh	w1, [x23]
	stp	x22, x21, [sp]
	mov	x25, x17
	add	x4, x20, x17
	ldr	x19, [sp, #24]                  ; 8-byte Reload
	mov	x0, x19
	mov	x2, x22
	mov	x3, x21
	mov	x6, x27
	mov	x7, x21
	bl	__ZN18cngcompress_layout12_GLOBAL__N_14emitERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_S8_
	ldrh	w8, [x23, #2]
	ldp	x9, x5, [sp, #40]               ; 16-byte Folded Reload
	sub	x9, x9, x21
	add	x10, x0, x25
	sub	x5, x5, x10
	ldr	x11, [sp, #32]                  ; 8-byte Reload
	sub	x11, x11, x21
	cmn	x28, #1
	csel	x25, x9, x28, eq
	add	x26, x22, x21
	add	x20, x20, x10
	csel	x7, x11, x28, eq
	add	x22, x21, x27
	ldr	x9, [sp, #56]                   ; 8-byte Reload
	add	x9, x10, x9
	add	x23, x19, x8, lsl #4
	ldrh	w8, [x23, #4]
	cmp	w8, #256
	ccmp	x25, #0, #4, eq
	mov	x19, x26
	mov	x1, x25
	b.eq	LBB8_17
LBB8_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB8_9 Depth 2
                                        ;     Child Loop BB8_14 Depth 2
	ldr	w8, [x23, #12]
	cmp	w8, #1
	csinc	w21, w8, wzr, hi
	mov	x8, #7                          ; =0x7
	madd	x8, x25, x21, x8
	lsr	x28, x8, #3
	str	x5, [sp, #48]                   ; 8-byte Spill
	subs	x5, x5, x28
	b.lo	LBB8_20
; %bb.5:                                ;   in Loop: Header=BB8_4 Depth=1
	stp	x1, x7, [sp, #32]               ; 16-byte Folded Spill
	str	x9, [sp, #56]                   ; 8-byte Spill
	cbz	x28, LBB8_7
; %bb.6:                                ;   in Loop: Header=BB8_4 Depth=1
	mov	x0, x20
	mov	x1, x28
	mov	x27, x5
	bl	_bzero
	mov	x5, x27
LBB8_7:                                 ;   in Loop: Header=BB8_4 Depth=1
	mov	x17, x28
	mov	x8, #0                          ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w9, #-1                         ; =0xffffffff
	lsl	w9, w9, w21
	mov	x10, x26
	mov	x11, x25
	b	LBB8_9
LBB8_8:                                 ;   in Loop: Header=BB8_9 Depth=2
	add	x28, x28, w12, uxtw
	add	x8, x8, x21
	subs	x11, x11, #1
	b.eq	LBB8_11
LBB8_9:                                 ;   Parent Loop BB8_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w12, [x10], #1
	ldrh	w12, [x24, x12, lsl #1]
	ldr	w13, [x23, #8]
	lsr	w12, w12, w13
	bic	w12, w12, w9
	and	x15, x8, #0x7
	lsl	w14, w12, w15
	add	x13, x20, x8, lsr #3
	ldrb	w16, [x13]
	orr	w16, w16, w14
	strb	w16, [x13]
	add	x15, x15, x21
	cmp	x15, #9
	b.lo	LBB8_8
; %bb.10:                               ;   in Loop: Header=BB8_9 Depth=2
	ldrb	w15, [x13, #1]
	orr	w14, w15, w14, lsr #8
	strb	w14, [x13, #1]
	b	LBB8_8
LBB8_11:                                ;   in Loop: Header=BB8_4 Depth=1
	ldr	w8, [x23, #12]
	cbnz	w8, LBB8_16
; %bb.12:                               ;   in Loop: Header=BB8_4 Depth=1
	mov	x27, x19
	mov	x8, #0                          ; =0x0
	sub	x21, x25, x28
	sub	x9, x25, x28
	b	LBB8_14
LBB8_13:                                ;   in Loop: Header=BB8_14 Depth=2
	strb	w10, [x22, x9]
	add	x9, x9, #1
	add	x26, x26, #1
	subs	x25, x25, #1
	b.eq	LBB8_3
LBB8_14:                                ;   Parent Loop BB8_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w10, [x26]
	ldrh	w11, [x24, x10, lsl #1]
	ldr	w12, [x23, #8]
	lsr	w11, w11, w12
	tbnz	w11, #0, LBB8_13
; %bb.15:                               ;   in Loop: Header=BB8_14 Depth=2
	strb	w10, [x22, x8]
	add	x8, x8, #1
	add	x26, x26, #1
	subs	x25, x25, #1
	b.ne	LBB8_14
	b	LBB8_3
LBB8_16:
	ldr	x9, [sp, #56]                   ; 8-byte Reload
	b	LBB8_18
LBB8_17:
	mov	x17, #0                         ; =0x0
LBB8_18:
	add	x0, x17, x9
LBB8_19:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB8_20:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp102:                                ; EH_LABEL
Lloh206:
	adrp	x1, l_.str.33@PAGE
Lloh207:
	add	x1, x1, l_.str.33@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp103:                                ; EH_LABEL
; %bb.21:
Lloh208:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh209:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh210:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh211:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB8_22:
Ltmp104:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpLdrGot	Lloh210, Lloh211
	.loh AdrpLdrGot	Lloh208, Lloh209
Lfunc_end8:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table8:
Lexception8:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end8-Lcst_begin8
Lcst_begin8:
	.uleb128 Lfunc_begin8-Lfunc_begin8      ; >> Call Site 1 <<
	.uleb128 Ltmp102-Lfunc_begin8           ;   Call between Lfunc_begin8 and Ltmp102
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp102-Lfunc_begin8           ; >> Call Site 2 <<
	.uleb128 Ltmp103-Ltmp102                ;   Call between Ltmp102 and Ltmp103
	.uleb128 Ltmp104-Lfunc_begin8           ;     jumps to Ltmp104
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp103-Lfunc_begin8           ; >> Call Site 3 <<
	.uleb128 Lfunc_end8-Ltmp103             ;   Call between Ltmp103 and Lfunc_end8
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end8:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function _ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_
lCPI9_0:
	.short	511                             ; 0x1ff
	.short	511                             ; 0x1ff
	.short	256                             ; 0x100
	.short	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_
	.p2align	2
__ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_: ; @_ZN18cngcompress_layout6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEES4_
Lfunc_begin9:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception9
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #1040
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh212:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh213:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh214:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	subs	x21, x1, #5
	b.lo	LBB9_10
; %bb.1:
	mov	x23, x0
	ldrb	w8, [x0]
	cmp	w8, #177
	b.ne	LBB9_10
; %bb.2:
	mov	x19, x3
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x3, x8
	b.hi	LBB9_11
; %bb.3:
	ldur	w8, [x23, #1]
	cmp	x19, x8
	b.ne	LBB9_11
; %bb.4:
	cmp	x5, x19
	b.lo	LBB9_12
; %bb.5:
	mov	x20, x4
	mov	x22, x2
	mov	x24, x1
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #768
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	add	x0, x23, #5
	add	x2, sp, #2, lsl #12             ; =8192
	add	x2, x2, #768
	mov	x1, x21
	bl	__ZN16cng_layout_model12_GLOBAL__N_112read_lengthsENSt3__14spanIKhLm18446744073709551615EEERNS1_5arrayIhLm256EEE
	mov	x25, x0
	add	x26, sp, #8
	add	x0, sp, #8
	mov	w1, #8176                       ; =0x1ff0
	bl	_bzero
	movi.2d	v1, #0000000000000000
	mov	x8, #-8128                      ; =0xffffffffffffe040
Lloh215:
	adrp	x9, lCPI9_0@PAGE
Lloh216:
	ldr	d0, [x9, lCPI9_0@PAGEOFF]
LBB9_6:                                 ; =>This Inner Loop Header: Depth=1
	add	x9, x26, x8
	str	d0, [x9, #8128]
	str	d0, [x9, #8144]
	str	d0, [x9, #8160]
	str	d0, [x9, #8176]
	str	d1, [x9, #8136]
	str	d1, [x9, #8152]
	str	d1, [x9, #8168]
	str	d1, [x9, #8184]
	adds	x8, x8, #64
	b.ne	LBB9_6
; %bb.7:
	str	d0, [sp, #8136]
	movi.2d	v1, #0000000000000000
	str	d1, [sp, #8144]
	str	d0, [sp, #8152]
	str	d1, [sp, #8160]
	str	d0, [sp, #8168]
	str	d1, [sp, #8176]
	mov	w8, #8176                       ; =0x1ff0
	add	x9, sp, #8
	add	x0, x9, x8
	mov	w1, #768                        ; =0x300
	bl	_bzero
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #8952]
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #768
	add	x1, sp, #8
	bl	__ZN18cngcompress_layout12_GLOBAL__N_19make_treeERKNSt3__15arrayIhLm256EEERNS0_4TreeE
	add	x8, x25, #5
	sub	x3, x24, x8
	add	x0, sp, #8
	add	x2, x23, x8
	mov	x1, #0                          ; =0x0
	mov	x4, x22
	mov	x5, x19
	mov	x6, x20
	mov	x7, x19
	bl	__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
	sub	x8, x21, x25
	cmp	x0, x8
	b.ne	LBB9_13
; %bb.8:
	ldur	x8, [x29, #-88]
Lloh217:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh218:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh219:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB9_15
; %bb.9:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #1040
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB9_10:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x20, x0
Ltmp105:                                ; EH_LABEL
Lloh220:
	adrp	x1, l_.str.11@PAGE
Lloh221:
	add	x1, x1, l_.str.11@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp106:                                ; EH_LABEL
	b	LBB9_14
LBB9_11:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x20, x0
Ltmp108:                                ; EH_LABEL
Lloh222:
	adrp	x1, l_.str.12@PAGE
Lloh223:
	add	x1, x1, l_.str.12@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp109:                                ; EH_LABEL
	b	LBB9_14
LBB9_12:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x20, x0
Ltmp114:                                ; EH_LABEL
Lloh224:
	adrp	x1, l_.str.13@PAGE
Lloh225:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp115:                                ; EH_LABEL
	b	LBB9_14
LBB9_13:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x20, x0
Ltmp111:                                ; EH_LABEL
Lloh226:
	adrp	x1, l_.str.14@PAGE
Lloh227:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp112:                                ; EH_LABEL
LBB9_14:
Lloh228:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh229:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh230:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh231:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x20
	bl	___cxa_throw
LBB9_15:
	bl	___stack_chk_fail
LBB9_16:
Ltmp113:                                ; EH_LABEL
	mov	x19, x0
	mov	x0, x20
	bl	___cxa_free_exception
	mov	x0, x19
	bl	__Unwind_Resume
LBB9_17:
Ltmp116:                                ; EH_LABEL
	mov	x19, x0
	mov	x0, x20
	bl	___cxa_free_exception
	mov	x0, x19
	bl	__Unwind_Resume
LBB9_18:
Ltmp110:                                ; EH_LABEL
	mov	x19, x0
	mov	x0, x20
	bl	___cxa_free_exception
	mov	x0, x19
	bl	__Unwind_Resume
LBB9_19:
Ltmp107:                                ; EH_LABEL
	mov	x19, x0
	mov	x0, x20
	bl	___cxa_free_exception
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh212, Lloh213, Lloh214
	.loh AdrpLdr	Lloh215, Lloh216
	.loh AdrpLdrGotLdr	Lloh217, Lloh218, Lloh219
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpLdrGot	Lloh230, Lloh231
	.loh AdrpLdrGot	Lloh228, Lloh229
Lfunc_end9:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table9:
Lexception9:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end9-Lcst_begin9
Lcst_begin9:
	.uleb128 Lfunc_begin9-Lfunc_begin9      ; >> Call Site 1 <<
	.uleb128 Ltmp105-Lfunc_begin9           ;   Call between Lfunc_begin9 and Ltmp105
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp105-Lfunc_begin9           ; >> Call Site 2 <<
	.uleb128 Ltmp106-Ltmp105                ;   Call between Ltmp105 and Ltmp106
	.uleb128 Ltmp107-Lfunc_begin9           ;     jumps to Ltmp107
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp106-Lfunc_begin9           ; >> Call Site 3 <<
	.uleb128 Ltmp108-Ltmp106                ;   Call between Ltmp106 and Ltmp108
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp108-Lfunc_begin9           ; >> Call Site 4 <<
	.uleb128 Ltmp109-Ltmp108                ;   Call between Ltmp108 and Ltmp109
	.uleb128 Ltmp110-Lfunc_begin9           ;     jumps to Ltmp110
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp109-Lfunc_begin9           ; >> Call Site 5 <<
	.uleb128 Ltmp114-Ltmp109                ;   Call between Ltmp109 and Ltmp114
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp114-Lfunc_begin9           ; >> Call Site 6 <<
	.uleb128 Ltmp115-Ltmp114                ;   Call between Ltmp114 and Ltmp115
	.uleb128 Ltmp116-Lfunc_begin9           ;     jumps to Ltmp116
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp115-Lfunc_begin9           ; >> Call Site 7 <<
	.uleb128 Ltmp111-Ltmp115                ;   Call between Ltmp115 and Ltmp111
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp111-Lfunc_begin9           ; >> Call Site 8 <<
	.uleb128 Ltmp112-Ltmp111                ;   Call between Ltmp111 and Ltmp112
	.uleb128 Ltmp113-Lfunc_begin9           ;     jumps to Ltmp113
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp112-Lfunc_begin9           ; >> Call Site 9 <<
	.uleb128 Lfunc_end9-Ltmp112             ;   Call between Ltmp112 and Lfunc_end9
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end9:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
lCPI10_0:
	.byte	8                               ; 0x8
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	9                               ; 0x9
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	10                              ; 0xa
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	11                              ; 0xb
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI10_1:
	.byte	4                               ; 0x4
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	5                               ; 0x5
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	6                               ; 0x6
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	7                               ; 0x7
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI10_2:
	.byte	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	2                               ; 0x2
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	3                               ; 0x3
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI10_3:
	.byte	12                              ; 0xc
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	13                              ; 0xd
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	14                              ; 0xe
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	15                              ; 0xf
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_: ; @_ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
Lfunc_begin10:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception10
; %bb.0:
	sub	sp, sp, #160
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	cbz	x5, LBB10_14
; %bb.1:
	add	x20, x0, x1, lsl #4
	ldrh	w8, [x20, #4]
	cmp	w8, #256
	b.ne	LBB10_153
; %bb.2:
	ldr	w9, [x20, #12]
	cmp	w9, #1
	csinc	w10, w9, wzr, hi
	mov	x8, #7                          ; =0x7
	madd	x11, x5, x10, x8
	lsr	x8, x11, #3
	str	x8, [sp, #24]                   ; 8-byte Spill
	subs	x8, x3, x8
	b.lo	LBB10_154
; %bb.3:
	mov	x23, x4
	mul	w10, w10, w5
	ands	w10, w10, #0x7
	b.eq	LBB10_5
; %bb.4:
	ldr	x12, [sp, #24]                  ; 8-byte Reload
	add	x12, x2, x12
	ldurb	w12, [x12, #-1]
	lsr	w10, w12, w10
	cbnz	w10, LBB10_155
LBB10_5:
	cbz	w9, LBB10_15
; %bb.6:
	ldrh	w8, [x20, #6]
	mov	w10, #8176                      ; =0x1ff0
	add	x10, x0, x10
	add	x8, x10, x8
	cmp	w9, #4
	b.gt	LBB10_18
; %bb.7:
	cmp	w9, #2
	b.gt	LBB10_25
; %bb.8:
	cmp	w9, #1
	b.eq	LBB10_40
; %bb.9:
	cmp	w9, #2
	b.ne	LBB10_157
; %bb.10:
	cmp	x5, #8
	b.lo	LBB10_138
; %bb.11:
	mov	x9, #0                          ; =0x0
	add	x10, x2, #1
	mov	x11, x23
LBB10_12:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-1]
	ldrb	w13, [x10], #2
	and	x14, x12, #0x3
	ldrb	w14, [x8, x14]
	strb	w14, [x11]
	ubfx	x14, x12, #2, #2
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #1]
	ubfx	x14, x12, #4, #2
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #2]
	lsr	x12, x12, #6
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #3]
	and	x12, x13, #0x3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #4]
	ubfx	x12, x13, #2, #2
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #5]
	ubfx	x12, x13, #4, #2
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #6]
	lsr	x12, x13, #6
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #7]
	sub	x9, x9, #8
	add	x12, x5, x9
	add	x11, x11, #8
	cmp	x12, #7
	b.hi	LBB10_12
; %bb.13:
	neg	x11, x9
	subs	x9, x5, x11
	b.hi	LBB10_139
	b	LBB10_151
LBB10_14:
	mov	x0, #0                          ; =0x0
	b	LBB10_152
LBB10_15:
	ldr	x10, [sp, #24]                  ; 8-byte Reload
	add	x9, x2, x10
	cbz	x10, LBB10_37
; %bb.16:
	cmp	x11, #32
	b.hs	LBB10_38
; %bb.17:
	mov	x21, #0                         ; =0x0
	mov	x10, x2
	b	LBB10_65
LBB10_18:
	cmp	w9, #6
	b.gt	LBB10_31
; %bb.19:
	cmp	w9, #5
	b.eq	LBB10_46
; %bb.20:
	cmp	w9, #6
	b.ne	LBB10_157
; %bb.21:
	cmp	x5, #8
	b.lo	LBB10_141
; %bb.22:
	mov	x9, #0                          ; =0x0
	add	x10, x2, #2
	mov	x11, x23
LBB10_23:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-2]
	ldurb	w13, [x10, #-1]
	and	x14, x12, #0x3f
                                        ; kill: def $w12 killed $w12 killed $x12 def $x12
	bfi	w12, w13, #8, #8
	ldrb	w15, [x10]
	ldrb	w16, [x10, #1]
	lsl	w13, w13, #8
	orr	w13, w13, w15, lsl #16
	ldrb	w17, [x10, #2]
	lsl	x17, x17, #32
	ldrb	w0, [x10, #3]
	orr	x1, x17, x0, lsl #40
	orr	x17, x17, x16, lsl #24
	ldrb	w14, [x8, x14]
	strb	w14, [x11]
	ubfx	x12, x12, #6, #6
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #1]
	ubfx	x12, x13, #12, #6
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #2]
	lsr	x12, x15, #2
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #3]
	and	x12, x16, #0x3f
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #4]
	ubfx	x12, x17, #30, #6
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #5]
	ubfx	x12, x1, #36, #6
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #6]
	lsr	x12, x0, #2
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #7]
	sub	x9, x9, #8
	add	x12, x5, x9
	add	x10, x10, #6
	add	x11, x11, #8
	cmp	x12, #7
	b.hi	LBB10_23
; %bb.24:
	neg	x11, x9
	subs	x9, x5, x11
	b.hi	LBB10_142
	b	LBB10_151
LBB10_25:
	cmp	w9, #3
	b.eq	LBB10_50
; %bb.26:
	cmp	w9, #4
	b.ne	LBB10_157
; %bb.27:
	cmp	x5, #8
	b.lo	LBB10_146
; %bb.28:
	mov	x9, #0                          ; =0x0
	add	x10, x2, #3
	mov	x11, x23
LBB10_29:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-3]
	ldurb	w13, [x10, #-2]
	ldurb	w14, [x10, #-1]
	ldrb	w15, [x10], #4
	and	x16, x12, #0xf
	ldrb	w16, [x8, x16]
	strb	w16, [x11]
	lsr	x12, x12, #4
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #1]
	and	x12, x13, #0xf
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #2]
	lsr	x12, x13, #4
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #3]
	and	x12, x14, #0xf
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #4]
	lsr	x12, x14, #4
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #5]
	and	x12, x15, #0xf
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #6]
	lsr	x12, x15, #4
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #7]
	sub	x9, x9, #8
	add	x12, x5, x9
	add	x11, x11, #8
	cmp	x12, #7
	b.hi	LBB10_29
; %bb.30:
	neg	x11, x9
	subs	x9, x5, x11
	b.hi	LBB10_147
	b	LBB10_151
LBB10_31:
	cmp	w9, #7
	b.eq	LBB10_54
; %bb.32:
	cmp	w9, #8
	b.ne	LBB10_157
; %bb.33:
	cmp	x5, #8
	b.lo	LBB10_149
; %bb.34:
	mov	x9, #0                          ; =0x0
	mov	x10, x5
LBB10_35:                               ; =>This Inner Loop Header: Depth=1
	add	x11, x2, x9
	ldrb	w12, [x11]
	ldrb	w13, [x11, #1]
	ldrb	w14, [x11, #2]
	ldrb	w15, [x11, #3]
	ldrb	w16, [x11, #4]
	ldrb	w17, [x11, #5]
	ldrb	w0, [x11, #6]
	ldrb	w11, [x11, #7]
	add	x1, x23, x9
	ldrb	w12, [x8, x12]
	strb	w12, [x1]
	ldrb	w12, [x8, x13]
	strb	w12, [x1, #1]
	ldrb	w12, [x8, x14]
	strb	w12, [x1, #2]
	ldrb	w12, [x8, x15]
	strb	w12, [x1, #3]
	ldrb	w12, [x8, x16]
	strb	w12, [x1, #4]
	ldrb	w12, [x8, x17]
	strb	w12, [x1, #5]
	ldrb	w12, [x8, x0]
	strb	w12, [x1, #6]
	ldrb	w11, [x8, x11]
	strb	w11, [x1, #7]
	add	x9, x9, #8
	sub	x10, x10, #8
	cmp	x10, #7
	b.hi	LBB10_35
; %bb.36:
	cmp	x9, x5
	b.lo	LBB10_150
	b	LBB10_151
LBB10_37:
	mov	x21, #0                         ; =0x0
	b	LBB10_66
LBB10_38:
	cmp	x11, #256
	b.hs	LBB10_58
; %bb.39:
	mov	x12, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB10_62
LBB10_40:
	mov	x9, #0                          ; =0x0
	subs	x10, x5, #8
	b.lo	LBB10_44
; %bb.41:
	lsr	x10, x10, #3
	add	x10, x10, #1
	mov	x11, x23
	mov	x12, x2
LBB10_42:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w13, [x12], #1
	and	x14, x13, #0x1
	ldrb	w14, [x8, x14]
	strb	w14, [x11]
	ubfx	x14, x13, #1, #1
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #1]
	ubfx	x14, x13, #2, #1
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #2]
	ubfx	x14, x13, #3, #1
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #3]
	ubfx	x14, x13, #4, #1
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #4]
	ubfx	x14, x13, #5, #1
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #5]
	ubfx	x14, x13, #6, #1
	ldrb	w14, [x8, x14]
	strb	w14, [x11, #6]
	lsr	x13, x13, #7
	ldrb	w13, [x8, x13]
	strb	w13, [x11, #7]
	sub	x9, x9, #8
	add	x11, x11, #8
	subs	x10, x10, #1
	b.ne	LBB10_42
; %bb.43:
	neg	x9, x9
LBB10_44:
	cmp	x9, x5
	b.hs	LBB10_151
LBB10_45:                               ; =>This Inner Loop Header: Depth=1
	lsr	x10, x9, #3
	ldrb	w10, [x2, x10]
	and	w11, w9, #0x7
	lsr	w10, w10, w11
	and	x10, x10, #0x1
	ldrb	w10, [x8, x10]
	strb	w10, [x23, x9]
	add	x9, x9, #1
	cmp	x5, x9
	b.ne	LBB10_45
	b	LBB10_151
LBB10_46:
	cmp	x5, #8
	b.lo	LBB10_123
; %bb.47:
	mov	x9, #0                          ; =0x0
	add	x10, x2, #2
	mov	x11, x23
LBB10_48:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-2]
	ldurb	w13, [x10, #-1]
	ldrb	w14, [x10]
	lsl	w15, w14, #16
	orr	w15, w15, w13, lsl #8
	and	x16, x12, #0x1f
                                        ; kill: def $w12 killed $w12 killed $x12 def $x12
	bfi	w12, w13, #8, #8
	ldrb	w17, [x10, #1]
	lsl	x0, x17, #24
	ldrb	w1, [x10, #2]
	orr	x3, x0, x1, lsl #32
                                        ; kill: def $w0 killed $w0 killed $x0 def $x0
	bfi	w0, w14, #16, #8
	ldrb	w14, [x8, x16]
	strb	w14, [x11]
	ubfx	x12, x12, #5, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #1]
	ubfx	x12, x13, #2, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #2]
	ubfx	x12, x15, #15, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #3]
	ubfx	x12, x0, #20, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #4]
	ubfx	x12, x17, #1, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #5]
	ubfx	x12, x3, #30, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #6]
	lsr	x12, x1, #3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #7]
	sub	x9, x9, #8
	add	x12, x5, x9
	add	x10, x10, #5
	add	x11, x11, #8
	cmp	x12, #7
	b.hi	LBB10_48
; %bb.49:
	neg	x11, x9
	subs	x9, x5, x11
	b.hi	LBB10_124
	b	LBB10_151
LBB10_50:
	cmp	x5, #8
	b.lo	LBB10_128
; %bb.51:
	mov	x9, #0                          ; =0x0
	add	x10, x2, #2
	mov	x11, x23
LBB10_52:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-2]
	ldurb	w13, [x10, #-1]
	ldrb	w14, [x10], #3
	lsl	w15, w13, #8
	orr	w15, w15, w14, lsl #16
	and	x16, x12, #0x7
	ubfx	x17, x12, #3, #3
                                        ; kill: def $w12 killed $w12 killed $x12 def $x12
	bfi	w12, w13, #8, #8
	ldrb	w16, [x8, x16]
	strb	w16, [x11]
	ldrb	w16, [x8, x17]
	strb	w16, [x11, #1]
	ubfx	x12, x12, #6, #3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #2]
	ubfx	x12, x13, #1, #3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #3]
	ubfx	x12, x13, #4, #3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #4]
	ubfx	x12, x15, #15, #3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #5]
	ubfx	x12, x14, #2, #3
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #6]
	lsr	x12, x14, #5
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #7]
	sub	x9, x9, #8
	add	x12, x5, x9
	add	x11, x11, #8
	cmp	x12, #7
	b.hi	LBB10_52
; %bb.53:
	neg	x11, x9
	subs	x9, x5, x11
	b.hi	LBB10_129
	b	LBB10_151
LBB10_54:
	cmp	x5, #8
	b.lo	LBB10_133
; %bb.55:
	mov	x9, #0                          ; =0x0
	add	x10, x2, #3
	mov	x11, x23
LBB10_56:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x10, #-3]
	ldurb	w13, [x10, #-2]
	lsl	x13, x13, #8
	ldurb	w14, [x10, #-1]
	orr	x13, x13, x14, lsl #16
	orr	x14, x13, x12
	ldrb	w15, [x10]
	lsl	x15, x15, #24
	ldrb	w16, [x10, #1]
	orr	x15, x15, x16, lsl #32
	orr	x16, x15, x14
	ldrb	w17, [x10, #2]
	lsl	x17, x17, #40
	ldrb	w0, [x10, #3]
	orr	x17, x17, x0, lsl #48
	orr	x17, x17, x16
	and	x12, x12, #0x7f
	ldrb	w12, [x8, x12]
	strb	w12, [x11]
	ubfx	x12, x14, #7, #7
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #1]
	ubfx	x12, x13, #14, #7
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #2]
	ubfx	x12, x16, #21, #7
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #3]
	ubfx	x12, x15, #28, #7
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #4]
	ubfx	x12, x17, #35, #7
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #5]
	ubfx	x12, x17, #42, #7
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #6]
	lsr	x12, x17, #49
	ldrb	w12, [x8, x12]
	strb	w12, [x11, #7]
	sub	x9, x9, #8
	add	x12, x5, x9
	add	x10, x10, #7
	add	x11, x11, #8
	cmp	x12, #7
	b.hi	LBB10_56
; %bb.57:
	neg	x11, x9
	subs	x9, x5, x11
	b.hi	LBB10_134
	b	LBB10_151
LBB10_58:
	movi.2d	v0, #0000000000000000
	ldr	x15, [sp, #24]                  ; 8-byte Reload
	and	x12, x15, #0x1fffffffffffffe0
	add	x10, x2, x12
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	add	x13, x2, #16
	movi.2d	v3, #0000000000000000
Lloh232:
	adrp	x14, lCPI10_0@PAGE
Lloh233:
	ldr	q5, [x14, lCPI10_0@PAGEOFF]
Lloh234:
	adrp	x14, lCPI10_1@PAGE
Lloh235:
	ldr	q7, [x14, lCPI10_1@PAGEOFF]
Lloh236:
	adrp	x14, lCPI10_2@PAGE
Lloh237:
	ldr	q19, [x14, lCPI10_2@PAGEOFF]
	movi.2d	v18, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
Lloh238:
	adrp	x14, lCPI10_3@PAGE
Lloh239:
	ldr	q23, [x14, lCPI10_3@PAGEOFF]
	and	x14, x15, #0x1fffffffffffffe0
	movi.2d	v22, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v27, #0000000000000000
LBB10_59:                               ; =>This Inner Loop Header: Depth=1
	ldp	q28, q29, [x13, #-16]
	cnt.16b	v28, v28
	cnt.16b	v29, v29
	tbl.16b	v30, { v28 }, v5
	tbl.16b	v31, { v28 }, v7
	tbl.16b	v8, { v28 }, v19
	tbl.16b	v28, { v28 }, v23
	tbl.16b	v9, { v29 }, v5
	tbl.16b	v10, { v29 }, v7
	tbl.16b	v11, { v29 }, v19
	tbl.16b	v29, { v29 }, v23
	uaddw2.2d	v18, v18, v31
	uaddw2.2d	v2, v2, v8
	uaddw.2d	v4, v4, v30
	uaddw.2d	v3, v3, v31
	uaddw.2d	v1, v1, v8
	uaddw2.2d	v16, v16, v30
	uaddw.2d	v6, v6, v28
	uaddw2.2d	v20, v20, v28
	uaddw2.2d	v26, v26, v10
	uaddw2.2d	v0, v0, v11
	uaddw.2d	v21, v21, v9
	uaddw.2d	v22, v22, v10
	uaddw.2d	v17, v17, v11
	uaddw2.2d	v25, v25, v9
	uaddw.2d	v24, v24, v29
	uaddw2.2d	v27, v27, v29
	add	x13, x13, #32
	subs	x14, x14, #32
	b.ne	LBB10_59
; %bb.60:
	add.2d	v5, v26, v18
	add.2d	v7, v27, v20
	add.2d	v0, v0, v2
	add.2d	v2, v25, v16
	add.2d	v3, v22, v3
	add.2d	v6, v24, v6
	add.2d	v1, v17, v1
	add.2d	v4, v21, v4
	add.2d	v1, v1, v4
	add.2d	v3, v3, v6
	add.2d	v1, v1, v3
	add.2d	v0, v0, v2
	add.2d	v2, v5, v7
	add.2d	v0, v0, v2
	add.2d	v0, v1, v0
	addp.2d	d0, v0
	fmov	x21, d0
	ldr	x13, [sp, #24]                  ; 8-byte Reload
	cmp	x13, x12
	b.eq	LBB10_66
; %bb.61:
	tst	x11, #0xe0
	b.eq	LBB10_65
LBB10_62:
	ldr	x10, [sp, #24]                  ; 8-byte Reload
	and	x11, x10, #0x1ffffffffffffffc
	add	x10, x2, x11
	fmov	d0, x21
	movi.2d	v1, #0000000000000000
	sub	x13, x12, x11
	add	x12, x2, x12
	movi.16b	v2, #1
LBB10_63:                               ; =>This Inner Loop Header: Depth=1
	ldr	s3, [x12], #4
	ushll.8h	v3, v3, #0
	ushll.4s	v3, v3, #0
	cnt.16b	v3, v3
	movi.2d	v4, #0000000000000000
	udot.4s	v4, v2, v3
	uaddw2.2d	v1, v1, v4
	uaddw.2d	v0, v0, v4
	adds	x13, x13, #4
	b.ne	LBB10_63
; %bb.64:
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x21, d0
	ldr	x12, [sp, #24]                  ; 8-byte Reload
	cmp	x12, x11
	b.eq	LBB10_66
LBB10_65:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #1
	fmov	d0, x11
	cnt.8b	v0, v0
	fmov	w11, s0
	add	x21, x21, x11
	cmp	x10, x9
	b.ne	LBB10_65
LBB10_66:
	sub	x22, x5, x21
	ldrh	w1, [x20]
	add	x26, x0, x1, lsl #4
	ldrh	w9, [x20, #2]
	str	x0, [sp, #16]                   ; 8-byte Spill
	add	x10, x0, x9, lsl #4
	ldrh	w9, [x26, #4]
	ldr	x0, [sp, #24]                   ; 8-byte Reload
	cmp	w9, #256
	b.ne	LBB10_68
; %bb.67:
	mov	x27, x2
	ldp	x0, x9, [sp, #16]               ; 16-byte Folded Reload
	add	x2, x2, x9
	mov	x28, x5
	sub	x5, x5, x21
	stp	x22, x7, [sp]                   ; 16-byte Folded Spill
	sub	x7, x28, x21
	mov	x19, x3
	mov	x3, x8
	mov	x4, x6
	mov	x22, x9
	mov	x25, x6
	mov	x6, x23
	mov	x24, x26
	mov	x26, x10
	bl	__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
	mov	x10, x26
	mov	x26, x24
	mov	x3, x19
	mov	x6, x25
	mov	x8, x22
	ldp	x22, x7, [sp]                   ; 16-byte Folded Reload
	mov	x5, x28
	mov	x2, x27
	add	x0, x0, x8
LBB10_68:
	ldrh	w8, [x10, #4]
	cmp	w8, #256
	b.ne	LBB10_72
; %bb.69:
	ldrh	w1, [x20, #2]
	sub	x3, x3, x0
	sub	x8, x7, x22
	cmn	x21, #1
	csel	x8, x8, x21, eq
	mov	x27, x2
	add	x2, x2, x0
	mov	x24, x6
	add	x4, x6, x22
	add	x6, x23, x22
	mov	x28, x0
	ldr	x0, [sp, #16]                   ; 8-byte Reload
	mov	x19, x5
	mov	x5, x8
	mov	x20, x7
	mov	x7, x21
	mov	x25, x10
	bl	__ZN18cngcompress_layout12_GLOBAL__N_111reconstructERKNS0_4TreeEmNSt3__14spanIKhLm18446744073709551615EEENS5_IhLm18446744073709551615EEES8_
	mov	x10, x25
	mov	x7, x20
	mov	x5, x19
	mov	x2, x27
	add	x0, x0, x28
	ldrh	w9, [x26, #4]
	cmp	w9, #256
	b.eq	LBB10_73
LBB10_70:
	add	x8, x24, x22
	and	w9, w9, #0xff
	sub	x11, x5, #1
	and	x10, x5, #0x7
	cmp	x11, #7
	b.hs	LBB10_75
; %bb.71:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	b	LBB10_96
LBB10_72:
	mov	x24, x6
	ldrh	w9, [x26, #4]
	cmp	w9, #256
	b.ne	LBB10_70
LBB10_73:
	ldrh	w9, [x10, #4]
	cmp	w9, #256
	mov	x8, x24
	b.ne	LBB10_98
; %bb.74:
	sub	x9, x7, x22
	cmn	x21, #1
	csel	x9, x9, x21, eq
	add	x4, x8, x22
	mov	x21, x0
	mov	x0, x2
	ldr	x1, [sp, #24]                   ; 8-byte Reload
	mov	x2, x8
	mov	x3, x22
	mov	x7, x5
	mov	x5, x9
	mov	x6, x23
	bl	__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	mov	x0, x21
	b	LBB10_152
LBB10_75:
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	and	x13, x5, #0xfffffffffffffff8
	neg	x13, x13
	add	x14, x23, #3
	mov	x15, x2
	b	LBB10_78
LBB10_76:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	strb	w16, [x14, #3]
	ldrsb	w16, [x15], #1
	tbnz	w16, #31, LBB10_92
LBB10_77:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	strb	w16, [x14, #4]
	sub	x12, x12, #8
	add	x14, x14, #8
	cmp	x13, x12
	b.eq	LBB10_93
LBB10_78:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w16, [x15]
	tbnz	w16, #0, LBB10_85
; %bb.79:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	sturb	w16, [x14, #-3]
	ldrb	w16, [x15]
	tbz	w16, #1, LBB10_86
LBB10_80:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	sturb	w16, [x14, #-2]
	ldrb	w16, [x15]
	tbz	w16, #2, LBB10_87
LBB10_81:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	sturb	w16, [x14, #-1]
	ldrb	w16, [x15]
	tbz	w16, #3, LBB10_88
LBB10_82:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14]
	ldrb	w16, [x15]
	tbz	w16, #4, LBB10_89
LBB10_83:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #1]
	ldrb	w16, [x15]
	tbz	w16, #5, LBB10_90
LBB10_84:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #2]
	ldrb	w16, [x15]
	tbz	w16, #6, LBB10_76
	b	LBB10_91
LBB10_85:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	sturb	w16, [x14, #-3]
	ldrb	w16, [x15]
	tbnz	w16, #1, LBB10_80
LBB10_86:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	sturb	w16, [x14, #-2]
	ldrb	w16, [x15]
	tbnz	w16, #2, LBB10_81
LBB10_87:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	sturb	w16, [x14, #-1]
	ldrb	w16, [x15]
	tbnz	w16, #3, LBB10_82
LBB10_88:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	strb	w16, [x14]
	ldrb	w16, [x15]
	tbnz	w16, #4, LBB10_83
LBB10_89:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	strb	w16, [x14, #1]
	ldrb	w16, [x15]
	tbnz	w16, #5, LBB10_84
LBB10_90:                               ;   in Loop: Header=BB10_78 Depth=1
	mov	x16, x9
	strb	w16, [x14, #2]
	ldrb	w16, [x15]
	tbz	w16, #6, LBB10_76
LBB10_91:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #3]
	ldrsb	w16, [x15], #1
	tbz	w16, #31, LBB10_77
LBB10_92:                               ;   in Loop: Header=BB10_78 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #4]
	sub	x12, x12, #8
	add	x14, x14, #8
	cmp	x13, x12
	b.ne	LBB10_78
LBB10_93:
	cbz	x10, LBB10_152
; %bb.94:
	neg	x12, x12
	b	LBB10_96
LBB10_95:                               ;   in Loop: Header=BB10_96 Depth=1
	mov	x13, x9
	strb	w13, [x23, x12]
	add	x12, x12, #1
	subs	x10, x10, #1
	b.eq	LBB10_152
LBB10_96:                               ; =>This Inner Loop Header: Depth=1
	lsr	x13, x12, #3
	ldrb	w13, [x2, x13]
	and	w14, w12, #0x7
	lsr	w13, w13, w14
	tbz	w13, #0, LBB10_95
; %bb.97:                               ;   in Loop: Header=BB10_96 Depth=1
	ldrb	w13, [x8, x11]
	add	x11, x11, #1
	strb	w13, [x23, x12]
	add	x12, x12, #1
	subs	x10, x10, #1
	b.ne	LBB10_96
	b	LBB10_152
LBB10_98:
	and	w9, w9, #0xff
	sub	x11, x5, #1
	and	x10, x5, #0x7
	cmp	x11, #7
	b.hs	LBB10_100
; %bb.99:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	b	LBB10_121
LBB10_100:
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	and	x13, x5, #0xfffffffffffffff8
	neg	x13, x13
	add	x14, x23, #3
	mov	x15, x2
	b	LBB10_103
LBB10_101:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #3]
	ldrsb	w16, [x15], #1
	tbnz	w16, #31, LBB10_117
LBB10_102:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #4]
	sub	x12, x12, #8
	add	x14, x14, #8
	cmp	x13, x12
	b.eq	LBB10_118
LBB10_103:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w16, [x15]
	tbnz	w16, #0, LBB10_110
; %bb.104:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	sturb	w16, [x14, #-3]
	ldrb	w16, [x15]
	tbz	w16, #1, LBB10_111
LBB10_105:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	sturb	w16, [x14, #-2]
	ldrb	w16, [x15]
	tbz	w16, #2, LBB10_112
LBB10_106:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	sturb	w16, [x14, #-1]
	ldrb	w16, [x15]
	tbz	w16, #3, LBB10_113
LBB10_107:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	strb	w16, [x14]
	ldrb	w16, [x15]
	tbz	w16, #4, LBB10_114
LBB10_108:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	strb	w16, [x14, #1]
	ldrb	w16, [x15]
	tbz	w16, #5, LBB10_115
LBB10_109:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	strb	w16, [x14, #2]
	ldrb	w16, [x15]
	tbz	w16, #6, LBB10_101
	b	LBB10_116
LBB10_110:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	sturb	w16, [x14, #-3]
	ldrb	w16, [x15]
	tbnz	w16, #1, LBB10_105
LBB10_111:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	sturb	w16, [x14, #-2]
	ldrb	w16, [x15]
	tbnz	w16, #2, LBB10_106
LBB10_112:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	sturb	w16, [x14, #-1]
	ldrb	w16, [x15]
	tbnz	w16, #3, LBB10_107
LBB10_113:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14]
	ldrb	w16, [x15]
	tbnz	w16, #4, LBB10_108
LBB10_114:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #1]
	ldrb	w16, [x15]
	tbnz	w16, #5, LBB10_109
LBB10_115:                              ;   in Loop: Header=BB10_103 Depth=1
	ldrb	w16, [x8, x11]
	add	x11, x11, #1
	strb	w16, [x14, #2]
	ldrb	w16, [x15]
	tbz	w16, #6, LBB10_101
LBB10_116:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	strb	w16, [x14, #3]
	ldrsb	w16, [x15], #1
	tbz	w16, #31, LBB10_102
LBB10_117:                              ;   in Loop: Header=BB10_103 Depth=1
	mov	x16, x9
	strb	w16, [x14, #4]
	sub	x12, x12, #8
	add	x14, x14, #8
	cmp	x13, x12
	b.ne	LBB10_103
LBB10_118:
	cbz	x10, LBB10_152
; %bb.119:
	neg	x12, x12
	b	LBB10_121
LBB10_120:                              ;   in Loop: Header=BB10_121 Depth=1
	ldrb	w13, [x8, x11]
	add	x11, x11, #1
	strb	w13, [x23, x12]
	add	x12, x12, #1
	subs	x10, x10, #1
	b.eq	LBB10_152
LBB10_121:                              ; =>This Inner Loop Header: Depth=1
	lsr	x13, x12, #3
	ldrb	w13, [x2, x13]
	and	w14, w12, #0x7
	lsr	w13, w13, w14
	tbz	w13, #0, LBB10_120
; %bb.122:                              ;   in Loop: Header=BB10_121 Depth=1
	mov	x13, x9
	strb	w13, [x23, x12]
	add	x12, x12, #1
	subs	x10, x10, #1
	b.ne	LBB10_121
	b	LBB10_152
LBB10_123:
	mov	x11, #0                         ; =0x0
	subs	x9, x5, x11
	b.ls	LBB10_151
LBB10_124:
	add	x10, x23, x11
	add	x11, x11, x11, lsl #2
	b	LBB10_126
LBB10_125:                              ;   in Loop: Header=BB10_126 Depth=1
	lsr	w12, w12, w13
	and	x12, x12, #0x1f
	ldrb	w12, [x8, x12]
	strb	w12, [x10], #1
	add	x11, x11, #5
	subs	x9, x9, #1
	b.eq	LBB10_151
LBB10_126:                              ; =>This Inner Loop Header: Depth=1
	add	x14, x2, x11, lsr #3
	ldrb	w12, [x14]
	and	x13, x11, #0x7
	cmp	x13, #4
	b.lo	LBB10_125
; %bb.127:                              ;   in Loop: Header=BB10_126 Depth=1
	ldrb	w14, [x14, #1]
	orr	w12, w12, w14, lsl #8
	b	LBB10_125
LBB10_128:
	mov	x11, #0                         ; =0x0
	subs	x9, x5, x11
	b.ls	LBB10_151
LBB10_129:
	add	x10, x23, x11
	add	x11, x11, x11, lsl #1
	b	LBB10_131
LBB10_130:                              ;   in Loop: Header=BB10_131 Depth=1
	lsr	w12, w12, w13
	and	x12, x12, #0x7
	ldrb	w12, [x8, x12]
	strb	w12, [x10], #1
	add	x11, x11, #3
	subs	x9, x9, #1
	b.eq	LBB10_151
LBB10_131:                              ; =>This Inner Loop Header: Depth=1
	add	x14, x2, x11, lsr #3
	ldrb	w12, [x14]
	and	x13, x11, #0x7
	cmp	x13, #6
	b.lo	LBB10_130
; %bb.132:                              ;   in Loop: Header=BB10_131 Depth=1
	ldrb	w14, [x14, #1]
	orr	w12, w12, w14, lsl #8
	b	LBB10_130
LBB10_133:
	mov	x11, #0                         ; =0x0
	subs	x9, x5, x11
	b.ls	LBB10_151
LBB10_134:
	add	x10, x23, x11
	lsl	x12, x11, #3
	sub	x11, x12, x11
	b	LBB10_136
LBB10_135:                              ;   in Loop: Header=BB10_136 Depth=1
	lsr	w12, w12, w13
	and	x12, x12, #0x7f
	ldrb	w12, [x8, x12]
	strb	w12, [x10], #1
	add	x11, x11, #7
	subs	x9, x9, #1
	b.eq	LBB10_151
LBB10_136:                              ; =>This Inner Loop Header: Depth=1
	add	x14, x2, x11, lsr #3
	ldrb	w12, [x14]
	and	x13, x11, #0x7
	cmp	x13, #2
	b.lo	LBB10_135
; %bb.137:                              ;   in Loop: Header=BB10_136 Depth=1
	ldrb	w14, [x14, #1]
	orr	w12, w12, w14, lsl #8
	b	LBB10_135
LBB10_138:
	mov	x11, #0                         ; =0x0
	subs	x9, x5, x11
	b.ls	LBB10_151
LBB10_139:
	add	x10, x23, x11
	lsl	x11, x11, #1
LBB10_140:                              ; =>This Inner Loop Header: Depth=1
	lsr	x12, x11, #3
	ldrb	w12, [x2, x12]
	and	w13, w11, #0x6
	lsr	w12, w12, w13
	and	x12, x12, #0x3
	ldrb	w12, [x8, x12]
	strb	w12, [x10], #1
	add	x11, x11, #2
	subs	x9, x9, #1
	b.ne	LBB10_140
	b	LBB10_151
LBB10_141:
	mov	x11, #0                         ; =0x0
	subs	x9, x5, x11
	b.ls	LBB10_151
LBB10_142:
	add	x10, x23, x11
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #1
	b	LBB10_144
LBB10_143:                              ;   in Loop: Header=BB10_144 Depth=1
	lsr	w12, w12, w13
	and	x12, x12, #0x3f
	ldrb	w12, [x8, x12]
	strb	w12, [x10], #1
	add	x11, x11, #6
	subs	x9, x9, #1
	b.eq	LBB10_151
LBB10_144:                              ; =>This Inner Loop Header: Depth=1
	add	x14, x2, x11, lsr #3
	ldrb	w12, [x14]
	and	x13, x11, #0x6
	cmp	x13, #3
	b.lo	LBB10_143
; %bb.145:                              ;   in Loop: Header=BB10_144 Depth=1
	ldrb	w14, [x14, #1]
	orr	w12, w12, w14, lsl #8
	b	LBB10_143
LBB10_146:
	mov	x11, #0                         ; =0x0
	subs	x9, x5, x11
	b.ls	LBB10_151
LBB10_147:
	add	x10, x23, x11
	lsl	x11, x11, #2
LBB10_148:                              ; =>This Inner Loop Header: Depth=1
	lsr	x12, x11, #3
	ldrb	w12, [x2, x12]
	and	w13, w11, #0x4
	lsr	w12, w12, w13
	and	x12, x12, #0xf
	ldrb	w12, [x8, x12]
	strb	w12, [x10], #1
	add	x11, x11, #4
	subs	x9, x9, #1
	b.ne	LBB10_148
	b	LBB10_151
LBB10_149:
	mov	x9, #0                          ; =0x0
	cmp	x9, x5
	b.hs	LBB10_151
LBB10_150:                              ; =>This Inner Loop Header: Depth=1
	and	x10, x9, #0x1fffffffffffffff
	ldrb	w10, [x2, x10]
	ldrb	w10, [x8, x10]
	strb	w10, [x23, x9]
	add	x9, x9, #1
	cmp	x5, x9
	b.ne	LBB10_150
LBB10_151:
	ldr	x0, [sp, #24]                   ; 8-byte Reload
LBB10_152:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB10_153:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp117:                                ; EH_LABEL
Lloh240:
	adrp	x1, l_.str.34@PAGE
Lloh241:
	add	x1, x1, l_.str.34@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp118:                                ; EH_LABEL
	b	LBB10_156
LBB10_154:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp126:                                ; EH_LABEL
Lloh242:
	adrp	x1, l_.str.35@PAGE
Lloh243:
	add	x1, x1, l_.str.35@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp127:                                ; EH_LABEL
	b	LBB10_156
LBB10_155:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp120:                                ; EH_LABEL
Lloh244:
	adrp	x1, l_.str.36@PAGE
Lloh245:
	add	x1, x1, l_.str.36@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp121:                                ; EH_LABEL
LBB10_156:
Lloh246:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh247:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh248:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh249:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB10_157:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp123:                                ; EH_LABEL
Lloh250:
	adrp	x1, l_.str.37@PAGE
Lloh251:
	add	x1, x1, l_.str.37@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp124:                                ; EH_LABEL
	b	LBB10_156
LBB10_158:
Ltmp125:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB10_159:
Ltmp122:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB10_160:
Ltmp128:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB10_161:
Ltmp119:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpAdrp	Lloh236, Lloh238
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpAdrp	Lloh234, Lloh236
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpAdrp	Lloh232, Lloh234
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpLdrGot	Lloh248, Lloh249
	.loh AdrpLdrGot	Lloh246, Lloh247
	.loh AdrpAdd	Lloh250, Lloh251
Lfunc_end10:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table10:
Lexception10:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end10-Lcst_begin10
Lcst_begin10:
	.uleb128 Lfunc_begin10-Lfunc_begin10    ; >> Call Site 1 <<
	.uleb128 Ltmp117-Lfunc_begin10          ;   Call between Lfunc_begin10 and Ltmp117
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp117-Lfunc_begin10          ; >> Call Site 2 <<
	.uleb128 Ltmp118-Ltmp117                ;   Call between Ltmp117 and Ltmp118
	.uleb128 Ltmp119-Lfunc_begin10          ;     jumps to Ltmp119
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp118-Lfunc_begin10          ; >> Call Site 3 <<
	.uleb128 Ltmp126-Ltmp118                ;   Call between Ltmp118 and Ltmp126
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp126-Lfunc_begin10          ; >> Call Site 4 <<
	.uleb128 Ltmp127-Ltmp126                ;   Call between Ltmp126 and Ltmp127
	.uleb128 Ltmp128-Lfunc_begin10          ;     jumps to Ltmp128
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp127-Lfunc_begin10          ; >> Call Site 5 <<
	.uleb128 Ltmp120-Ltmp127                ;   Call between Ltmp127 and Ltmp120
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp120-Lfunc_begin10          ; >> Call Site 6 <<
	.uleb128 Ltmp121-Ltmp120                ;   Call between Ltmp120 and Ltmp121
	.uleb128 Ltmp122-Lfunc_begin10          ;     jumps to Ltmp122
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp121-Lfunc_begin10          ; >> Call Site 7 <<
	.uleb128 Ltmp123-Ltmp121                ;   Call between Ltmp121 and Ltmp123
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp123-Lfunc_begin10          ; >> Call Site 8 <<
	.uleb128 Ltmp124-Ltmp123                ;   Call between Ltmp123 and Ltmp124
	.uleb128 Ltmp125-Lfunc_begin10          ;     jumps to Ltmp125
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp124-Lfunc_begin10          ; >> Call Site 9 <<
	.uleb128 Lfunc_end10-Ltmp124            ;   Call between Ltmp124 and Lfunc_end10
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end10:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE ; -- Begin function _ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.weak_def_can_be_hidden	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.p2align	2
__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE: ; @_ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
Lfunc_begin11:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception11
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #4, lsl #12             ; =16384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	sub	x8, x1, #257
	cmn	x8, #255
	b.lo	LBB11_39
; %bb.1:
	mov	x22, x2
	sub	w8, w2, #13
	cmn	w8, #12
	b.lo	LBB11_39
; %bb.2:
	mov	x20, x1
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w22
	cmp	x1, x8
	b.hi	LBB11_39
; %bb.3:
	mov	x19, x3
	mov	x21, x0
	add	x23, sp, #3, lsl #12            ; =12288
	add	x0, sp, #3, lsl #12             ; =12288
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	mov	x24, sp
	mov	x0, sp
	mov	w1, #12288                      ; =0x3000
	bl	_bzero
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	cmp	x20, #5
	b.hs	LBB11_5
; %bb.4:
	mov	x8, #0                          ; =0x0
	b	LBB11_12
LBB11_5:
	cmp	x20, #17
	b.hs	LBB11_7
; %bb.6:
	mov	x8, #0                          ; =0x0
	b	LBB11_10
LBB11_7:
	ands	x8, x20, #0xf
	mov	w9, #16                         ; =0x10
	csel	x9, x9, x8, eq
	sub	x8, x20, x9
	add	x10, x21, #68
	mov	x11, sp
	add	x11, x11, #16
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #32
	mov	x13, x20
LBB11_8:                                ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x10, #-52]
	ldur	q1, [x10, #-68]
	sub	x14, x10, #12
	sub	x15, x10, #20
	ldur	q2, [x10, #-36]
	mov.s	v2[1], v2[2]
	uzp1.4s	v0, v1, v0
	ldur	q1, [x10, #12]
	ldur	q3, [x10, #-4]
	add	x16, x10, #52
	ld1.s	{ v2 }[2], [x15]
	add	x15, x10, #44
	ldur	q4, [x10, #28]
	mov.s	v4[1], v4[2]
	ld1.s	{ v2 }[3], [x14]
	ld1.s	{ v4 }[2], [x15]
	uzp1.4s	v1, v3, v1
	ldursh	w14, [x10, #-8]
	ld1.s	{ v4 }[3], [x16]
	ldur	w15, [x10, #-16]
	ldp	q5, q3, [x10, #-48]
	ldur	q6, [x10, #-64]
	stp	q0, q2, [x12, #-32]
	mov.h	v6[1], v6[4]
	mov.h	v6[2], v5[0]
	stp	q1, q4, [x12], #64
	mov.h	v6[3], v5[4]
	ldrsh	w16, [x10, #56]
	ldp	q1, q0, [x10, #16]
	mov.h	v6[4], v3[0]
	ldr	q2, [x10]
	mov.h	v2[1], v2[4]
	mov.h	v6[5], v3[4]
	mov.h	v2[2], v1[0]
	mov.h	v2[3], v1[4]
	mov.h	v6[6], w15
	mov.h	v2[4], v0[0]
	mov.h	v2[5], v0[4]
	mov.h	v6[7], w14
	ldr	w14, [x10, #48]
	mov.h	v2[6], w14
	mov.h	v2[7], w16
	stp	q6, q2, [x11, #-16]
	add	x10, x10, #128
	sub	x13, x13, #16
	add	x11, x11, #32
	cmp	x9, x13
	b.ne	LBB11_8
; %bb.9:
	cmp	x9, #4
	b.ls	LBB11_12
LBB11_10:
	mov	x11, x8
	ands	x8, x20, #0x3
	mov	w9, #4                          ; =0x4
	csel	x12, x9, x8, eq
	mov	x8, sp
	add	x9, x8, x11, lsl #1
	add	x8, sp, #3, lsl #12             ; =12288
	add	x10, x8, x11, lsl #2
	add	x13, x21, x11, lsl #3
	sub	x8, x20, x12
	add	x11, x12, x11
	sub	x11, x11, x20
	add	x12, x13, #4
LBB11_11:                               ; =>This Inner Loop Header: Depth=1
	add	x13, x12, #12
	ldur	q0, [x12, #-4]
	mov.s	v0[1], v0[2]
	ld1.s	{ v0 }[2], [x13]
	add	x13, x12, #20
	ld1.s	{ v0 }[3], [x13]
	str	q0, [x10], #16
	ldrsh	w13, [x12, #24]
	ldr	w14, [x12, #16]
	ldr	q0, [x12], #32
	mov.h	v0[1], v0[4]
	mov.h	v0[2], w14
	mov.h	v0[3], w13
	str	d0, [x9], #8
	adds	x11, x11, #4
	b.ne	LBB11_11
LBB11_12:
	add	x9, x21, x8, lsl #3
	add	x9, x9, #4
LBB11_13:                               ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-4]
	str	w10, [x23, x8, lsl #2]
	ldrh	w10, [x9], #8
	strh	w10, [x24, x8, lsl #1]
	add	x8, x8, #1
	cmp	x20, x8
	b.ne	LBB11_13
; %bb.14:
	mov	w8, w22
	cmp	w22, #2
	b.lo	LBB11_27
; %bb.15:
	mov	x9, sp
	add	x9, x9, #1024
	mov	w10, #1                         ; =0x1
	add	x11, sp, #3, lsl #12            ; =12288
	mov	x12, x20
	b	LBB11_17
LBB11_16:                               ;   in Loop: Header=BB11_17 Depth=1
	add	x10, x10, #1
	add	x9, x9, #1024
	cmp	x10, x8
	b.eq	LBB11_29
LBB11_17:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB11_20 Depth 2
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mvn	w16, w10
	and	x15, x10, #0x1
	add	x15, x11, x15, lsl #11
	and	x16, x16, #0x1
	add	x16, x11, x16, lsl #11
	lsr	x17, x12, #1
	cmp	x17, #0
	cset	w1, ne
	mov	w0, #1                          ; =0x1
	mov	x12, #0                         ; =0x0
	b	LBB11_20
LBB11_18:                               ;   in Loop: Header=BB11_20 Depth=2
	str	w1, [x15, x12, lsl #2]
	lsl	w0, w13, #1
	add	w0, w0, #256
	strh	w0, [x9, x12, lsl #1]
	add	x13, x13, #1
LBB11_19:                               ;   in Loop: Header=BB11_20 Depth=2
	add	x12, x12, #1
	cmp	x14, x20
	cset	w0, lo
	cmp	x13, x17
	cset	w1, lo
	csinc	w2, w0, wzr, hs
	tbz	w2, #0, LBB11_16
LBB11_20:                               ;   Parent Loop BB11_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	tbz	w1, #0, LBB11_23
; %bb.21:                               ;   in Loop: Header=BB11_20 Depth=2
	add	x1, x16, x13, lsl #3
	ldp	w2, w1, [x1]
	add	w1, w1, w2
	tbz	w0, #0, LBB11_24
; %bb.22:                               ;   in Loop: Header=BB11_20 Depth=2
	lsl	x0, x14, #3
	ldr	w0, [x21, x0]
	cmp	w0, w1
	b.hi	LBB11_18
	b	LBB11_26
LBB11_23:                               ;   in Loop: Header=BB11_20 Depth=2
	mov	w1, #0                          ; =0x0
LBB11_24:                               ;   in Loop: Header=BB11_20 Depth=2
	cmp	x13, x17
	b.ne	LBB11_18
; %bb.25:                               ;   in Loop: Header=BB11_20 Depth=2
	lsl	x0, x14, #3
	ldr	w0, [x21, x0]
LBB11_26:                               ;   in Loop: Header=BB11_20 Depth=2
	add	x1, x21, x14, lsl #3
	str	w0, [x15, x12, lsl #2]
	ldrh	w0, [x1, #4]
	strh	w0, [x9, x12, lsl #1]
	add	x14, x14, #1
	b	LBB11_19
LBB11_27:
	lsl	x9, x20, #1
	sub	x9, x9, #2
	cmp	x9, x20
	b.ls	LBB11_30
LBB11_28:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp129:                                ; EH_LABEL
Lloh252:
	adrp	x1, l_.str.17@PAGE
Lloh253:
	add	x1, x1, l_.str.17@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp130:                                ; EH_LABEL
	b	LBB11_40
LBB11_29:
	lsl	x9, x20, #1
	sub	x9, x9, #2
	cmp	x9, x12
	b.hi	LBB11_28
LBB11_30:
	mov	x10, sp
	add	x10, x10, x8, lsl #10
	sub	x10, x10, #1024
	b	LBB11_33
LBB11_31:                               ;   in Loop: Header=BB11_33 Depth=1
	lsl	x9, x11, #1
LBB11_32:                               ;   in Loop: Header=BB11_33 Depth=1
	sub	x10, x10, #1024
	sub	x8, x8, #1
	cbz	w8, LBB11_38
LBB11_33:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB11_36 Depth 2
	cbz	x9, LBB11_32
; %bb.34:                               ;   in Loop: Header=BB11_33 Depth=1
	mov	x11, #0                         ; =0x0
	mov	x12, x10
	b	LBB11_36
LBB11_35:                               ;   in Loop: Header=BB11_36 Depth=2
	add	x11, x11, #1
	subs	x9, x9, #1
	b.eq	LBB11_31
LBB11_36:                               ;   Parent Loop BB11_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w13, [x12], #2
	cmp	x13, #255
	b.hi	LBB11_35
; %bb.37:                               ;   in Loop: Header=BB11_36 Depth=2
	ldrb	w14, [x19, x13]
	add	w14, w14, #1
	strb	w14, [x19, x13]
	subs	x9, x9, #1
	b.ne	LBB11_36
	b	LBB11_31
LBB11_38:
	add	sp, sp, #4, lsl #12             ; =16384
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB11_39:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp132:                                ; EH_LABEL
Lloh254:
	adrp	x1, l_.str.16@PAGE
Lloh255:
	add	x1, x1, l_.str.16@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp133:                                ; EH_LABEL
LBB11_40:
Lloh256:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh257:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh258:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh259:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB11_41:
Ltmp131:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB11_42:
Ltmp134:                                ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpLdrGot	Lloh258, Lloh259
	.loh AdrpLdrGot	Lloh256, Lloh257
Lfunc_end11:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table11:
Lexception11:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end11-Lcst_begin11
Lcst_begin11:
	.uleb128 Lfunc_begin11-Lfunc_begin11    ; >> Call Site 1 <<
	.uleb128 Ltmp129-Lfunc_begin11          ;   Call between Lfunc_begin11 and Ltmp129
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp129-Lfunc_begin11          ; >> Call Site 2 <<
	.uleb128 Ltmp130-Ltmp129                ;   Call between Ltmp129 and Ltmp130
	.uleb128 Ltmp131-Lfunc_begin11          ;     jumps to Ltmp131
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp130-Lfunc_begin11          ; >> Call Site 3 <<
	.uleb128 Ltmp132-Ltmp130                ;   Call between Ltmp130 and Ltmp132
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp132-Lfunc_begin11          ; >> Call Site 4 <<
	.uleb128 Ltmp133-Ltmp132                ;   Call between Ltmp132 and Ltmp133
	.uleb128 Ltmp134-Lfunc_begin11          ;     jumps to Ltmp134
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp133-Lfunc_begin11          ; >> Call Site 5 <<
	.uleb128 Lfunc_end11-Ltmp133            ;   Call between Ltmp133 and Lfunc_end11
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end11:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	6                               ; -- Begin function _ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb: ; @_ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x3
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
LBB12_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_2 Depth 2
                                        ;       Child Loop BB12_77 Depth 3
                                        ;       Child Loop BB12_75 Depth 3
                                        ;       Child Loop BB12_81 Depth 3
                                        ;       Child Loop BB12_85 Depth 3
                                        ;         Child Loop BB12_83 Depth 4
                                        ;         Child Loop BB12_84 Depth 4
                                        ;       Child Loop BB12_55 Depth 3
                                        ;       Child Loop BB12_60 Depth 3
                                        ;       Child Loop BB12_58 Depth 3
                                        ;       Child Loop BB12_63 Depth 3
                                        ;         Child Loop BB12_64 Depth 4
                                        ;         Child Loop BB12_65 Depth 4
	sub	x22, x20, #8
	sub	x26, x20, #16
	sub	x27, x20, #24
	mov	x24, x19
LBB12_2:                                ;   Parent Loop BB12_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB12_77 Depth 3
                                        ;       Child Loop BB12_75 Depth 3
                                        ;       Child Loop BB12_81 Depth 3
                                        ;       Child Loop BB12_85 Depth 3
                                        ;         Child Loop BB12_83 Depth 4
                                        ;         Child Loop BB12_84 Depth 4
                                        ;       Child Loop BB12_55 Depth 3
                                        ;       Child Loop BB12_60 Depth 3
                                        ;       Child Loop BB12_58 Depth 3
                                        ;       Child Loop BB12_63 Depth 3
                                        ;         Child Loop BB12_64 Depth 4
                                        ;         Child Loop BB12_65 Depth 4
	mov	x19, x24
	sub	x8, x20, x24
	asr	x9, x8, #3
	subs	x8, x9, #2
	b.gt	LBB12_5
; %bb.3:                                ;   in Loop: Header=BB12_2 Depth=2
	b.lo	LBB12_154
; %bb.4:                                ;   in Loop: Header=BB12_2 Depth=2
	cmp	x9, #2
	b.ne	LBB12_8
	b	LBB12_95
LBB12_5:                                ;   in Loop: Header=BB12_2 Depth=2
	cmp	x9, #3
	b.eq	LBB12_97
; %bb.6:                                ;   in Loop: Header=BB12_2 Depth=2
	cmp	x9, #4
	b.eq	LBB12_100
; %bb.7:                                ;   in Loop: Header=BB12_2 Depth=2
	cmp	x9, #5
	b.eq	LBB12_90
LBB12_8:                                ;   in Loop: Header=BB12_2 Depth=2
	cmp	x9, #23
	b.le	LBB12_101
; %bb.9:                                ;   in Loop: Header=BB12_2 Depth=2
	cbz	x21, LBB12_111
; %bb.10:                               ;   in Loop: Header=BB12_2 Depth=2
	lsr	x8, x9, #1
	add	x8, x19, x8, lsl #3
	ldur	w10, [x20, #-8]
	ldurh	w11, [x20, #-4]
	cmp	x9, #129
	b.lo	LBB12_14
; %bb.11:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w9, [x8]
	ldrh	w12, [x8, #4]
	ldr	w13, [x19]
	ldrh	w14, [x19, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w9, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	cmp	w11, w12
	cset	w11, lo
	cmp	w10, w9
	cset	w9, lo
	csel	w11, w11, w9, eq
	tbz	w13, #0, LBB12_17
; %bb.12:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x19]
	lsr	x10, x9, #32
	cbz	w11, LBB12_23
; %bb.13:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w11, [x22]
	ldrh	w12, [x22, #4]
	strh	w12, [x19, #4]
	str	w11, [x19]
	strh	w10, [x22, #4]
	str	w9, [x22]
	b	LBB12_25
LBB12_14:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w9, [x19]
	ldrh	w12, [x19, #4]
	ldr	w13, [x8]
	ldrh	w14, [x8, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w9, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	cmp	w11, w12
	cset	w11, lo
	cmp	w10, w9
	cset	w9, lo
	csel	w11, w11, w9, eq
	tbz	w13, #0, LBB12_20
; %bb.15:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x8]
	lsr	x10, x9, #32
	cbz	w11, LBB12_31
; %bb.16:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w11, [x22]
	ldrh	w12, [x22, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	strh	w10, [x22, #4]
	str	w9, [x22]
	sub	x21, x21, #1
	tbz	w23, #0, LBB12_53
	b	LBB12_54
LBB12_17:                               ;   in Loop: Header=BB12_2 Depth=2
	cbz	w11, LBB12_25
; %bb.18:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x8]
	ldr	w10, [x22]
	ldrh	w11, [x22, #4]
	strh	w11, [x8, #4]
	str	w10, [x8]
	str	w9, [x22]
	lsr	x9, x9, #32
	strh	w9, [x22, #4]
	ldr	w9, [x8]
	ldrh	w10, [x8, #4]
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB12_25
; %bb.19:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x19]
	ldr	w10, [x8]
	ldrh	w11, [x8, #4]
	strh	w11, [x19, #4]
	str	w10, [x19]
	str	w9, [x8]
	lsr	x9, x9, #32
	strh	w9, [x8, #4]
	b	LBB12_25
LBB12_20:                               ;   in Loop: Header=BB12_2 Depth=2
	cbz	w11, LBB12_33
; %bb.21:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x19]
	ldr	w10, [x22]
	ldrh	w11, [x22, #4]
	strh	w11, [x19, #4]
	str	w10, [x19]
	str	w9, [x22]
	lsr	x9, x9, #32
	strh	w9, [x22, #4]
	ldr	w9, [x19]
	ldrh	w10, [x19, #4]
	ldr	w11, [x8]
	ldrh	w12, [x8, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB12_33
; %bb.22:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x8]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	strh	w11, [x8, #4]
	str	w10, [x8]
	str	w9, [x19]
	lsr	x8, x9, #32
	strh	w8, [x19, #4]
	sub	x21, x21, #1
	tbz	w23, #0, LBB12_53
	b	LBB12_54
LBB12_23:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w11, [x8]
	ldrh	w12, [x8, #4]
	strh	w12, [x19, #4]
	str	w11, [x19]
	strh	w10, [x8, #4]
	str	w9, [x8]
	ldur	w11, [x20, #-8]
	ldurh	w12, [x20, #-4]
	cmp	w12, w10, uxth
	cset	w10, lo
	cmp	w11, w9
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB12_25
; %bb.24:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x8]
	ldr	w10, [x22]
	ldrh	w11, [x22, #4]
	strh	w11, [x8, #4]
	str	w10, [x8]
	str	w9, [x22]
	lsr	x9, x9, #32
	strh	w9, [x22, #4]
LBB12_25:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x10, x19
	ldr	w11, [x10, #8]!
	mov	x9, x8
	ldr	w12, [x9, #-8]!
	ldrh	w13, [x9, #4]
	ldrh	w14, [x10, #4]
	cmp	w13, w14
	cset	w14, lo
	cmp	w12, w11
	cset	w11, lo
	csel	w11, w14, w11, eq
	ldur	w14, [x20, #-16]
	ldurh	w15, [x20, #-12]
	cmp	w15, w13
	cset	w13, lo
	cmp	w14, w12
	cset	w12, lo
	csel	w13, w13, w12, eq
	tbz	w11, #0, LBB12_28
; %bb.26:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x11, [x10]
	lsr	x12, x11, #32
	cbz	w13, LBB12_34
; %bb.27:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w13, [x26]
	ldrh	w14, [x26, #4]
	strh	w14, [x10, #4]
	str	w13, [x10]
	strh	w12, [x26, #4]
	str	w11, [x26]
	b	LBB12_36
LBB12_28:                               ;   in Loop: Header=BB12_2 Depth=2
	cbz	w13, LBB12_36
; %bb.29:                               ;   in Loop: Header=BB12_2 Depth=2
	ldur	x11, [x8, #-8]
	ldr	w12, [x26]
	ldrh	w13, [x26, #4]
	strh	w13, [x9, #4]
	str	w12, [x9]
	str	w11, [x26]
	lsr	x11, x11, #32
	strh	w11, [x26, #4]
	ldur	w11, [x8, #-8]
	ldurh	w12, [x8, #-4]
	ldr	w13, [x19, #8]
	ldrh	w14, [x19, #12]
	cmp	w12, w14
	cset	w12, lo
	cmp	w11, w13
	cset	w11, lo
	csel	w11, w12, w11, eq
	cbz	w11, LBB12_36
; %bb.30:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x11, [x10]
	ldr	w12, [x9]
	ldrh	w13, [x9, #4]
	strh	w13, [x10, #4]
	str	w12, [x10]
	str	w11, [x9]
	lsr	x10, x11, #32
	strh	w10, [x9, #4]
	b	LBB12_36
LBB12_31:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	strh	w10, [x19, #4]
	str	w9, [x19]
	ldur	w8, [x20, #-8]
	ldurh	w11, [x20, #-4]
	cmp	w11, w10, uxth
	cset	w10, lo
	cmp	w8, w9
	cset	w8, lo
	csel	w8, w10, w8, eq
	cbz	w8, LBB12_33
; %bb.32:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x8, [x19]
	ldr	w9, [x22]
	ldrh	w10, [x22, #4]
	strh	w10, [x19, #4]
	str	w9, [x19]
	str	w8, [x22]
	lsr	x8, x8, #32
	strh	w8, [x22, #4]
LBB12_33:                               ;   in Loop: Header=BB12_2 Depth=2
	sub	x21, x21, #1
	tbz	w23, #0, LBB12_53
	b	LBB12_54
LBB12_34:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w13, [x9]
	ldrh	w14, [x9, #4]
	strh	w14, [x10, #4]
	str	w13, [x10]
	strh	w12, [x9, #4]
	str	w11, [x9]
	ldur	w10, [x20, #-16]
	ldurh	w13, [x20, #-12]
	cmp	w13, w12, uxth
	cset	w12, lo
	cmp	w10, w11
	cset	w10, lo
	csel	w10, w12, w10, eq
	cbz	w10, LBB12_36
; %bb.35:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x10, [x9]
	ldr	w11, [x26]
	ldrh	w12, [x26, #4]
	strh	w12, [x9, #4]
	str	w11, [x9]
	str	w10, [x26]
	lsr	x10, x10, #32
	strh	w10, [x26, #4]
LBB12_36:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x11, x19
	ldr	w12, [x11, #16]!
	mov	x10, x8
	ldr	w13, [x10, #8]!
	ldrh	w14, [x10, #4]
	ldrh	w15, [x11, #4]
	cmp	w14, w15
	cset	w15, lo
	cmp	w13, w12
	cset	w12, lo
	csel	w12, w15, w12, eq
	ldur	w15, [x20, #-24]
	ldurh	w16, [x20, #-20]
	cmp	w16, w14
	cset	w14, lo
	cmp	w15, w13
	cset	w13, lo
	csel	w14, w14, w13, eq
	tbz	w12, #0, LBB12_39
; %bb.37:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x12, [x11]
	lsr	x13, x12, #32
	cbz	w14, LBB12_42
; %bb.38:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w14, [x27]
	ldrh	w15, [x27, #4]
	strh	w15, [x11, #4]
	str	w14, [x11]
	strh	w13, [x27, #4]
	str	w12, [x27]
	b	LBB12_44
LBB12_39:                               ;   in Loop: Header=BB12_2 Depth=2
	cbz	w14, LBB12_44
; %bb.40:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x12, [x8, #8]
	ldr	w13, [x27]
	ldrh	w14, [x27, #4]
	strh	w14, [x10, #4]
	str	w13, [x10]
	str	w12, [x27]
	lsr	x12, x12, #32
	strh	w12, [x27, #4]
	ldr	w12, [x8, #8]
	ldrh	w13, [x8, #12]
	ldr	w14, [x19, #16]
	ldrh	w15, [x19, #20]
	cmp	w13, w15
	cset	w13, lo
	cmp	w12, w14
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB12_44
; %bb.41:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x12, [x11]
	ldr	w13, [x10]
	ldrh	w14, [x10, #4]
	strh	w14, [x11, #4]
	str	w13, [x11]
	str	w12, [x10]
	lsr	x11, x12, #32
	strh	w11, [x10, #4]
	b	LBB12_44
LBB12_42:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w14, [x10]
	ldrh	w15, [x10, #4]
	strh	w15, [x11, #4]
	str	w14, [x11]
	strh	w13, [x10, #4]
	str	w12, [x10]
	ldur	w11, [x20, #-24]
	ldurh	w14, [x20, #-20]
	cmp	w14, w13, uxth
	cset	w13, lo
	cmp	w11, w12
	cset	w11, lo
	csel	w11, w13, w11, eq
	cbz	w11, LBB12_44
; %bb.43:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x11, [x10]
	ldr	w12, [x27]
	ldrh	w13, [x27, #4]
	strh	w13, [x10, #4]
	str	w12, [x10]
	str	w11, [x27]
	lsr	x11, x11, #32
	strh	w11, [x27, #4]
LBB12_44:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w15, [x8]
	ldrh	w16, [x8, #4]
	ldur	w11, [x8, #-8]
	ldurh	w12, [x8, #-4]
	cmp	w16, w12
	cset	w13, lo
	cmp	w15, w11
	cset	w14, lo
	csel	w17, w13, w14, eq
	ldr	w13, [x8, #8]
	ldrh	w14, [x8, #12]
	cmp	w14, w16
	cset	w16, lo
	cmp	w13, w15
	cset	w15, lo
	csel	w15, w16, w15, eq
	tbz	w17, #0, LBB12_47
; %bb.45:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x11, [x9]
	lsr	x12, x11, #32
	cbz	w15, LBB12_50
; %bb.46:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w13, [x10]
	str	w13, [x9]
	ldrh	w13, [x10, #4]
	strh	w13, [x9, #4]
	str	w11, [x10]
	strh	w12, [x10, #4]
	b	LBB12_52
LBB12_47:                               ;   in Loop: Header=BB12_2 Depth=2
	cbz	w15, LBB12_52
; %bb.48:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x13, [x8]
	ldr	w14, [x10]
	str	w14, [x8]
	ldrh	w10, [x10, #4]
	strh	w10, [x8, #4]
	str	w13, [x8, #8]
	lsr	x13, x13, #32
	strh	w13, [x8, #12]
	cmp	w10, w12
	cset	w10, lo
	cmp	w14, w11
	cset	w11, lo
	csel	w10, w10, w11, eq
	cbz	w10, LBB12_52
; %bb.49:                               ;   in Loop: Header=BB12_2 Depth=2
	ldur	x10, [x8, #-8]
	ldr	w11, [x8]
	str	w11, [x9]
	ldrh	w11, [x8, #4]
	strh	w11, [x9, #4]
	str	w10, [x8]
	lsr	x9, x10, #32
	strh	w9, [x8, #4]
	b	LBB12_52
LBB12_50:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w15, [x8]
	str	w15, [x9]
	ldrh	w15, [x8, #4]
	strh	w15, [x9, #4]
	str	w11, [x8]
	strh	w12, [x8, #4]
	cmp	w14, w12, uxth
	cset	w9, lo
	cmp	w13, w11
	cset	w11, lo
	csel	w9, w9, w11, eq
	cbz	w9, LBB12_52
; %bb.51:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x8]
	ldr	w11, [x10]
	str	w11, [x8]
	ldrh	w10, [x10, #4]
	strh	w10, [x8, #4]
	str	w9, [x8, #8]
	lsr	x9, x9, #32
	strh	w9, [x8, #12]
LBB12_52:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	x9, [x19]
	ldr	w10, [x8]
	ldrh	w11, [x8, #4]
	strh	w11, [x19, #4]
	str	w10, [x19]
	str	w9, [x8]
	lsr	x9, x9, #32
	strh	w9, [x8, #4]
	sub	x21, x21, #1
	tbnz	w23, #0, LBB12_54
LBB12_53:                               ;   in Loop: Header=BB12_2 Depth=2
	ldur	w8, [x19, #-8]
	ldurh	w9, [x19, #-4]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	tbz	w8, #0, LBB12_73
LBB12_54:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	w8, [x19]
	ldrh	w9, [x19, #4]
LBB12_55:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x19, x12
	ldr	w11, [x10, #8]
	ldrh	w10, [x10, #12]
	cmp	w10, w9
	cset	w10, lo
	cmp	w11, w8
	cset	w11, lo
	csel	w10, w10, w11, eq
	add	x12, x12, #8
	tbnz	w10, #0, LBB12_55
; %bb.56:                               ;   in Loop: Header=BB12_2 Depth=2
	add	x10, x19, x12
	mov	x11, x20
	cmp	x12, #8
	b.ne	LBB12_60
; %bb.57:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x11, x20
LBB12_58:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x10, x11
	b.hs	LBB12_61
; %bb.59:                               ;   in Loop: Header=BB12_58 Depth=3
	ldr	w12, [x11, #-8]!
	ldrh	w13, [x11, #4]
	cmp	w13, w9
	cset	w13, lo
	cmp	w12, w8
	cset	w12, lo
	csel	w12, w13, w12, eq
	tbz	w12, #0, LBB12_58
	b	LBB12_61
LBB12_60:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w12, [x11, #-8]!
	ldrh	w13, [x11, #4]
	cmp	w13, w9
	cset	w13, lo
	cmp	w12, w8
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB12_60
LBB12_61:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x24, x10
	cmp	x10, x11
	b.hs	LBB12_67
; %bb.62:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x12, x11
LBB12_63:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB12_64 Depth 4
                                        ;         Child Loop BB12_65 Depth 4
	ldr	x13, [x24]
	ldr	w14, [x12]
	ldrh	w15, [x12, #4]
	strh	w15, [x24, #4]
	str	w14, [x24]
	str	w13, [x12]
	lsr	x13, x13, #32
	strh	w13, [x12, #4]
LBB12_64:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ;       Parent Loop BB12_63 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x24, #8]!
	ldrh	w14, [x24, #4]
	cmp	w14, w9
	cset	w14, lo
	cmp	w13, w8
	cset	w13, lo
	csel	w13, w14, w13, eq
	tbnz	w13, #0, LBB12_64
LBB12_65:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ;       Parent Loop BB12_63 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x12, #-8]!
	ldrh	w14, [x12, #4]
	cmp	w14, w9
	cset	w14, lo
	cmp	w13, w8
	cset	w13, lo
	csel	w13, w14, w13, eq
	cbz	w13, LBB12_65
; %bb.66:                               ;   in Loop: Header=BB12_63 Depth=3
	cmp	x24, x12
	b.lo	LBB12_63
LBB12_67:                               ;   in Loop: Header=BB12_2 Depth=2
	sub	x28, x24, #8
	cmp	x19, x28
	b.eq	LBB12_69
; %bb.68:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w12, [x28]
	ldrh	w13, [x28, #4]
	strh	w13, [x19, #4]
	str	w12, [x19]
LBB12_69:                               ;   in Loop: Header=BB12_2 Depth=2
	stur	w8, [x24, #-8]
	sturh	w9, [x24, #-4]
	cmp	x10, x11
	b.lo	LBB12_72
; %bb.70:                               ;   in Loop: Header=BB12_2 Depth=2
	sub	x1, x24, #8
	mov	x0, x19
	bl	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	mov	x25, x0
	mov	x0, x24
	mov	x1, x20
	bl	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	cbnz	w0, LBB12_89
; %bb.71:                               ;   in Loop: Header=BB12_2 Depth=2
	tbnz	w25, #0, LBB12_2
LBB12_72:                               ;   in Loop: Header=BB12_2 Depth=2
	sub	x1, x24, #8
	and	w3, w23, #0x1
	mov	x0, x19
	mov	x2, x21
	bl	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	mov	w23, #0                         ; =0x0
	b	LBB12_2
LBB12_73:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w8, [x19]
	ldrh	w9, [x19, #4]
	ldur	w10, [x20, #-8]
	ldurh	w11, [x20, #-4]
	cmp	w11, w9
	cset	w11, hi
	cmp	w10, w8
	cset	w10, hi
	csel	w10, w11, w10, eq
	tbz	w10, #0, LBB12_76
; %bb.74:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x24, x19
LBB12_75:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x24, #8]!
	ldrh	w11, [x24, #4]
	cmp	w11, w9
	cset	w11, hi
	cmp	w10, w8
	cset	w10, hi
	csel	w10, w11, w10, eq
	tbz	w10, #0, LBB12_75
	b	LBB12_79
LBB12_76:                               ;   in Loop: Header=BB12_2 Depth=2
	add	x10, x19, #8
LBB12_77:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov	x24, x10
	cmp	x10, x20
	b.hs	LBB12_79
; %bb.78:                               ;   in Loop: Header=BB12_77 Depth=3
	ldr	w10, [x24]
	ldrh	w11, [x24, #4]
	cmp	w11, w9
	cset	w11, hi
	cmp	w10, w8
	cset	w10, hi
	csel	w11, w11, w10, eq
	add	x10, x24, #8
	cbz	w11, LBB12_77
LBB12_79:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x10, x20
	cmp	x24, x20
	b.hs	LBB12_85
; %bb.80:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	x10, x20
LBB12_81:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w11, [x10, #-8]!
	ldrh	w12, [x10, #4]
	cmp	w12, w9
	cset	w12, hi
	cmp	w11, w8
	cset	w11, hi
	csel	w11, w12, w11, eq
	tbnz	w11, #0, LBB12_81
	b	LBB12_85
LBB12_82:                               ;   in Loop: Header=BB12_85 Depth=3
	ldr	x11, [x24]
	ldr	w12, [x10]
	ldrh	w13, [x10, #4]
	strh	w13, [x24, #4]
	str	w12, [x24]
	str	w11, [x10]
	lsr	x11, x11, #32
	strh	w11, [x10, #4]
LBB12_83:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ;       Parent Loop BB12_85 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x24, #8]!
	ldrh	w12, [x24, #4]
	cmp	w12, w9
	cset	w12, hi
	cmp	w11, w8
	cset	w11, hi
	csel	w11, w12, w11, eq
	cbz	w11, LBB12_83
LBB12_84:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ;       Parent Loop BB12_85 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x10, #-8]!
	ldrh	w12, [x10, #4]
	cmp	w12, w9
	cset	w12, hi
	cmp	w11, w8
	cset	w11, hi
	csel	w11, w12, w11, eq
	tbnz	w11, #0, LBB12_84
LBB12_85:                               ;   Parent Loop BB12_1 Depth=1
                                        ;     Parent Loop BB12_2 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB12_83 Depth 4
                                        ;         Child Loop BB12_84 Depth 4
	cmp	x24, x10
	b.lo	LBB12_82
; %bb.86:                               ;   in Loop: Header=BB12_2 Depth=2
	sub	x10, x24, #8
	cmp	x19, x10
	b.eq	LBB12_88
; %bb.87:                               ;   in Loop: Header=BB12_2 Depth=2
	ldr	w11, [x10]
	ldrh	w10, [x10, #4]
	strh	w10, [x19, #4]
	str	w11, [x19]
LBB12_88:                               ;   in Loop: Header=BB12_2 Depth=2
	mov	w23, #0                         ; =0x0
	stur	w8, [x24, #-8]
	sturh	w9, [x24, #-4]
	b	LBB12_2
LBB12_89:                               ;   in Loop: Header=BB12_1 Depth=1
	mov	x20, x28
	tbz	w25, #0, LBB12_1
	b	LBB12_154
LBB12_90:
	add	x1, x19, #8
	add	x2, x19, #16
	add	x3, x19, #24
	mov	x0, x19
	bl	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	ldr	w8, [x20, #-8]!
	ldrh	w9, [x20, #4]
	ldr	w10, [x19, #24]
	ldrh	w11, [x19, #28]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB12_154
; %bb.91:
	ldr	x8, [x19, #24]
	ldr	w9, [x20]
	ldrh	w10, [x20, #4]
	sturh	w10, [x19, #28]
	stur	w9, [x19, #24]
	str	w8, [x20]
	lsr	x8, x8, #32
	strh	w8, [x20, #4]
	ldr	w8, [x19, #24]
	ldrh	w9, [x19, #28]
	ldr	w10, [x19, #16]
	ldrh	w11, [x19, #20]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB12_154
; %bb.92:
	ldr	x8, [x19, #16]
	ldurh	w9, [x19, #28]
	sturh	w9, [x19, #20]
	ldur	w9, [x19, #24]
	stur	w9, [x19, #16]
	str	w8, [x19, #24]
	lsr	x8, x8, #32
	strh	w8, [x19, #28]
	ldr	w8, [x19, #16]
	ldrh	w9, [x19, #20]
	ldr	w10, [x19, #8]
	ldrh	w11, [x19, #12]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB12_154
; %bb.93:
	ldr	x8, [x19, #8]
	ldurh	w9, [x19, #20]
	sturh	w9, [x19, #12]
	ldur	w9, [x19, #16]
	stur	w9, [x19, #8]
	str	w8, [x19, #16]
	lsr	x8, x8, #32
	strh	w8, [x19, #20]
	ldr	w8, [x19, #8]
	ldrh	w9, [x19, #12]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB12_154
; %bb.94:
	ldr	x8, [x19]
	ldur	w9, [x19, #8]
	str	w9, [x19]
	ldurh	w9, [x19, #12]
	strh	w9, [x19, #4]
	str	w8, [x19, #8]
	lsr	x8, x8, #32
	b	LBB12_145
LBB12_95:
	ldr	w8, [x20, #-8]!
	ldrh	w9, [x20, #4]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB12_154
; %bb.96:
	ldr	x8, [x19]
	ldr	w9, [x20]
	ldrh	w10, [x20, #4]
	strh	w10, [x19, #4]
	str	w9, [x19]
	str	w8, [x20]
	lsr	x8, x8, #32
	strh	w8, [x20, #4]
	b	LBB12_154
LBB12_97:
	mov	x8, x19
	ldr	w10, [x8, #8]!
	mov	x9, x20
	ldr	w11, [x9, #-8]!
	ldrh	w12, [x19, #12]
	ldr	w13, [x19]
	ldrh	w14, [x19, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w10, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	ldrh	w14, [x9, #4]
	cmp	w14, w12
	cset	w12, lo
	cmp	w11, w10
	cset	w10, lo
	csel	w11, w12, w10, eq
	tbz	w13, #0, LBB12_142
; %bb.98:
	ldr	x10, [x19]
	cbz	w11, LBB12_152
; %bb.99:
	ldr	w8, [x9]
	ldrh	w11, [x9, #4]
	strh	w11, [x19, #4]
	str	w8, [x19]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
	str	w10, [x9]
	b	LBB12_154
LBB12_100:
	add	x1, x19, #8
	add	x2, x19, #16
	mov	x0, x19
	mov	x3, x22
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
LBB12_101:
	cmp	x19, x20
	add	x10, x19, #8
	ccmp	x10, x20, #4, ne
	cset	w8, eq
	tbz	w23, #0, LBB12_146
; %bb.102:
	tbnz	w8, #0, LBB12_154
; %bb.103:
	mov	x8, #0                          ; =0x0
	mov	x12, x19
	b	LBB12_107
LBB12_104:                              ;   in Loop: Header=BB12_107 Depth=1
	mov	x14, x19
LBB12_105:                              ;   in Loop: Header=BB12_107 Depth=1
	str	w10, [x14]
	strh	w11, [x14, #4]
LBB12_106:                              ;   in Loop: Header=BB12_107 Depth=1
	add	x10, x9, #8
	add	x8, x8, #8
	mov	x12, x9
	cmp	x10, x20
	b.eq	LBB12_154
LBB12_107:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_109 Depth 2
	mov	x9, x10
	ldr	w10, [x12, #8]
	ldrh	w11, [x12, #12]
	ldr	w13, [x12]
	ldrh	w14, [x12, #4]
	cmp	w11, w14
	cset	w11, lo
	cmp	w10, w13
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB12_106
; %bb.108:                              ;   in Loop: Header=BB12_107 Depth=1
	ldr	x10, [x12, #8]
	ldr	w11, [x12]
	str	w11, [x9]
	ldrh	w11, [x12, #4]
	strh	w11, [x9, #4]
	lsr	x11, x10, #32
	mov	x13, x8
	mov	x14, x19
	cmp	x12, x19
	b.eq	LBB12_105
LBB12_109:                              ;   Parent Loop BB12_107 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x19, x13
	add	x12, x19, x13
	ldr	w15, [x12, #-8]!
	ldurh	w16, [x14, #-4]
	cmp	w16, w11, uxth
	cset	w16, hi
	cmp	w15, w10
	cset	w15, hi
	csel	w15, w16, w15, eq
	tbz	w15, #0, LBB12_105
; %bb.110:                              ;   in Loop: Header=BB12_109 Depth=2
	ldr	w15, [x12]
	str	w15, [x14]
	ldrh	w12, [x12, #4]
	strh	w12, [x14, #4]
	subs	x13, x13, #8
	b.ne	LBB12_109
	b	LBB12_104
LBB12_111:
	cmp	x19, x20
	b.eq	LBB12_154
; %bb.112:
	lsr	x8, x8, #1
	mov	x11, x8
	b	LBB12_115
LBB12_113:                              ;   in Loop: Header=BB12_115 Depth=1
	str	w12, [x13]
	strh	w14, [x13, #4]
LBB12_114:                              ;   in Loop: Header=BB12_115 Depth=1
	sub	x11, x10, #1
	cbz	x10, LBB12_130
LBB12_115:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_125 Depth 2
	mov	x10, x11
	cmp	x8, x11
	b.lo	LBB12_114
; %bb.116:                              ;   in Loop: Header=BB12_115 Depth=1
	lsl	x12, x10, #1
	mov	w11, #1                         ; =0x1
	bfi	x11, x10, #1, #62
	add	x13, x12, #2
	add	x14, x19, x11, lsl #3
	cmp	x13, x9
	b.hs	LBB12_119
; %bb.117:                              ;   in Loop: Header=BB12_115 Depth=1
	add	x12, x19, x13, lsl #3
	ldr	w15, [x14]
	ldrh	w14, [x14, #4]
	ldr	w16, [x12]
	ldrh	w17, [x12, #4]
	cmp	w14, w17
	cset	w12, lo
	cmp	w15, w16
	cset	w0, lo
	csel	w12, w12, w0, eq
	.p2align	6, , 4
; %bb.118:                              ;   in Loop: Header=BB12_115 Depth=1
	cmp	w12, #0
	csel	w12, w16, w15, ne
	csel	x11, x13, x11, ne
	csel	w13, w17, w14, ne
	b	LBB12_120
LBB12_119:                              ;   in Loop: Header=BB12_115 Depth=1
	ldr	w12, [x14]
	ldrh	w13, [x14, #4]
LBB12_120:                              ;   in Loop: Header=BB12_115 Depth=1
	add	x14, x19, x10, lsl #3
	ldr	w15, [x14]
	ldrh	w16, [x14, #4]
	cmp	w13, w16
	cset	w13, lo
	cmp	w12, w15
	cset	w12, lo
	csel	w12, w13, w12, eq
	tbnz	w12, #0, LBB12_114
; %bb.121:                              ;   in Loop: Header=BB12_115 Depth=1
	ldr	x12, [x14]
	mov	x16, x10
	b	LBB12_125
LBB12_122:                              ;   in Loop: Header=BB12_125 Depth=2
	add	x16, x19, x17, lsl #3
	ldr	w1, [x0]
	ldrh	w0, [x0, #4]
	ldr	w2, [x16]
	ldrh	w3, [x16, #4]
	cmp	w0, w3
	cset	w16, lo
	cmp	w1, w2
	cset	w4, lo
	csel	w16, w16, w4, eq
	.p2align	6, , 4
; %bb.123:                              ;   in Loop: Header=BB12_125 Depth=2
	cmp	w16, #0
	csel	w16, w2, w1, ne
	csel	x15, x17, x15, ne
	csel	w17, w3, w0, ne
LBB12_124:                              ;   in Loop: Header=BB12_125 Depth=2
	cmp	w17, w14, uxth
	cset	w17, lo
	cmp	w16, w12
	cset	w16, lo
	csel	w17, w17, w16, eq
	mov	x16, x11
	mov	x11, x15
	cbnz	w17, LBB12_113
LBB12_125:                              ;   Parent Loop BB12_115 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x19, x11, lsl #3
	ldr	w14, [x13]
	ldrh	w15, [x13, #4]
	add	x16, x19, x16, lsl #3
	strh	w15, [x16, #4]
	str	w14, [x16]
	lsr	x14, x12, #32
	cmp	x8, x11
	b.lt	LBB12_113
; %bb.126:                              ;   in Loop: Header=BB12_125 Depth=2
	lsl	x16, x11, #1
	mov	w15, #1                         ; =0x1
	bfi	x15, x11, #1, #62
	add	x17, x16, #2
	add	x0, x19, x15, lsl #3
	cmp	x17, x9
	b.lt	LBB12_122
; %bb.127:                              ;   in Loop: Header=BB12_125 Depth=2
	ldr	w16, [x0]
	ldrh	w17, [x0, #4]
	b	LBB12_124
LBB12_128:                              ;   in Loop: Header=BB12_130 Depth=1
	str	w10, [x8]
	strh	w11, [x8, #4]
LBB12_129:                              ;   in Loop: Header=BB12_130 Depth=1
	cmp	x9, #2
	sub	x9, x9, #1
	b.le	LBB12_154
LBB12_130:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_133 Depth 2
                                        ;     Child Loop BB12_139 Depth 2
	mov	x13, #0                         ; =0x0
	ldr	x10, [x19]
	sub	x8, x9, #2
	lsr	x11, x8, #1
	mov	x12, x19
	b	LBB12_133
LBB12_131:                              ;   in Loop: Header=BB12_133 Depth=2
	ldr	w16, [x15, #16]!
	ldur	w17, [x15, #-8]
	ldurh	w0, [x15, #-4]
	ldrh	w1, [x15, #4]
	cmp	w0, w1
	cset	w0, lo
	cmp	w17, w16
	cset	w16, lo
	csel	w16, w0, w16, eq
	cmp	w16, #0
	csel	x8, x15, x8, ne
	csel	x13, x13, x14, ne
LBB12_132:                              ;   in Loop: Header=BB12_133 Depth=2
	ldr	w14, [x8]
	ldrh	w15, [x8, #4]
	strh	w15, [x12, #4]
	str	w14, [x12]
	mov	x12, x8
	cmp	x13, x11
	b.gt	LBB12_135
LBB12_133:                              ;   Parent Loop BB12_130 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x12, x13, lsl #3
	add	x8, x15, #8
	lsl	x16, x13, #1
	mov	w14, #1                         ; =0x1
	bfi	x14, x13, #1, #63
	add	x13, x16, #2
	cmp	x13, x9
	b.lt	LBB12_131
; %bb.134:                              ;   in Loop: Header=BB12_133 Depth=2
	mov	x13, x14
	b	LBB12_132
LBB12_135:                              ;   in Loop: Header=BB12_130 Depth=1
	sub	x20, x20, #8
	lsr	x11, x10, #32
	cmp	x8, x20
	b.eq	LBB12_128
; %bb.136:                              ;   in Loop: Header=BB12_130 Depth=1
	ldr	w12, [x20]
	ldrh	w13, [x20, #4]
	strh	w13, [x8, #4]
	str	w12, [x8]
	strh	w11, [x20, #4]
	str	w10, [x20]
	sub	x10, x8, x19
	add	x10, x10, #8
	asr	x10, x10, #3
	subs	x10, x10, #2
	b.lt	LBB12_129
; %bb.137:                              ;   in Loop: Header=BB12_130 Depth=1
	lsr	x10, x10, #1
	add	x11, x19, x10, lsl #3
	ldr	w12, [x11]
	ldrh	w13, [x11, #4]
	ldr	w14, [x8]
	ldrh	w15, [x8, #4]
	cmp	w13, w15
	cset	w13, lo
	cmp	w12, w14
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB12_129
; %bb.138:                              ;   in Loop: Header=BB12_130 Depth=1
	ldr	x12, [x8]
LBB12_139:                              ;   Parent Loop BB12_130 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x13, x8
	mov	x8, x11
	ldr	w11, [x11]
	ldrh	w14, [x8, #4]
	strh	w14, [x13, #4]
	str	w11, [x13]
	lsr	x13, x12, #32
	cbz	x10, LBB12_141
; %bb.140:                              ;   in Loop: Header=BB12_139 Depth=2
	sub	x10, x10, #1
	lsr	x10, x10, #1
	add	x11, x19, x10, lsl #3
	ldr	w14, [x11]
	ldrh	w15, [x11, #4]
	cmp	w15, w13, uxth
	cset	w15, lo
	cmp	w14, w12
	cset	w14, lo
	csel	w14, w15, w14, eq
	tbnz	w14, #0, LBB12_139
LBB12_141:                              ;   in Loop: Header=BB12_130 Depth=1
	str	w12, [x8]
	strh	w13, [x8, #4]
	b	LBB12_129
LBB12_142:
	cbz	w11, LBB12_154
; %bb.143:
	ldr	x10, [x19, #8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x10, x10, #32
	strh	w10, [x9, #4]
	ldr	w9, [x19, #8]
	ldrh	w10, [x19, #12]
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB12_154
; %bb.144:
	ldr	x9, [x19]
	ldr	w10, [x8]
	str	w10, [x19]
	ldrh	w8, [x8, #4]
	strh	w8, [x19, #4]
	str	w9, [x19, #8]
	lsr	x8, x9, #32
LBB12_145:
	strh	w8, [x19, #12]
	b	LBB12_154
LBB12_146:
	tbz	w8, #0, LBB12_148
	b	LBB12_154
LBB12_147:                              ;   in Loop: Header=BB12_148 Depth=1
	add	x10, x19, #8
	cmp	x10, x20
	b.eq	LBB12_154
LBB12_148:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_150 Depth 2
	ldr	w8, [x19, #8]
	ldrh	w9, [x19, #12]
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	mov	x19, x10
	cmp	w9, w12
	cset	w9, lo
	cmp	w8, w11
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB12_147
; %bb.149:                              ;   in Loop: Header=BB12_148 Depth=1
	ldr	x8, [x19]
	lsr	x9, x8, #32
	mov	x10, x19
LBB12_150:                              ;   Parent Loop BB12_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x11, x10
	ldr	w12, [x10, #-8]!
	str	w12, [x11]
	ldurh	w12, [x11, #-4]
	strh	w12, [x11, #4]
	ldur	w12, [x11, #-16]
	ldurh	w11, [x11, #-12]
	cmp	w11, w9, uxth
	cset	w11, hi
	cmp	w12, w8
	cset	w12, hi
	csel	w11, w11, w12, eq
	tbnz	w11, #0, LBB12_150
; %bb.151:                              ;   in Loop: Header=BB12_148 Depth=1
	str	w8, [x10]
	strh	w9, [x10, #4]
	b	LBB12_147
LBB12_152:
	ldr	w11, [x8]
	str	w11, [x19]
	ldrh	w11, [x8, #4]
	strh	w11, [x19, #4]
	str	w10, [x19, #8]
	lsr	x11, x10, #32
	strh	w11, [x19, #12]
	ldur	w12, [x20, #-8]
	ldurh	w13, [x20, #-4]
	cmp	w13, w11, uxth
	cset	w11, lo
	cmp	w12, w10
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB12_154
; %bb.153:
	ldr	x10, [x8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
LBB12_154:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function _ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_: ; @_ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	.cfi_startproc
; %bb.0:
	ldr	w10, [x1]
	ldrh	w11, [x1, #4]
	ldr	w8, [x0]
	ldrh	w9, [x0, #4]
	cmp	w11, w9
	cset	w9, lo
	cmp	w10, w8
	cset	w8, lo
	csel	w12, w9, w8, eq
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	cmp	w9, w11
	cset	w11, lo
	cmp	w8, w10
	cset	w10, lo
	csel	w11, w11, w10, eq
	tbz	w12, #0, LBB13_3
; %bb.1:
	ldr	x10, [x0]
	cbz	w11, LBB13_6
; %bb.2:
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	strh	w9, [x0, #4]
	str	w8, [x0]
	lsr	x8, x10, #32
	strh	w8, [x2, #4]
	str	w10, [x2]
	ubfx	x9, x10, #32, #16
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	mov	x8, x10
	b	LBB13_9
LBB13_3:
	cbz	w11, LBB13_9
; %bb.4:
	ldr	x8, [x1]
	ldr	w9, [x2]
	ldrh	w10, [x2, #4]
	strh	w10, [x1, #4]
	str	w9, [x1]
	str	w8, [x2]
	lsr	x9, x8, #32
	strh	w9, [x2, #4]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	ldr	w11, [x0]
	ldrh	w12, [x0, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB13_8
; %bb.5:
	ldr	x8, [x0]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	strh	w10, [x0, #4]
	str	w9, [x0]
	str	w8, [x1]
	lsr	x8, x8, #32
	strh	w8, [x1, #4]
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	b	LBB13_9
LBB13_6:
	ldr	w8, [x1]
	ldrh	w9, [x1, #4]
	strh	w9, [x0, #4]
	str	w8, [x0]
	lsr	x11, x10, #32
	strh	w11, [x1, #4]
	str	w10, [x1]
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	cmp	w9, w11, uxth
	cset	w11, lo
	cmp	w8, w10
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB13_9
; %bb.7:
	ldr	x8, [x1]
	ldr	w9, [x2]
	ldrh	w10, [x2, #4]
	strh	w10, [x1, #4]
	str	w9, [x1]
	str	w8, [x2]
	lsr	x9, x8, #32
	strh	w9, [x2, #4]
	ubfx	x9, x8, #32, #16
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB13_9
LBB13_8:
	ubfx	x9, x8, #32, #16
LBB13_9:
	ldr	w10, [x3]
	ldrh	w11, [x3, #4]
	cmp	w11, w9
	cset	w9, lo
	cmp	w10, w8
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB13_13
; %bb.10:
	ldr	x8, [x2]
	ldr	w9, [x3]
	ldrh	w10, [x3, #4]
	strh	w10, [x2, #4]
	str	w9, [x2]
	str	w8, [x3]
	lsr	x8, x8, #32
	strh	w8, [x3, #4]
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	ldr	w10, [x1]
	ldrh	w11, [x1, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB13_13
; %bb.11:
	ldr	x8, [x1]
	ldr	w9, [x2]
	ldrh	w10, [x2, #4]
	strh	w10, [x1, #4]
	str	w9, [x1]
	str	w8, [x2]
	lsr	x8, x8, #32
	strh	w8, [x2, #4]
	ldr	w8, [x1]
	ldrh	w9, [x1, #4]
	ldr	w10, [x0]
	ldrh	w11, [x0, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB13_13
; %bb.12:
	ldr	x8, [x0]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	strh	w10, [x0, #4]
	str	w9, [x0]
	str	w8, [x1]
	lsr	x8, x8, #32
	strh	w8, [x1, #4]
LBB13_13:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function _ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_: ; @_ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	sub	x8, x1, x0
	asr	x8, x8, #3
	cmp	x8, #2
	b.gt	LBB14_5
; %bb.1:
	b.lo	LBB14_39
; %bb.2:
	cmp	x8, #2
	b.ne	LBB14_16
; %bb.3:
	ldr	w8, [x1, #-8]!
	ldrh	w9, [x1, #4]
	ldr	w10, [x0]
	ldrh	w11, [x0, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB14_39
; %bb.4:
	ldr	x8, [x0]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	strh	w10, [x0, #4]
	str	w9, [x0]
	str	w8, [x1]
	lsr	x8, x8, #32
	strh	w8, [x1, #4]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_5:
	cmp	x8, #3
	b.eq	LBB14_13
; %bb.6:
	cmp	x8, #4
	b.eq	LBB14_19
; %bb.7:
	cmp	x8, #5
	b.ne	LBB14_16
; %bb.8:
	mov	x20, x1
	add	x1, x0, #8
	add	x2, x0, #16
	add	x3, x0, #24
	mov	x19, x0
	bl	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	mov	x8, x20
	ldr	w9, [x8, #-8]!
	ldrh	w10, [x8, #4]
	ldr	w11, [x19, #24]
	ldrh	w12, [x19, #28]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB14_39
; %bb.9:
	ldr	x9, [x19, #24]
	ldr	w10, [x8]
	ldrh	w11, [x8, #4]
	sturh	w11, [x19, #28]
	stur	w10, [x19, #24]
	str	w9, [x8]
	lsr	x9, x9, #32
	strh	w9, [x8, #4]
	ldr	w8, [x19, #24]
	ldrh	w9, [x19, #28]
	ldr	w10, [x19, #16]
	ldrh	w11, [x19, #20]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB14_39
; %bb.10:
	ldr	x8, [x19, #16]
	ldurh	w9, [x19, #28]
	sturh	w9, [x19, #20]
	ldur	w9, [x19, #24]
	stur	w9, [x19, #16]
	str	w8, [x19, #24]
	lsr	x8, x8, #32
	strh	w8, [x19, #28]
	ldr	w8, [x19, #16]
	ldrh	w9, [x19, #20]
	ldr	w10, [x19, #8]
	ldrh	w11, [x19, #12]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB14_39
; %bb.11:
	ldr	x8, [x19, #8]
	ldurh	w9, [x19, #20]
	sturh	w9, [x19, #12]
	ldur	w9, [x19, #16]
	stur	w9, [x19, #8]
	str	w8, [x19, #16]
	lsr	x8, x8, #32
	strh	w8, [x19, #20]
	ldr	w8, [x19, #8]
	ldrh	w9, [x19, #12]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB14_39
; %bb.12:
	ldr	x8, [x19]
	ldur	w9, [x19, #8]
	str	w9, [x19]
	ldurh	w9, [x19, #12]
	strh	w9, [x19, #4]
	str	w8, [x19, #8]
	lsr	x8, x8, #32
	strh	w8, [x19, #12]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_13:
	mov	x8, x0
	ldr	w10, [x8, #8]!
	mov	x9, x1
	ldr	w11, [x9, #-8]!
	ldrh	w12, [x0, #12]
	ldr	w13, [x0]
	ldrh	w14, [x0, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w10, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	ldrh	w14, [x9, #4]
	cmp	w14, w12
	cset	w12, lo
	cmp	w11, w10
	cset	w10, lo
	csel	w11, w12, w10, eq
	tbz	w13, #0, LBB14_20
; %bb.14:
	ldr	x10, [x0]
	cbz	w11, LBB14_26
; %bb.15:
	ldr	w8, [x9]
	ldrh	w11, [x9, #4]
	strh	w11, [x0, #4]
	str	w8, [x0]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
	str	w10, [x9]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_16:
	mov	x8, x0
	ldr	w10, [x8, #16]!
	mov	x9, x0
	ldr	w14, [x9, #8]!
	ldrh	w15, [x0, #12]
	ldr	w11, [x0]
	ldrh	w12, [x0, #4]
	cmp	w15, w12
	cset	w13, lo
	cmp	w14, w11
	cset	w16, lo
	csel	w16, w13, w16, eq
	ldrh	w13, [x0, #20]
	cmp	w13, w15
	cset	w15, lo
	cmp	w10, w14
	cset	w14, lo
	csel	w14, w15, w14, eq
	tbz	w16, #0, LBB14_23
; %bb.17:
	ldr	x11, [x0]
	cbz	w14, LBB14_28
; %bb.18:
	ldr	w9, [x8]
	str	w9, [x0]
	ldrh	w9, [x8, #4]
	strh	w9, [x0, #4]
	str	w11, [x0, #16]
	lsr	x9, x11, #32
	strh	w9, [x0, #20]
	b	LBB14_30
LBB14_19:
	sub	x3, x1, #8
	add	x1, x0, #8
	add	x2, x0, #16
	bl	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN16cng_layout_model12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_20:
	cbz	w11, LBB14_39
; %bb.21:
	ldr	x10, [x0, #8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x10, x10, #32
	strh	w10, [x9, #4]
	ldr	w9, [x0, #8]
	ldrh	w10, [x0, #12]
	ldr	w11, [x0]
	ldrh	w12, [x0, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB14_39
; %bb.22:
	ldr	x9, [x0]
	ldr	w10, [x8]
	str	w10, [x0]
	ldrh	w8, [x8, #4]
	strh	w8, [x0, #4]
	str	w9, [x0, #8]
	lsr	x8, x9, #32
	strh	w8, [x0, #12]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_23:
	cbz	w14, LBB14_30
; %bb.24:
	ldr	x10, [x0, #8]
	ldrh	w13, [x8, #4]
	strh	w13, [x9, #4]
	ldr	w13, [x8]
	str	w13, [x9]
	str	w10, [x0, #16]
	lsr	x10, x10, #32
	strh	w10, [x0, #20]
	ldr	w10, [x0, #8]
	ldrh	w13, [x0, #12]
	cmp	w13, w12
	cset	w12, lo
	cmp	w10, w11
	cset	w10, lo
	csel	w10, w12, w10, eq
	cbz	w10, LBB14_30
; %bb.25:
	ldr	x10, [x0]
	ldr	w11, [x9]
	str	w11, [x0]
	ldrh	w9, [x9, #4]
	strh	w9, [x0, #4]
	str	w10, [x0, #8]
	lsr	x9, x10, #32
	strh	w9, [x0, #12]
	b	LBB14_30
LBB14_26:
	ldr	w11, [x8]
	str	w11, [x0]
	ldrh	w11, [x8, #4]
	strh	w11, [x0, #4]
	str	w10, [x0, #8]
	lsr	x11, x10, #32
	strh	w11, [x0, #12]
	ldur	w12, [x1, #-8]
	ldurh	w13, [x1, #-4]
	cmp	w13, w11, uxth
	cset	w11, lo
	cmp	w12, w10
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB14_39
; %bb.27:
	ldr	x10, [x8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_28:
	ldr	w12, [x9]
	str	w12, [x0]
	ldrh	w12, [x9, #4]
	strh	w12, [x0, #4]
	str	w11, [x0, #8]
	lsr	x12, x11, #32
	strh	w12, [x0, #12]
	cmp	w13, w12, uxth
	cset	w12, lo
	cmp	w10, w11
	cset	w10, lo
	csel	w10, w12, w10, eq
	cbz	w10, LBB14_30
; %bb.29:
	ldr	x10, [x9]
	ldr	w11, [x8]
	str	w11, [x9]
	ldrh	w11, [x8, #4]
	strh	w11, [x9, #4]
	str	w10, [x8]
	lsr	x9, x10, #32
	strh	w9, [x8, #4]
LBB14_30:
	add	x9, x0, #24
	cmp	x9, x1
	b.eq	LBB14_39
; %bb.31:
	mov	x10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	b	LBB14_33
LBB14_32:                               ;   in Loop: Header=BB14_33 Depth=1
	add	x13, x15, #16
	str	w12, [x13]
	strh	w8, [x13, #4]
	add	w11, w11, #1
	cmp	w11, #8
	b.ne	LBB14_38
	b	LBB14_40
LBB14_33:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_35 Depth 2
	ldr	w12, [x9]
	ldrh	w13, [x9, #4]
	ldr	w14, [x8]
	ldrh	w15, [x8, #4]
	cmp	w13, w15
	cset	w13, lo
	cmp	w12, w14
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB14_38
; %bb.34:                               ;   in Loop: Header=BB14_33 Depth=1
	ldr	x12, [x9]
	ldr	w13, [x8]
	str	w13, [x9]
	ldrh	w8, [x8, #4]
	strh	w8, [x9, #4]
	lsr	x8, x12, #32
	mov	x13, x10
LBB14_35:                               ;   Parent Loop BB14_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x0, x13
	add	x14, x0, x13
	ldr	w16, [x14, #8]!
	ldrh	w17, [x14, #4]
	cmp	w17, w8, uxth
	cset	w17, hi
	cmp	w16, w12
	cset	w16, hi
	csel	w16, w17, w16, eq
	tbz	w16, #0, LBB14_32
; %bb.36:                               ;   in Loop: Header=BB14_35 Depth=2
	ldr	w15, [x14]
	stur	w15, [x14, #8]
	ldrh	w15, [x14, #4]
	sturh	w15, [x14, #12]
	sub	x13, x13, #8
	cmn	x13, #16
	b.ne	LBB14_35
; %bb.37:                               ;   in Loop: Header=BB14_33 Depth=1
	str	w12, [x0]
	strh	w8, [x0, #4]
	add	w11, w11, #1
	cmp	w11, #8
	b.eq	LBB14_40
LBB14_38:                               ;   in Loop: Header=BB14_33 Depth=1
	mov	x8, x9
	add	x9, x9, #8
	add	x10, x10, #8
	cmp	x9, x1
	b.ne	LBB14_33
LBB14_39:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_40:
	add	x8, x9, #8
	cmp	x8, x1
	cset	w0, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"Huffman capacity"

l_.str.1:                               ; @.str.1
	.asciz	"Huffman output extent"

l_.str.2:                               ; @.str.2
	.asciz	"Huffman stored extent"

l_.str.3:                               ; @.str.3
	.asciz	"Huffman constant extent"

l_.str.4:                               ; @.str.4
	.asciz	"Huffman coding"

l_.str.5:                               ; @.str.5
	.asciz	"Huffman coded extent"

l_.str.6:                               ; @.str.6
	.asciz	"Huffman stream extent"

l_.str.8:                               ; @.str.8
	.asciz	"layout input bound"

l_.str.9:                               ; @.str.9
	.asciz	"layout encode storage"

l_.str.10:                              ; @.str.10
	.asciz	"layout input symbol"

l_.str.11:                              ; @.str.11
	.asciz	"layout header"

l_.str.12:                              ; @.str.12
	.asciz	"layout size"

l_.str.13:                              ; @.str.13
	.asciz	"layout decode workspace"

l_.str.14:                              ; @.str.14
	.asciz	"layout trailing bytes"

l_.str.15:                              ; @.str.15
	.asciz	"Huffman nondegenerate population"

l_.str.16:                              ; @.str.16
	.asciz	"package-merge shape"

l_.str.17:                              ; @.str.17
	.asciz	"package-merge feasibility"

l_.str.18:                              ; @.str.18
	.asciz	"Huffman code length"

l_.str.19:                              ; @.str.19
	.asciz	"Huffman prefix population"

l_.str.20:                              ; @.str.20
	.asciz	"Huffman complete tree"

l_.str.21:                              ; @.str.21
	.asciz	"Huffman table capacity"

l_.str.22:                              ; @.str.22
	.asciz	"Huffman reserved table token"

l_.str.23:                              ; @.str.23
	.asciz	"Huffman table run"

l_.str.24:                              ; @.str.24
	.asciz	"Huffman table bound"

l_.str.25:                              ; @.str.25
	.asciz	"Huffman table padding"

l_.str.26:                              ; @.str.26
	.asciz	"Huffman table extent"

l_.str.27:                              ; @.str.27
	.asciz	"Huffman exact byte extent"

l_.str.28:                              ; @.str.28
	.asciz	"Huffman bit padding"

l_.str.29:                              ; @.str.29
	.asciz	"layout tree capacity"

l_.str.30:                              ; @.str.30
	.asciz	"layout tree children"

l_.str.31:                              ; @.str.31
	.asciz	"flat map capacity"

l_.str.32:                              ; @.str.32
	.asciz	"flat map leaf"

l_.str.33:                              ; @.str.33
	.asciz	"layout emit capacity"

l_.str.34:                              ; @.str.34
	.asciz	"nonconstant reconstruction"

l_.str.35:                              ; @.str.35
	.asciz	"node bit extent"

l_.str.36:                              ; @.str.36
	.asciz	"node padding"

l_.str.37:                              ; @.str.37
	.asciz	"flat width"

.subsections_via_symbols
