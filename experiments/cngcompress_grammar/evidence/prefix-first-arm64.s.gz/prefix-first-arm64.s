	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE ; -- Begin function _ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE
	.p2align	2
__ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE: ; @_ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x1, x8
	b.hi	LBB0_129
; %bb.1:
	mov	x10, x1
	mov	w8, #131071                     ; =0x1ffff
	add	w8, w10, w8
	lsr	w8, w8, #15
	and	x8, x8, #0xfc
	add	x20, x1, #5
	add	x8, x20, x8
	cmp	x3, x8
	b.lo	LBB0_129
; %bb.2:
	mov	x22, x4
	mov	x24, x2
	mov	x21, x0
	mov	w8, #17                         ; =0x11
	strb	w8, [x2]
	strb	w10, [x2, #1]
	lsr	x8, x10, #8
	strb	w8, [x2, #2]
	lsr	x8, x10, #16
	strb	w8, [x2, #3]
	strb	wzr, [x2, #4]
	mov	w8, #67                         ; =0x43
	cmp	x10, #67
	csel	x8, x10, x8, hi
	lsr	x8, x8, #2
	mov	w9, #16384                      ; =0x4000
	cmp	x8, #4, lsl #12                 ; =16384
	csel	x8, x8, x9, lo
	clz	x8, x8
	mov	x9, #-9223372036854775808       ; =0x8000000000000000
	lsr	x19, x9, x8
	lsl	x1, x19, #4
	mov	x0, x4
	str	x10, [sp, #40]                  ; 8-byte Spill
	bl	_bzero
	ldr	x2, [sp, #40]                   ; 8-byte Reload
	cbz	x2, LBB0_120
; %bb.3:
	stp	x20, x24, [sp]                  ; 16-byte Folded Spill
	mov	x20, #0                         ; =0x0
	sub	x28, x19, #1
	mov	w27, #16                        ; =0x10
	movk	w27, #2, lsl #16
	mov	w30, #31153                     ; =0x79b1
	movk	w30, #40503, lsl #16
	add	x5, x22, #64, lsl #12           ; =262144
	mov	w8, #5                          ; =0x5
	str	x8, [sp, #24]                   ; 8-byte Spill
	mov	w6, #8                          ; =0x8
	mov	w4, #512                        ; =0x200
	mov	w7, #256                        ; =0x100
	b	LBB0_6
LBB0_4:                                 ;   in Loop: Header=BB0_6 Depth=1
	mov	x2, x25
	ldp	x20, x1, [sp, #24]              ; 16-byte Folded Reload
	add	x8, x24, x20
	strb	w2, [x8]
	lsr	x9, x25, #8
	strb	w9, [x8, #1]
	lsr	x9, x25, #16
	strb	w9, [x8, #2]
	mov	w9, #128                        ; =0x80
	strb	w9, [x8, #3]
	add	x0, x8, #4
	bl	_memcpy
	add	x8, x25, #4
LBB0_5:                                 ;   in Loop: Header=BB0_6 Depth=1
	add	x20, x8, x20
	str	x20, [sp, #24]                  ; 8-byte Spill
	ldp	x2, x8, [sp, #40]               ; 16-byte Folded Reload
	mov	x20, x8
	cmp	x8, x2
	mov	w30, #31153                     ; =0x79b1
	movk	w30, #40503, lsl #16
	add	x5, x22, #64, lsl #12           ; =262144
	mov	w6, #8                          ; =0x8
	mov	w4, #512                        ; =0x200
	mov	w7, #256                        ; =0x100
	b.hs	LBB0_118
LBB0_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_9 Depth 2
                                        ;       Child Loop BB0_15 Depth 3
                                        ;       Child Loop BB0_19 Depth 3
                                        ;       Child Loop BB0_50 Depth 3
                                        ;       Child Loop BB0_54 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
                                        ;       Child Loop BB0_36 Depth 3
	sub	x8, x2, x20
	cmp	x8, #32, lsl #12                ; =131072
	mov	w9, #131072                     ; =0x20000
	csel	x10, x8, x9, lo
	add	x9, x21, x20
	str	x9, [sp, #32]                   ; 8-byte Spill
	add	x9, x10, x20
	str	x9, [sp, #48]                   ; 8-byte Spill
	cmp	x8, #8
	b.lo	LBB0_112
; %bb.7:                                ;   in Loop: Header=BB0_6 Depth=1
	mov	x1, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	str	x10, [sp, #16]                  ; 8-byte Spill
	mov	x24, x20
	b	LBB0_9
LBB0_8:                                 ;   in Loop: Header=BB0_9 Depth=2
	mov	x8, #0                          ; =0x0
	add	x9, x21, x9
	ldrh	w10, [x9]
	ldrb	w11, [x21, x24]
	orr	w10, w10, w11, lsl #16
	ldrb	w9, [x9, #3]
	orr	w9, w10, w9, lsl #24
	mul	w10, w9, w30
	lsr	w10, w10, #18
	and	x10, x28, x10
	add	x10, x22, x10, lsl #4
	ldr	x11, [x10]
	str	x11, [x10, #8]
	sub	w11, w24, #1
	stp	w9, w11, [x10]
	mov	w9, #1                          ; =0x1
	mov	x20, x24
	ldr	x10, [sp, #48]                  ; 8-byte Reload
	sub	x10, x10, x24
	cmp	x10, #7
	b.ls	LBB0_106
LBB0_9:                                 ;   Parent Loop BB0_6 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_15 Depth 3
                                        ;       Child Loop BB0_19 Depth 3
                                        ;       Child Loop BB0_50 Depth 3
                                        ;       Child Loop BB0_54 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
                                        ;       Child Loop BB0_36 Depth 3
	add	x11, x21, x24
	ldr	w13, [x11]
	mul	w12, w13, w30
	lsr	w12, w12, #18
	and	x12, x28, x12
	add	x12, x22, x12, lsl #4
	ldp	w17, w14, [x12]
	ldr	x16, [x12, #8]
	stp	w17, w14, [x12, #8]
	add	w15, w24, #1
	stp	w13, w15, [x12]
	ldr	w12, [x11, #4]
	and	x0, x10, #0xfffffffffffffff8
	lsr	x15, x16, #32
	cmp	x0, #8
	b.ne	LBB0_12
; %bb.10:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	w14, #0
	ccmp	w17, w13, #0, ne
	b.eq	LBB0_23
; %bb.11:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	x19, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	cmp	w13, w16
	ccmp	w14, w15, #4, eq
	ccmp	x15, #0, #4, ne
	b.ne	LBB0_30
	b	LBB0_65
LBB0_12:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	w14, #0
	ccmp	w17, w13, #0, ne
	b.ne	LBB0_22
; %bb.13:                               ;   in Loop: Header=BB0_9 Depth=2
	sub	w19, w14, #1
	add	x17, x21, x19
	ldr	w17, [x17, #4]
	cmp	w17, w12
	b.ne	LBB0_22
; %bb.14:                               ;   in Loop: Header=BB0_9 Depth=2
	add	x17, x21, #8
	add	x0, x17, x24
	add	x7, x17, x19
	mov	x17, #-8                        ; =0xfffffffffffffff8
LBB0_15:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x3, [x7], #8
	ldr	x4, [x0], #8
	cmp	x3, x4
	b.ne	LBB0_43
; %bb.16:                               ;   in Loop: Header=BB0_15 Depth=3
	sub	x17, x17, #8
	add	x3, x10, x17
	cmp	x3, #7
	b.hi	LBB0_15
; %bb.17:                               ;   in Loop: Header=BB0_9 Depth=2
	neg	x23, x17
	cmp	x23, x10
	b.hs	LBB0_44
; %bb.18:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	x3, #0                          ; =0x0
	add	x4, x10, x17
LBB0_19:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w5, [x7, x3]
	ldrb	w6, [x0, x3]
	cmp	w5, w6
	b.ne	LBB0_63
; %bb.20:                               ;   in Loop: Header=BB0_19 Depth=3
	add	x3, x3, #1
	cmp	x4, x3
	b.ne	LBB0_19
; %bb.21:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	x23, x10
	b	LBB0_64
LBB0_22:                                ;   in Loop: Header=BB0_9 Depth=2
	mov	x19, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	cmp	w13, w16
	ccmp	w14, w15, #4, eq
	ccmp	x15, #0, #4, ne
	b.ne	LBB0_45
	b	LBB0_65
LBB0_23:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	w3, w14, #1
	add	x17, x21, x3
	ldr	w0, [x17, #4]
	cmp	w0, w12
	csel	x19, xzr, x3, ne
	csel	x23, xzr, x6, ne
	cmp	x10, #9
	b.lo	LBB0_29
; %bb.24:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	w0, w12
	b.ne	LBB0_29
; %bb.25:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w23, #8                         ; =0x8
LBB0_26:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w0, [x17, x23]
	ldrb	w3, [x11, x23]
	cmp	w0, w3
	b.ne	LBB0_58
; %bb.27:                               ;   in Loop: Header=BB0_26 Depth=3
	add	x23, x23, #1
	cmp	x10, x23
	b.ne	LBB0_26
; %bb.28:                               ;   in Loop: Header=BB0_9 Depth=2
	sub	w19, w14, #1
	mov	x23, x10
LBB0_29:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	w13, w16
	ccmp	w14, w15, #4, eq
	ccmp	x15, #0, #4, ne
	b.eq	LBB0_65
LBB0_30:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	w13, w15, #1
	cbz	x23, LBB0_34
; %bb.31:                               ;   in Loop: Header=BB0_9 Depth=2
	add	x14, x21, x23
	add	x14, x14, x13
	ldurb	w14, [x14, #-1]
	add	x15, x11, x23
	ldurb	w15, [x15, #-1]
	cmp	w14, w15
	b.ne	LBB0_66
; %bb.32:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	x23, x10
	b.ne	LBB0_34
; %bb.33:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	x19, x13
	b.hs	LBB0_57
LBB0_34:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x14, x21, x13
	ldr	w15, [x14, #4]
	cmp	w15, w12
	b.ne	LBB0_65
; %bb.35:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w8, #8                          ; =0x8
	cmp	x10, #9
	b.lo	LBB0_39
LBB0_36:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w9, [x14, x8]
	ldrb	w12, [x11, x8]
	cmp	w9, w12
	b.ne	LBB0_39
; %bb.37:                               ;   in Loop: Header=BB0_36 Depth=3
	add	x8, x8, #1
	cmp	x10, x8
	b.ne	LBB0_36
; %bb.38:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	x8, x10
LBB0_39:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x8, x23
	b.hi	LBB0_42
; %bb.40:                               ;   in Loop: Header=BB0_9 Depth=2
	b.ne	LBB0_66
; %bb.41:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	x19, x13
	b.hs	LBB0_66
LBB0_42:                                ;   in Loop: Header=BB0_9 Depth=2
	mov	x23, x8
	mov	x19, x13
	b	LBB0_66
LBB0_43:                                ;   in Loop: Header=BB0_9 Depth=2
	eor	x0, x4, x3
	rbit	x0, x0
	clz	x0, x0
	lsr	x0, x0, #3
	sub	x23, x0, x17
LBB0_44:                                ;   in Loop: Header=BB0_9 Depth=2
	mov	w4, #512                        ; =0x200
	mov	w7, #256                        ; =0x100
	cmp	w13, w16
	ccmp	w14, w15, #4, eq
	ccmp	x15, #0, #4, ne
	b.eq	LBB0_65
LBB0_45:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	w13, w15, #1
	cbz	x23, LBB0_48
; %bb.46:                               ;   in Loop: Header=BB0_9 Depth=2
	add	x14, x21, x23
	add	x14, x14, x13
	ldurb	w14, [x14, #-1]
	add	x11, x11, x23
	ldurb	w11, [x11, #-1]
	cmp	w14, w11
	b.ne	LBB0_66
; %bb.47:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	x23, x10
	ccmp	x19, x13, #0, eq
	b.hs	LBB0_57
LBB0_48:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x11, x21, x13
	ldr	w11, [x11, #4]
	cmp	w11, w12
	b.ne	LBB0_65
; %bb.49:                               ;   in Loop: Header=BB0_9 Depth=2
	add	x11, x21, #8
	add	x12, x11, x24
	add	x14, x11, x13
	mov	x11, #-8                        ; =0xfffffffffffffff8
LBB0_50:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x15, [x14], #8
	ldr	x16, [x12], #8
	cmp	x15, x16
	b.ne	LBB0_59
; %bb.51:                               ;   in Loop: Header=BB0_50 Depth=3
	sub	x11, x11, #8
	add	x15, x10, x11
	cmp	x15, #7
	b.hi	LBB0_50
; %bb.52:                               ;   in Loop: Header=BB0_9 Depth=2
	neg	x15, x11
	cmp	x15, x10
	b.hs	LBB0_60
; %bb.53:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	x15, #0                         ; =0x0
	add	x16, x10, x11
LBB0_54:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w17, [x14, x15]
	ldrb	w0, [x12, x15]
	cmp	w17, w0
	b.ne	LBB0_105
; %bb.55:                               ;   in Loop: Header=BB0_54 Depth=3
	add	x15, x15, #1
	cmp	x16, x15
	b.ne	LBB0_54
; %bb.56:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	x15, x10
	cmp	x10, x23
	b.ls	LBB0_61
	b	LBB0_62
LBB0_57:                                ;   in Loop: Header=BB0_9 Depth=2
	mov	x23, x10
	b	LBB0_66
LBB0_58:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	w19, w14, #1
	cmp	w13, w16
	ccmp	w14, w15, #4, eq
	ccmp	x15, #0, #4, ne
	b.ne	LBB0_30
	b	LBB0_65
LBB0_59:                                ;   in Loop: Header=BB0_9 Depth=2
	eor	x12, x16, x15
	rbit	x12, x12
	clz	x12, x12
	lsr	x12, x12, #3
	sub	x15, x12, x11
LBB0_60:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x15, x23
	b.hi	LBB0_62
LBB0_61:                                ;   in Loop: Header=BB0_9 Depth=2
	ccmp	x19, x13, #2, eq
	b.hs	LBB0_65
LBB0_62:                                ;   in Loop: Header=BB0_9 Depth=2
	mov	x19, x13
	mov	x23, x15
	b	LBB0_65
LBB0_63:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	x23, x3, x17
LBB0_64:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x5, x22, #64, lsl #12           ; =262144
	mov	w6, #8                          ; =0x8
	mov	w4, #512                        ; =0x200
	mov	w7, #256                        ; =0x100
	cmp	w13, w16
	ccmp	w14, w15, #4, eq
	ccmp	x15, #0, #4, ne
	b.ne	LBB0_45
LBB0_65:                                ;   in Loop: Header=BB0_9 Depth=2
	cbz	x23, LBB0_70
LBB0_66:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	x26, x24, x20
	cmp	x26, #128
	b.hs	LBB0_68
; %bb.67:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB0_72
LBB0_68:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x26, #4, lsl #12                ; =16384
	b.hs	LBB0_71
; %bb.69:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB0_72
LBB0_70:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x8, x8, #1
	lsr	x11, x8, #6
	add	x12, x11, #1
	cmp	x10, x12
	csinc	x10, x10, x11, lo
	add	x24, x10, x24
	ldr	x10, [sp, #48]                  ; 8-byte Reload
	sub	x10, x10, x24
	cmp	x10, #7
	b.hi	LBB0_9
	b	LBB0_106
LBB0_71:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x26, #512, lsl #12              ; =2097152
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, hs
	lsr	x9, x26, #28
	cbnz	x9, LBB0_122
LBB0_72:                                ;   in Loop: Header=BB0_9 Depth=2
	mov	w8, w8
	sub	x9, x27, x1
	cmp	x9, x8
	b.lo	LBB0_122
; %bb.73:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	w9, w4, w8
	cmp	w8, #1
	csneg	w9, wzr, w9, eq
	lsr	w10, w7, w8
	sub	w10, w10, #1
	and	w10, w26, w10
	orr	w10, w10, w9
	add	x9, x5, x1
	strb	w10, [x9]
	cmp	w8, #2
	b.lo	LBB0_78
; %bb.74:                               ;   in Loop: Header=BB0_9 Depth=2
	sub	w10, w6, w8
	lsr	x10, x26, x10
	strb	w10, [x9, #1]
	cmp	w8, #2
	b.eq	LBB0_78
; %bb.75:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	x11, x10, #8
	strb	w11, [x9, #2]
	cmp	w8, #3
	b.eq	LBB0_78
; %bb.76:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	x11, x10, #16
	strb	w11, [x9, #3]
	cmp	w8, #4
	b.eq	LBB0_78
; %bb.77:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	x11, x10, #24
	strb	w11, [x9, #4]
	lsr	x11, x10, #32
	strb	w11, [x9, #5]
	lsr	x10, x10, #40
	strb	w10, [x9, #6]
LBB0_78:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x25, x1, x8
	sub	x8, x27, x25
	cmp	x26, x8
	b.hi	LBB0_125
; %bb.79:                               ;   in Loop: Header=BB0_9 Depth=2
	cmp	x24, x20
	b.eq	LBB0_81
; %bb.80:                               ;   in Loop: Header=BB0_9 Depth=2
	add	x0, x5, x25
	add	x1, x21, x20
	mov	x2, x26
	bl	_memcpy
	mov	w7, #256                        ; =0x100
	mov	w4, #512                        ; =0x200
	mov	w6, #8                          ; =0x8
	add	x5, x22, #64, lsl #12           ; =262144
	mov	w30, #31153                     ; =0x79b1
	movk	w30, #40503, lsl #16
	ldr	x2, [sp, #40]                   ; 8-byte Reload
LBB0_81:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	x10, x24, x19
	cmp	x10, #128
	b.hs	LBB0_83
; %bb.82:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w9, #1                          ; =0x1
	b	LBB0_86
LBB0_83:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x10, #4, lsl #12                ; =16384
	b.hs	LBB0_85
; %bb.84:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w9, #2                          ; =0x2
	b	LBB0_86
LBB0_85:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x10, #512, lsl #12              ; =2097152
	mov	w8, #3                          ; =0x3
	cinc	w9, w8, hs
	lsr	x8, x10, #28
	cbnz	x8, LBB0_124
LBB0_86:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x8, x25, x26
	sub	x11, x27, x8
	mov	w9, w9
	cmp	x11, x9
	b.lo	LBB0_124
; %bb.87:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	w11, w4, w9
	cmp	w9, #1
	csneg	w11, wzr, w11, eq
	lsr	w12, w7, w9
	sub	w12, w12, #1
	and	w12, w10, w12
	orr	w12, w12, w11
	add	x11, x5, x8
	strb	w12, [x11]
	cmp	w9, #2
	b.lo	LBB0_92
; %bb.88:                               ;   in Loop: Header=BB0_9 Depth=2
	sub	w12, w6, w9
	lsr	x10, x10, x12
	strb	w10, [x11, #1]
	cmp	w9, #2
	b.eq	LBB0_92
; %bb.89:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	x12, x10, #8
	strb	w12, [x11, #2]
	cmp	w9, #3
	b.eq	LBB0_92
; %bb.90:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	x12, x10, #16
	strb	w12, [x11, #3]
	cmp	w9, #4
	b.eq	LBB0_92
; %bb.91:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	x12, x10, #24
	strb	w12, [x11, #4]
	lsr	x12, x10, #32
	strb	w12, [x11, #5]
	lsr	x10, x10, #40
	strb	w10, [x11, #6]
LBB0_92:                                ;   in Loop: Header=BB0_9 Depth=2
	sub	x10, x23, #8
	cmp	x10, #128
	b.hs	LBB0_94
; %bb.93:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w11, #1                         ; =0x1
	b	LBB0_97
LBB0_94:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x10, #4, lsl #12                ; =16384
	b.hs	LBB0_96
; %bb.95:                               ;   in Loop: Header=BB0_9 Depth=2
	mov	w11, #2                         ; =0x2
	b	LBB0_97
LBB0_96:                                ;   in Loop: Header=BB0_9 Depth=2
	cmp	x10, #512, lsl #12              ; =2097152
	mov	w11, #3                         ; =0x3
	cinc	w11, w11, hs
	lsr	x12, x10, #28
	cbnz	x12, LBB0_123
LBB0_97:                                ;   in Loop: Header=BB0_9 Depth=2
	add	x8, x8, x9
	sub	x12, x27, x8
	mov	w9, w11
	cmp	x12, x9
	b.lo	LBB0_123
; %bb.98:                               ;   in Loop: Header=BB0_9 Depth=2
	lsr	w11, w4, w9
	cmp	w9, #1
	csneg	w11, wzr, w11, eq
	lsr	w12, w7, w9
	sub	w12, w12, #1
	and	w12, w10, w12
	orr	w12, w12, w11
	add	x11, x5, x8
	strb	w12, [x11]
	cmp	w9, #2
	b.lo	LBB0_103
; %bb.99:                               ;   in Loop: Header=BB0_9 Depth=2
	sub	w12, w6, w9
	lsr	x10, x10, x12
	strb	w10, [x11, #1]
	cmp	w9, #2
	b.eq	LBB0_103
; %bb.100:                              ;   in Loop: Header=BB0_9 Depth=2
	lsr	x12, x10, #8
	strb	w12, [x11, #2]
	cmp	w9, #3
	b.eq	LBB0_103
; %bb.101:                              ;   in Loop: Header=BB0_9 Depth=2
	lsr	x12, x10, #16
	strb	w12, [x11, #3]
	cmp	w9, #4
	b.eq	LBB0_103
; %bb.102:                              ;   in Loop: Header=BB0_9 Depth=2
	lsr	x12, x10, #24
	strb	w12, [x11, #4]
	lsr	x12, x10, #32
	strb	w12, [x11, #5]
	lsr	x10, x10, #40
	strb	w10, [x11, #6]
LBB0_103:                               ;   in Loop: Header=BB0_9 Depth=2
	add	x1, x8, x9
	add	x24, x23, x24
	sub	x9, x24, #2
	sub	x8, x2, x9
	cmp	x8, #4
	b.hs	LBB0_8
; %bb.104:                              ;   in Loop: Header=BB0_9 Depth=2
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	mov	x20, x24
	ldr	x10, [sp, #48]                  ; 8-byte Reload
	sub	x10, x10, x24
	cmp	x10, #7
	b.hi	LBB0_9
	b	LBB0_106
LBB0_105:                               ;   in Loop: Header=BB0_9 Depth=2
	sub	x15, x15, x11
	cmp	x15, x23
	b.ls	LBB0_61
	b	LBB0_62
LBB0_106:                               ;   in Loop: Header=BB0_6 Depth=1
	str	x1, [sp, #56]
	ldp	x24, x10, [sp, #8]              ; 16-byte Folded Reload
	tbz	w9, #0, LBB0_112
; %bb.107:                              ;   in Loop: Header=BB0_6 Depth=1
	add	x23, x22, #64, lsl #12          ; =262144
	ldr	x8, [sp, #48]                   ; 8-byte Reload
	subs	x26, x8, x20
	b.eq	LBB0_110
; %bb.108:                              ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x22, #64, lsl #12           ; =262144
	add	x2, sp, #56
	mov	w1, #16                         ; =0x10
	movk	w1, #2, lsl #16
	mov	x3, x26
	bl	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm
	ldr	x19, [sp, #56]
	sub	x8, x27, x19
	cmp	x26, x8
	b.hi	LBB0_128
; %bb.109:                              ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x23, x19
	add	x1, x21, x20
	mov	x2, x26
	bl	_memcpy
	add	x1, x19, x26
	ldr	x10, [sp, #16]                  ; 8-byte Reload
LBB0_110:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x8, x10, #3
	cmp	x1, x8
	b.hi	LBB0_127
; %bb.111:                              ;   in Loop: Header=BB0_6 Depth=1
	mov	w20, #1                         ; =0x1
	add	x0, x22, #64, lsl #12           ; =262144
	mov	x19, x1
	mov	w23, #4                         ; =0x4
	b	LBB0_113
LBB0_112:                               ;   in Loop: Header=BB0_6 Depth=1
	mov	w20, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	ldr	x0, [sp, #32]                   ; 8-byte Reload
	mov	x1, x10
LBB0_113:                               ;   in Loop: Header=BB0_6 Depth=1
	mov	x25, x10
	mov	w8, #16                         ; =0x10
	movk	w8, #6, lsl #16
	add	x2, x22, x8
	mov	w3, #1024                       ; =0x400
	movk	w3, #4, lsl #16
	bl	__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	add	x8, x0, x23
	cmp	x8, x25
	b.hs	LBB0_4
; %bb.114:                              ;   in Loop: Header=BB0_6 Depth=1
	tbz	w20, #0, LBB0_116
; %bb.115:                              ;   in Loop: Header=BB0_6 Depth=1
	add	w8, w0, #4
	ldr	x20, [sp, #24]                  ; 8-byte Reload
	add	x9, x24, x20
	stp	w8, w19, [x9]
	mov	x24, x0
	add	x0, x9, #8
	mov	w8, #16                         ; =0x10
	movk	w8, #6, lsl #16
	add	x1, x22, x8
	mov	x2, x24
	bl	_memcpy
	add	x8, x24, #8
	b	LBB0_117
LBB0_116:                               ;   in Loop: Header=BB0_6 Depth=1
	ldr	x20, [sp, #24]                  ; 8-byte Reload
	add	x8, x24, x20
	strb	w0, [x8]
	lsr	x9, x0, #8
	strb	w9, [x8, #1]
	lsr	x9, x0, #16
	strb	w9, [x8, #2]
	lsr	w9, w0, #24
	orr	w9, w9, #0x40
	strb	w9, [x8, #3]
	mov	x24, x0
	add	x0, x8, #4
	mov	w8, #16                         ; =0x10
	movk	w8, #6, lsl #16
	add	x1, x22, x8
	mov	x2, x24
	bl	_memcpy
	add	x8, x24, #4
LBB0_117:                               ;   in Loop: Header=BB0_6 Depth=1
	ldr	x24, [sp, #8]                   ; 8-byte Reload
	b	LBB0_5
LBB0_118:
	ldr	x19, [sp]                       ; 8-byte Reload
	ldr	x0, [sp, #24]                   ; 8-byte Reload
	cmp	x0, x19
	b.lo	LBB0_121
; %bb.119:
	strb	wzr, [x24], #5
	mov	x0, x24
	mov	x1, x21
	bl	_memcpy
	mov	x0, x19
	b	LBB0_121
LBB0_120:
	strb	wzr, [x24]
	mov	w0, #5                          ; =0x5
LBB0_121:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB0_122:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp9:                                  ; EH_LABEL
Lloh0:
	adrp	x1, l_.str.13@PAGE
Lloh1:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ; EH_LABEL
	b	LBB0_126
LBB0_123:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp0:                                  ; EH_LABEL
Lloh2:
	adrp	x1, l_.str.13@PAGE
Lloh3:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ; EH_LABEL
	b	LBB0_126
LBB0_124:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp3:                                  ; EH_LABEL
Lloh4:
	adrp	x1, l_.str.13@PAGE
Lloh5:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ; EH_LABEL
	b	LBB0_126
LBB0_125:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp6:                                  ; EH_LABEL
Lloh6:
	adrp	x1, l_.str.10@PAGE
Lloh7:
	add	x1, x1, l_.str.10@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ; EH_LABEL
LBB0_126:
Lloh8:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh9:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh10:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh11:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB0_127:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp15:                                 ; EH_LABEL
Lloh12:
	adrp	x1, l_.str.12@PAGE
Lloh13:
	add	x1, x1, l_.str.12@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ; EH_LABEL
	b	LBB0_126
LBB0_128:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp12:                                 ; EH_LABEL
Lloh14:
	adrp	x1, l_.str.11@PAGE
Lloh15:
	add	x1, x1, l_.str.11@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ; EH_LABEL
	b	LBB0_126
LBB0_129:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp18:                                 ; EH_LABEL
Lloh16:
	adrp	x1, l_.str@PAGE
Lloh17:
	add	x1, x1, l_.str@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ; EH_LABEL
	b	LBB0_126
LBB0_130:
Ltmp20:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_131:
Ltmp14:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_132:
Ltmp17:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_133:
Ltmp8:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_134:
Ltmp5:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_135:
Ltmp2:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_136:
Ltmp11:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpLdrGot	Lloh10, Lloh11
	.loh AdrpLdrGot	Lloh8, Lloh9
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ; >> Call Site 1 <<
	.uleb128 Ltmp9-Lfunc_begin0             ;   Call between Lfunc_begin0 and Ltmp9
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ; >> Call Site 2 <<
	.uleb128 Ltmp10-Ltmp9                   ;   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin0            ;     jumps to Ltmp11
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin0            ; >> Call Site 3 <<
	.uleb128 Ltmp0-Ltmp10                   ;   Call between Ltmp10 and Ltmp0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ; >> Call Site 4 <<
	.uleb128 Ltmp1-Ltmp0                    ;   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ;     jumps to Ltmp2
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ; >> Call Site 5 <<
	.uleb128 Ltmp3-Ltmp1                    ;   Call between Ltmp1 and Ltmp3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ; >> Call Site 6 <<
	.uleb128 Ltmp4-Ltmp3                    ;   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ;     jumps to Ltmp5
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ; >> Call Site 7 <<
	.uleb128 Ltmp6-Ltmp4                    ;   Call between Ltmp4 and Ltmp6
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ; >> Call Site 8 <<
	.uleb128 Ltmp7-Ltmp6                    ;   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin0             ;     jumps to Ltmp8
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin0             ; >> Call Site 9 <<
	.uleb128 Ltmp15-Ltmp7                   ;   Call between Ltmp7 and Ltmp15
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin0            ; >> Call Site 10 <<
	.uleb128 Ltmp16-Ltmp15                  ;   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin0            ;     jumps to Ltmp17
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin0            ; >> Call Site 11 <<
	.uleb128 Ltmp12-Ltmp16                  ;   Call between Ltmp16 and Ltmp12
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin0            ; >> Call Site 12 <<
	.uleb128 Ltmp13-Ltmp12                  ;   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin0            ;     jumps to Ltmp14
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin0            ; >> Call Site 13 <<
	.uleb128 Ltmp18-Ltmp13                  ;   Call between Ltmp13 and Ltmp18
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin0            ; >> Call Site 14 <<
	.uleb128 Ltmp19-Ltmp18                  ;   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin0            ;     jumps to Ltmp20
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin0            ; >> Call Site 15 <<
	.uleb128 Lfunc_end0-Ltmp19              ;   Call between Ltmp19 and Lfunc_end0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE ; -- Begin function _ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE
	.p2align	2
__ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE: ; @_ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x4, [sp, #48]                   ; 8-byte Spill
	cmp	x1, #5
	b.lo	LBB1_49
; %bb.1:
	mov	x19, x3
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x3, x8
	b.hi	LBB1_49
; %bb.2:
	mov	x21, x0
	ldur	w8, [x0, #1]
	cmp	x19, x8
	b.ne	LBB1_49
; %bb.3:
	mov	x20, x2
	mov	x25, x1
	ldrb	w8, [x21]
	cmp	w8, #17
	b.eq	LBB1_8
; %bb.4:
	cbnz	w8, LBB1_50
; %bb.5:
	add	x8, x19, #5
	cmp	x25, x8
	b.ne	LBB1_51
; %bb.6:
	cbz	x19, LBB1_40
; %bb.7:
	add	x1, x21, #5
	mov	x0, x20
	mov	x2, x19
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	b	_memcpy
LBB1_8:
	cbz	x19, LBB1_50
; %bb.9:
	mov	x22, #0                         ; =0x0
	mov	w9, #5                          ; =0x5
	mov	w27, #131072                    ; =0x20000
	stp	x21, x19, [sp, #16]             ; 16-byte Folded Spill
	str	x25, [sp, #8]                   ; 8-byte Spill
	b	LBB1_12
LBB1_10:                                ;   in Loop: Header=BB1_12 Depth=1
	add	x0, x21, x26
	add	x2, x20, x22
	mov	x1, x24
	mov	x3, x28
	bl	__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
LBB1_11:                                ;   in Loop: Header=BB1_12 Depth=1
	add	x9, x26, x24
	add	x22, x28, x22
	cmp	x22, x19
	b.hs	LBB1_39
LBB1_12:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_22 Depth 2
                                        ;       Child Loop BB1_32 Depth 3
	sub	x8, x25, x9
	cmp	x8, #3
	b.ls	LBB1_43
; %bb.13:                               ;   in Loop: Header=BB1_12 Depth=1
	add	x8, x21, x9
	ldrh	w10, [x8]
	ldrb	w11, [x8, #2]
	orr	w24, w10, w11, lsl #16
	ldrb	w10, [x8, #3]
	add	x26, x9, #4
	bfi	w24, w10, #24, #6
	sub	x9, x19, x22
	cmp	x9, #32, lsl #12                ; =131072
	csel	x28, x9, x27, lo
	sub	x9, x25, x26
	cmp	x9, x24
	b.lo	LBB1_44
; %bb.14:                               ;   in Loop: Header=BB1_12 Depth=1
	lsl	w9, w10, #24
	tbnz	w9, #31, LBB1_33
; %bb.15:                               ;   in Loop: Header=BB1_12 Depth=1
	cmp	w10, #64
	b.hs	LBB1_10
; %bb.16:                               ;   in Loop: Header=BB1_12 Depth=1
	cmp	w24, #8
	b.ls	LBB1_47
; %bb.17:                               ;   in Loop: Header=BB1_12 Depth=1
	str	x26, [sp, #40]                  ; 8-byte Spill
	ldr	w26, [x21, x26]
	add	x9, x28, #3
	cmp	x9, x26
	b.lo	LBB1_48
; %bb.18:                               ;   in Loop: Header=BB1_12 Depth=1
	add	x0, x8, #8
	sub	x1, x24, #4
	ldr	x2, [sp, #48]                   ; 8-byte Reload
	mov	x3, x26
	bl	__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	mov	x8, #0                          ; =0x0
	str	xzr, [sp, #56]
	add	x9, x28, x22
	add	x23, x28, x22
	cmp	x22, x9
	b.hs	LBB1_37
; %bb.19:                               ;   in Loop: Header=BB1_12 Depth=1
	str	x28, [sp, #32]                  ; 8-byte Spill
	mov	x19, x22
	b	LBB1_22
LBB1_20:                                ;   in Loop: Header=BB1_22 Depth=2
	add	x8, x20, x19
	sub	x1, x8, x28
	add	x0, x20, x19
	mov	x2, x27
	bl	_memcpy
LBB1_21:                                ;   in Loop: Header=BB1_22 Depth=2
	add	x19, x27, x19
	cmp	x19, x23
	b.hs	LBB1_35
LBB1_22:                                ;   Parent Loop BB1_12 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_32 Depth 3
	add	x2, sp, #56
	ldr	x25, [sp, #48]                  ; 8-byte Reload
	mov	x0, x25
	mov	x1, x26
	bl	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	ldr	x21, [sp, #56]
	sub	x8, x23, x19
	sub	x9, x26, x21
	cmp	x0, x9
	ccmp	x0, x8, #2, ls
	b.hi	LBB1_41
; %bb.23:                               ;   in Loop: Header=BB1_22 Depth=2
	mov	x27, x0
	cbz	x0, LBB1_25
; %bb.24:                               ;   in Loop: Header=BB1_22 Depth=2
	add	x0, x20, x19
	add	x1, x25, x21
	mov	x2, x27
	bl	_memcpy
LBB1_25:                                ;   in Loop: Header=BB1_22 Depth=2
	add	x8, x21, x27
	str	x8, [sp, #56]
	add	x19, x27, x19
	subs	x21, x23, x19
	b.eq	LBB1_36
; %bb.26:                               ;   in Loop: Header=BB1_22 Depth=2
	add	x2, sp, #56
	mov	x0, x25
	mov	x1, x26
	bl	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	mov	x28, x0
	add	x2, sp, #56
	mov	x0, x25
	mov	x1, x26
	bl	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	sub	x8, x28, #1
	cmp	x8, x19
	b.hs	LBB1_42
; %bb.27:                               ;   in Loop: Header=BB1_22 Depth=2
	add	x27, x0, #8
	cmp	x27, x21
	b.hi	LBB1_42
; %bb.28:                               ;   in Loop: Header=BB1_22 Depth=2
	cmp	x28, x27
	b.hs	LBB1_20
; %bb.29:                               ;   in Loop: Header=BB1_22 Depth=2
	add	x25, x20, x19
	cmp	x28, #1
	b.ne	LBB1_31
; %bb.30:                               ;   in Loop: Header=BB1_22 Depth=2
	ldurb	w1, [x25, #-1]
	add	x0, x20, x19
	mov	x2, x27
	bl	_memset
	b	LBB1_21
LBB1_31:                                ;   in Loop: Header=BB1_22 Depth=2
	sub	x1, x25, x28
	add	x0, x20, x19
	mov	x2, x28
	bl	_memcpy
LBB1_32:                                ;   Parent Loop BB1_12 Depth=1
                                        ;     Parent Loop BB1_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x8, x27, x28
	cmp	x8, x28
	csel	x21, x8, x28, lo
	add	x0, x25, x28
	add	x1, x20, x19
	mov	x2, x21
	bl	_memcpy
	add	x28, x21, x28
	cmp	x28, x27
	b.lo	LBB1_32
	b	LBB1_21
LBB1_33:                                ;   in Loop: Header=BB1_12 Depth=1
	cmp	x28, x24
	b.ne	LBB1_45
; %bb.34:                               ;   in Loop: Header=BB1_12 Depth=1
	add	x0, x20, x22
	add	x1, x21, x26
	mov	x2, x24
	bl	_memcpy
	mov	w27, #131072                    ; =0x20000
	b	LBB1_11
LBB1_35:                                ;   in Loop: Header=BB1_12 Depth=1
	ldr	x8, [sp, #56]
LBB1_36:                                ;   in Loop: Header=BB1_12 Depth=1
	ldp	x21, x19, [sp, #16]             ; 16-byte Folded Reload
	ldr	x25, [sp, #8]                   ; 8-byte Reload
	mov	w27, #131072                    ; =0x20000
	ldr	x28, [sp, #32]                  ; 8-byte Reload
LBB1_37:                                ;   in Loop: Header=BB1_12 Depth=1
	cmp	x8, x26
	b.ne	LBB1_46
; %bb.38:                               ;   in Loop: Header=BB1_12 Depth=1
	ldr	x26, [sp, #40]                  ; 8-byte Reload
	b	LBB1_11
LBB1_39:
	cmp	x9, x25
	b.ne	LBB1_52
LBB1_40:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB1_41:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp33:                                 ; EH_LABEL
Lloh18:
	adrp	x1, l_.str.14@PAGE
Lloh19:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ; EH_LABEL
	b	LBB1_53
LBB1_42:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp36:                                 ; EH_LABEL
Lloh20:
	adrp	x1, l_.str.15@PAGE
Lloh21:
	add	x1, x1, l_.str.15@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ; EH_LABEL
	b	LBB1_53
LBB1_43:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp24:                                 ; EH_LABEL
Lloh22:
	adrp	x1, l_.str.4@PAGE
Lloh23:
	add	x1, x1, l_.str.4@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ; EH_LABEL
	b	LBB1_53
LBB1_44:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp48:                                 ; EH_LABEL
Lloh24:
	adrp	x1, l_.str.5@PAGE
Lloh25:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ; EH_LABEL
	b	LBB1_53
LBB1_45:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp27:                                 ; EH_LABEL
Lloh26:
	adrp	x1, l_.str.6@PAGE
Lloh27:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ; EH_LABEL
	b	LBB1_53
LBB1_46:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp39:                                 ; EH_LABEL
Lloh28:
	adrp	x1, l_.str.16@PAGE
Lloh29:
	add	x1, x1, l_.str.16@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ; EH_LABEL
	b	LBB1_53
LBB1_47:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp30:                                 ; EH_LABEL
Lloh30:
	adrp	x1, l_.str.7@PAGE
Lloh31:
	add	x1, x1, l_.str.7@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ; EH_LABEL
	b	LBB1_53
LBB1_48:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp45:                                 ; EH_LABEL
Lloh32:
	adrp	x1, l_.str.8@PAGE
Lloh33:
	add	x1, x1, l_.str.8@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ; EH_LABEL
	b	LBB1_53
LBB1_49:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp21:                                 ; EH_LABEL
Lloh34:
	adrp	x1, l_.str.1@PAGE
Lloh35:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ; EH_LABEL
	b	LBB1_53
LBB1_50:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp54:                                 ; EH_LABEL
Lloh36:
	adrp	x1, l_.str.3@PAGE
Lloh37:
	add	x1, x1, l_.str.3@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ; EH_LABEL
	b	LBB1_53
LBB1_51:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp51:                                 ; EH_LABEL
Lloh38:
	adrp	x1, l_.str.2@PAGE
Lloh39:
	add	x1, x1, l_.str.2@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ; EH_LABEL
	b	LBB1_53
LBB1_52:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp42:                                 ; EH_LABEL
Lloh40:
	adrp	x1, l_.str.9@PAGE
Lloh41:
	add	x1, x1, l_.str.9@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ; EH_LABEL
LBB1_53:
Lloh42:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh43:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh44:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh45:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB1_54:
Ltmp44:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_55:
Ltmp53:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_56:
Ltmp56:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_57:
Ltmp23:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_58:
Ltmp47:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_59:
Ltmp32:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_60:
Ltmp41:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_61:
Ltmp29:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_62:
Ltmp50:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_63:
Ltmp26:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_64:
Ltmp38:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_65:
Ltmp35:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpLdrGot	Lloh44, Lloh45
	.loh AdrpLdrGot	Lloh42, Lloh43
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ; >> Call Site 1 <<
	.uleb128 Ltmp33-Lfunc_begin1            ;   Call between Lfunc_begin1 and Ltmp33
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin1            ; >> Call Site 2 <<
	.uleb128 Ltmp34-Ltmp33                  ;   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin1            ;     jumps to Ltmp35
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin1            ; >> Call Site 3 <<
	.uleb128 Ltmp36-Ltmp34                  ;   Call between Ltmp34 and Ltmp36
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin1            ; >> Call Site 4 <<
	.uleb128 Ltmp37-Ltmp36                  ;   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin1            ;     jumps to Ltmp38
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin1            ; >> Call Site 5 <<
	.uleb128 Ltmp24-Ltmp37                  ;   Call between Ltmp37 and Ltmp24
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin1            ; >> Call Site 6 <<
	.uleb128 Ltmp25-Ltmp24                  ;   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin1            ;     jumps to Ltmp26
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin1            ; >> Call Site 7 <<
	.uleb128 Ltmp48-Ltmp25                  ;   Call between Ltmp25 and Ltmp48
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin1            ; >> Call Site 8 <<
	.uleb128 Ltmp49-Ltmp48                  ;   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin1            ;     jumps to Ltmp50
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin1            ; >> Call Site 9 <<
	.uleb128 Ltmp27-Ltmp49                  ;   Call between Ltmp49 and Ltmp27
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin1            ; >> Call Site 10 <<
	.uleb128 Ltmp28-Ltmp27                  ;   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin1            ;     jumps to Ltmp29
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin1            ; >> Call Site 11 <<
	.uleb128 Ltmp39-Ltmp28                  ;   Call between Ltmp28 and Ltmp39
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin1            ; >> Call Site 12 <<
	.uleb128 Ltmp40-Ltmp39                  ;   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin1            ;     jumps to Ltmp41
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin1            ; >> Call Site 13 <<
	.uleb128 Ltmp30-Ltmp40                  ;   Call between Ltmp40 and Ltmp30
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin1            ; >> Call Site 14 <<
	.uleb128 Ltmp31-Ltmp30                  ;   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin1            ;     jumps to Ltmp32
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin1            ; >> Call Site 15 <<
	.uleb128 Ltmp45-Ltmp31                  ;   Call between Ltmp31 and Ltmp45
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin1            ; >> Call Site 16 <<
	.uleb128 Ltmp46-Ltmp45                  ;   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin1            ;     jumps to Ltmp47
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin1            ; >> Call Site 17 <<
	.uleb128 Ltmp21-Ltmp46                  ;   Call between Ltmp46 and Ltmp21
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin1            ; >> Call Site 18 <<
	.uleb128 Ltmp22-Ltmp21                  ;   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin1            ;     jumps to Ltmp23
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin1            ; >> Call Site 19 <<
	.uleb128 Ltmp54-Ltmp22                  ;   Call between Ltmp22 and Ltmp54
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin1            ; >> Call Site 20 <<
	.uleb128 Ltmp55-Ltmp54                  ;   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin1            ;     jumps to Ltmp56
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin1            ; >> Call Site 21 <<
	.uleb128 Ltmp51-Ltmp55                  ;   Call between Ltmp55 and Ltmp51
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin1            ; >> Call Site 22 <<
	.uleb128 Ltmp52-Ltmp51                  ;   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin1            ;     jumps to Ltmp53
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin1            ; >> Call Site 23 <<
	.uleb128 Ltmp42-Ltmp52                  ;   Call between Ltmp52 and Ltmp42
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin1            ; >> Call Site 24 <<
	.uleb128 Ltmp43-Ltmp42                  ;   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin1            ;     jumps to Ltmp44
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin1            ; >> Call Site 25 <<
	.uleb128 Lfunc_end1-Ltmp43              ;   Call between Ltmp43 and Lfunc_end1
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm
__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm: ; @_ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cmp	x3, #128
	b.hs	LBB2_2
; %bb.1:
	mov	w8, #1                          ; =0x1
	b	LBB2_5
LBB2_2:
	cmp	x3, #4, lsl #12                 ; =16384
	b.hs	LBB2_4
; %bb.3:
	mov	w8, #2                          ; =0x2
	b	LBB2_5
LBB2_4:
	cmp	x3, #512, lsl #12               ; =2097152
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, hs
	lsr	x9, x3, #28
	cbnz	x9, LBB2_12
LBB2_5:
	ldr	x9, [x2]
	mov	w8, w8
	sub	x10, x1, x9
	cmp	x10, x8
	b.lo	LBB2_12
; %bb.6:
	mov	w10, #512                       ; =0x200
	lsr	w10, w10, w8
	mov	w11, #256                       ; =0x100
	lsr	w11, w11, w8
	sub	w11, w11, #1
	cmp	w8, #1
	csneg	w10, wzr, w10, eq
	and	w11, w3, w11
	orr	w10, w11, w10
	strb	w10, [x0, x9]
	b.ls	LBB2_11
; %bb.7:
	mov	w9, #8                          ; =0x8
	sub	w9, w9, w8
	lsr	x9, x3, x9
	ldr	x10, [x2]
	add	x10, x0, x10
	strb	w9, [x10, #1]
	cmp	w8, #2
	b.eq	LBB2_11
; %bb.8:
	lsr	x10, x9, #8
	ldr	x11, [x2]
	add	x11, x0, x11
	strb	w10, [x11, #2]
	cmp	w8, #3
	b.eq	LBB2_11
; %bb.9:
	lsr	x10, x9, #16
	ldr	x11, [x2]
	add	x11, x0, x11
	strb	w10, [x11, #3]
	cmp	w8, #4
	b.eq	LBB2_11
; %bb.10:
	lsr	x10, x9, #24
	ldr	x11, [x2]
	add	x11, x0, x11
	strb	w10, [x11, #4]
	lsr	x10, x9, #32
	ldr	x11, [x2]
	add	x11, x0, x11
	strb	w10, [x11, #5]
	lsr	x9, x9, #40
	ldr	x10, [x2]
	add	x10, x0, x10
	strb	w9, [x10, #6]
LBB2_11:
	ldr	x9, [x2]
	add	x8, x9, x8
	str	x8, [x2]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB2_12:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp57:                                 ; EH_LABEL
Lloh46:
	adrp	x1, l_.str.13@PAGE
Lloh47:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ; EH_LABEL
; %bb.13:
Lloh48:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh49:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh50:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh51:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB2_14:
Ltmp59:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpLdrGot	Lloh50, Lloh51
	.loh AdrpLdrGot	Lloh48, Lloh49
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ; >> Call Site 1 <<
	.uleb128 Ltmp57-Lfunc_begin2            ;   Call between Lfunc_begin2 and Ltmp57
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin2            ; >> Call Site 2 <<
	.uleb128 Ltmp58-Ltmp57                  ;   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin2            ;     jumps to Ltmp59
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin2            ; >> Call Site 3 <<
	.uleb128 Lfunc_end2-Ltmp58              ;   Call between Ltmp58 and Lfunc_end2
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm: ; @_ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception3
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x2]
	subs	x10, x1, x8
	b.ls	LBB3_13
; %bb.1:
	ldrsb	w9, [x0, x8]
	tbnz	w9, #31, LBB3_4
; %bb.2:
	cmp	x1, x8
	b.eq	LBB3_12
; %bb.3:
	and	x0, x9, #0xff
	mov	w9, #1                          ; =0x1
	add	x8, x8, x9
	str	x8, [x2]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB3_4:
	mov	x11, x0
	and	w12, w9, #0xff
	cmp	w12, #192
	b.hs	LBB3_6
; %bb.5:
	mov	w9, #2                          ; =0x2
	b	LBB3_7
LBB3_6:
	cmp	w12, #224
	mov	w9, #3                          ; =0x3
	cinc	w9, w9, hs
	cmp	w12, #239
	b.hi	LBB3_12
LBB3_7:
	mov	w9, w9
	cmp	x10, x9
	b.lo	LBB3_12
; %bb.8:
	mov	w10, #256                       ; =0x100
	lsr	w10, w10, w9
	sub	w10, w10, #1
	and	w0, w10, w12
	mov	w10, #8                         ; =0x8
	sub	w10, w10, w9
	add	x11, x8, x11
	add	x11, x11, #1
	sub	x12, x9, #1
LBB3_9:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w13, [x11], #1
	lsl	x13, x13, x10
	orr	x0, x13, x0
	add	w10, w10, #8
	subs	x12, x12, #1
	b.ne	LBB3_9
; %bb.10:
	lsl	w10, w9, #3
	sub	w10, w10, w9
	sub	w10, w10, #7
	lsr	x10, x0, x10
	cbz	x10, LBB3_14
; %bb.11:
	add	x8, x8, x9
	str	x8, [x2]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB3_12:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp66:                                 ; EH_LABEL
Lloh52:
	adrp	x1, l_.str.18@PAGE
Lloh53:
	add	x1, x1, l_.str.18@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ; EH_LABEL
	b	LBB3_15
LBB3_13:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp60:                                 ; EH_LABEL
Lloh54:
	adrp	x1, l_.str.17@PAGE
Lloh55:
	add	x1, x1, l_.str.17@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ; EH_LABEL
	b	LBB3_15
LBB3_14:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp63:                                 ; EH_LABEL
Lloh56:
	adrp	x1, l_.str.19@PAGE
Lloh57:
	add	x1, x1, l_.str.19@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ; EH_LABEL
LBB3_15:
Lloh58:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh59:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh60:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh61:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB3_16:
Ltmp65:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_17:
Ltmp62:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_18:
Ltmp68:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpLdrGot	Lloh60, Lloh61
	.loh AdrpLdrGot	Lloh58, Lloh59
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception3:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3      ; >> Call Site 1 <<
	.uleb128 Ltmp66-Lfunc_begin3            ;   Call between Lfunc_begin3 and Ltmp66
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin3            ; >> Call Site 2 <<
	.uleb128 Ltmp67-Ltmp66                  ;   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin3            ;     jumps to Ltmp68
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin3            ; >> Call Site 3 <<
	.uleb128 Ltmp60-Ltmp67                  ;   Call between Ltmp67 and Ltmp60
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin3            ; >> Call Site 4 <<
	.uleb128 Ltmp61-Ltmp60                  ;   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin3            ;     jumps to Ltmp62
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin3            ; >> Call Site 5 <<
	.uleb128 Ltmp63-Ltmp61                  ;   Call between Ltmp61 and Ltmp63
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin3            ; >> Call Site 6 <<
	.uleb128 Ltmp64-Ltmp63                  ;   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin3            ;     jumps to Ltmp65
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin3            ; >> Call Site 7 <<
	.uleb128 Lfunc_end3-Ltmp64              ;   Call between Ltmp64 and Lfunc_end3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end3:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"match packet capacity"

l_.str.1:                               ; @.str.1
	.asciz	"match packet output extent"

l_.str.2:                               ; @.str.2
	.asciz	"match stored extent"

l_.str.3:                               ; @.str.3
	.asciz	"match packet coding"

l_.str.4:                               ; @.str.4
	.asciz	"match block header extent"

l_.str.5:                               ; @.str.5
	.asciz	"match block extent"

l_.str.6:                               ; @.str.6
	.asciz	"match stored block extent"

l_.str.7:                               ; @.str.7
	.asciz	"match coded block header"

l_.str.8:                               ; @.str.8
	.asciz	"match parsed bound"

l_.str.9:                               ; @.str.9
	.asciz	"match exact packet extent"

l_.str.10:                              ; @.str.10
	.asciz	"match literal capacity"

l_.str.11:                              ; @.str.11
	.asciz	"match tail capacity"

l_.str.12:                              ; @.str.12
	.asciz	"match parse bound"

l_.str.13:                              ; @.str.13
	.asciz	"prefix integer capacity"

l_.str.14:                              ; @.str.14
	.asciz	"match literal extent"

l_.str.15:                              ; @.str.15
	.asciz	"match reference extent"

l_.str.16:                              ; @.str.16
	.asciz	"match exact control consumption"

l_.str.17:                              ; @.str.17
	.asciz	"prefix integer extent"

l_.str.18:                              ; @.str.18
	.asciz	"prefix integer width"

l_.str.19:                              ; @.str.19
	.asciz	"prefix integer canonical form"

.subsections_via_symbols
