	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.globl	__ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE ## -- Begin function _ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE
	.p2align	4
__ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE: ## @_ZN10cng_prefix6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15EncodeWorkspaceE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$2097160, %rsi                  ## imm = 0x200008
	ja	LBB0_126
## %bb.1:
	movq	%rdx, %rbx
	movq	%rsi, -56(%rbp)                 ## 8-byte Spill
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	addl	$131071, %eax                   ## imm = 0x1FFFF
	shrl	$15, %eax
	andl	$252, %eax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	addq	%rdx, %rax
	addq	$5, %rax
	cmpq	%rax, %rcx
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	jb	LBB0_126
## %bb.2:
	movq	%r8, %r15
	movq	%rdi, %r13
	movb	$17, (%rbx)
	movb	%al, 1(%rbx)
	movq	-56(%rbp), %rax                 ## 8-byte Reload
                                        ## kill: def $eax killed $eax killed $rax
	shrl	$16, %eax
	cmpq	$68, -56(%rbp)                  ## 8-byte Folded Reload
	movl	$67, %ecx
	cmovaeq	-56(%rbp), %rcx                 ## 8-byte Folded Reload
	shrq	$2, %rcx
	cmpq	$16384, %rcx                    ## imm = 0x4000
	movl	$16384, %edx                    ## imm = 0x4000
	cmovbq	%rcx, %rdx
	movq	-56(%rbp), %rcx                 ## 8-byte Reload
	movb	%ch, 2(%rbx)
	bsrq	%rdx, %rcx
	notl	%ecx
	movabsq	$-9223372036854775808, %r14     ## imm = 0x8000000000000000
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r14
	movb	%al, 3(%rbx)
	movb	$0, 4(%rbx)
	movq	%r14, %rsi
	shlq	$4, %rsi
	movq	%r8, %rdi
	callq	___bzero
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	testq	%rdx, %rdx
	je	LBB0_117
## %bb.3:
	leaq	5(%rdx), %rax
	movq	%rax, -176(%rbp)                ## 8-byte Spill
	decq	%r14
	leaq	262144(%r15), %rax
	movq	%rax, -48(%rbp)                 ## 8-byte Spill
	leaq	393232(%r15), %rax
	movq	%rax, -136(%rbp)                ## 8-byte Spill
	leaq	8(%r13), %rax
	movq	%rax, -144(%rbp)                ## 8-byte Spill
	movl	$5, %eax
	xorl	%esi, %esi
	movq	%r13, -64(%rbp)                 ## 8-byte Spill
	movq	%r15, -160(%rbp)                ## 8-byte Spill
	movq	%r14, %r9
	movq	%r14, -112(%rbp)                ## 8-byte Spill
	movq	%rbx, -96(%rbp)                 ## 8-byte Spill
	jmp	LBB0_6
	.p2align	4
LBB0_4:                                 ##   in Loop: Header=BB0_6 Depth=1
	movq	-96(%rbp), %rbx                 ## 8-byte Reload
	movq	-104(%rbp), %rcx                ## 8-byte Reload
	movb	%dl, (%rbx,%rcx)
	movb	%dh, 1(%rbx,%rcx)
	movl	%edx, %eax
	shrl	$16, %eax
	movb	%al, 2(%rbx,%rcx)
	movb	$-128, 3(%rbx,%rcx)
	movq	%rcx, %r12
	leaq	(%rbx,%rcx), %rdi
	addq	$4, %rdi
	movq	-120(%rbp), %rsi                ## 8-byte Reload
	callq	_memcpy
	movq	-72(%rbp), %rax                 ## 8-byte Reload
	addq	$4, %rax
LBB0_5:                                 ##   in Loop: Header=BB0_6 Depth=1
	addq	%r12, %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movq	-128(%rbp), %rsi                ## 8-byte Reload
	cmpq	%rdx, %rsi
	movq	-112(%rbp), %r9                 ## 8-byte Reload
	jae	LBB0_115
LBB0_6:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_10 Depth 2
                                        ##       Child Loop BB0_23 Depth 3
                                        ##       Child Loop BB0_26 Depth 3
                                        ##       Child Loop BB0_39 Depth 3
                                        ##       Child Loop BB0_43 Depth 3
                                        ##       Child Loop BB0_16 Depth 3
                                        ##       Child Loop BB0_59 Depth 3
	movq	%rax, -104(%rbp)                ## 8-byte Spill
	movq	%rdx, %rax
	subq	%rsi, %rax
	cmpq	$131072, %rax                   ## imm = 0x20000
	movl	$131072, %ecx                   ## imm = 0x20000
	cmovbq	%rax, %rcx
	leaq	(%rsi,%r13), %rdi
	leaq	(%rcx,%rsi), %rdx
	cmpq	$8, %rax
	movq	%rcx, -72(%rbp)                 ## 8-byte Spill
	movq	%rdx, -128(%rbp)                ## 8-byte Spill
	movq	%rdi, -120(%rbp)                ## 8-byte Spill
	jb	LBB0_113
## %bb.7:                               ##   in Loop: Header=BB0_6 Depth=1
	xorl	%ebx, %ebx
	movq	$0, -152(%rbp)                  ## 8-byte Folded Spill
	movq	%rsi, %r14
	movq	$0, -88(%rbp)                   ## 8-byte Folded Spill
	jmp	LBB0_10
	.p2align	4
LBB0_8:                                 ##   in Loop: Header=BB0_10 Depth=2
	movq	$0, -88(%rbp)                   ## 8-byte Folded Spill
	movq	%r12, %rsi
LBB0_9:                                 ##   in Loop: Header=BB0_10 Depth=2
	movq	-128(%rbp), %rcx                ## 8-byte Reload
	subq	%r12, %rcx
	movq	%r12, %r14
	cmpq	$7, %rcx
	jbe	LBB0_106
LBB0_10:                                ##   Parent Loop BB0_6 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB0_23 Depth 3
                                        ##       Child Loop BB0_26 Depth 3
                                        ##       Child Loop BB0_39 Depth 3
                                        ##       Child Loop BB0_43 Depth 3
                                        ##       Child Loop BB0_16 Depth 3
                                        ##       Child Loop BB0_59 Depth 3
	leaq	(%r14,%r13), %rax
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
	movl	(%r13,%r14), %r8d
	imull	$-1640531535, %r8d, %eax        ## imm = 0x9E3779B1
	shrl	$18, %eax
	andl	%r9d, %eax
	shll	$4, %eax
	movl	(%r15,%rax), %r11d
	movl	4(%r15,%rax), %r9d
	movq	8(%r15,%rax), %r10
	movl	%r11d, 8(%r15,%rax)
	movl	%r9d, 12(%r15,%rax)
	leal	1(%r14), %edx
	movl	%r8d, (%r15,%rax)
	movl	%edx, 4(%r15,%rax)
	movl	4(%r13,%r14), %edi
	movq	%rcx, %rax
	andq	$-8, %rax
	cmpq	$8, %rax
	jne	LBB0_19
## %bb.11:                              ##   in Loop: Header=BB0_10 Depth=2
	testl	%r9d, %r9d
	je	LBB0_30
## %bb.12:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$0, %r15d
	movl	$0, %r12d
	cmpl	%r8d, %r11d
	leaq	(%r13,%r14), %rdx
	jne	LBB0_50
## %bb.13:                              ##   in Loop: Header=BB0_10 Depth=2
	leal	-1(%r9), %r11d
	movl	4(%r13,%r11), %r13d
	xorl	%r12d, %r12d
	cmpl	%edi, %r13d
	sete	%r12b
	movl	$0, %r15d
	cmoveq	%r11, %r15
	shll	$3, %r12d
	cmpq	$9, %rcx
	jb	LBB0_49
## %bb.14:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%edi, %r13d
	movq	-64(%rbp), %r13                 ## 8-byte Reload
	jne	LBB0_50
## %bb.15:                              ##   in Loop: Header=BB0_10 Depth=2
	leaq	(%r11,%r13), %r15
	movl	$8, %r12d
	.p2align	4
LBB0_16:                                ##   Parent Loop BB0_6 Depth=1
                                        ##     Parent Loop BB0_10 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movzbl	(%r15,%r12), %eax
	cmpb	(%rdx,%r12), %al
	jne	LBB0_48
## %bb.17:                              ##   in Loop: Header=BB0_16 Depth=3
	incq	%r12
	cmpq	%r12, %rcx
	jne	LBB0_16
## %bb.18:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	%r11, %r15
	movq	%rcx, %r12
	jmp	LBB0_50
	.p2align	4
LBB0_19:                                ##   in Loop: Header=BB0_10 Depth=2
	testl	%r9d, %r9d
	je	LBB0_29
## %bb.20:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$0, %r15d
	movl	$0, %r12d
	cmpl	%r8d, %r11d
	jne	LBB0_32
## %bb.21:                              ##   in Loop: Header=BB0_10 Depth=2
	leal	-1(%r9), %r15d
	cmpl	%edi, 4(%r13,%r15)
	jne	LBB0_29
## %bb.22:                              ##   in Loop: Header=BB0_10 Depth=2
	leaq	(%r15,%r13), %r11
	movq	$-8, %r12
	movq	-144(%rbp), %r13                ## 8-byte Reload
	.p2align	4
LBB0_23:                                ##   Parent Loop BB0_6 Depth=1
                                        ##     Parent Loop BB0_10 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	(%r13,%r15), %rax
	movq	(%r13,%r14), %rdx
	cmpq	%rdx, %rax
	jne	LBB0_31
## %bb.24:                              ##   in Loop: Header=BB0_23 Depth=3
	leaq	(%rcx,%r12), %rax
	addq	$-8, %rax
	addq	$-8, %r12
	addq	$8, %r13
	cmpq	$7, %rax
	ja	LBB0_23
## %bb.25:                              ##   in Loop: Header=BB0_10 Depth=2
	negq	%r12
	cmpq	%rcx, %r12
	movq	-64(%rbp), %r13                 ## 8-byte Reload
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	jae	LBB0_32
	.p2align	4
LBB0_26:                                ##   Parent Loop BB0_6 Depth=1
                                        ##     Parent Loop BB0_10 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movzbl	(%r11,%r12), %eax
	cmpb	(%rdx,%r12), %al
	jne	LBB0_32
## %bb.27:                              ##   in Loop: Header=BB0_26 Depth=3
	incq	%r12
	cmpq	%r12, %rcx
	jne	LBB0_26
## %bb.28:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	%rcx, %r12
	jmp	LBB0_32
	.p2align	4
LBB0_29:                                ##   in Loop: Header=BB0_10 Depth=2
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	jmp	LBB0_32
LBB0_30:                                ##   in Loop: Header=BB0_10 Depth=2
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	jmp	LBB0_50
LBB0_31:                                ##   in Loop: Header=BB0_10 Depth=2
	xorq	%rax, %rdx
	rep		bsfq	%rdx, %rax
	shrl	$3, %eax
	subq	%r12, %rax
	movq	%rax, %r12
	movq	-64(%rbp), %r13                 ## 8-byte Reload
	.p2align	4
LBB0_32:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%r10, %r11
	shrq	$32, %r11
	sete	%al
	cmpl	%r10d, %r8d
	setne	%dl
	cmpl	%r11d, %r9d
	sete	%r8b
	orb	%al, %r8b
	orb	%dl, %r8b
	jne	LBB0_69
## %bb.33:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$4294967295, %eax               ## imm = 0xFFFFFFFF
	addl	%eax, %r11d
	testq	%r12, %r12
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	je	LBB0_37
## %bb.34:                              ##   in Loop: Header=BB0_10 Depth=2
	leaq	(%r12,%r13), %rax
	movzbl	-1(%r11,%rax), %eax
	cmpb	-1(%rdx,%r12), %al
	jne	LBB0_64
## %bb.35:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpq	%rcx, %r12
	jne	LBB0_37
## %bb.36:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%r11d, %r15d
	jae	LBB0_55
LBB0_37:                                ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%edi, 4(%r13,%r11)
	jne	LBB0_69
## %bb.38:                              ##   in Loop: Header=BB0_10 Depth=2
	leaq	(%r11,%r13), %r8
	movq	$-8, %rdi
	movq	-144(%rbp), %r9                 ## 8-byte Reload
	.p2align	4
LBB0_39:                                ##   Parent Loop BB0_6 Depth=1
                                        ##     Parent Loop BB0_10 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	(%r9,%r11), %rax
	movq	(%r9,%r14), %rdx
	cmpq	%rdx, %rax
	jne	LBB0_65
## %bb.40:                              ##   in Loop: Header=BB0_39 Depth=3
	leaq	(%rcx,%rdi), %rax
	addq	$-8, %rax
	addq	$-8, %rdi
	addq	$8, %r9
	cmpq	$7, %rax
	ja	LBB0_39
## %bb.41:                              ##   in Loop: Header=BB0_10 Depth=2
	negq	%rdi
	cmpq	%rcx, %rdi
	jae	LBB0_46
## %bb.42:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	.p2align	4
LBB0_43:                                ##   Parent Loop BB0_6 Depth=1
                                        ##     Parent Loop BB0_10 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movzbl	(%r8,%rdi), %eax
	cmpb	(%rdx,%rdi), %al
	jne	LBB0_46
## %bb.44:                              ##   in Loop: Header=BB0_43 Depth=3
	incq	%rdi
	cmpq	%rdi, %rcx
	jne	LBB0_43
## %bb.45:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	%rcx, %rdi
LBB0_46:                                ##   in Loop: Header=BB0_10 Depth=2
	cmpq	%r12, %rdi
	jbe	LBB0_66
	jmp	LBB0_68
LBB0_48:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%r11, %r15
	jmp	LBB0_50
LBB0_49:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	-64(%rbp), %r13                 ## 8-byte Reload
	.p2align	4
LBB0_50:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%r10, %r11
	shrq	$32, %r11
	sete	%al
	cmpl	%r10d, %r8d
	setne	%dl
	cmpl	%r11d, %r9d
	sete	%r8b
	orb	%al, %r8b
	orb	%dl, %r8b
	jne	LBB0_69
## %bb.51:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$4294967295, %eax               ## imm = 0xFFFFFFFF
	addl	%eax, %r11d
	testq	%r12, %r12
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	je	LBB0_56
## %bb.52:                              ##   in Loop: Header=BB0_10 Depth=2
	leaq	(%r12,%r13), %rax
	movzbl	-1(%r11,%rax), %eax
	cmpb	-1(%rdx,%r12), %al
	jne	LBB0_64
## %bb.53:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpq	%rcx, %r12
	jne	LBB0_56
## %bb.54:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%r11d, %r15d
	jb	LBB0_56
LBB0_55:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%rcx, %r12
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	jmp	LBB0_70
LBB0_56:                                ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%edi, 4(%r13,%r11)
	jne	LBB0_69
## %bb.57:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$8, %eax
	cmpq	$9, %rcx
	jb	LBB0_62
## %bb.58:                              ##   in Loop: Header=BB0_10 Depth=2
	leaq	(%r11,%r13), %rdx
	.p2align	4
LBB0_59:                                ##   Parent Loop BB0_6 Depth=1
                                        ##     Parent Loop BB0_10 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movzbl	(%rdx,%rax), %edi
	movq	-80(%rbp), %r8                  ## 8-byte Reload
	cmpb	(%r8,%rax), %dil
	jne	LBB0_62
## %bb.60:                              ##   in Loop: Header=BB0_59 Depth=3
	incq	%rax
	cmpq	%rax, %rcx
	jne	LBB0_59
## %bb.61:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	%rcx, %rax
LBB0_62:                                ##   in Loop: Header=BB0_10 Depth=2
	cmpq	%r12, %rax
	jbe	LBB0_103
## %bb.63:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	%rax, %r12
	movq	%r11, %r15
LBB0_64:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	jmp	LBB0_70
LBB0_65:                                ##   in Loop: Header=BB0_10 Depth=2
	xorq	%rax, %rdx
	rep		bsfq	%rdx, %rax
	shrl	$3, %eax
	subq	%rdi, %rax
	movq	%rax, %rdi
	cmpq	%r12, %rdi
	ja	LBB0_68
LBB0_66:                                ##   in Loop: Header=BB0_10 Depth=2
	jne	LBB0_69
## %bb.67:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%r11d, %r15d
	jae	LBB0_69
LBB0_68:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%r11, %r15
	movq	%rdi, %r12
	.p2align	4
LBB0_69:                                ##   in Loop: Header=BB0_10 Depth=2
	testq	%r12, %r12
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	je	LBB0_102
LBB0_70:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%r14, %r13
	subq	%rsi, %r13
	movl	$1, %eax
	cmpq	$128, %r13
	jb	LBB0_73
## %bb.71:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$2, %eax
	cmpq	$16384, %r13                    ## imm = 0x4000
	jb	LBB0_73
## %bb.72:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpq	$2097152, %r13                  ## imm = 0x200000
	movl	$4, %eax
	sbbl	$0, %eax
	cmpq	$268435455, %r13                ## imm = 0xFFFFFFF
	ja	LBB0_119
LBB0_73:                                ##   in Loop: Header=BB0_10 Depth=2
	movl	$131088, %ecx                   ## imm = 0x20010
	subq	%rbx, %rcx
	movl	%eax, %eax
	cmpq	%rax, %rcx
	jb	LBB0_119
## %bb.74:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$512, %edx                      ## imm = 0x200
	movl	%eax, %ecx
	shrl	%cl, %edx
	negl	%edx
	cmpq	$1, %rax
	movl	$0, %ecx
	cmovel	%ecx, %edx
	movl	$256, %edi                      ## imm = 0x100
	movl	%eax, %ecx
	shrl	%cl, %edi
	decl	%edi
	andl	%r13d, %edi
	orl	%edx, %edi
	movb	%dil, (%r8,%rbx)
	cmpl	$2, %eax
	jb	LBB0_79
## %bb.75:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	%r8, %rdi
	movb	$8, %cl
	subb	%al, %cl
	movq	%r13, %rdx
	shrq	%cl, %rdx
	movb	%dl, 1(%r8,%rbx)
	cmpq	$2, %rax
	je	LBB0_79
## %bb.76:                              ##   in Loop: Header=BB0_10 Depth=2
	movb	%dh, 2(%rdi,%rbx)
	cmpl	$3, %eax
	je	LBB0_79
## %bb.77:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	%edx, %ecx
	shrl	$16, %ecx
	movb	%cl, 3(%rdi,%rbx)
	cmpl	$4, %eax
	je	LBB0_79
## %bb.78:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	%edx, %ecx
	shrl	$24, %ecx
	movb	%cl, 4(%rdi,%rbx)
	movq	%rdx, %rcx
	shrq	$32, %rcx
	movb	%cl, 5(%rdi,%rbx)
	shrq	$40, %rdx
	movb	%dl, 6(%rdi,%rbx)
	.p2align	4
LBB0_79:                                ##   in Loop: Header=BB0_10 Depth=2
	addq	%rax, %rbx
	movl	$131088, %eax                   ## imm = 0x20010
	subq	%rbx, %rax
	cmpq	%rax, %r13
	ja	LBB0_122
## %bb.80:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpq	%rsi, %r14
	je	LBB0_82
## %bb.81:                              ##   in Loop: Header=BB0_10 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%rbx), %rdi
	addq	-64(%rbp), %rsi                 ## 8-byte Folded Reload
	movq	%r13, %rdx
	callq	_memcpy
LBB0_82:                                ##   in Loop: Header=BB0_10 Depth=2
	movq	%r14, %rdx
	subq	%r15, %rdx
	movl	$1, %eax
	cmpq	$128, %rdx
	jb	LBB0_85
## %bb.83:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$2, %eax
	cmpq	$16384, %rdx                    ## imm = 0x4000
	jb	LBB0_85
## %bb.84:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpq	$2097152, %rdx                  ## imm = 0x200000
	movl	$4, %eax
	sbbl	$0, %eax
	cmpq	$268435455, %rdx                ## imm = 0xFFFFFFF
	ja	LBB0_121
LBB0_85:                                ##   in Loop: Header=BB0_10 Depth=2
	addq	%r13, %rbx
	movl	$131088, %ecx                   ## imm = 0x20010
	subq	%rbx, %rcx
	movl	%eax, %eax
	cmpq	%rax, %rcx
	jb	LBB0_121
## %bb.86:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$512, %esi                      ## imm = 0x200
	movl	%eax, %ecx
	shrl	%cl, %esi
	negl	%esi
	cmpq	$1, %rax
	movl	$0, %ecx
	cmovel	%ecx, %esi
	movl	$256, %edi                      ## imm = 0x100
	movl	%eax, %ecx
	shrl	%cl, %edi
	decl	%edi
	andl	%edx, %edi
	orl	%esi, %edi
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	movb	%dil, (%rcx,%rbx)
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	cmpl	$2, %eax
	jb	LBB0_91
## %bb.87:                              ##   in Loop: Header=BB0_10 Depth=2
	movb	$8, %cl
	subb	%al, %cl
	shrq	%cl, %rdx
	movb	%dl, 1(%rsi,%rbx)
	cmpq	$2, %rax
	je	LBB0_91
## %bb.88:                              ##   in Loop: Header=BB0_10 Depth=2
	movb	%dh, 2(%rsi,%rbx)
	cmpl	$3, %eax
	je	LBB0_91
## %bb.89:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	%edx, %ecx
	shrl	$16, %ecx
	movb	%cl, 3(%rsi,%rbx)
	cmpl	$4, %eax
	je	LBB0_91
## %bb.90:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	%edx, %ecx
	shrl	$24, %ecx
	movb	%cl, 4(%rsi,%rbx)
	movq	%rdx, %rcx
	shrq	$32, %rcx
	movb	%cl, 5(%rsi,%rbx)
	shrq	$40, %rdx
	movb	%dl, 6(%rsi,%rbx)
	.p2align	4
LBB0_91:                                ##   in Loop: Header=BB0_10 Depth=2
	leaq	-8(%r12), %rdx
	movl	$1, %ecx
	cmpq	$128, %rdx
	movq	-64(%rbp), %r13                 ## 8-byte Reload
	movq	-160(%rbp), %r15                ## 8-byte Reload
	movq	-112(%rbp), %r9                 ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
	jb	LBB0_94
## %bb.92:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$2, %ecx
	cmpq	$16384, %rdx                    ## imm = 0x4000
	jb	LBB0_94
## %bb.93:                              ##   in Loop: Header=BB0_10 Depth=2
	cmpq	$2097152, %rdx                  ## imm = 0x200000
	movl	$4, %ecx
	sbbl	$0, %ecx
	cmpq	$268435455, %rdx                ## imm = 0xFFFFFFF
	ja	LBB0_120
LBB0_94:                                ##   in Loop: Header=BB0_10 Depth=2
	addq	%rax, %rbx
	movl	$131088, %esi                   ## imm = 0x20010
	subq	%rbx, %rsi
	movl	%ecx, %eax
	cmpq	%rax, %rsi
	jb	LBB0_120
## %bb.95:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	$512, %esi                      ## imm = 0x200
	movl	%eax, %ecx
	shrl	%cl, %esi
	negl	%esi
	cmpq	$1, %rax
	movl	$0, %ecx
	cmovel	%ecx, %esi
	movl	$256, %r8d                      ## imm = 0x100
	movl	%eax, %ecx
	shrl	%cl, %r8d
	decl	%r8d
	andl	%edx, %r8d
	orl	%esi, %r8d
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	movb	%r8b, (%rcx,%rbx)
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	cmpl	$2, %eax
	jb	LBB0_100
## %bb.96:                              ##   in Loop: Header=BB0_10 Depth=2
	movb	$8, %cl
	subb	%al, %cl
	shrq	%cl, %rdx
	movb	%dl, 1(%rsi,%rbx)
	cmpq	$2, %rax
	je	LBB0_100
## %bb.97:                              ##   in Loop: Header=BB0_10 Depth=2
	movb	%dh, 2(%rsi,%rbx)
	cmpl	$3, %eax
	je	LBB0_100
## %bb.98:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	%edx, %ecx
	shrl	$16, %ecx
	movb	%cl, 3(%rsi,%rbx)
	cmpl	$4, %eax
	je	LBB0_100
## %bb.99:                              ##   in Loop: Header=BB0_10 Depth=2
	movl	%edx, %ecx
	shrl	$24, %ecx
	movb	%cl, 4(%rsi,%rbx)
	movq	%rdx, %rcx
	shrq	$32, %rcx
	movb	%cl, 5(%rsi,%rbx)
	shrq	$40, %rdx
	movb	%dl, 6(%rsi,%rbx)
	.p2align	4
LBB0_100:                               ##   in Loop: Header=BB0_10 Depth=2
	movq	%rsi, %r8
	addq	%rax, %rbx
	addq	%r14, %r12
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	subq	%r12, %rax
	addq	$2, %rax
	movb	$1, %cl
	movq	%rcx, -152(%rbp)                ## 8-byte Spill
	cmpq	$4, %rax
	jb	LBB0_8
## %bb.101:                             ##   in Loop: Header=BB0_10 Depth=2
	movl	-2(%r13,%r12), %eax
	imull	$-1640531535, %eax, %ecx        ## imm = 0x9E3779B1
	shrl	$18, %ecx
	andl	%r9d, %ecx
	shll	$4, %ecx
	movq	(%r15,%rcx), %rdx
	movq	%rdx, 8(%r15,%rcx)
	leal	-1(%r12), %edx
	movl	%eax, (%r15,%rcx)
	movl	%edx, 4(%r15,%rcx)
	jmp	LBB0_8
	.p2align	4
LBB0_102:                               ##   in Loop: Header=BB0_10 Depth=2
	movq	-88(%rbp), %r12                 ## 8-byte Reload
	incq	%r12
	movq	%r12, -88(%rbp)                 ## 8-byte Spill
	shrq	$6, %r12
	incq	%r12
	cmpq	%r12, %rcx
	cmovbq	%rcx, %r12
	addq	%r14, %r12
	movq	-160(%rbp), %r15                ## 8-byte Reload
	movq	-112(%rbp), %r9                 ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
	jmp	LBB0_9
LBB0_103:                               ##   in Loop: Header=BB0_10 Depth=2
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	jne	LBB0_70
## %bb.104:                             ##   in Loop: Header=BB0_10 Depth=2
	cmpl	%r11d, %r15d
	jae	LBB0_70
## %bb.105:                             ##   in Loop: Header=BB0_10 Depth=2
	movq	%rax, %r12
	movq	%r11, %r15
	jmp	LBB0_70
	.p2align	4
LBB0_106:                               ##   in Loop: Header=BB0_6 Depth=1
	movq	%rbx, -168(%rbp)
	testb	$1, -152(%rbp)                  ## 1-byte Folded Reload
	movq	-128(%rbp), %rdx                ## 8-byte Reload
	movq	-72(%rbp), %r14                 ## 8-byte Reload
	je	LBB0_113
## %bb.107:                             ##   in Loop: Header=BB0_6 Depth=1
	movq	%rdx, %r13
	subq	%rsi, %r13
	je	LBB0_110
## %bb.108:                             ##   in Loop: Header=BB0_6 Depth=1
	movq	%rsi, %r12
	movl	$131088, %esi                   ## imm = 0x20010
	movq	%r8, %r14
	movq	%r8, %rdi
	leaq	-168(%rbp), %rdx
	movq	%r13, %rcx
	callq	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm
	movq	-168(%rbp), %rbx
	movl	$131088, %eax                   ## imm = 0x20010
	subq	%rbx, %rax
	cmpq	%rax, %r13
	ja	LBB0_125
## %bb.109:                             ##   in Loop: Header=BB0_6 Depth=1
	leaq	(%r14,%rbx), %rdi
	movq	%r12, %rsi
	addq	-64(%rbp), %rsi                 ## 8-byte Folded Reload
	movq	%r13, %rdx
	callq	_memcpy
	addq	%r13, %rbx
	movq	%r14, %r8
	movq	-72(%rbp), %r14                 ## 8-byte Reload
LBB0_110:                               ##   in Loop: Header=BB0_6 Depth=1
	leaq	3(%r14), %rax
	cmpq	%rax, %rbx
	movq	-136(%rbp), %r12                ## 8-byte Reload
	ja	LBB0_124
## %bb.111:                             ##   in Loop: Header=BB0_6 Depth=1
	movl	$263168, %ecx                   ## imm = 0x40400
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	callq	__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	leaq	4(%rax), %rcx
	cmpq	%r14, %rcx
	movq	-64(%rbp), %r13                 ## 8-byte Reload
	movq	%r14, %rdx
	jae	LBB0_4
## %bb.112:                             ##   in Loop: Header=BB0_6 Depth=1
	leal	4(%rax), %ecx
	movq	%r12, %rsi
	movq	-96(%rbp), %r14                 ## 8-byte Reload
	movq	-104(%rbp), %rdx                ## 8-byte Reload
	movl	%ecx, (%r14,%rdx)
	movl	%ebx, 4(%r14,%rdx)
	movq	%rdx, %r12
	leaq	(%r14,%rdx), %rdi
	addq	$8, %rdi
	movq	%rax, %rdx
	movq	%rax, %rbx
	callq	_memcpy
	addq	$8, %rbx
	movq	%rbx, %rax
	movq	%r14, %rbx
	jmp	LBB0_5
	.p2align	4
LBB0_113:                               ##   in Loop: Header=BB0_6 Depth=1
	movl	$263168, %ecx                   ## imm = 0x40400
	movq	-72(%rbp), %rsi                 ## 8-byte Reload
	movq	-136(%rbp), %r14                ## 8-byte Reload
	movq	%r14, %rdx
	callq	__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %rax
	jae	LBB0_4
## %bb.114:                             ##   in Loop: Header=BB0_6 Depth=1
	movq	-96(%rbp), %rbx                 ## 8-byte Reload
	movq	-104(%rbp), %rdx                ## 8-byte Reload
	movb	%al, (%rbx,%rdx)
	movb	%ah, 1(%rbx,%rdx)
	movl	%eax, %ecx
	shrl	$16, %ecx
	movb	%cl, 2(%rbx,%rdx)
	movb	$64, 3(%rbx,%rdx)
	movq	%rdx, %r12
	leaq	(%rbx,%rdx), %rdi
	addq	$4, %rdi
	movq	%r14, %rsi
	movq	%rax, %rdx
	movq	%rax, %r14
	callq	_memcpy
	addq	$4, %r14
	movq	%r14, %rax
	jmp	LBB0_5
LBB0_115:
	movq	-176(%rbp), %r14                ## 8-byte Reload
	cmpq	%r14, %rax
	jb	LBB0_118
## %bb.116:
	movb	$0, (%rbx)
	addq	$5, %rbx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	callq	_memcpy
	movq	%r14, %rax
	jmp	LBB0_118
LBB0_117:
	movb	$0, (%rbx)
	movl	$5, %eax
LBB0_118:
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB0_119:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp9:                                  ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ## EH_LABEL
	jmp	LBB0_123
LBB0_120:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp0:                                  ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ## EH_LABEL
	jmp	LBB0_123
LBB0_121:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp3:                                  ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ## EH_LABEL
	jmp	LBB0_123
LBB0_122:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp6:                                  ## EH_LABEL
	leaq	L_.str.10(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ## EH_LABEL
LBB0_123:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB0_124:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp15:                                 ## EH_LABEL
	leaq	L_.str.12(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ## EH_LABEL
	jmp	LBB0_123
LBB0_125:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp12:                                 ## EH_LABEL
	leaq	L_.str.11(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ## EH_LABEL
	jmp	LBB0_123
LBB0_126:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp18:                                 ## EH_LABEL
	leaq	L_.str(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ## EH_LABEL
	jmp	LBB0_123
LBB0_127:
Ltmp20:                                 ## EH_LABEL
	jmp	LBB0_134
LBB0_128:
Ltmp14:                                 ## EH_LABEL
	jmp	LBB0_134
LBB0_129:
Ltmp17:                                 ## EH_LABEL
	jmp	LBB0_134
LBB0_130:
Ltmp8:                                  ## EH_LABEL
	jmp	LBB0_134
LBB0_131:
Ltmp5:                                  ## EH_LABEL
	jmp	LBB0_134
LBB0_132:
Ltmp2:                                  ## EH_LABEL
	jmp	LBB0_134
LBB0_133:
Ltmp11:                                 ## EH_LABEL
LBB0_134:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ## >> Call Site 1 <<
	.uleb128 Ltmp9-Lfunc_begin0             ##   Call between Lfunc_begin0 and Ltmp9
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ## >> Call Site 2 <<
	.uleb128 Ltmp10-Ltmp9                   ##   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin0            ##     jumps to Ltmp11
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin0            ## >> Call Site 3 <<
	.uleb128 Ltmp0-Ltmp10                   ##   Call between Ltmp10 and Ltmp0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ## >> Call Site 4 <<
	.uleb128 Ltmp1-Ltmp0                    ##   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ##     jumps to Ltmp2
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ## >> Call Site 5 <<
	.uleb128 Ltmp3-Ltmp1                    ##   Call between Ltmp1 and Ltmp3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ## >> Call Site 6 <<
	.uleb128 Ltmp4-Ltmp3                    ##   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ##     jumps to Ltmp5
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ## >> Call Site 7 <<
	.uleb128 Ltmp6-Ltmp4                    ##   Call between Ltmp4 and Ltmp6
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ## >> Call Site 8 <<
	.uleb128 Ltmp7-Ltmp6                    ##   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin0             ##     jumps to Ltmp8
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin0             ## >> Call Site 9 <<
	.uleb128 Ltmp15-Ltmp7                   ##   Call between Ltmp7 and Ltmp15
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin0            ## >> Call Site 10 <<
	.uleb128 Ltmp16-Ltmp15                  ##   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin0            ##     jumps to Ltmp17
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin0            ## >> Call Site 11 <<
	.uleb128 Ltmp12-Ltmp16                  ##   Call between Ltmp16 and Ltmp12
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin0            ## >> Call Site 12 <<
	.uleb128 Ltmp13-Ltmp12                  ##   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin0            ##     jumps to Ltmp14
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin0            ## >> Call Site 13 <<
	.uleb128 Ltmp18-Ltmp13                  ##   Call between Ltmp13 and Ltmp18
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin0            ## >> Call Site 14 <<
	.uleb128 Ltmp19-Ltmp18                  ##   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin0            ##     jumps to Ltmp20
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin0            ## >> Call Site 15 <<
	.uleb128 Lfunc_end0-Ltmp19              ##   Call between Ltmp19 and Lfunc_end0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE ## -- Begin function _ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE
	.p2align	4
__ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE: ## @_ZN10cng_prefix6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERN15cng_match_trial15DecodeWorkspaceE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdx, -48(%rbp)                 ## 8-byte Spill
	cmpq	$5, %rsi
	jb	LBB1_3
## %bb.1:
	movq	%rcx, %r10
	cmpq	$2097160, %rcx                  ## imm = 0x200008
	ja	LBB1_3
## %bb.2:
	movq	%rdi, %r9
	movl	1(%rdi), %eax
	cmpq	%rax, %r10
	jne	LBB1_3
## %bb.7:
	movq	%rsi, %r11
	movzbl	(%r9), %eax
	cmpl	$17, %eax
	je	LBB1_14
## %bb.8:
	testl	%eax, %eax
	jne	LBB1_18
## %bb.9:
	leaq	5(%r10), %rax
	cmpq	%rax, %r11
	jne	LBB1_10
## %bb.12:
	testq	%r10, %r10
	je	LBB1_66
## %bb.13:
	addq	$5, %r9
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	movq	%r9, %rsi
	movq	%r10, %rdx
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	_memcpy                         ## TAILCALL
LBB1_14:
	testq	%r10, %r10
	je	LBB1_18
## %bb.15:
	movq	%r8, %r13
	movl	$5, %edi
	xorl	%r12d, %r12d
	movq	%r10, -88(%rbp)                 ## 8-byte Spill
	movq	%r9, -104(%rbp)                 ## 8-byte Spill
	movq	%r11, -96(%rbp)                 ## 8-byte Spill
	movq	%r8, -136(%rbp)                 ## 8-byte Spill
	jmp	LBB1_16
	.p2align	4
LBB1_33:                                ##   in Loop: Header=BB1_16 Depth=1
	leaq	(%r9,%rsi), %rdi
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %rdx
	movq	%r8, %rsi
	movq	%r15, %rcx
	movq	%r8, %r15
	movq	%r9, %rbx
	movq	%r11, %r14
	callq	__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	movq	%r14, %r11
	movq	-88(%rbp), %r10                 ## 8-byte Reload
	movq	%rbx, %r9
	movq	%r15, %rax
	movq	-112(%rbp), %r14                ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
LBB1_65:                                ##   in Loop: Header=BB1_16 Depth=1
	addq	%rax, %rdi
	addq	%r14, %r12
	cmpq	%r10, %r12
	jae	LBB1_20
LBB1_16:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_42 Depth 2
                                        ##       Child Loop BB1_58 Depth 3
	movq	%r11, %rax
	subq	%rdi, %rax
	cmpq	$3, %rax
	jbe	LBB1_17
## %bb.24:                              ##   in Loop: Header=BB1_16 Depth=1
	movzwl	(%r9,%rdi), %eax
	movzbl	2(%r9,%rdi), %edx
	shll	$16, %edx
	orl	%eax, %edx
	movzbl	3(%r9,%rdi), %eax
	movl	%eax, %ecx
	shll	$24, %ecx
	movl	%ecx, %r8d
	andl	$1056964608, %r8d               ## imm = 0x3F000000
	orl	%edx, %r8d
	movq	%r10, %r15
	subq	%r12, %r15
	cmpq	$131072, %r15                   ## imm = 0x20000
	movl	$131072, %edx                   ## imm = 0x20000
	cmovaeq	%rdx, %r15
	leaq	4(%rdi), %rsi
	movq	%r11, %rdx
	subq	%rsi, %rdx
	cmpq	%r8, %rdx
	jb	LBB1_25
## %bb.27:                              ##   in Loop: Header=BB1_16 Depth=1
	testl	%ecx, %ecx
	js	LBB1_28
## %bb.32:                              ##   in Loop: Header=BB1_16 Depth=1
	cmpb	$64, %al
	movq	%rsi, -120(%rbp)                ## 8-byte Spill
	movq	%r15, -112(%rbp)                ## 8-byte Spill
	jae	LBB1_33
## %bb.34:                              ##   in Loop: Header=BB1_16 Depth=1
	cmpl	$8, %r8d
	jbe	LBB1_35
## %bb.37:                              ##   in Loop: Header=BB1_16 Depth=1
	movl	(%r9,%rsi), %ebx
	leaq	3(%r15), %rax
	cmpq	%rbx, %rax
	jb	LBB1_38
## %bb.40:                              ##   in Loop: Header=BB1_16 Depth=1
	addq	%r9, %rdi
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	leaq	-4(%r8), %rsi
	addq	$8, %rdi
	movq	%r13, %rdx
	movq	%rbx, %rcx
	callq	__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	leaq	(%r15,%r12), %rax
	movq	$0, -56(%rbp)
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
	cmpq	%rax, %r12
	movq	%rbx, -64(%rbp)                 ## 8-byte Spill
	movq	%r12, -128(%rbp)                ## 8-byte Spill
	jb	LBB1_42
## %bb.41:                              ##   in Loop: Header=BB1_16 Depth=1
	xorl	%r15d, %r15d
	jmp	LBB1_61
	.p2align	4
LBB1_54:                                ##   in Loop: Header=BB1_42 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %rdi
	movq	%rdi, %rsi
	subq	%r14, %rsi
	movq	%r13, %rdx
	callq	_memcpy
LBB1_59:                                ##   in Loop: Header=BB1_42 Depth=2
	addq	%r13, %r12
	cmpq	-80(%rbp), %r12                 ## 8-byte Folded Reload
	movq	-136(%rbp), %r13                ## 8-byte Reload
	movq	-64(%rbp), %rbx                 ## 8-byte Reload
	jae	LBB1_60
LBB1_42:                                ##   Parent Loop BB1_16 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB1_58 Depth 3
	movq	%r13, %rdi
	movq	%rbx, %rsi
	leaq	-56(%rbp), %rdx
	callq	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	movq	-56(%rbp), %r15
	subq	%r15, %rbx
	cmpq	%rbx, %rax
	ja	LBB1_44
## %bb.43:                              ##   in Loop: Header=BB1_42 Depth=2
	movq	%rax, %r14
	movq	-80(%rbp), %rax                 ## 8-byte Reload
	subq	%r12, %rax
	cmpq	%rax, %r14
	ja	LBB1_44
## %bb.46:                              ##   in Loop: Header=BB1_42 Depth=2
	testq	%r14, %r14
	je	LBB1_48
## %bb.47:                              ##   in Loop: Header=BB1_42 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %rdi
	leaq	(%r15,%r13), %rsi
	movq	%r14, %rdx
	callq	_memcpy
LBB1_48:                                ##   in Loop: Header=BB1_42 Depth=2
	addq	%r14, %r15
	movq	%r15, -56(%rbp)
	addq	%r14, %r12
	movq	-80(%rbp), %rbx                 ## 8-byte Reload
	subq	%r12, %rbx
	je	LBB1_61
## %bb.49:                              ##   in Loop: Header=BB1_42 Depth=2
	movq	%r13, %rdi
	movq	-64(%rbp), %rsi                 ## 8-byte Reload
	leaq	-56(%rbp), %r15
	movq	%r15, %rdx
	callq	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	movq	%rax, %r14
	movq	%r13, %rdi
	movq	-64(%rbp), %rsi                 ## 8-byte Reload
	movq	%r15, %rdx
	callq	__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	movq	%rax, %r13
	leaq	-1(%r14), %rax
	cmpq	%r12, %rax
	jae	LBB1_51
## %bb.50:                              ##   in Loop: Header=BB1_42 Depth=2
	addq	$8, %r13
	cmpq	%rbx, %r13
	ja	LBB1_51
## %bb.53:                              ##   in Loop: Header=BB1_42 Depth=2
	cmpq	%r13, %r14
	jae	LBB1_54
## %bb.55:                              ##   in Loop: Header=BB1_42 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %r15
	cmpq	$1, %r14
	jne	LBB1_57
## %bb.56:                              ##   in Loop: Header=BB1_42 Depth=2
	movzbl	-1(%r15), %esi
	movq	%r15, %rdi
	movq	%r13, %rdx
	callq	_memset
	jmp	LBB1_59
	.p2align	4
LBB1_57:                                ##   in Loop: Header=BB1_42 Depth=2
	movq	%r15, %rsi
	subq	%r14, %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	_memcpy
	.p2align	4
LBB1_58:                                ##   Parent Loop BB1_16 Depth=1
                                        ##     Parent Loop BB1_42 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	%r14, %rbx
	movq	%r13, %r14
	subq	%rbx, %r14
	cmpq	%rbx, %r14
	cmovaeq	%rbx, %r14
	leaq	(%r15,%rbx), %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	_memcpy
	addq	%rbx, %r14
	cmpq	%r13, %r14
	jb	LBB1_58
	jmp	LBB1_59
	.p2align	4
LBB1_28:                                ##   in Loop: Header=BB1_16 Depth=1
	cmpq	%r8, %r15
	jne	LBB1_29
## %bb.31:                              ##   in Loop: Header=BB1_16 Depth=1
	movq	%r10, %rbx
	movq	%r15, %r14
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %rdi
	movq	%rsi, %r15
	addq	%r9, %rsi
	movq	%r8, %rdx
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	callq	_memcpy
	movq	-104(%rbp), %r9                 ## 8-byte Reload
	movq	-72(%rbp), %rax                 ## 8-byte Reload
	movq	%r15, %rdi
	movq	%rbx, %r10
	movq	-96(%rbp), %r11                 ## 8-byte Reload
	jmp	LBB1_65
LBB1_60:                                ##   in Loop: Header=BB1_16 Depth=1
	movq	-56(%rbp), %r15
LBB1_61:                                ##   in Loop: Header=BB1_16 Depth=1
	cmpq	-64(%rbp), %r15                 ## 8-byte Folded Reload
	jne	LBB1_62
## %bb.64:                              ##   in Loop: Header=BB1_16 Depth=1
	movq	-88(%rbp), %r10                 ## 8-byte Reload
	movq	-104(%rbp), %r9                 ## 8-byte Reload
	movq	-96(%rbp), %r11                 ## 8-byte Reload
	movq	-128(%rbp), %r12                ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
	movq	-72(%rbp), %rax                 ## 8-byte Reload
	movq	-112(%rbp), %r14                ## 8-byte Reload
	jmp	LBB1_65
LBB1_20:
	cmpq	%r11, %rdi
	jne	LBB1_21
LBB1_66:
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB1_44:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp33:                                 ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_51:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp36:                                 ## EH_LABEL
	leaq	L_.str.15(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_17:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp24:                                 ## EH_LABEL
	leaq	L_.str.4(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_25:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp48:                                 ## EH_LABEL
	leaq	L_.str.5(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_29:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp27:                                 ## EH_LABEL
	leaq	L_.str.6(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_35:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp30:                                 ## EH_LABEL
	leaq	L_.str.7(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_38:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp45:                                 ## EH_LABEL
	leaq	L_.str.8(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_62:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp39:                                 ## EH_LABEL
	leaq	L_.str.16(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_3:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp21:                                 ## EH_LABEL
	leaq	L_.str.1(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_18:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp54:                                 ## EH_LABEL
	leaq	L_.str.3(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_10:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp51:                                 ## EH_LABEL
	leaq	L_.str.2(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ## EH_LABEL
	jmp	LBB1_4
LBB1_21:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp42:                                 ## EH_LABEL
	leaq	L_.str.9(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ## EH_LABEL
LBB1_4:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB1_22:
Ltmp44:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_11:
Ltmp53:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_19:
Ltmp56:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_5:
Ltmp23:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_63:
Ltmp41:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_39:
Ltmp47:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_36:
Ltmp32:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_30:
Ltmp29:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_26:
Ltmp50:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_23:
Ltmp26:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_52:
Ltmp38:                                 ## EH_LABEL
	jmp	LBB1_6
LBB1_45:
Ltmp35:                                 ## EH_LABEL
LBB1_6:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ## >> Call Site 1 <<
	.uleb128 Ltmp33-Lfunc_begin1            ##   Call between Lfunc_begin1 and Ltmp33
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin1            ## >> Call Site 2 <<
	.uleb128 Ltmp34-Ltmp33                  ##   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin1            ##     jumps to Ltmp35
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin1            ## >> Call Site 3 <<
	.uleb128 Ltmp36-Ltmp34                  ##   Call between Ltmp34 and Ltmp36
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin1            ## >> Call Site 4 <<
	.uleb128 Ltmp37-Ltmp36                  ##   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin1            ##     jumps to Ltmp38
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin1            ## >> Call Site 5 <<
	.uleb128 Ltmp24-Ltmp37                  ##   Call between Ltmp37 and Ltmp24
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin1            ## >> Call Site 6 <<
	.uleb128 Ltmp25-Ltmp24                  ##   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin1            ##     jumps to Ltmp26
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin1            ## >> Call Site 7 <<
	.uleb128 Ltmp48-Ltmp25                  ##   Call between Ltmp25 and Ltmp48
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin1            ## >> Call Site 8 <<
	.uleb128 Ltmp49-Ltmp48                  ##   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin1            ##     jumps to Ltmp50
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin1            ## >> Call Site 9 <<
	.uleb128 Ltmp27-Ltmp49                  ##   Call between Ltmp49 and Ltmp27
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin1            ## >> Call Site 10 <<
	.uleb128 Ltmp28-Ltmp27                  ##   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin1            ##     jumps to Ltmp29
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin1            ## >> Call Site 11 <<
	.uleb128 Ltmp30-Ltmp28                  ##   Call between Ltmp28 and Ltmp30
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin1            ## >> Call Site 12 <<
	.uleb128 Ltmp31-Ltmp30                  ##   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin1            ##     jumps to Ltmp32
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin1            ## >> Call Site 13 <<
	.uleb128 Ltmp45-Ltmp31                  ##   Call between Ltmp31 and Ltmp45
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin1            ## >> Call Site 14 <<
	.uleb128 Ltmp46-Ltmp45                  ##   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin1            ##     jumps to Ltmp47
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin1            ## >> Call Site 15 <<
	.uleb128 Ltmp39-Ltmp46                  ##   Call between Ltmp46 and Ltmp39
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin1            ## >> Call Site 16 <<
	.uleb128 Ltmp40-Ltmp39                  ##   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin1            ##     jumps to Ltmp41
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin1            ## >> Call Site 17 <<
	.uleb128 Ltmp21-Ltmp40                  ##   Call between Ltmp40 and Ltmp21
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin1            ## >> Call Site 18 <<
	.uleb128 Ltmp22-Ltmp21                  ##   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin1            ##     jumps to Ltmp23
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin1            ## >> Call Site 19 <<
	.uleb128 Ltmp54-Ltmp22                  ##   Call between Ltmp22 and Ltmp54
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin1            ## >> Call Site 20 <<
	.uleb128 Ltmp55-Ltmp54                  ##   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin1            ##     jumps to Ltmp56
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin1            ## >> Call Site 21 <<
	.uleb128 Ltmp51-Ltmp55                  ##   Call between Ltmp55 and Ltmp51
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin1            ## >> Call Site 22 <<
	.uleb128 Ltmp52-Ltmp51                  ##   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin1            ##     jumps to Ltmp53
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin1            ## >> Call Site 23 <<
	.uleb128 Ltmp42-Ltmp52                  ##   Call between Ltmp52 and Ltmp42
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin1            ## >> Call Site 24 <<
	.uleb128 Ltmp43-Ltmp42                  ##   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin1            ##     jumps to Ltmp44
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin1            ## >> Call Site 25 <<
	.uleb128 Lfunc_end1-Ltmp43              ##   Call between Ltmp43 and Lfunc_end1
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm
__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm: ## @_ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIhLm18446744073709551615EEERmm
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	%rcx, %rax
	movl	$1, %ecx
	cmpq	$128, %rax
	jb	LBB2_3
## %bb.1:
	movl	$2, %ecx
	cmpq	$16384, %rax                    ## imm = 0x4000
	jb	LBB2_3
## %bb.2:
	cmpq	$2097152, %rax                  ## imm = 0x200000
	movl	$4, %ecx
	sbbl	$0, %ecx
	cmpq	$268435455, %rax                ## imm = 0xFFFFFFF
	ja	LBB2_4
LBB2_3:
	movq	(%rdx), %r9
	subq	%r9, %rsi
	movl	%ecx, %r8d
	cmpq	%r8, %rsi
	jb	LBB2_4
## %bb.7:
	movl	$512, %esi                      ## imm = 0x200
	movl	%r8d, %ecx
	shrl	%cl, %esi
	negl	%esi
	xorl	%r10d, %r10d
	cmpq	$1, %r8
	cmovnel	%esi, %r10d
	movl	$256, %esi                      ## imm = 0x100
	shrl	%cl, %esi
	decl	%esi
	andl	%eax, %esi
	orl	%r10d, %esi
	movb	%sil, (%rdi,%r9)
	cmpl	$1, %r8d
	jbe	LBB2_12
## %bb.8:
	movb	$8, %cl
	subb	%r8b, %cl
	shrq	%cl, %rax
	movq	(%rdx), %rcx
	movb	%al, 1(%rdi,%rcx)
	cmpq	$2, %r8
	je	LBB2_12
## %bb.9:
	movq	(%rdx), %rcx
	movb	%ah, 2(%rdi,%rcx)
	cmpl	$3, %r8d
	je	LBB2_12
## %bb.10:
	movl	%eax, %ecx
	shrl	$16, %ecx
	movq	(%rdx), %rsi
	movb	%cl, 3(%rdi,%rsi)
	cmpl	$4, %r8d
	je	LBB2_12
## %bb.11:
	movl	%eax, %ecx
	shrl	$24, %ecx
	movq	(%rdx), %rsi
	movb	%cl, 4(%rdi,%rsi)
	movq	%rax, %rcx
	shrq	$32, %rcx
	movq	(%rdx), %rsi
	movb	%cl, 5(%rdi,%rsi)
	shrq	$40, %rax
	movq	(%rdx), %rcx
	movb	%al, 6(%rdi,%rcx)
LBB2_12:
	addq	%r8, (%rdx)
	popq	%rbx
	popq	%r14
	popq	%rbp
	retq
LBB2_4:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp57:                                 ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ## EH_LABEL
## %bb.5:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB2_6:
Ltmp59:                                 ## EH_LABEL
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ## >> Call Site 1 <<
	.uleb128 Ltmp57-Lfunc_begin2            ##   Call between Lfunc_begin2 and Ltmp57
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin2            ## >> Call Site 2 <<
	.uleb128 Ltmp58-Ltmp57                  ##   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin2            ##     jumps to Ltmp59
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin2            ## >> Call Site 3 <<
	.uleb128 Lfunc_end2-Ltmp58              ##   Call between Ltmp58 and Lfunc_end2
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
__ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm: ## @_ZN10cng_prefix12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception3
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rdx), %r9
	movq	%rsi, %rax
	subq	%r9, %rax
	jbe	LBB3_1
## %bb.5:
	movzbl	(%rdi,%r9), %r8d
	testb	%r8b, %r8b
	js	LBB3_6
## %bb.10:
	cmpq	%r9, %rsi
	je	LBB3_9
## %bb.11:
	movl	%r8d, %eax
	movl	$1, %esi
	jmp	LBB3_12
LBB3_6:
	movl	$2, %ecx
	cmpb	$-64, %r8b
	jb	LBB3_8
## %bb.7:
	cmpb	$-32, %r8b
	movl	$4, %ecx
	sbbl	$0, %ecx
	cmpb	$-17, %r8b
	ja	LBB3_9
LBB3_8:
	movl	%ecx, %esi
	cmpq	%rsi, %rax
	jb	LBB3_9
## %bb.14:
	movl	$256, %eax                      ## imm = 0x100
	movl	%esi, %ecx
	shrl	%cl, %eax
	decl	%eax
	andl	%r8d, %eax
	leaq	-1(%rsi), %rbx
	movl	%ebx, %r10d
	andl	$3, %r10d
	leal	-2(%rsi), %ecx
	movl	$1, %r11d
	cmpl	$3, %ecx
	jb	LBB3_19
## %bb.15:
	andq	$-4, %rbx
	movl	$32, %r8d
	subl	%esi, %r8d
	leaq	(%r9,%rdi), %r14
	addq	$4, %r14
	xorl	%r11d, %r11d
	.p2align	4
LBB3_16:                                ## =>This Inner Loop Header: Depth=1
	movzbl	-3(%r14,%r11), %r15d
	leal	-24(%r8), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r15
	movzbl	-2(%r14,%r11), %r12d
	leal	-16(%r8), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r12
	movzbl	-1(%r14,%r11), %r13d
	leal	-8(%r8), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r13
	orq	%r15, %rax
	orq	%r12, %r13
	orq	%rax, %r13
	movzbl	(%r14,%r11), %eax
	movl	%r8d, %ecx
	shlq	%cl, %rax
	orq	%r13, %rax
	addq	$4, %r11
	addl	$32, %r8d
	cmpq	%r11, %rbx
	jne	LBB3_16
## %bb.17:
	testq	%r10, %r10
	je	LBB3_21
## %bb.18:
	incq	%r11
LBB3_19:
	leal	(,%r11,8), %ecx
	subl	%esi, %ecx
	addq	%r11, %rdi
	addq	%r9, %rdi
	xorl	%r8d, %r8d
	.p2align	4
LBB3_20:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r8), %r11d
	shlq	%cl, %r11
	orq	%r11, %rax
	incq	%r8
	addl	$8, %ecx
	cmpq	%r8, %r10
	jne	LBB3_20
LBB3_21:
	leal	(,%rsi,8), %ecx
	subl	%esi, %ecx
	addb	$-7, %cl
	movq	%rax, %rdi
                                        ## kill: def $cl killed $cl killed $ecx
	shrq	%cl, %rdi
	testq	%rdi, %rdi
	je	LBB3_22
LBB3_12:
	addq	%rsi, %r9
	movq	%r9, (%rdx)
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB3_9:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp66:                                 ## EH_LABEL
	leaq	L_.str.18(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ## EH_LABEL
	jmp	LBB3_2
LBB3_1:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp60:                                 ## EH_LABEL
	leaq	L_.str.17(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ## EH_LABEL
	jmp	LBB3_2
LBB3_22:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp63:                                 ## EH_LABEL
	leaq	L_.str.19(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ## EH_LABEL
LBB3_2:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB3_23:
Ltmp65:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_3:
Ltmp62:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_13:
Ltmp68:                                 ## EH_LABEL
LBB3_4:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception3:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3      ## >> Call Site 1 <<
	.uleb128 Ltmp66-Lfunc_begin3            ##   Call between Lfunc_begin3 and Ltmp66
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin3            ## >> Call Site 2 <<
	.uleb128 Ltmp67-Ltmp66                  ##   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin3            ##     jumps to Ltmp68
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin3            ## >> Call Site 3 <<
	.uleb128 Ltmp60-Ltmp67                  ##   Call between Ltmp67 and Ltmp60
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin3            ## >> Call Site 4 <<
	.uleb128 Ltmp61-Ltmp60                  ##   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin3            ##     jumps to Ltmp62
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin3            ## >> Call Site 5 <<
	.uleb128 Ltmp63-Ltmp61                  ##   Call between Ltmp61 and Ltmp63
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin3            ## >> Call Site 6 <<
	.uleb128 Ltmp64-Ltmp63                  ##   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin3            ##     jumps to Ltmp65
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin3            ## >> Call Site 7 <<
	.uleb128 Lfunc_end3-Ltmp64              ##   Call between Ltmp64 and Lfunc_end3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end3:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__cstring,cstring_literals
L_.str:                                 ## @.str
	.asciz	"match packet capacity"

L_.str.1:                               ## @.str.1
	.asciz	"match packet output extent"

L_.str.2:                               ## @.str.2
	.asciz	"match stored extent"

L_.str.3:                               ## @.str.3
	.asciz	"match packet coding"

L_.str.4:                               ## @.str.4
	.asciz	"match block header extent"

L_.str.5:                               ## @.str.5
	.asciz	"match block extent"

L_.str.6:                               ## @.str.6
	.asciz	"match stored block extent"

L_.str.7:                               ## @.str.7
	.asciz	"match coded block header"

L_.str.8:                               ## @.str.8
	.asciz	"match parsed bound"

L_.str.9:                               ## @.str.9
	.asciz	"match exact packet extent"

L_.str.10:                              ## @.str.10
	.asciz	"match literal capacity"

L_.str.11:                              ## @.str.11
	.asciz	"match tail capacity"

L_.str.12:                              ## @.str.12
	.asciz	"match parse bound"

L_.str.13:                              ## @.str.13
	.asciz	"prefix integer capacity"

L_.str.14:                              ## @.str.14
	.asciz	"match literal extent"

L_.str.15:                              ## @.str.15
	.asciz	"match reference extent"

L_.str.16:                              ## @.str.16
	.asciz	"match exact control consumption"

L_.str.17:                              ## @.str.17
	.asciz	"prefix integer extent"

L_.str.18:                              ## @.str.18
	.asciz	"prefix integer width"

L_.str.19:                              ## @.str.19
	.asciz	"prefix integer canonical form"

.subsections_via_symbols
