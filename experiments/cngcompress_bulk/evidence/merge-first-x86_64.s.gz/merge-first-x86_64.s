	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.globl	__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	24(%rbp), %rax
	testq	%rax, %rax
	je	LBB0_3
## %bb.1:
	movq	16(%rbp), %rsi
	xorl	%r9d, %r9d
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	.p2align	4
LBB0_2:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rbx
	movq	%rcx, %r10
	movq	%r9, %r11
	shrq	$3, %r11
	movl	%r9d, %ecx
	andb	$7, %cl
	movl	$1, %r14d
	shll	%cl, %r14d
	movzbl	(%rdi,%r11), %r15d
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	testl	%r15d, %r14d
	leaq	(%rdx,%rbx), %r14
	leaq	(%r8,%r10), %r15
	cmoveq	%r14, %r15
	setne	%cl
	sete	%r11b
	addq	%rbx, %r11
	addq	%r10, %rcx
	movzbl	(%r15), %r10d
	movb	%r10b, (%rsi,%r9)
	incq	%r9
	cmpq	%r9, %rax
	jne	LBB0_2
LBB0_3:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -96(%rbp)                  ## 8-byte Spill
	movq	%rcx, %r14
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	movq	16(%rbp), %rax
	movq	24(%rbp), %rcx
	movq	%rcx, -80(%rbp)                 ## 8-byte Spill
	andq	$-8, %rcx
	movq	%rdi, -88(%rbp)                 ## 8-byte Spill
	je	LBB1_1
## %bb.2:
	xorl	%r10d, %r10d
	movq	%rdi, %r12
	xorl	%ebx, %ebx
	xorl	%r11d, %r11d
	movq	%r14, -72(%rbp)                 ## 8-byte Spill
	jmp	LBB1_3
	.p2align	4
LBB1_6:                                 ##   in Loop: Header=BB1_3 Depth=1
	movq	(%r8,%r11), %rsi
	movq	%rsi, (%rax,%r10)
	addq	$8, %r11
LBB1_29:                                ##   in Loop: Header=BB1_3 Depth=1
	addq	$8, %r10
	incq	%r12
	cmpq	%rcx, %r10
	jae	LBB1_30
LBB1_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r12), %esi
	cmpl	$255, %esi
	je	LBB1_6
## %bb.4:                               ##   in Loop: Header=BB1_3 Depth=1
	testl	%esi, %esi
	jne	LBB1_7
## %bb.5:                               ##   in Loop: Header=BB1_3 Depth=1
	movq	(%rdx,%rbx), %rsi
	movq	%rsi, (%rax,%r10)
	addq	$8, %rbx
	jmp	LBB1_29
	.p2align	4
LBB1_7:                                 ##   in Loop: Header=BB1_3 Depth=1
	leaq	(%rsi,%rsi,8), %r15
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rsi
	movzbl	8(%rsi,%r15), %r9d
	movq	%r14, %r13
	subq	%rbx, %r13
	jne	LBB1_9
## %bb.8:                               ##   in Loop: Header=BB1_3 Depth=1
	xorl	%esi, %esi
	jmp	LBB1_17
LBB1_9:                                 ##   in Loop: Header=BB1_3 Depth=1
	movzbl	(%rdx,%rbx), %esi
	cmpq	$1, %r13
	je	LBB1_17
## %bb.10:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	1(%rdx,%rbx), %edi
	shll	$8, %edi
	orq	%rdi, %rsi
	cmpq	$2, %r13
	je	LBB1_17
## %bb.11:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	2(%rdx,%rbx), %edi
	shll	$16, %edi
	orq	%rdi, %rsi
	cmpq	$3, %r13
	je	LBB1_17
## %bb.12:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	3(%rdx,%rbx), %edi
	shll	$24, %edi
	orq	%rdi, %rsi
	cmpq	$4, %r13
	je	LBB1_17
## %bb.13:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	4(%rdx,%rbx), %edi
	shlq	$32, %rdi
	orq	%rdi, %rsi
	cmpq	$5, %r13
	je	LBB1_17
## %bb.14:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	5(%rdx,%rbx), %edi
	shlq	$40, %rdi
	orq	%rdi, %rsi
	cmpq	$6, %r13
	je	LBB1_17
## %bb.15:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	6(%rdx,%rbx), %edi
	shlq	$48, %rdi
	orq	%rdi, %rsi
	cmpq	$7, %r13
	je	LBB1_17
## %bb.16:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	7(%rdx,%rbx), %edi
	shlq	$56, %rdi
	orq	%rdi, %rsi
	.p2align	4
LBB1_17:                                ##   in Loop: Header=BB1_3 Depth=1
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rdi
	addq	%rdi, %r15
	movq	-96(%rbp), %rdi                 ## 8-byte Reload
	subq	%r11, %rdi
	jne	LBB1_19
## %bb.18:                              ##   in Loop: Header=BB1_3 Depth=1
	xorl	%r13d, %r13d
	jmp	LBB1_28
LBB1_19:                                ##   in Loop: Header=BB1_3 Depth=1
	movzbl	(%r8,%r11), %r13d
	cmpq	$1, %rdi
	je	LBB1_28
## %bb.20:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	1(%r8,%r11), %r14d
	shll	$8, %r14d
	orq	%r14, %r13
	cmpq	$2, %rdi
	je	LBB1_27
## %bb.21:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	2(%r8,%r11), %r14d
	shll	$16, %r14d
	orq	%r14, %r13
	cmpq	$3, %rdi
	je	LBB1_27
## %bb.22:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	3(%r8,%r11), %r14d
	shll	$24, %r14d
	orq	%r14, %r13
	cmpq	$4, %rdi
	je	LBB1_27
## %bb.23:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	4(%r8,%r11), %r14d
	shlq	$32, %r14
	orq	%r14, %r13
	cmpq	$5, %rdi
	je	LBB1_27
## %bb.24:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	5(%r8,%r11), %r14d
	shlq	$40, %r14
	orq	%r14, %r13
	cmpq	$6, %rdi
	je	LBB1_27
## %bb.25:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	6(%r8,%r11), %r14d
	shlq	$48, %r14
	orq	%r14, %r13
	cmpq	$7, %rdi
	je	LBB1_27
## %bb.26:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	7(%r8,%r11), %edi
	shlq	$56, %rdi
	orq	%rdi, %r13
LBB1_27:                                ##   in Loop: Header=BB1_3 Depth=1
	movq	-72(%rbp), %r14                 ## 8-byte Reload
LBB1_28:                                ##   in Loop: Header=BB1_3 Depth=1
	movq	%rsi, -64(%rbp)
	movq	%r13, -56(%rbp)
	movzbl	(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, (%rax,%r10)
	movzbl	1(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 1(%rax,%r10)
	movzbl	2(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 2(%rax,%r10)
	movzbl	3(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 3(%rax,%r10)
	movzbl	4(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 4(%rax,%r10)
	movzbl	5(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 5(%rax,%r10)
	movzbl	6(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 6(%rax,%r10)
	movzbl	7(%r15), %esi
	movzbl	-64(%rbp,%rsi), %esi
	movb	%sil, 7(%rax,%r10)
	movl	$8, %esi
	subl	%r9d, %esi
	addq	%rsi, %rbx
	addq	%r9, %r11
	jmp	LBB1_29
LBB1_1:
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	xorl	%r10d, %r10d
LBB1_30:
	movq	-80(%rbp), %r12                 ## 8-byte Reload
	cmpq	%r12, %r10
	movq	-88(%rbp), %r15                 ## 8-byte Reload
	jae	LBB1_32
	.p2align	4
LBB1_31:                                ## =>This Inner Loop Header: Depth=1
	movq	%rbx, %rdi
	movq	%r11, %rsi
	movq	%r10, %r9
	shrq	$3, %r9
	movl	%r10d, %ecx
	andb	$7, %cl
	movl	$1, %r14d
	shll	%cl, %r14d
	movzbl	(%r15,%r9), %ecx
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	testl	%ecx, %r14d
	leaq	(%rdx,%rdi), %rcx
	leaq	(%r8,%rsi), %r9
	cmoveq	%rcx, %r9
	setne	%r11b
	sete	%bl
	addq	%rdi, %rbx
	addq	%rsi, %r11
	movzbl	(%r9), %ecx
	movb	%cl, (%rax,%r10)
	incq	%r10
	cmpq	%r10, %r12
	jne	LBB1_31
LBB1_32:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB1_34
## %bb.33:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB1_34:
	callq	___stack_chk_fail
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
LCPI2_0:
	.byte	8                               ## 0x8
	.byte	8                               ## 0x8
	.byte	8                               ## 0x8
	.byte	8                               ## 0x8
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI2_1:
	.byte	56                              ## 0x38
	.byte	56                              ## 0x38
	.byte	56                              ## 0x38
	.byte	56                              ## 0x38
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI2_2:
	.long	56                              ## 0x38
	.long	0                               ## 0x0
	.long	0                               ## 0x0
	.long	0                               ## 0x0
LCPI2_3:
	.byte	255                             ## 0xff
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	255                             ## 0xff
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
LCPI2_4:
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	255                             ## 0xff
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	255                             ## 0xff
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI2_5:
	.long	56                              ## 0x38
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -104(%rbp)                 ## 8-byte Spill
	movq	%rcx, -96(%rbp)                 ## 8-byte Spill
	movq	16(%rbp), %r15
	movq	24(%rbp), %rcx
	movq	%rcx, -48(%rbp)                 ## 8-byte Spill
	andq	$-8, %rcx
	movq	%rdi, -56(%rbp)                 ## 8-byte Spill
	je	LBB2_34
## %bb.1:
	xorl	%r11d, %r11d
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rsi
	movdqa	LCPI2_0(%rip), %xmm2            ## xmm2 = [8,8,8,8,u,u,u,u,u,u,u,u,u,u,u,u]
	pcmpeqd	%xmm3, %xmm3
	movdqa	LCPI2_1(%rip), %xmm4            ## xmm4 = [56,56,56,56,u,u,u,u,u,u,u,u,u,u,u,u]
	movd	LCPI2_5(%rip), %xmm5            ## xmm5 = [56,0,0,0]
	movdqa	LCPI2_3(%rip), %xmm6            ## xmm6 = [255,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0]
	movdqa	LCPI2_4(%rip), %xmm7            ## xmm7 = [0,0,255,0,0,0,0,0,0,0,0,255,0,0,0,0]
	movq	%rdi, %r13
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	movq	%r8, -88(%rbp)                  ## 8-byte Spill
	movq	%rdx, -80(%rbp)                 ## 8-byte Spill
	movq	%r15, -72(%rbp)                 ## 8-byte Spill
	movq	%rcx, -64(%rbp)                 ## 8-byte Spill
	jmp	LBB2_4
	.p2align	4
LBB2_2:                                 ##   in Loop: Header=BB2_4 Depth=1
	movq	(%r8,%rbx), %rax
	movq	%rax, (%r15,%r11)
	addq	$8, %rbx
LBB2_3:                                 ##   in Loop: Header=BB2_4 Depth=1
	addq	$8, %r11
	incq	%r13
	cmpq	%rcx, %r11
	jae	LBB2_35
LBB2_4:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13), %r9d
	cmpl	$255, %r9d
	je	LBB2_2
## %bb.5:                               ##   in Loop: Header=BB2_4 Depth=1
	testl	%r9d, %r9d
	jne	LBB2_7
## %bb.6:                               ##   in Loop: Header=BB2_4 Depth=1
	movq	(%rdx,%r14), %rax
	movq	%rax, (%r15,%r11)
	addq	$8, %r14
	jmp	LBB2_3
	.p2align	4
LBB2_7:                                 ##   in Loop: Header=BB2_4 Depth=1
	leaq	(%r9,%r9,8), %r10
	movzbl	8(%rsi,%r10), %r12d
	movq	-96(%rbp), %rcx                 ## 8-byte Reload
	subq	%r14, %rcx
	jne	LBB2_9
## %bb.8:                               ##   in Loop: Header=BB2_4 Depth=1
	xorl	%eax, %eax
	jmp	LBB2_17
LBB2_9:                                 ##   in Loop: Header=BB2_4 Depth=1
	movzbl	(%rdx,%r14), %eax
	cmpq	$1, %rcx
	je	LBB2_17
## %bb.10:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	1(%rdx,%r14), %edi
	shll	$8, %edi
	orq	%rdi, %rax
	cmpq	$2, %rcx
	je	LBB2_17
## %bb.11:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	2(%rdx,%r14), %edi
	shll	$16, %edi
	orq	%rdi, %rax
	cmpq	$3, %rcx
	je	LBB2_17
## %bb.12:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	3(%rdx,%r14), %edi
	shll	$24, %edi
	orq	%rdi, %rax
	cmpq	$4, %rcx
	je	LBB2_17
## %bb.13:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	4(%rdx,%r14), %edi
	shlq	$32, %rdi
	orq	%rdi, %rax
	cmpq	$5, %rcx
	je	LBB2_17
## %bb.14:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	5(%rdx,%r14), %edi
	shlq	$40, %rdi
	orq	%rdi, %rax
	cmpq	$6, %rcx
	je	LBB2_17
## %bb.15:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	6(%rdx,%r14), %edi
	shlq	$48, %rdi
	orq	%rdi, %rax
	cmpq	$7, %rcx
	je	LBB2_17
## %bb.16:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	7(%rdx,%r14), %ecx
	shlq	$56, %rcx
	orq	%rcx, %rax
	.p2align	4
LBB2_17:                                ##   in Loop: Header=BB2_4 Depth=1
	addq	%rsi, %r10
	movq	-104(%rbp), %rcx                ## 8-byte Reload
	subq	%rbx, %rcx
	jne	LBB2_19
## %bb.18:                              ##   in Loop: Header=BB2_4 Depth=1
	movq	%r12, %rdx
	xorl	%esi, %esi
	jmp	LBB2_33
LBB2_19:                                ##   in Loop: Header=BB2_4 Depth=1
	movzbl	(%r8,%rbx), %esi
	cmpq	$1, %rcx
	je	LBB2_20
## %bb.21:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	1(%r8,%rbx), %r15d
	shll	$8, %r15d
	orq	%r15, %rsi
	cmpq	$2, %rcx
	je	LBB2_20
## %bb.23:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	2(%r8,%rbx), %r15d
	shll	$16, %r15d
	orq	%r15, %rsi
	cmpq	$3, %rcx
	je	LBB2_20
## %bb.25:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	3(%r8,%rbx), %r15d
	shll	$24, %r15d
	orq	%r15, %rsi
	cmpq	$4, %rcx
	je	LBB2_20
## %bb.27:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	4(%r8,%rbx), %r15d
	shlq	$32, %r15
	orq	%r15, %rsi
	cmpq	$5, %rcx
	je	LBB2_20
## %bb.29:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	5(%r8,%rbx), %r15d
	shlq	$40, %r15
	orq	%r15, %rsi
	cmpq	$6, %rcx
	jne	LBB2_31
LBB2_20:                                ##   in Loop: Header=BB2_4 Depth=1
	movq	%r12, %rdx
LBB2_33:                                ##   in Loop: Header=BB2_4 Depth=1
	movd	(%r10), %xmm9                   ## xmm9 = mem[0],zero,zero,zero
	movdqa	%xmm9, %xmm0
	pmaxub	%xmm2, %xmm0
	pcmpeqb	%xmm9, %xmm0
	pxor	%xmm3, %xmm0
	pmovsxbq	%xmm0, %xmm1
	psrld	$16, %xmm0
	pmovsxbq	%xmm0, %xmm0
	movq	%rax, %xmm8
	pshufd	$68, %xmm8, %xmm10              ## xmm10 = xmm8[0,1,0,1]
	movq	%rsi, %xmm8
	pshufd	$68, %xmm8, %xmm8               ## xmm8 = xmm8[0,1,0,1]
	movdqa	%xmm8, %xmm11
	blendvpd	%xmm0, %xmm10, %xmm11
	movdqa	%xmm1, %xmm0
	blendvpd	%xmm0, %xmm10, %xmm8
	psllw	$3, %xmm9
	movdqa	%xmm9, %xmm0
	pand	%xmm4, %xmm0
	pmovzxbq	%xmm0, %xmm1                    ## xmm1 = xmm0[0],zero,zero,zero,zero,zero,zero,zero,xmm0[1],zero,zero,zero,zero,zero,zero,zero
	psrld	$16, %xmm0
	pand	%xmm5, %xmm9
	movapd	%xmm8, %xmm10
	psrlq	%xmm9, %xmm10
	pmovzxbq	%xmm0, %xmm0                    ## xmm0 = xmm0[0],zero,zero,zero,zero,zero,zero,zero,xmm0[1],zero,zero,zero,zero,zero,zero,zero
	pshufd	$238, %xmm1, %xmm1              ## xmm1 = xmm1[2,3,2,3]
	psrlq	%xmm1, %xmm8
	movapd	%xmm11, %xmm1
	psrlq	%xmm0, %xmm1
	pshufd	$238, %xmm0, %xmm0              ## xmm0 = xmm0[2,3,2,3]
	psrlq	%xmm0, %xmm11
	psllq	$24, %xmm11
	psllq	$16, %xmm1
	pblendw	$240, %xmm11, %xmm1             ## xmm1 = xmm1[0,1,2,3],xmm11[4,5,6,7]
	pand	%xmm7, %xmm1
	psllq	$8, %xmm8
	pblendw	$15, %xmm10, %xmm8              ## xmm8 = xmm10[0,1,2,3],xmm8[4,5,6,7]
	pand	%xmm6, %xmm8
	por	%xmm1, %xmm8
	movzbl	4(%r10), %ecx
	cmpb	$8, %cl
	movq	%rsi, %r15
	cmovbq	%rax, %r15
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r15
	movzbl	%r15b, %r15d
	shlq	$32, %r15
	movzbl	5(%r10), %ecx
	cmpb	$8, %cl
	movq	%rsi, %r12
	cmovbq	%rax, %r12
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r12
	movzbl	%r12b, %r12d
	shlq	$40, %r12
	movzbl	6(%r10), %ecx
	cmpb	$8, %cl
	movq	%rsi, %rdi
	cmovbq	%rax, %rdi
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdi
	movzbl	%dil, %edi
	shlq	$48, %rdi
	movzbl	7(%r10), %ecx
	shlb	$3, %cl
	testb	%r9b, %r9b
	cmovsq	%rsi, %rax
	shrq	%cl, %rax
	shlq	$56, %rax
	pshufd	$238, %xmm8, %xmm0              ## xmm0 = xmm8[2,3,2,3]
	por	%xmm8, %xmm0
	movq	%xmm0, %rcx
	orq	%r15, %rcx
	orq	%r12, %rdi
	orq	%rcx, %rdi
	orq	%rax, %rdi
	movq	-72(%rbp), %r15                 ## 8-byte Reload
	movq	%rdi, (%r15,%r11)
	movl	$8, %eax
	subl	%edx, %eax
	addq	%rax, %r14
	addq	%rdx, %rbx
	movq	-88(%rbp), %r8                  ## 8-byte Reload
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	movq	-64(%rbp), %rcx                 ## 8-byte Reload
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rsi
	jmp	LBB2_3
LBB2_31:                                ##   in Loop: Header=BB2_4 Depth=1
	movzbl	6(%r8,%rbx), %r15d
	shlq	$48, %r15
	orq	%r15, %rsi
	movq	%r12, %rdx
	cmpq	$7, %rcx
	je	LBB2_33
## %bb.32:                              ##   in Loop: Header=BB2_4 Depth=1
	movzbl	7(%r8,%rbx), %ecx
	shlq	$56, %rcx
	orq	%rcx, %rsi
	jmp	LBB2_33
LBB2_34:
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	xorl	%r11d, %r11d
LBB2_35:
	movq	-48(%rbp), %r12                 ## 8-byte Reload
	cmpq	%r12, %r11
	movq	-56(%rbp), %r10                 ## 8-byte Reload
	jae	LBB2_37
	.p2align	4
LBB2_36:                                ## =>This Inner Loop Header: Depth=1
	movq	%r14, %rdi
	movq	%rbx, %rax
	movq	%r11, %rsi
	shrq	$3, %rsi
	movl	%r11d, %ecx
	andb	$7, %cl
	movl	$1, %r9d
	shll	%cl, %r9d
	movzbl	(%r10,%rsi), %ecx
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	testl	%ecx, %r9d
	leaq	(%rdx,%rdi), %rcx
	leaq	(%r8,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%bl
	sete	%r14b
	addq	%rdi, %r14
	addq	%rax, %rbx
	movzbl	(%rsi), %eax
	movb	%al, (%r15,%r11)
	incq	%r11
	cmpq	%r11, %r12
	jne	LBB2_36
LBB2_37:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -48(%rbp)                  ## 8-byte Spill
	movq	%rcx, -72(%rbp)                 ## 8-byte Spill
	movq	16(%rbp), %rax
	movq	24(%rbp), %r14
	movq	%r14, -56(%rbp)                 ## 8-byte Spill
	andq	$-8, %r14
	movq	%rdi, -64(%rbp)                 ## 8-byte Spill
	je	LBB3_1
## %bb.2:
	xorl	%r10d, %r10d
	movq	%rdi, %r13
	xorl	%ebx, %ebx
	xorl	%r11d, %r11d
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	jmp	LBB3_3
	.p2align	4
LBB3_6:                                 ##   in Loop: Header=BB3_3 Depth=1
	movq	(%r8,%r11), %rcx
	movq	%rcx, (%rax,%r10)
	addq	$8, %r11
LBB3_29:                                ##   in Loop: Header=BB3_3 Depth=1
	addq	$8, %r10
	incq	%r13
	cmpq	%r14, %r10
	jae	LBB3_30
LBB3_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13), %r12d
	cmpl	$255, %r12d
	je	LBB3_6
## %bb.4:                               ##   in Loop: Header=BB3_3 Depth=1
	testl	%r12d, %r12d
	jne	LBB3_7
## %bb.5:                               ##   in Loop: Header=BB3_3 Depth=1
	movq	(%rdx,%rbx), %rcx
	movq	%rcx, (%rax,%r10)
	addq	$8, %rbx
	jmp	LBB3_29
	.p2align	4
LBB3_7:                                 ##   in Loop: Header=BB3_3 Depth=1
	leaq	(%r12,%r12,8), %rcx
	movq	-72(%rbp), %r9                  ## 8-byte Reload
	subq	%rbx, %r9
	jne	LBB3_9
## %bb.8:                               ##   in Loop: Header=BB3_3 Depth=1
	xorl	%r15d, %r15d
	jmp	LBB3_17
LBB3_9:                                 ##   in Loop: Header=BB3_3 Depth=1
	movzbl	(%rdx,%rbx), %r15d
	cmpq	$1, %r9
	je	LBB3_17
## %bb.10:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	1(%rdx,%rbx), %esi
	shll	$8, %esi
	orq	%rsi, %r15
	cmpq	$2, %r9
	je	LBB3_17
## %bb.11:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	2(%rdx,%rbx), %esi
	shll	$16, %esi
	orq	%rsi, %r15
	cmpq	$3, %r9
	je	LBB3_17
## %bb.12:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	3(%rdx,%rbx), %esi
	shll	$24, %esi
	orq	%rsi, %r15
	cmpq	$4, %r9
	je	LBB3_17
## %bb.13:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	4(%rdx,%rbx), %esi
	shlq	$32, %rsi
	orq	%rsi, %r15
	cmpq	$5, %r9
	je	LBB3_17
## %bb.14:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	5(%rdx,%rbx), %esi
	shlq	$40, %rsi
	orq	%rsi, %r15
	cmpq	$6, %r9
	je	LBB3_17
## %bb.15:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	6(%rdx,%rbx), %esi
	shlq	$48, %rsi
	orq	%rsi, %r15
	cmpq	$7, %r9
	je	LBB3_17
## %bb.16:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	7(%rdx,%rbx), %esi
	shlq	$56, %rsi
	orq	%rsi, %r15
	.p2align	4
LBB3_17:                                ##   in Loop: Header=BB3_3 Depth=1
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rsi
	movzbl	8(%rsi,%rcx), %r9d
	movq	%rdi, %rsi
	subq	%r11, %rsi
	jne	LBB3_19
## %bb.18:                              ##   in Loop: Header=BB3_3 Depth=1
	xorl	%ecx, %ecx
	jmp	LBB3_28
LBB3_19:                                ##   in Loop: Header=BB3_3 Depth=1
	movzbl	(%r8,%r11), %ecx
	cmpq	$1, %rsi
	je	LBB3_28
## %bb.20:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	1(%r8,%r11), %edi
	shll	$8, %edi
	orq	%rdi, %rcx
	cmpq	$2, %rsi
	je	LBB3_27
## %bb.21:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	2(%r8,%r11), %edi
	shll	$16, %edi
	orq	%rdi, %rcx
	cmpq	$3, %rsi
	je	LBB3_27
## %bb.22:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	3(%r8,%r11), %edi
	shll	$24, %edi
	orq	%rdi, %rcx
	cmpq	$4, %rsi
	je	LBB3_27
## %bb.23:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	4(%r8,%r11), %edi
	shlq	$32, %rdi
	orq	%rdi, %rcx
	cmpq	$5, %rsi
	je	LBB3_27
## %bb.24:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	5(%r8,%r11), %edi
	shlq	$40, %rdi
	orq	%rdi, %rcx
	cmpq	$6, %rsi
	je	LBB3_27
## %bb.25:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	6(%r8,%r11), %edi
	shlq	$48, %rdi
	orq	%rdi, %rcx
	cmpq	$7, %rsi
	je	LBB3_27
## %bb.26:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	7(%r8,%r11), %esi
	shlq	$56, %rsi
	orq	%rsi, %rcx
LBB3_27:                                ##   in Loop: Header=BB3_3 Depth=1
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
LBB3_28:                                ##   in Loop: Header=BB3_3 Depth=1
	leaq	(%r12,%r12,2), %rsi
	movl	$8, %r12d
	subl	%r9d, %r12d
	movd	%r9d, %xmm0
	pinsrd	$1, %r12d, %xmm0
	shll	$4, %esi
	pslld	$3, %xmm0
	pmovzxdq	%xmm0, %xmm0                    ## xmm0 = xmm0[0],zero,xmm0[1],zero
	pcmpeqd	%xmm1, %xmm1
	psllq	%xmm0, %xmm1
	pshufd	$238, %xmm0, %xmm0              ## xmm0 = xmm0[2,3,2,3]
	pcmpeqd	%xmm2, %xmm2
	psllq	%xmm0, %xmm2
	pblendw	$15, %xmm1, %xmm2               ## xmm2 = xmm1[0,1,2,3],xmm2[4,5,6,7]
	movq	%r15, %xmm0
	movq	%rcx, %xmm1
	punpcklqdq	%xmm0, %xmm1            ## xmm1 = xmm1[0],xmm0[0]
	pandn	%xmm1, %xmm2
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_18movementE(%rip), %rcx
	movdqu	(%rsi,%rcx), %xmm0
	movdqu	16(%rsi,%rcx), %xmm1
	movdqu	32(%rsi,%rcx), %xmm3
	movdqa	%xmm0, %xmm4
	palignr	$8, %xmm1, %xmm4                ## xmm4 = xmm1[8,9,10,11,12,13,14,15],xmm4[0,1,2,3,4,5,6,7]
	pand	%xmm2, %xmm4
	pxor	%xmm4, %xmm2
	psllq	$32, %xmm4
	por	%xmm2, %xmm4
	pblendw	$15, %xmm3, %xmm0               ## xmm0 = xmm3[0,1,2,3],xmm0[4,5,6,7]
	pand	%xmm4, %xmm0
	pxor	%xmm0, %xmm4
	psllq	$16, %xmm0
	por	%xmm4, %xmm0
	palignr	$8, %xmm3, %xmm1                ## xmm1 = xmm3[8,9,10,11,12,13,14,15],xmm1[0,1,2,3,4,5,6,7]
	pand	%xmm0, %xmm1
	pxor	%xmm1, %xmm0
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	por	%xmm1, %xmm2
	movq	%xmm2, %rcx
	shlq	$8, %rcx
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	movq	%xmm1, %rsi
	orq	%rcx, %rsi
	movq	%rsi, (%rax,%r10)
	addq	%r12, %rbx
	movl	%r9d, %ecx
	addq	%rcx, %r11
	jmp	LBB3_29
LBB3_1:
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	xorl	%r10d, %r10d
LBB3_30:
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	cmpq	%r12, %r10
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	jae	LBB3_32
	.p2align	4
LBB3_31:                                ## =>This Inner Loop Header: Depth=1
	movq	%rbx, %r9
	movq	%r11, %rsi
	movq	%r10, %rdi
	shrq	$3, %rdi
	movl	%r10d, %ecx
	andb	$7, %cl
	movl	$1, %r14d
	shll	%cl, %r14d
	movzbl	(%r15,%rdi), %ecx
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	testl	%ecx, %r14d
	leaq	(%rdx,%r9), %rcx
	leaq	(%r8,%rsi), %rdi
	cmoveq	%rcx, %rdi
	setne	%r11b
	sete	%bl
	addq	%r9, %rbx
	addq	%rsi, %r11
	movzbl	(%rdi), %ecx
	movb	%cl, (%rax,%r10)
	incq	%r10
	cmpq	%r10, %r12
	jne	LBB3_31
LBB3_32:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
LCPI4_0:
	.quad	9                               ## 0x9
	.quad	49                              ## 0x31
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.p2align	4
__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm: ## @_ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.cfi_startproc
## %bb.0:
	movq	%rdi, %rax
	leaq	(%r8,%rcx), %rdx
	leaq	(%r8,%rcx), %rdi
	addq	$7, %rdi
	shrq	$3, %rdi
	movq	%rdi, (%rax)
	movq	%rdx, 24(%rax)
	movq	%rdx, 8(%rax)
	cmpq	$8, %rdx
	jb	LBB4_1
## %bb.3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	pxor	%xmm0, %xmm0
	xorl	%edi, %edi
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %r11
	movdqa	LCPI4_0(%rip), %xmm1            ## xmm1 = [9,49]
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	jmp	LBB4_4
	.p2align	4
LBB4_8:                                 ##   in Loop: Header=BB4_4 Depth=1
	cmpq	$8, %r8
	cmovbq	%r8, %r14
	addq	%r15, %r14
	addq	%r14, %rdi
	paddq	%xmm1, %xmm0
	incq	%r10
LBB4_9:                                 ##   in Loop: Header=BB4_4 Depth=1
	movl	$8, %r14d
	subl	%ebx, %r14d
	subq	%r14, %rcx
	subq	%rbx, %r8
	addq	$-8, %rdx
	incq	%rsi
	cmpq	$7, %rdx
	jbe	LBB4_10
LBB4_4:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rsi), %r14d
	leaq	(%r14,%r14,8), %rbx
	movzbl	8(%r11,%rbx), %ebx
	incl	%r14d
	cmpb	$1, %r14b
	ja	LBB4_6
## %bb.5:                               ##   in Loop: Header=BB4_4 Depth=1
	addq	$8, %rdi
	incq	%r9
	jmp	LBB4_9
	.p2align	4
LBB4_6:                                 ##   in Loop: Header=BB4_4 Depth=1
	movl	$8, %r14d
	movq	%rcx, %r15
	cmpq	$8, %rcx
	jb	LBB4_8
## %bb.7:                               ##   in Loop: Header=BB4_4 Depth=1
	movl	$8, %r15d
	jmp	LBB4_8
LBB4_1:
	pxor	%xmm0, %xmm0
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	xorl	%edi, %edi
	jmp	LBB4_2
LBB4_10:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
LBB4_2:
	addq	%rdx, %rdi
	movdqu	%xmm0, 32(%rax)
	movq	%r10, 48(%rax)
	movq	%r9, 56(%rax)
	movq	%rdi, 16(%rax)
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE: ## @_ZN16cngcompress_bulk12_GLOBAL__N_19selectionE
	.ascii	"\000\001\002\003\004\005\006\007"
	.byte	0                               ## 0x0
	.ascii	"\b\000\001\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\000\b\001\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\t\000\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\001\b\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\t\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\t\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\n\000\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\002\b\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\013\000\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\003\b\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\f\000\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\004\b\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\r\000\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\005\b\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\000\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\b\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\f\r\001"
	.byte	6                               ## 0x6
	.asciz	"\b\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\005\006\b"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\000\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\b\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\f\r\000\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\005\b\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\f\000\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\b\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\000\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\b\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\000\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\b\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\001\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\001\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\000\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\b\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\000\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\b\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\b\t\n\013\f\r\016\017"
	.byte	8                               ## 0x8

	.p2align	3, 0x0                          ## @_ZN16cngcompress_bulk12_GLOBAL__N_18movementE
__ZN16cngcompress_bulk12_GLOBAL__N_18movementE:
	.space	48
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.space	24
	.space	24
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.space	24
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.space	24
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.space	24
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.space	24
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.space	24
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	48

.subsections_via_symbols
