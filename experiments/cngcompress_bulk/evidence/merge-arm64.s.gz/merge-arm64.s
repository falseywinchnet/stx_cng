	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ; -- Begin function _ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	cbz	x7, LBB0_3
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w11, #1                         ; =0x1
LBB0_2:                                 ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, #3
	ldrb	w12, [x0, x12]
	and	w13, w8, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x10
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x10, x10, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x8]
	add	x8, x8, #1
	cmp	x7, x8
	b.ne	LBB0_2
LBB0_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ; -- Begin function _ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ands	x10, x7, #0xfffffffffffffff8
	b.eq	LBB1_25
; %bb.1:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w13, #7                         ; =0x7
	add	x11, sp, #8
	mov	w12, #8                         ; =0x8
	mov	x14, x6
	mov	x15, x0
Lloh3:
	adrp	x16, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh4:
	add	x16, x16, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	b	LBB1_4
LBB1_2:                                 ;   in Loop: Header=BB1_4 Depth=1
	ldr	x17, [x4, x8]
	str	x17, [x14]
	add	x8, x8, #8
LBB1_3:                                 ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x13, #8
	add	x1, x13, #1
	add	x14, x14, #8
	mov	x13, x17
	cmp	x1, x10
	b.hs	LBB1_24
LBB1_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w17, [x15], #1
	cmp	w17, #255
	b.eq	LBB1_2
; %bb.5:                                ;   in Loop: Header=BB1_4 Depth=1
	cbnz	w17, LBB1_7
; %bb.6:                                ;   in Loop: Header=BB1_4 Depth=1
	ldr	x17, [x2, x9]
	str	x17, [x14]
	add	x9, x9, #8
	b	LBB1_3
LBB1_7:                                 ;   in Loop: Header=BB1_4 Depth=1
	sub	x21, x3, x9
	cmp	x21, #8
	b.lo	LBB1_9
; %bb.8:                                ;   in Loop: Header=BB1_4 Depth=1
	ldr	x1, [x2, x9]
	b	LBB1_15
LBB1_9:                                 ;   in Loop: Header=BB1_4 Depth=1
	subs	x20, x21, #4
	b.lo	LBB1_11
; %bb.10:                               ;   in Loop: Header=BB1_4 Depth=1
	ldr	w1, [x2, x9]
	add	x19, x9, #4
	mov	x21, x20
	mov	w20, #32                        ; =0x20
	subs	x22, x21, #2
	b.hs	LBB1_12
	b	LBB1_13
LBB1_11:                                ;   in Loop: Header=BB1_4 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x20, #0                         ; =0x0
	mov	x19, x9
	subs	x22, x21, #2
	b.lo	LBB1_13
LBB1_12:                                ;   in Loop: Header=BB1_4 Depth=1
	ldrh	w21, [x2, x19]
	lsl	x21, x21, x20
	orr	x1, x21, x1
	add	x19, x19, #2
	orr	x20, x20, #0x10
	mov	x21, x22
LBB1_13:                                ;   in Loop: Header=BB1_4 Depth=1
	cbz	x21, LBB1_15
; %bb.14:                               ;   in Loop: Header=BB1_4 Depth=1
	ldrb	w19, [x2, x19]
	lsl	x19, x19, x20
	orr	x1, x19, x1
LBB1_15:                                ;   in Loop: Header=BB1_4 Depth=1
	sub	x22, x5, x8
	cmp	x22, #8
	b.lo	LBB1_17
; %bb.16:                               ;   in Loop: Header=BB1_4 Depth=1
	ldr	x19, [x4, x8]
	b	LBB1_23
LBB1_17:                                ;   in Loop: Header=BB1_4 Depth=1
	subs	x21, x22, #4
	b.lo	LBB1_19
; %bb.18:                               ;   in Loop: Header=BB1_4 Depth=1
	ldr	w19, [x4, x8]
	add	x20, x8, #4
	mov	x22, x21
	mov	w21, #32                        ; =0x20
	subs	x23, x22, #2
	b.hs	LBB1_20
	b	LBB1_21
LBB1_19:                                ;   in Loop: Header=BB1_4 Depth=1
	mov	x19, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	mov	x20, x8
	subs	x23, x22, #2
	b.lo	LBB1_21
LBB1_20:                                ;   in Loop: Header=BB1_4 Depth=1
	ldrh	w22, [x4, x20]
	lsl	x22, x22, x21
	orr	x19, x22, x19
	add	x20, x20, #2
	orr	x21, x21, #0x10
	mov	x22, x23
LBB1_21:                                ;   in Loop: Header=BB1_4 Depth=1
	cbz	x22, LBB1_23
; %bb.22:                               ;   in Loop: Header=BB1_4 Depth=1
	ldrb	w20, [x4, x20]
	lsl	x20, x20, x21
	orr	x19, x20, x19
LBB1_23:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x17, x17, lsl #3
	add	x17, x16, x17
	ldrb	w20, [x17, #8]
	stp	x1, x19, [sp, #8]
	ldrb	w1, [x17]
	ldrb	w1, [x11, x1]
	strb	w1, [x14]
	ldrb	w1, [x17, #1]
	ldrb	w1, [x11, x1]
	strb	w1, [x14, #1]
	ldrb	w1, [x17, #2]
	ldrb	w1, [x11, x1]
	strb	w1, [x14, #2]
	ldrb	w1, [x17, #3]
	ldrb	w1, [x11, x1]
	strb	w1, [x14, #3]
	ldrb	w1, [x17, #4]
	ldrb	w1, [x11, x1]
	strb	w1, [x14, #4]
	ldrb	w1, [x17, #5]
	ldrb	w1, [x11, x1]
	strb	w1, [x14, #5]
	ldrb	w1, [x17, #6]
	ldrb	w1, [x11, x1]
	strb	w1, [x14, #6]
	ldrb	w17, [x17, #7]
	ldrb	w17, [x11, x17]
	strb	w17, [x14, #7]
	sub	w17, w12, w20
	add	x9, x17, x9
	add	x8, x8, x20
	b	LBB1_3
LBB1_24:
	sub	x10, x17, #7
	cmp	x10, x7
	b.lo	LBB1_26
	b	LBB1_28
LBB1_25:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	cmp	x10, x7
	b.hs	LBB1_28
LBB1_26:
	mov	w11, #1                         ; =0x1
LBB1_27:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x9
	add	x15, x4, x8
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x9, x9, eq
	cinc	x8, x8, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB1_27
LBB1_28:
	ldr	x8, [sp, #24]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_30
; %bb.29:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB1_30:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAdd	Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
lCPI2_0:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI2_1:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI2_2:
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
lCPI2_3:
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB2_24
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	movi.4h	v0, #8
Lloh8:
	adrp	x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh9:
	add	x12, x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	movi.4h	v1, #56
	movi.2d	v2, #0x000000000000ff
Lloh10:
	adrp	x13, lCPI2_0@PAGE
Lloh11:
	ldr	q3, [x13, lCPI2_0@PAGEOFF]
Lloh12:
	adrp	x13, lCPI2_1@PAGE
Lloh13:
	ldr	q4, [x13, lCPI2_1@PAGEOFF]
Lloh14:
	adrp	x13, lCPI2_2@PAGE
Lloh15:
	ldr	q5, [x13, lCPI2_2@PAGEOFF]
Lloh16:
	adrp	x13, lCPI2_3@PAGE
Lloh17:
	ldr	q6, [x13, lCPI2_3@PAGEOFF]
	mov	w13, #8                         ; =0x8
	mov	x14, x0
	b	LBB2_4
LBB2_2:                                 ;   in Loop: Header=BB2_4 Depth=1
	ldr	x15, [x4, x9]
	str	x15, [x6, x10]
	add	x9, x9, #8
LBB2_3:                                 ;   in Loop: Header=BB2_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB2_25
LBB2_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w15, [x14], #1
	cmp	w15, #255
	b.eq	LBB2_2
; %bb.5:                                ;   in Loop: Header=BB2_4 Depth=1
	cbnz	w15, LBB2_7
; %bb.6:                                ;   in Loop: Header=BB2_4 Depth=1
	ldr	x15, [x2, x8]
	str	x15, [x6, x10]
	add	x8, x8, #8
	b	LBB2_3
LBB2_7:                                 ;   in Loop: Header=BB2_4 Depth=1
	sub	x19, x3, x8
	cmp	x19, #8
	b.lo	LBB2_9
; %bb.8:                                ;   in Loop: Header=BB2_4 Depth=1
	ldr	x16, [x2, x8]
	b	LBB2_15
LBB2_9:                                 ;   in Loop: Header=BB2_4 Depth=1
	subs	x1, x19, #4
	b.lo	LBB2_11
; %bb.10:                               ;   in Loop: Header=BB2_4 Depth=1
	ldr	w16, [x2, x8]
	add	x17, x8, #4
	mov	x19, x1
	mov	w1, #32                         ; =0x20
	subs	x20, x19, #2
	b.hs	LBB2_12
	b	LBB2_13
LBB2_11:                                ;   in Loop: Header=BB2_4 Depth=1
	mov	x16, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x17, x8
	subs	x20, x19, #2
	b.lo	LBB2_13
LBB2_12:                                ;   in Loop: Header=BB2_4 Depth=1
	ldrh	w19, [x2, x17]
	lsl	x19, x19, x1
	orr	x16, x19, x16
	add	x17, x17, #2
	orr	x1, x1, #0x10
	mov	x19, x20
LBB2_13:                                ;   in Loop: Header=BB2_4 Depth=1
	cbz	x19, LBB2_15
; %bb.14:                               ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w17, [x2, x17]
	lsl	x17, x17, x1
	orr	x16, x17, x16
LBB2_15:                                ;   in Loop: Header=BB2_4 Depth=1
	sub	x20, x5, x9
	cmp	x20, #8
	b.lo	LBB2_17
; %bb.16:                               ;   in Loop: Header=BB2_4 Depth=1
	ldr	x17, [x4, x9]
	b	LBB2_23
LBB2_17:                                ;   in Loop: Header=BB2_4 Depth=1
	subs	x19, x20, #4
	b.lo	LBB2_19
; %bb.18:                               ;   in Loop: Header=BB2_4 Depth=1
	ldr	w17, [x4, x9]
	add	x1, x9, #4
	mov	x20, x19
	mov	w19, #32                        ; =0x20
	subs	x21, x20, #2
	b.hs	LBB2_20
	b	LBB2_21
LBB2_19:                                ;   in Loop: Header=BB2_4 Depth=1
	mov	x17, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	mov	x1, x9
	subs	x21, x20, #2
	b.lo	LBB2_21
LBB2_20:                                ;   in Loop: Header=BB2_4 Depth=1
	ldrh	w20, [x4, x1]
	lsl	x20, x20, x19
	orr	x17, x20, x17
	add	x1, x1, #2
	orr	x19, x19, #0x10
	mov	x20, x21
LBB2_21:                                ;   in Loop: Header=BB2_4 Depth=1
	cbz	x20, LBB2_23
; %bb.22:                               ;   in Loop: Header=BB2_4 Depth=1
	ldrb	w1, [x4, x1]
	lsl	x1, x1, x19
	orr	x17, x1, x17
LBB2_23:                                ;   in Loop: Header=BB2_4 Depth=1
	add	x1, x15, x15, lsl #3
	add	x1, x12, x1
	ldr	s7, [x1]
	ushll.8h	v7, v7, #0
	cmhi.4h	v16, v0, v7
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	shl.2d	v17, v17, #56
	sshr.2d	v17, v17, #56
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #56
	dup.2d	v18, x16
	dup.2d	v19, x17
	sshr.2d	v16, v16, #56
	bsl.16b	v16, v18, v19
	bsl.16b	v17, v18, v19
	shl.4h	v7, v7, #3
	and.8b	v7, v7, v1
	ushll.4s	v7, v7, #0
	ushll.2d	v18, v7, #0
	and.16b	v18, v18, v2
	ushll2.2d	v7, v7, #0
	and.16b	v7, v7, v2
	neg.2d	v7, v7
	ushl.2d	v7, v17, v7
	neg.2d	v17, v18
	ushl.2d	v16, v16, v17
	ushl.2d	v16, v16, v3
	ushl.2d	v7, v7, v4
	and.16b	v7, v7, v5
	and.16b	v16, v16, v6
	ldrb	w19, [x1, #4]
	tst	w19, #0xf8
	csel	x20, x16, x17, eq
	ubfiz	x19, x19, #3, #3
	lsr	x19, x20, x19
	ubfiz	x19, x19, #32, #8
	ldrb	w20, [x1, #5]
	tst	w20, #0xf8
	csel	x21, x16, x17, eq
	ubfiz	x20, x20, #3, #3
	lsr	x20, x21, x20
	ldrb	w21, [x1, #6]
	tst	w21, #0xf8
	csel	x22, x16, x17, eq
	ubfiz	x21, x21, #3, #3
	lsr	x21, x22, x21
	ubfiz	x21, x21, #48, #8
	ldrb	w22, [x1, #7]
	tst	w15, #0x80
	csel	x15, x17, x16, ne
	ubfiz	x16, x22, #3, #3
	lsr	x15, x15, x16
	orr.16b	v7, v16, v7
	mov	d16, v7[1]
	orr.8b	v7, v7, v16
	fmov	x16, d7
	orr	x16, x16, x19
	bfi	x21, x20, #40, #8
	orr	x16, x16, x21
	orr	x15, x16, x15, lsl #56
	ldrb	w16, [x1, #8]
	str	x15, [x6, x10]
	sub	w15, w13, w16
	add	x8, x15, x8
	add	x9, x9, x16
	b	LBB2_3
LBB2_24:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB2_25:
	cmp	x10, x7
	b.hs	LBB2_28
; %bb.26:
	mov	w11, #1                         ; =0x1
LBB2_27:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB2_27
LBB2_28:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ; -- Begin function _ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB3_24
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
Lloh18:
	adrp	x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh19:
	add	x12, x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	mov	w13, #48                        ; =0x30
	mov	w14, #8                         ; =0x8
	mov	x15, #-1                        ; =0xffffffffffffffff
	mov	x16, x0
Lloh20:
	adrp	x17, __ZN16cngcompress_bulk12_GLOBAL__N_18movementE@PAGE
Lloh21:
	add	x17, x17, __ZN16cngcompress_bulk12_GLOBAL__N_18movementE@PAGEOFF
	b	LBB3_4
LBB3_2:                                 ;   in Loop: Header=BB3_4 Depth=1
	ldr	x1, [x4, x9]
	str	x1, [x6, x10]
	add	x9, x9, #8
LBB3_3:                                 ;   in Loop: Header=BB3_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB3_25
LBB3_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w19, [x16], #1
	cmp	w19, #255
	b.eq	LBB3_2
; %bb.5:                                ;   in Loop: Header=BB3_4 Depth=1
	cbnz	w19, LBB3_7
; %bb.6:                                ;   in Loop: Header=BB3_4 Depth=1
	ldr	x1, [x2, x8]
	str	x1, [x6, x10]
	add	x8, x8, #8
	b	LBB3_3
LBB3_7:                                 ;   in Loop: Header=BB3_4 Depth=1
	sub	x22, x3, x8
	cmp	x22, #8
	b.lo	LBB3_9
; %bb.8:                                ;   in Loop: Header=BB3_4 Depth=1
	ldr	x1, [x2, x8]
	b	LBB3_15
LBB3_9:                                 ;   in Loop: Header=BB3_4 Depth=1
	subs	x21, x22, #4
	b.lo	LBB3_11
; %bb.10:                               ;   in Loop: Header=BB3_4 Depth=1
	ldr	w1, [x2, x8]
	add	x20, x8, #4
	mov	x22, x21
	mov	w21, #32                        ; =0x20
	subs	x23, x22, #2
	b.hs	LBB3_12
	b	LBB3_13
LBB3_11:                                ;   in Loop: Header=BB3_4 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x21, #0                         ; =0x0
	mov	x20, x8
	subs	x23, x22, #2
	b.lo	LBB3_13
LBB3_12:                                ;   in Loop: Header=BB3_4 Depth=1
	ldrh	w22, [x2, x20]
	lsl	x22, x22, x21
	orr	x1, x22, x1
	add	x20, x20, #2
	orr	x21, x21, #0x10
	mov	x22, x23
LBB3_13:                                ;   in Loop: Header=BB3_4 Depth=1
	cbz	x22, LBB3_15
; %bb.14:                               ;   in Loop: Header=BB3_4 Depth=1
	ldrb	w20, [x2, x20]
	lsl	x20, x20, x21
	orr	x1, x20, x1
LBB3_15:                                ;   in Loop: Header=BB3_4 Depth=1
	sub	x23, x5, x9
	cmp	x23, #8
	b.lo	LBB3_17
; %bb.16:                               ;   in Loop: Header=BB3_4 Depth=1
	ldr	x20, [x4, x9]
	b	LBB3_23
LBB3_17:                                ;   in Loop: Header=BB3_4 Depth=1
	subs	x22, x23, #4
	b.lo	LBB3_19
; %bb.18:                               ;   in Loop: Header=BB3_4 Depth=1
	ldr	w20, [x4, x9]
	add	x21, x9, #4
	mov	x23, x22
	mov	w22, #32                        ; =0x20
	subs	x24, x23, #2
	b.hs	LBB3_20
	b	LBB3_21
LBB3_19:                                ;   in Loop: Header=BB3_4 Depth=1
	mov	x20, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	x21, x9
	subs	x24, x23, #2
	b.lo	LBB3_21
LBB3_20:                                ;   in Loop: Header=BB3_4 Depth=1
	ldrh	w23, [x4, x21]
	lsl	x23, x23, x22
	orr	x20, x23, x20
	add	x21, x21, #2
	orr	x22, x22, #0x10
	mov	x23, x24
LBB3_21:                                ;   in Loop: Header=BB3_4 Depth=1
	cbz	x23, LBB3_23
; %bb.22:                               ;   in Loop: Header=BB3_4 Depth=1
	ldrb	w21, [x4, x21]
	lsl	x21, x21, x22
	orr	x20, x21, x20
LBB3_23:                                ;   in Loop: Header=BB3_4 Depth=1
	add	x21, x19, x19, lsl #3
	add	x21, x12, x21
	ldrb	w21, [x21, #8]
	umaddl	x19, w19, w13, x17
	sub	w22, w14, w21
	add	x8, x8, x22
	lsl	w22, w22, #3
	lsl	x22, x15, x22
	bic	x1, x1, x22
	ldp	x22, x23, [x19]
	and	x22, x22, x1
	eor	x1, x22, x1
	orr	x1, x1, x22, lsl #32
	and	x22, x1, x23
	eor	x1, x22, x1
	orr	x1, x1, x22, lsl #16
	ldp	x22, x23, [x19, #16]
	and	x22, x1, x22
	eor	x1, x22, x1
	lsl	x24, x21, #3
	lsl	x24, x15, x24
	bic	x20, x20, x24
	and	x23, x23, x20
	eor	x20, x23, x20
	orr	x20, x20, x23, lsl #32
	ldp	x23, x19, [x19, #32]
	and	x23, x20, x23
	eor	x20, x23, x20
	orr	x20, x20, x23, lsl #16
	and	x19, x20, x19
	eor	x20, x19, x20
	orr	x19, x19, x22
	orr	x1, x20, x1
	orr	x1, x1, x19, lsl #8
	str	x1, [x6, x10]
	add	x9, x9, w21, uxtw
	b	LBB3_3
LBB3_24:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB3_25:
	cmp	x10, x7
	b.hs	LBB3_28
; %bb.26:
	mov	w11, #1                         ; =0x1
LBB3_27:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB3_27
LBB3_28:
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ; -- Begin function _ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB4_24
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
Lloh22:
	adrp	x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh23:
	add	x12, x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	mov	w13, #8                         ; =0x8
	mov	x14, x0
Lloh24:
	adrp	x15, __ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE@PAGE
Lloh25:
	add	x15, x15, __ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE@PAGEOFF
	b	LBB4_4
LBB4_2:                                 ;   in Loop: Header=BB4_4 Depth=1
	ldr	x16, [x4, x9]
	str	x16, [x6, x10]
	add	x9, x9, #8
LBB4_3:                                 ;   in Loop: Header=BB4_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB4_25
LBB4_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w16, [x14], #1
	cmp	w16, #255
	b.eq	LBB4_2
; %bb.5:                                ;   in Loop: Header=BB4_4 Depth=1
	cbnz	w16, LBB4_7
; %bb.6:                                ;   in Loop: Header=BB4_4 Depth=1
	ldr	x16, [x2, x8]
	str	x16, [x6, x10]
	add	x8, x8, #8
	b	LBB4_3
LBB4_7:                                 ;   in Loop: Header=BB4_4 Depth=1
	sub	x20, x3, x8
	cmp	x20, #8
	b.lo	LBB4_9
; %bb.8:                                ;   in Loop: Header=BB4_4 Depth=1
	ldr	x17, [x2, x8]
	b	LBB4_15
LBB4_9:                                 ;   in Loop: Header=BB4_4 Depth=1
	subs	x19, x20, #4
	b.lo	LBB4_11
; %bb.10:                               ;   in Loop: Header=BB4_4 Depth=1
	ldr	w17, [x2, x8]
	add	x1, x8, #4
	mov	x20, x19
	mov	w19, #32                        ; =0x20
	subs	x21, x20, #2
	b.hs	LBB4_12
	b	LBB4_13
LBB4_11:                                ;   in Loop: Header=BB4_4 Depth=1
	mov	x17, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	mov	x1, x8
	subs	x21, x20, #2
	b.lo	LBB4_13
LBB4_12:                                ;   in Loop: Header=BB4_4 Depth=1
	ldrh	w20, [x2, x1]
	lsl	x20, x20, x19
	orr	x17, x20, x17
	add	x1, x1, #2
	orr	x19, x19, #0x10
	mov	x20, x21
LBB4_13:                                ;   in Loop: Header=BB4_4 Depth=1
	cbz	x20, LBB4_15
; %bb.14:                               ;   in Loop: Header=BB4_4 Depth=1
	ldrb	w1, [x2, x1]
	lsl	x1, x1, x19
	orr	x17, x1, x17
LBB4_15:                                ;   in Loop: Header=BB4_4 Depth=1
	sub	x21, x5, x9
	cmp	x21, #8
	b.lo	LBB4_17
; %bb.16:                               ;   in Loop: Header=BB4_4 Depth=1
	ldr	x1, [x4, x9]
	b	LBB4_23
LBB4_17:                                ;   in Loop: Header=BB4_4 Depth=1
	subs	x20, x21, #4
	b.lo	LBB4_19
; %bb.18:                               ;   in Loop: Header=BB4_4 Depth=1
	ldr	w1, [x4, x9]
	add	x19, x9, #4
	mov	x21, x20
	mov	w20, #32                        ; =0x20
	subs	x22, x21, #2
	b.hs	LBB4_20
	b	LBB4_21
LBB4_19:                                ;   in Loop: Header=BB4_4 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x20, #0                         ; =0x0
	mov	x19, x9
	subs	x22, x21, #2
	b.lo	LBB4_21
LBB4_20:                                ;   in Loop: Header=BB4_4 Depth=1
	ldrh	w21, [x4, x19]
	lsl	x21, x21, x20
	orr	x1, x21, x1
	add	x19, x19, #2
	orr	x20, x20, #0x10
	mov	x21, x22
LBB4_21:                                ;   in Loop: Header=BB4_4 Depth=1
	cbz	x21, LBB4_23
; %bb.22:                               ;   in Loop: Header=BB4_4 Depth=1
	ldrb	w19, [x4, x19]
	lsl	x19, x19, x20
	orr	x1, x19, x1
LBB4_23:                                ;   in Loop: Header=BB4_4 Depth=1
	add	x19, x15, x16, lsl #6
	fmov	d0, x17
	mov.d	v0[1], x1
	ldp	q1, q2, [x19]
	and.16b	v0, v1, v0
	and.16b	v1, v2, v0
	eor.16b	v0, v1, v0
	shl.2d	v1, v1, #32
	orr.16b	v0, v0, v1
	ldp	q1, q2, [x19, #32]
	and.16b	v1, v0, v1
	eor.16b	v0, v1, v0
	shl.2d	v1, v1, #16
	orr.16b	v0, v0, v1
	add	x16, x16, x16, lsl #3
	add	x16, x12, x16
	and.16b	v1, v0, v2
	eor.16b	v0, v1, v0
	mov.d	x17, v0[1]
	fmov	x1, d0
	dup.2d	v0, v1[1]
	orr.16b	v0, v1, v0
	fmov	x19, d0
	orr	x1, x1, x19, lsl #8
	orr	x17, x1, x17
	ldrb	w16, [x16, #8]
	str	x17, [x6, x10]
	sub	w17, w13, w16
	add	x8, x17, x8
	add	x9, x9, x16
	b	LBB4_3
LBB4_24:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB4_25:
	cmp	x10, x7
	b.hs	LBB4_28
; %bb.26:
	mov	w11, #1                         ; =0x1
LBB4_27:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB4_27
LBB4_28:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
lCPI5_0:
	.quad	9                               ; 0x9
	.quad	49                              ; 0x31
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.p2align	2
__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm: ; @_ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.cfi_startproc
; %bb.0:
	add	x9, x3, x2
	add	x10, x9, #7
	str	x9, [x8, #24]
	lsr	x10, x10, #3
	stp	x10, x9, [x8]
	cmp	x9, #8
	b.lo	LBB5_6
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	mov	w13, #8                         ; =0x8
Lloh26:
	adrp	x14, lCPI5_0@PAGE
Lloh27:
	ldr	q1, [x14, lCPI5_0@PAGEOFF]
Lloh28:
	adrp	x14, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh29:
	add	x14, x14, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	b	LBB5_4
LBB5_2:                                 ;   in Loop: Header=BB5_4 Depth=1
	cmp	x2, #8
	csel	x16, x2, x13, lo
	cmp	x3, #8
	csel	x17, x3, x13, lo
	add	x16, x16, x17
	add	x10, x16, x10
	add.2d	v0, v0, v1
	add	x12, x12, #1
LBB5_3:                                 ;   in Loop: Header=BB5_4 Depth=1
	add	x15, x15, w15, uxtw #3
	add	x15, x14, x15
	ldrb	w15, [x15, #8]
	sub	w16, w13, w15
	sub	x2, x2, x16
	sub	x3, x3, x15
	sub	x9, x9, #8
	cmp	x9, #7
	b.ls	LBB5_7
LBB5_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w15, [x0], #1
	sub	w16, w15, #255
	cmn	w16, #255
	b.hi	LBB5_2
; %bb.5:                                ;   in Loop: Header=BB5_4 Depth=1
	add	x10, x10, #8
	add	x11, x11, #1
	b	LBB5_3
LBB5_6:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
LBB5_7:
	str	q0, [x8, #32]
	stp	x12, x11, [x8, #48]
	add	x9, x10, x9
	str	x9, [x8, #16]
	ret
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE: ; @_ZN16cngcompress_bulk12_GLOBAL__N_19selectionE
	.ascii	"\000\001\002\003\004\005\006\007"
	.byte	0                               ; 0x0
	.ascii	"\b\000\001\002\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\000\b\001\002\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\t\000\001\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\001\b\002\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\t\001\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\t\001\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\n\000\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\002\b\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\t\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\t\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\n\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\t\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\n\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\n\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\013\000\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\003\b\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\f\000\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\004\b\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\000\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\b\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\f\r\000\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\004\005\b\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\000\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\b\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\f\000\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\004\b\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\000\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\b\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\013\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\013\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\013\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\013\f\r\001"
	.byte	6                               ; 0x6
	.asciz	"\b\t\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\004\005\006\b"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\000\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\b\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\f\000\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\004\b\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\000\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\b\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\013\f\r\000\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\004\005\b\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\000\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\b\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\013\f\000\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\004\b\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\013\000\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\b\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\002\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\002\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\001\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\002\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\001\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\001\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\000\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\b\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\001\t\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\001\t\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\000\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\b\t\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\000\t\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\b\t\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\b\t\n\013\f\r\016\017"
	.byte	8                               ; 0x8

	.p2align	3, 0x0                          ; @_ZN16cngcompress_bulk12_GLOBAL__N_18movementE
__ZN16cngcompress_bulk12_GLOBAL__N_18movementE:
	.space	48
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594037862400               ; 0xffffffffff0000
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.space	24
	.space	24
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.space	24
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.space	24
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.space	24
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.space	24
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.space	24
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927680               ; 0xffffffffffff00
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	48

	.p2align	3, 0x0                          ; @_ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE
__ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE:
	.space	64
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.space	16
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	255                             ; 0xff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.space	16
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.space	16
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65280                           ; 0xff00
	.quad	16776960                        ; 0xffff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	65280                           ; 0xff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	65535                           ; 0xffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	255                             ; 0xff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	255                             ; 0xff
	.quad	4294967040                      ; 0xffffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.space	16
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	4278190335                      ; 0xff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65280                           ; 0xff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65535                           ; 0xffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	1099494850560                   ; 0xffff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	255                             ; 0xff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4278190080                      ; 0xff000000
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4278190080                      ; 0xff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	4278190080                      ; 0xff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	1095216660735                   ; 0xff000000ff
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4278190080                      ; 0xff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	4294967040                      ; 0xffffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	255                             ; 0xff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	255                             ; 0xff
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16777215                        ; 0xffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	16777215                        ; 0xffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	16776960                        ; 0xffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	16711680                        ; 0xff0000
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65535                           ; 0xffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	255                             ; 0xff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	16776960                        ; 0xffff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	16711680                        ; 0xff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	65280                           ; 0xff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	65535                           ; 0xffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	16711680                        ; 0xff0000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	16711680                        ; 0xff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	4278190335                      ; 0xff0000ff
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	255                             ; 0xff
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65280                           ; 0xff00
	.quad	16776960                        ; 0xffff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	1095216660735                   ; 0xff000000ff
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	255                             ; 0xff
	.quad	4294967040                      ; 0xffffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.space	16
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.space	16
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.space	16
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	255                             ; 0xff
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65535                           ; 0xffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65535                           ; 0xffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65535                           ; 0xffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190335                      ; 0xff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.space	16
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.space	16
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16777215                        ; 0xffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16776960                        ; 0xffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65535                           ; 0xffff
	.quad	281474976645120                 ; 0xffffffff0000
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.space	16
	.quad	255                             ; 0xff
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.space	16
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	64

.subsections_via_symbols
