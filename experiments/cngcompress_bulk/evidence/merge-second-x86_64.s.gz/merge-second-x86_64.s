	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.globl	__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	24(%rbp), %rax
	testq	%rax, %rax
	je	LBB0_3
## %bb.1:
	movq	16(%rbp), %rsi
	xorl	%r9d, %r9d
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	.p2align	4
LBB0_2:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rbx
	movq	%rcx, %r10
	movq	%r9, %r11
	shrq	$3, %r11
	movl	%r9d, %ecx
	andb	$7, %cl
	movl	$1, %r14d
	shll	%cl, %r14d
	movzbl	(%rdi,%r11), %r15d
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	testl	%r15d, %r14d
	leaq	(%rdx,%rbx), %r14
	leaq	(%r8,%r10), %r15
	cmoveq	%r14, %r15
	setne	%cl
	sete	%r11b
	addq	%rbx, %r11
	addq	%r10, %rcx
	movzbl	(%r15), %r10d
	movb	%r10b, (%rsi,%r9)
	incq	%r9
	cmpq	%r9, %rax
	jne	LBB0_2
LBB0_3:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r8, %r13
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	movq	16(%rbp), %r11
	movq	24(%rbp), %rbx
	movq	%rbx, %rsi
	andq	$-8, %rsi
	je	LBB1_1
## %bb.2:
	movq	%r9, -120(%rbp)                 ## 8-byte Spill
	leaq	3(%rdx), %rax
	movq	%rax, -96(%rbp)                 ## 8-byte Spill
	leaq	3(%r13), %rax
	movq	%rax, -88(%rbp)                 ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	xorl	%r15d, %r15d
	movq	%rdi, -144(%rbp)                ## 8-byte Spill
	movq	%r11, -136(%rbp)                ## 8-byte Spill
	movq	%rbx, -128(%rbp)                ## 8-byte Spill
	movq	%rcx, -112(%rbp)                ## 8-byte Spill
	movq	%rsi, -104(%rbp)                ## 8-byte Spill
	movq	%rdx, -72(%rbp)                 ## 8-byte Spill
	movq	%r13, -80(%rbp)                 ## 8-byte Spill
	jmp	LBB1_3
	.p2align	4
LBB1_6:                                 ##   in Loop: Header=BB1_3 Depth=1
	movq	(%r13,%r15), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r15
LBB1_30:                                ##   in Loop: Header=BB1_3 Depth=1
	addq	$8, %r14
	cmpq	%rsi, %r14
	jae	LBB1_31
LBB1_3:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_14 Depth 2
                                        ##     Child Loop BB1_17 Depth 2
                                        ##     Child Loop BB1_25 Depth 2
                                        ##     Child Loop BB1_28 Depth 2
	movq	%r14, %rax
	shrq	$3, %rax
	movzbl	(%rdi,%rax), %r9d
	cmpl	$255, %r9d
	je	LBB1_6
## %bb.4:                               ##   in Loop: Header=BB1_3 Depth=1
	testl	%r9d, %r9d
	jne	LBB1_7
## %bb.5:                               ##   in Loop: Header=BB1_3 Depth=1
	movq	(%rdx,%r12), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r12
	jmp	LBB1_30
	.p2align	4
LBB1_7:                                 ##   in Loop: Header=BB1_3 Depth=1
	movq	%rcx, %r11
	subq	%r12, %r11
	cmpq	$7, %r11
	jbe	LBB1_8
## %bb.12:                              ##   in Loop: Header=BB1_3 Depth=1
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	movq	(%rdx,%r12), %rax
	jmp	LBB1_18
LBB1_8:                                 ##   in Loop: Header=BB1_3 Depth=1
	cmpq	%r12, %rcx
	jne	LBB1_10
## %bb.9:                               ##   in Loop: Header=BB1_3 Depth=1
	xorl	%eax, %eax
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	jmp	LBB1_18
LBB1_10:                                ##   in Loop: Header=BB1_3 Depth=1
	movl	%r11d, %ebx
	andl	$3, %ebx
	movq	%r12, %rax
	subq	%rcx, %rax
	cmpq	$-4, %rax
	jbe	LBB1_13
## %bb.11:                              ##   in Loop: Header=BB1_3 Depth=1
	xorl	%esi, %esi
	xorl	%eax, %eax
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	jmp	LBB1_16
LBB1_13:                                ##   in Loop: Header=BB1_3 Depth=1
	andl	$4, %r11d
	movq	-96(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %rdx
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%eax, %eax
	.p2align	4
LBB1_14:                                ##   Parent Loop BB1_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%rdx,%rsi), %edi
	movl	%r10d, %ecx
	shlq	%cl, %rdi
	movzbl	-2(%rdx,%rsi), %r13d
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r13
	orq	%rdi, %rax
	movzbl	-1(%rdx,%rsi), %edi
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%r13, %rdi
	orq	%rax, %rdi
	movzbl	(%rdx,%rsi), %eax
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rax
	orq	%rdi, %rax
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r11
	jne	LBB1_14
## %bb.15:                              ##   in Loop: Header=BB1_3 Depth=1
	testq	%rbx, %rbx
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	je	LBB1_18
LBB1_16:                                ##   in Loop: Header=BB1_3 Depth=1
	leaq	(%rdx,%r12), %r11
	addq	%rsi, %r11
	shlq	$3, %rsi
	xorl	%edi, %edi
	.p2align	4
LBB1_17:                                ##   Parent Loop BB1_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r11,%rdi), %r10d
	movl	%esi, %ecx
	shlq	%cl, %r10
	orq	%r10, %rax
	incq	%rdi
	addq	$8, %rsi
	cmpq	%rdi, %rbx
	jne	LBB1_17
LBB1_18:                                ##   in Loop: Header=BB1_3 Depth=1
	leaq	(%r9,%r9,8), %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rsi
	leaq	(%rsi,%rcx), %r8
	movzbl	8(%rsi,%rcx), %ecx
	movq	-120(%rbp), %rsi                ## 8-byte Reload
	movq	%rsi, %r13
	subq	%r15, %r13
	cmpq	$7, %r13
	movq	%rcx, -152(%rbp)                ## 8-byte Spill
	jbe	LBB1_19
## %bb.23:                              ##   in Loop: Header=BB1_3 Depth=1
	movq	-80(%rbp), %r13                 ## 8-byte Reload
	movq	(%r13,%r15), %r9
	jmp	LBB1_29
LBB1_19:                                ##   in Loop: Header=BB1_3 Depth=1
	cmpq	%r15, %rsi
	jne	LBB1_21
## %bb.20:                              ##   in Loop: Header=BB1_3 Depth=1
	xorl	%r9d, %r9d
	movq	-80(%rbp), %r13                 ## 8-byte Reload
	jmp	LBB1_29
LBB1_21:                                ##   in Loop: Header=BB1_3 Depth=1
	movl	%r13d, %ebx
	andl	$3, %ebx
	movq	%r15, %rcx
	subq	%rsi, %rcx
	cmpq	$-4, %rcx
	jbe	LBB1_24
## %bb.22:                              ##   in Loop: Header=BB1_3 Depth=1
	xorl	%esi, %esi
	xorl	%r9d, %r9d
	movq	-80(%rbp), %r13                 ## 8-byte Reload
	jmp	LBB1_27
LBB1_24:                                ##   in Loop: Header=BB1_3 Depth=1
	andl	$4, %r13d
	movq	-88(%rbp), %rcx                 ## 8-byte Reload
	leaq	(%rcx,%r15), %rdx
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%r9d, %r9d
	.p2align	4
LBB1_25:                                ##   Parent Loop BB1_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%rdx,%rsi), %edi
	movl	%r10d, %ecx
	shlq	%cl, %rdi
	movzbl	-2(%rdx,%rsi), %r11d
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r11
	orq	%rdi, %r9
	movzbl	-1(%rdx,%rsi), %edi
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%r11, %rdi
	orq	%r9, %rdi
	movzbl	(%rdx,%rsi), %r9d
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r9
	orq	%rdi, %r9
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r13
	jne	LBB1_25
## %bb.26:                              ##   in Loop: Header=BB1_3 Depth=1
	testq	%rbx, %rbx
	movq	-80(%rbp), %r13                 ## 8-byte Reload
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	je	LBB1_29
LBB1_27:                                ##   in Loop: Header=BB1_3 Depth=1
	leaq	(%r15,%r13), %r11
	addq	%rsi, %r11
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB1_28:                                ##   Parent Loop BB1_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r11,%r10), %edi
	movl	%esi, %ecx
	shlq	%cl, %rdi
	orq	%rdi, %r9
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %rbx
	jne	LBB1_28
LBB1_29:                                ##   in Loop: Header=BB1_3 Depth=1
	movq	%rax, -64(%rbp)
	movq	%r9, -56(%rbp)
	movzbl	(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movq	-136(%rbp), %r11                ## 8-byte Reload
	movb	%al, (%r11,%r14)
	movzbl	1(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 1(%r11,%r14)
	movzbl	2(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 2(%r11,%r14)
	movzbl	3(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 3(%r11,%r14)
	movzbl	4(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 4(%r11,%r14)
	movzbl	5(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 5(%r11,%r14)
	movzbl	6(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 6(%r11,%r14)
	movzbl	7(%r8), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 7(%r11,%r14)
	movl	$8, %eax
	movq	-152(%rbp), %rcx                ## 8-byte Reload
	subl	%ecx, %eax
	addq	%rax, %r12
	addq	%rcx, %r15
	movq	-144(%rbp), %rdi                ## 8-byte Reload
	movq	-128(%rbp), %rbx                ## 8-byte Reload
	movq	-112(%rbp), %rcx                ## 8-byte Reload
	movq	-104(%rbp), %rsi                ## 8-byte Reload
	jmp	LBB1_30
LBB1_1:
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	xorl	%r14d, %r14d
LBB1_31:
	cmpq	%rbx, %r14
	jae	LBB1_33
	.p2align	4
LBB1_32:                                ## =>This Inner Loop Header: Depth=1
	movq	%r12, %r9
	movq	%r15, %rax
	movq	%r14, %rsi
	shrq	$3, %rsi
	movl	%r14d, %ecx
	andb	$7, %cl
	movl	$1, %r10d
	shll	%cl, %r10d
	movzbl	(%rdi,%rsi), %ecx
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	testl	%ecx, %r10d
	leaq	(%rdx,%r9), %rcx
	leaq	(%r13,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%r15b
	sete	%r12b
	addq	%r9, %r12
	addq	%rax, %r15
	movzbl	(%rsi), %eax
	movb	%al, (%r11,%r14)
	incq	%r14
	cmpq	%r14, %rbx
	jne	LBB1_32
LBB1_33:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB1_35
## %bb.34:
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB1_35:
	callq	___stack_chk_fail
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	16(%rbp), %r11
	movq	24(%rbp), %rbx
	movq	%rbx, %rsi
	andq	$-8, %rsi
	je	LBB2_1
## %bb.2:
	movq	%r9, -112(%rbp)                 ## 8-byte Spill
	leaq	3(%rdx), %rax
	movq	%rax, -72(%rbp)                 ## 8-byte Spill
	leaq	3(%r8), %rax
	movq	%rax, -64(%rbp)                 ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	xorl	%r15d, %r15d
	movq	%r8, -48(%rbp)                  ## 8-byte Spill
	movq	%rdx, -56(%rbp)                 ## 8-byte Spill
	movq	%rdi, -136(%rbp)                ## 8-byte Spill
	movq	%r11, -128(%rbp)                ## 8-byte Spill
	movq	%rbx, -120(%rbp)                ## 8-byte Spill
	movq	%rcx, -104(%rbp)                ## 8-byte Spill
	movq	%rsi, -96(%rbp)                 ## 8-byte Spill
	jmp	LBB2_3
	.p2align	4
LBB2_6:                                 ##   in Loop: Header=BB2_3 Depth=1
	movq	(%r8,%r15), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r15
LBB2_30:                                ##   in Loop: Header=BB2_3 Depth=1
	addq	$8, %r14
	cmpq	%rsi, %r14
	jae	LBB2_31
LBB2_3:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_14 Depth 2
                                        ##     Child Loop BB2_17 Depth 2
                                        ##     Child Loop BB2_25 Depth 2
                                        ##     Child Loop BB2_28 Depth 2
	movq	%r14, %rax
	shrq	$3, %rax
	movzbl	(%rdi,%rax), %r13d
	cmpl	$255, %r13d
	je	LBB2_6
## %bb.4:                               ##   in Loop: Header=BB2_3 Depth=1
	testl	%r13d, %r13d
	jne	LBB2_7
## %bb.5:                               ##   in Loop: Header=BB2_3 Depth=1
	movq	(%rdx,%r12), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r12
	jmp	LBB2_30
	.p2align	4
LBB2_7:                                 ##   in Loop: Header=BB2_3 Depth=1
	movq	%rcx, %rax
	subq	%r12, %rax
	cmpq	$7, %rax
	jbe	LBB2_8
## %bb.12:                              ##   in Loop: Header=BB2_3 Depth=1
	movq	(%rdx,%r12), %r9
	jmp	LBB2_18
LBB2_8:                                 ##   in Loop: Header=BB2_3 Depth=1
	cmpq	%r12, %rcx
	jne	LBB2_10
## %bb.9:                               ##   in Loop: Header=BB2_3 Depth=1
	xorl	%r9d, %r9d
	jmp	LBB2_18
LBB2_10:                                ##   in Loop: Header=BB2_3 Depth=1
	movl	%eax, %r8d
	andl	$3, %r8d
	movq	%r12, %rsi
	subq	%rcx, %rsi
	cmpq	$-4, %rsi
	jbe	LBB2_13
## %bb.11:                              ##   in Loop: Header=BB2_3 Depth=1
	xorl	%esi, %esi
	xorl	%r9d, %r9d
	jmp	LBB2_16
LBB2_13:                                ##   in Loop: Header=BB2_3 Depth=1
	movq	%r13, %rdi
	andl	$4, %eax
	movq	-72(%rbp), %rcx                 ## 8-byte Reload
	leaq	(%rcx,%r12), %rbx
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%r9d, %r9d
	.p2align	4
LBB2_14:                                ##   Parent Loop BB2_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%rbx,%rsi), %r11d
	movl	%r10d, %ecx
	shlq	%cl, %r11
	movzbl	-2(%rbx,%rsi), %r13d
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r13
	orq	%r11, %r9
	movzbl	-1(%rbx,%rsi), %r11d
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r11
	orq	%r13, %r11
	orq	%r9, %r11
	movzbl	(%rbx,%rsi), %r9d
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r9
	orq	%r11, %r9
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %rax
	jne	LBB2_14
## %bb.15:                              ##   in Loop: Header=BB2_3 Depth=1
	testq	%r8, %r8
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movq	%rdi, %r13
	je	LBB2_18
LBB2_16:                                ##   in Loop: Header=BB2_3 Depth=1
	addq	%r12, %rdx
	addq	%rsi, %rdx
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB2_17:                                ##   Parent Loop BB2_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%r10), %r11d
	movl	%esi, %ecx
	shlq	%cl, %r11
	orq	%r11, %r9
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %r8
	jne	LBB2_17
LBB2_18:                                ##   in Loop: Header=BB2_3 Depth=1
	leaq	(,%r13,8), %rcx
	addq	%r13, %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rax
	leaq	(%rax,%rcx), %r11
	movzbl	8(%rax,%rcx), %edi
	movq	-112(%rbp), %rax                ## 8-byte Reload
	movq	%rax, %rdx
	subq	%r15, %rdx
	cmpq	$7, %rdx
	movq	%r13, -144(%rbp)                ## 8-byte Spill
	jbe	LBB2_19
## %bb.23:                              ##   in Loop: Header=BB2_3 Depth=1
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movq	(%r8,%r15), %rbx
	jmp	LBB2_29
LBB2_19:                                ##   in Loop: Header=BB2_3 Depth=1
	cmpq	%r15, %rax
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	jne	LBB2_21
## %bb.20:                              ##   in Loop: Header=BB2_3 Depth=1
	xorl	%ebx, %ebx
	jmp	LBB2_29
LBB2_21:                                ##   in Loop: Header=BB2_3 Depth=1
	movl	%edx, %r13d
	andl	$3, %r13d
	movq	%r15, %rcx
	subq	%rax, %rcx
	cmpq	$-4, %rcx
	jbe	LBB2_24
## %bb.22:                              ##   in Loop: Header=BB2_3 Depth=1
	xorl	%esi, %esi
	xorl	%ebx, %ebx
	jmp	LBB2_27
LBB2_24:                                ##   in Loop: Header=BB2_3 Depth=1
	movq	%r11, -80(%rbp)                 ## 8-byte Spill
	movq	%rdi, -88(%rbp)                 ## 8-byte Spill
	andl	$4, %edx
	movq	-64(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r15), %r11
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%ebx, %ebx
	.p2align	4
LBB2_25:                                ##   Parent Loop BB2_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%r11,%rsi), %eax
	movl	%r10d, %ecx
	shlq	%cl, %rax
	movzbl	-2(%r11,%rsi), %edi
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%rax, %rbx
	movzbl	-1(%r11,%rsi), %eax
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rax
	orq	%rdi, %rax
	orq	%rbx, %rax
	movzbl	(%r11,%rsi), %ebx
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rbx
	orq	%rax, %rbx
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %rdx
	jne	LBB2_25
## %bb.26:                              ##   in Loop: Header=BB2_3 Depth=1
	testq	%r13, %r13
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movq	-88(%rbp), %rdi                 ## 8-byte Reload
	movq	-80(%rbp), %r11                 ## 8-byte Reload
	je	LBB2_29
LBB2_27:                                ##   in Loop: Header=BB2_3 Depth=1
	leaq	(%r8,%r15), %rdx
	addq	%rsi, %rdx
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB2_28:                                ##   Parent Loop BB2_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%r10), %eax
	movl	%esi, %ecx
	shlq	%cl, %rax
	orq	%rax, %rbx
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %r13
	jne	LBB2_28
LBB2_29:                                ##   in Loop: Header=BB2_3 Depth=1
	movzbl	(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rax
	cmovbq	%r9, %rax
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rax
	movzbl	1(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rdx
	cmovbq	%r9, %rdx
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdx
	movzbl	%al, %eax
	shll	$8, %edx
	movzwl	%dx, %edx
	orq	%rax, %rdx
	movzbl	2(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rax
	cmovbq	%r9, %rax
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rax
	movzbl	%al, %eax
	shll	$16, %eax
	orq	%rdx, %rax
	movzbl	3(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rdx
	cmovbq	%r9, %rdx
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdx
	shll	$24, %edx
	orq	%rax, %rdx
	movzbl	4(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rax
	cmovbq	%r9, %rax
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rax
	movzbl	%al, %eax
	shlq	$32, %rax
	orq	%rdx, %rax
	movzbl	5(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rdx
	cmovbq	%r9, %rdx
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdx
	movzbl	%dl, %edx
	shlq	$40, %rdx
	orq	%rax, %rdx
	movzbl	6(%r11), %ecx
	cmpb	$8, %cl
	movq	%rbx, %rax
	cmovbq	%r9, %rax
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rax
	movzbl	%al, %eax
	shlq	$48, %rax
	orq	%rdx, %rax
	movzbl	7(%r11), %ecx
	shlb	$3, %cl
	cmpb	$0, -144(%rbp)                  ## 1-byte Folded Reload
	cmovsq	%rbx, %r9
	shrq	%cl, %r9
	shlq	$56, %r9
	orq	%rax, %r9
	movq	-128(%rbp), %r11                ## 8-byte Reload
	movq	%r9, (%r11,%r14)
	movl	$8, %eax
	subl	%edi, %eax
	addq	%rax, %r12
	addq	%rdi, %r15
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movq	-136(%rbp), %rdi                ## 8-byte Reload
	movq	-120(%rbp), %rbx                ## 8-byte Reload
	movq	-104(%rbp), %rcx                ## 8-byte Reload
	movq	-96(%rbp), %rsi                 ## 8-byte Reload
	jmp	LBB2_30
LBB2_1:
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	xorl	%r14d, %r14d
LBB2_31:
	cmpq	%rbx, %r14
	jae	LBB2_33
	.p2align	4
LBB2_32:                                ## =>This Inner Loop Header: Depth=1
	movq	%r12, %r9
	movq	%r15, %rax
	movq	%r14, %rsi
	shrq	$3, %rsi
	movl	%r14d, %ecx
	andb	$7, %cl
	movl	$1, %r10d
	shll	%cl, %r10d
	movzbl	(%rdi,%rsi), %ecx
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	testl	%ecx, %r10d
	leaq	(%rdx,%r9), %rcx
	leaq	(%r8,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%r15b
	sete	%r12b
	addq	%r9, %r12
	addq	%rax, %r15
	movzbl	(%rsi), %eax
	movb	%al, (%r11,%r14)
	incq	%r14
	cmpq	%r14, %rbx
	jne	LBB2_32
LBB2_33:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	16(%rbp), %r11
	movq	24(%rbp), %rbx
	movq	%rbx, %rsi
	andq	$-8, %rsi
	je	LBB3_1
## %bb.2:
	movq	%r9, -88(%rbp)                  ## 8-byte Spill
	leaq	3(%rdx), %rax
	movq	%rax, -64(%rbp)                 ## 8-byte Spill
	leaq	3(%r8), %rax
	movq	%rax, -56(%rbp)                 ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	xorl	%r15d, %r15d
	movq	%rdx, -120(%rbp)                ## 8-byte Spill
	movq	%rdi, -112(%rbp)                ## 8-byte Spill
	movq	%r11, -104(%rbp)                ## 8-byte Spill
	movq	%rbx, -96(%rbp)                 ## 8-byte Spill
	movq	%rcx, -80(%rbp)                 ## 8-byte Spill
	movq	%rsi, -72(%rbp)                 ## 8-byte Spill
	movq	%r8, -48(%rbp)                  ## 8-byte Spill
	jmp	LBB3_3
	.p2align	4
LBB3_6:                                 ##   in Loop: Header=BB3_3 Depth=1
	movq	(%r8,%r15), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r15
LBB3_30:                                ##   in Loop: Header=BB3_3 Depth=1
	addq	$8, %r14
	cmpq	%rsi, %r14
	jae	LBB3_31
LBB3_3:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB3_14 Depth 2
                                        ##     Child Loop BB3_17 Depth 2
                                        ##     Child Loop BB3_25 Depth 2
                                        ##     Child Loop BB3_28 Depth 2
	movq	%r14, %rax
	shrq	$3, %rax
	movzbl	(%rdi,%rax), %r9d
	cmpl	$255, %r9d
	je	LBB3_6
## %bb.4:                               ##   in Loop: Header=BB3_3 Depth=1
	testl	%r9d, %r9d
	jne	LBB3_7
## %bb.5:                               ##   in Loop: Header=BB3_3 Depth=1
	movq	(%rdx,%r12), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r12
	jmp	LBB3_30
	.p2align	4
LBB3_7:                                 ##   in Loop: Header=BB3_3 Depth=1
	movq	%rcx, %r11
	subq	%r12, %r11
	cmpq	$7, %r11
	jbe	LBB3_8
## %bb.12:                              ##   in Loop: Header=BB3_3 Depth=1
	movq	(%rdx,%r12), %rbx
	jmp	LBB3_18
LBB3_8:                                 ##   in Loop: Header=BB3_3 Depth=1
	cmpq	%r12, %rcx
	jne	LBB3_10
## %bb.9:                               ##   in Loop: Header=BB3_3 Depth=1
	xorl	%ebx, %ebx
	jmp	LBB3_18
LBB3_10:                                ##   in Loop: Header=BB3_3 Depth=1
	movl	%r11d, %eax
	andl	$3, %eax
	movq	%r12, %rsi
	subq	%rcx, %rsi
	cmpq	$-4, %rsi
	jbe	LBB3_13
## %bb.11:                              ##   in Loop: Header=BB3_3 Depth=1
	xorl	%esi, %esi
	xorl	%ebx, %ebx
	jmp	LBB3_16
LBB3_13:                                ##   in Loop: Header=BB3_3 Depth=1
	andl	$4, %r11d
	movq	-64(%rbp), %rcx                 ## 8-byte Reload
	leaq	(%rcx,%r12), %r8
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%ebx, %ebx
	.p2align	4
LBB3_14:                                ##   Parent Loop BB3_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%r8,%rsi), %edi
	movl	%r10d, %ecx
	shlq	%cl, %rdi
	movzbl	-2(%r8,%rsi), %r13d
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r13
	orq	%rdi, %rbx
	movzbl	-1(%r8,%rsi), %edi
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%r13, %rdi
	orq	%rbx, %rdi
	movzbl	(%r8,%rsi), %ebx
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rbx
	orq	%rdi, %rbx
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r11
	jne	LBB3_14
## %bb.15:                              ##   in Loop: Header=BB3_3 Depth=1
	testq	%rax, %rax
	je	LBB3_18
LBB3_16:                                ##   in Loop: Header=BB3_3 Depth=1
	addq	%r12, %rdx
	addq	%rsi, %rdx
	shlq	$3, %rsi
	xorl	%r8d, %r8d
	.p2align	4
LBB3_17:                                ##   Parent Loop BB3_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%r8), %r10d
	movl	%esi, %ecx
	shlq	%cl, %r10
	orq	%r10, %rbx
	incq	%r8
	addq	$8, %rsi
	cmpq	%r8, %rax
	jne	LBB3_17
LBB3_18:                                ##   in Loop: Header=BB3_3 Depth=1
	leaq	(%r9,%r9,8), %rax
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rcx
	movzbl	8(%rcx,%rax), %ecx
	movq	-88(%rbp), %rax                 ## 8-byte Reload
	movq	%rax, %r11
	subq	%r15, %r11
	cmpq	$7, %r11
	movq	%r9, -136(%rbp)                 ## 8-byte Spill
	movq	%rcx, -128(%rbp)                ## 8-byte Spill
	jbe	LBB3_19
## %bb.23:                              ##   in Loop: Header=BB3_3 Depth=1
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	movq	(%rdi,%r15), %r13
	jmp	LBB3_29
LBB3_19:                                ##   in Loop: Header=BB3_3 Depth=1
	cmpq	%r15, %rax
	jne	LBB3_21
## %bb.20:                              ##   in Loop: Header=BB3_3 Depth=1
	xorl	%r13d, %r13d
	jmp	LBB3_29
LBB3_21:                                ##   in Loop: Header=BB3_3 Depth=1
	movl	%r11d, %r9d
	andl	$3, %r9d
	movq	%r15, %rcx
	subq	%rax, %rcx
	cmpq	$-4, %rcx
	jbe	LBB3_24
## %bb.22:                              ##   in Loop: Header=BB3_3 Depth=1
	xorl	%esi, %esi
	xorl	%r13d, %r13d
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	jmp	LBB3_27
LBB3_24:                                ##   in Loop: Header=BB3_3 Depth=1
	andl	$4, %r11d
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r15), %rdx
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%r13d, %r13d
	.p2align	4
LBB3_25:                                ##   Parent Loop BB3_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%rdx,%rsi), %eax
	movl	%r10d, %ecx
	shlq	%cl, %rax
	movzbl	-2(%rdx,%rsi), %edi
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%rax, %r13
	movzbl	-1(%rdx,%rsi), %eax
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rax
	orq	%rdi, %rax
	orq	%r13, %rax
	movzbl	(%rdx,%rsi), %r13d
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r13
	orq	%rax, %r13
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r11
	jne	LBB3_25
## %bb.26:                              ##   in Loop: Header=BB3_3 Depth=1
	testq	%r9, %r9
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	je	LBB3_29
LBB3_27:                                ##   in Loop: Header=BB3_3 Depth=1
	leaq	(%rdi,%r15), %rdx
	addq	%rsi, %rdx
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB3_28:                                ##   Parent Loop BB3_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%r10), %eax
	movl	%esi, %ecx
	shlq	%cl, %rax
	orq	%rax, %r13
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %r9
	jne	LBB3_28
LBB3_29:                                ##   in Loop: Header=BB3_3 Depth=1
	movq	-136(%rbp), %rax                ## 8-byte Reload
	leaq	(%rax,%rax,2), %rdi
	shll	$4, %edi
	movl	$8, %esi
	movq	-128(%rbp), %r8                 ## 8-byte Reload
	subl	%r8d, %esi
	leal	(,%rsi,8), %ecx
	movq	$-1, %rax
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rax
	notq	%rax
	andq	%rax, %rbx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_18movementE(%rip), %r10
	movq	(%rdi,%r10), %rax
	andq	%rbx, %rax
	xorq	%rax, %rbx
	shlq	$32, %rax
	orq	%rbx, %rax
	movq	8(%rdi,%r10), %rdx
	andq	%rax, %rdx
	xorq	%rdx, %rax
	shlq	$16, %rdx
	orq	%rax, %rdx
	movq	16(%rdi,%r10), %r9
	andq	%rdx, %r9
	leal	(,%r8,8), %ecx
	movq	$-1, %rax
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rax
	xorq	%r9, %rdx
	notq	%rax
	andq	%r13, %rax
	movq	24(%rdi,%r10), %rcx
	andq	%rax, %rcx
	xorq	%rcx, %rax
	shlq	$32, %rcx
	orq	%rax, %rcx
	movq	32(%rdi,%r10), %rax
	andq	%rcx, %rax
	xorq	%rax, %rcx
	shlq	$16, %rax
	orq	%rcx, %rax
	movq	40(%rdi,%r10), %rcx
	andq	%rax, %rcx
	xorq	%rcx, %rax
	orq	%rdx, %rax
	orq	%r9, %rcx
	shlq	$8, %rcx
	orq	%rax, %rcx
	movq	-104(%rbp), %r11                ## 8-byte Reload
	movq	%rcx, (%r11,%r14)
	addq	%rsi, %r12
	movl	%r8d, %eax
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	addq	%rax, %r15
	movq	-120(%rbp), %rdx                ## 8-byte Reload
	movq	-112(%rbp), %rdi                ## 8-byte Reload
	movq	-96(%rbp), %rbx                 ## 8-byte Reload
	movq	-80(%rbp), %rcx                 ## 8-byte Reload
	movq	-72(%rbp), %rsi                 ## 8-byte Reload
	jmp	LBB3_30
LBB3_1:
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	xorl	%r14d, %r14d
LBB3_31:
	cmpq	%rbx, %r14
	jae	LBB3_33
	.p2align	4
LBB3_32:                                ## =>This Inner Loop Header: Depth=1
	movq	%r12, %r9
	movq	%r15, %rax
	movq	%r14, %rsi
	shrq	$3, %rsi
	movl	%r14d, %ecx
	andb	$7, %cl
	movl	$1, %r10d
	shll	%cl, %r10d
	movzbl	(%rdi,%rsi), %ecx
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	testl	%ecx, %r10d
	leaq	(%rdx,%r9), %rcx
	leaq	(%r8,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%r15b
	sete	%r12b
	addq	%r9, %r12
	addq	%rax, %r15
	movzbl	(%rsi), %eax
	movb	%al, (%r11,%r14)
	incq	%r14
	cmpq	%r14, %rbx
	jne	LBB3_32
LBB3_33:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -128(%rbp)                 ## 8-byte Spill
	movq	16(%rbp), %r11
	movq	24(%rbp), %rbx
	movq	%rbx, %rsi
	andq	$-8, %rsi
	je	LBB4_1
## %bb.2:
	leaq	3(%rdx), %rax
	movq	%rax, -64(%rbp)                 ## 8-byte Spill
	leaq	3(%r8), %rax
	movq	%rax, -56(%rbp)                 ## 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	xorl	%r15d, %r15d
	movq	%r8, -48(%rbp)                  ## 8-byte Spill
	movq	%rdx, -120(%rbp)                ## 8-byte Spill
	movq	%rdi, -112(%rbp)                ## 8-byte Spill
	movq	%r11, -104(%rbp)                ## 8-byte Spill
	movq	%rbx, -96(%rbp)                 ## 8-byte Spill
	movq	%rcx, -88(%rbp)                 ## 8-byte Spill
	movq	%rsi, -80(%rbp)                 ## 8-byte Spill
	jmp	LBB4_3
	.p2align	4
LBB4_6:                                 ##   in Loop: Header=BB4_3 Depth=1
	movq	(%r8,%r15), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r15
LBB4_30:                                ##   in Loop: Header=BB4_3 Depth=1
	addq	$8, %r14
	cmpq	%rsi, %r14
	jae	LBB4_31
LBB4_3:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB4_14 Depth 2
                                        ##     Child Loop BB4_17 Depth 2
                                        ##     Child Loop BB4_25 Depth 2
                                        ##     Child Loop BB4_28 Depth 2
	movq	%r14, %rax
	shrq	$3, %rax
	movzbl	(%rdi,%rax), %r9d
	cmpl	$255, %r9d
	je	LBB4_6
## %bb.4:                               ##   in Loop: Header=BB4_3 Depth=1
	testl	%r9d, %r9d
	jne	LBB4_7
## %bb.5:                               ##   in Loop: Header=BB4_3 Depth=1
	movq	(%rdx,%r12), %rax
	movq	%rax, (%r11,%r14)
	addq	$8, %r12
	jmp	LBB4_30
	.p2align	4
LBB4_7:                                 ##   in Loop: Header=BB4_3 Depth=1
	movq	%rcx, %r11
	subq	%r12, %r11
	cmpq	$7, %r11
	jbe	LBB4_8
## %bb.12:                              ##   in Loop: Header=BB4_3 Depth=1
	movq	(%rdx,%r12), %rax
	jmp	LBB4_18
LBB4_8:                                 ##   in Loop: Header=BB4_3 Depth=1
	cmpq	%r12, %rcx
	jne	LBB4_10
## %bb.9:                               ##   in Loop: Header=BB4_3 Depth=1
	xorl	%eax, %eax
	jmp	LBB4_18
LBB4_10:                                ##   in Loop: Header=BB4_3 Depth=1
	movl	%r11d, %ebx
	andl	$3, %ebx
	movq	%r12, %rax
	subq	%rcx, %rax
	cmpq	$-4, %rax
	jbe	LBB4_13
## %bb.11:                              ##   in Loop: Header=BB4_3 Depth=1
	xorl	%esi, %esi
	xorl	%eax, %eax
	jmp	LBB4_16
LBB4_13:                                ##   in Loop: Header=BB4_3 Depth=1
	andl	$4, %r11d
	movq	-64(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r12), %r8
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%eax, %eax
	.p2align	4
LBB4_14:                                ##   Parent Loop BB4_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%r8,%rsi), %edi
	movl	%r10d, %ecx
	shlq	%cl, %rdi
	movzbl	-2(%r8,%rsi), %r13d
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r13
	orq	%rdi, %rax
	movzbl	-1(%r8,%rsi), %edi
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%r13, %rdi
	orq	%rax, %rdi
	movzbl	(%r8,%rsi), %eax
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rax
	orq	%rdi, %rax
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r11
	jne	LBB4_14
## %bb.15:                              ##   in Loop: Header=BB4_3 Depth=1
	testq	%rbx, %rbx
	je	LBB4_18
LBB4_16:                                ##   in Loop: Header=BB4_3 Depth=1
	addq	%r12, %rdx
	addq	%rsi, %rdx
	shlq	$3, %rsi
	xorl	%r8d, %r8d
	.p2align	4
LBB4_17:                                ##   Parent Loop BB4_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%r8), %r10d
	movl	%esi, %ecx
	shlq	%cl, %r10
	orq	%r10, %rax
	incq	%r8
	addq	$8, %rsi
	cmpq	%r8, %rbx
	jne	LBB4_17
LBB4_18:                                ##   in Loop: Header=BB4_3 Depth=1
	leaq	(%r9,%r9,8), %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rdx
	movzbl	8(%rdx,%rcx), %ebx
	movq	-128(%rbp), %rdx                ## 8-byte Reload
	movq	%rdx, %r13
	subq	%r15, %r13
	cmpq	$7, %r13
	movq	%r9, -136(%rbp)                 ## 8-byte Spill
	jbe	LBB4_19
## %bb.23:                              ##   in Loop: Header=BB4_3 Depth=1
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movq	(%r8,%r15), %r11
	jmp	LBB4_29
LBB4_19:                                ##   in Loop: Header=BB4_3 Depth=1
	cmpq	%r15, %rdx
	jne	LBB4_21
## %bb.20:                              ##   in Loop: Header=BB4_3 Depth=1
	xorl	%r11d, %r11d
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	jmp	LBB4_29
LBB4_21:                                ##   in Loop: Header=BB4_3 Depth=1
	movl	%r13d, %r9d
	andl	$3, %r9d
	movq	%r15, %rcx
	subq	%rdx, %rcx
	cmpq	$-4, %rcx
	jbe	LBB4_24
## %bb.22:                              ##   in Loop: Header=BB4_3 Depth=1
	xorl	%esi, %esi
	xorl	%r11d, %r11d
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	jmp	LBB4_27
LBB4_24:                                ##   in Loop: Header=BB4_3 Depth=1
	movq	%rbx, -72(%rbp)                 ## 8-byte Spill
	andl	$4, %r13d
	movq	-56(%rbp), %rcx                 ## 8-byte Reload
	leaq	(%rcx,%r15), %rdx
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	xorl	%r11d, %r11d
	.p2align	4
LBB4_25:                                ##   Parent Loop BB4_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	-3(%rdx,%rsi), %ebx
	movl	%r10d, %ecx
	shlq	%cl, %rbx
	movzbl	-2(%rdx,%rsi), %edi
	leal	8(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%rbx, %r11
	movzbl	-1(%rdx,%rsi), %ebx
	leal	16(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rbx
	orq	%rdi, %rbx
	orq	%r11, %rbx
	movzbl	(%rdx,%rsi), %r11d
	leal	24(%r10), %ecx
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r11
	orq	%rbx, %r11
	addq	$4, %rsi
	addq	$32, %r10
	cmpq	%rsi, %r13
	jne	LBB4_25
## %bb.26:                              ##   in Loop: Header=BB4_3 Depth=1
	testq	%r9, %r9
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movq	-72(%rbp), %rbx                 ## 8-byte Reload
	je	LBB4_29
LBB4_27:                                ##   in Loop: Header=BB4_3 Depth=1
	leaq	(%r8,%r15), %rdx
	addq	%rsi, %rdx
	shlq	$3, %rsi
	xorl	%r10d, %r10d
	.p2align	4
LBB4_28:                                ##   Parent Loop BB4_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%r10), %edi
	movl	%esi, %ecx
	shlq	%cl, %rdi
	orq	%rdi, %r11
	incq	%r10
	addq	$8, %rsi
	cmpq	%r10, %r9
	jne	LBB4_28
LBB4_29:                                ##   in Loop: Header=BB4_3 Depth=1
	movq	-136(%rbp), %rcx                ## 8-byte Reload
	shll	$6, %ecx
	movq	%r11, %xmm0
	movq	%rax, %xmm1
	punpcklqdq	%xmm0, %xmm1            ## xmm1 = xmm1[0],xmm0[0]
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE(%rip), %rax
	movdqu	(%rcx,%rax), %xmm0
	pand	%xmm1, %xmm0
	movdqu	16(%rcx,%rax), %xmm1
	movdqu	32(%rcx,%rax), %xmm2
	movdqu	48(%rcx,%rax), %xmm3
	pand	%xmm0, %xmm1
	pxor	%xmm1, %xmm0
	psllq	$32, %xmm1
	por	%xmm0, %xmm1
	pand	%xmm1, %xmm2
	pxor	%xmm2, %xmm1
	psllq	$16, %xmm2
	por	%xmm1, %xmm2
	pand	%xmm2, %xmm3
	pxor	%xmm3, %xmm2
	movq	%xmm2, %rax
	pshufd	$238, %xmm2, %xmm0              ## xmm0 = xmm2[2,3,2,3]
	movq	%xmm0, %rcx
	orq	%rax, %rcx
	pshufd	$238, %xmm3, %xmm0              ## xmm0 = xmm3[2,3,2,3]
	por	%xmm3, %xmm0
	movq	%xmm0, %rax
	shlq	$8, %rax
	orq	%rcx, %rax
	movq	-104(%rbp), %r11                ## 8-byte Reload
	movq	%rax, (%r11,%r14)
	movl	$8, %eax
	subl	%ebx, %eax
	addq	%rax, %r12
	addq	%rbx, %r15
	movq	-120(%rbp), %rdx                ## 8-byte Reload
	movq	-112(%rbp), %rdi                ## 8-byte Reload
	movq	-96(%rbp), %rbx                 ## 8-byte Reload
	movq	-88(%rbp), %rcx                 ## 8-byte Reload
	movq	-80(%rbp), %rsi                 ## 8-byte Reload
	jmp	LBB4_30
LBB4_1:
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	xorl	%r14d, %r14d
LBB4_31:
	cmpq	%rbx, %r14
	jae	LBB4_33
	.p2align	4
LBB4_32:                                ## =>This Inner Loop Header: Depth=1
	movq	%r12, %r9
	movq	%r15, %rax
	movq	%r14, %rsi
	shrq	$3, %rsi
	movl	%r14d, %ecx
	andb	$7, %cl
	movl	$1, %r10d
	shll	%cl, %r10d
	movzbl	(%rdi,%rsi), %ecx
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	testl	%ecx, %r10d
	leaq	(%rdx,%r9), %rcx
	leaq	(%r8,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%r15b
	sete	%r12b
	addq	%r9, %r12
	addq	%rax, %r15
	movzbl	(%rsi), %eax
	movb	%al, (%r11,%r14)
	incq	%r14
	cmpq	%r14, %rbx
	jne	LBB4_32
LBB4_33:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
LCPI5_0:
	.quad	9                               ## 0x9
	.quad	49                              ## 0x31
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.p2align	4
__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm: ## @_ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.cfi_startproc
## %bb.0:
	movq	%rdi, %rax
	leaq	(%r8,%rcx), %rdx
	leaq	(%r8,%rcx), %rdi
	addq	$7, %rdi
	shrq	$3, %rdi
	movq	%rdi, (%rax)
	movq	%rdx, 24(%rax)
	movq	%rdx, 8(%rax)
	cmpq	$8, %rdx
	jb	LBB5_1
## %bb.3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	pxor	%xmm0, %xmm0
	xorl	%edi, %edi
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %r11
	movdqa	LCPI5_0(%rip), %xmm1            ## xmm1 = [9,49]
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	jmp	LBB5_4
	.p2align	4
LBB5_8:                                 ##   in Loop: Header=BB5_4 Depth=1
	cmpq	$8, %r8
	cmovbq	%r8, %r14
	addq	%r15, %r14
	addq	%r14, %rdi
	paddq	%xmm1, %xmm0
	incq	%r10
LBB5_9:                                 ##   in Loop: Header=BB5_4 Depth=1
	movl	$8, %r14d
	subl	%ebx, %r14d
	subq	%r14, %rcx
	subq	%rbx, %r8
	addq	$-8, %rdx
	incq	%rsi
	cmpq	$7, %rdx
	jbe	LBB5_10
LBB5_4:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rsi), %r14d
	leaq	(%r14,%r14,8), %rbx
	movzbl	8(%r11,%rbx), %ebx
	incl	%r14d
	cmpb	$1, %r14b
	ja	LBB5_6
## %bb.5:                               ##   in Loop: Header=BB5_4 Depth=1
	addq	$8, %rdi
	incq	%r9
	jmp	LBB5_9
	.p2align	4
LBB5_6:                                 ##   in Loop: Header=BB5_4 Depth=1
	movl	$8, %r14d
	movq	%rcx, %r15
	cmpq	$8, %rcx
	jb	LBB5_8
## %bb.7:                               ##   in Loop: Header=BB5_4 Depth=1
	movl	$8, %r15d
	jmp	LBB5_8
LBB5_1:
	pxor	%xmm0, %xmm0
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	xorl	%edi, %edi
	jmp	LBB5_2
LBB5_10:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
LBB5_2:
	addq	%rdx, %rdi
	movdqu	%xmm0, 32(%rax)
	movq	%r10, 48(%rax)
	movq	%r9, 56(%rax)
	movq	%rdi, 16(%rax)
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE: ## @_ZN16cngcompress_bulk12_GLOBAL__N_19selectionE
	.ascii	"\000\001\002\003\004\005\006\007"
	.byte	0                               ## 0x0
	.ascii	"\b\000\001\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\000\b\001\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\t\000\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\001\b\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\t\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\t\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\n\000\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\002\b\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\013\000\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\003\b\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\f\000\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\004\b\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\r\000\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\005\b\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\000\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\b\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\f\r\001"
	.byte	6                               ## 0x6
	.asciz	"\b\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\005\006\b"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\000\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\b\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\f\r\000\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\005\b\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\f\000\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\b\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\000\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\b\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\000\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\b\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\001\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\001\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\000\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\b\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\000\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\b\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\b\t\n\013\f\r\016\017"
	.byte	8                               ## 0x8

	.p2align	3, 0x0                          ## @_ZN16cngcompress_bulk12_GLOBAL__N_18movementE
__ZN16cngcompress_bulk12_GLOBAL__N_18movementE:
	.space	48
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.space	24
	.space	24
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.space	24
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.space	24
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.space	24
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.space	24
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.space	24
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	48

	.p2align	3, 0x0                          ## @_ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE
__ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE:
	.space	64
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.space	16
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	255                             ## 0xff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.space	16
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.space	16
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	16776960                        ## 0xffff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	65280                           ## 0xff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	65535                           ## 0xffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	255                             ## 0xff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.space	16
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	4278190335                      ## 0xff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65535                           ## 0xffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	1099494850560                   ## 0xffff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	255                             ## 0xff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4278190080                      ## 0xff000000
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4278190080                      ## 0xff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	4278190080                      ## 0xff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	1095216660735                   ## 0xff000000ff
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	4294967040                      ## 0xffffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	255                             ## 0xff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	255                             ## 0xff
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16777215                        ## 0xffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	16777215                        ## 0xffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16711680                        ## 0xff0000
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65535                           ## 0xffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	255                             ## 0xff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	16776960                        ## 0xffff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16711680                        ## 0xff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	65280                           ## 0xff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	65535                           ## 0xffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	16711680                        ## 0xff0000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16711680                        ## 0xff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	4278190335                      ## 0xff0000ff
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	255                             ## 0xff
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	16776960                        ## 0xffff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	1095216660735                   ## 0xff000000ff
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.space	16
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.space	16
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.space	16
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	255                             ## 0xff
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65535                           ## 0xffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65535                           ## 0xffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65535                           ## 0xffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190335                      ## 0xff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.space	16
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.space	16
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16777215                        ## 0xffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65535                           ## 0xffff
	.quad	281474976645120                 ## 0xffffffff0000
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.space	16
	.quad	255                             ## 0xff
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.space	16
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	64

.subsections_via_symbols
