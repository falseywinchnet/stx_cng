	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ; -- Begin function _ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	cbz	x7, LBB0_3
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w11, #1                         ; =0x1
LBB0_2:                                 ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, #3
	ldrb	w12, [x0, x12]
	and	w13, w8, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x10
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x10, x10, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x8]
	add	x8, x8, #1
	cmp	x7, x8
	b.ne	LBB0_2
LBB0_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
lCPI1_0:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_1:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB1_30
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	neg	x12, x3
	neg	x13, x5
	add	x14, sp, #8
Lloh3:
	adrp	x15, lCPI1_0@PAGE
Lloh4:
	ldr	q0, [x15, lCPI1_0@PAGEOFF]
	mov	w15, #8                         ; =0x8
Lloh5:
	adrp	x16, lCPI1_1@PAGE
Lloh6:
	ldr	q1, [x16, lCPI1_1@PAGEOFF]
	movi.2d	v2, #0x000000000000ff
	mov	w16, #4                         ; =0x4
	dup.2d	v3, x16
Lloh7:
	adrp	x17, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh8:
	add	x17, x17, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	b	LBB1_4
LBB1_2:                                 ;   in Loop: Header=BB1_4 Depth=1
	ldr	x1, [x4, x9]
	str	x1, [x6, x10]
	add	x9, x9, #8
LBB1_3:                                 ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB1_31
LBB1_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_14 Depth 2
                                        ;     Child Loop BB1_17 Depth 2
                                        ;     Child Loop BB1_25 Depth 2
                                        ;     Child Loop BB1_28 Depth 2
	lsr	x1, x10, #3
	ldrb	w1, [x0, x1]
	cmp	w1, #255
	b.eq	LBB1_2
; %bb.5:                                ;   in Loop: Header=BB1_4 Depth=1
	cbnz	w1, LBB1_7
; %bb.6:                                ;   in Loop: Header=BB1_4 Depth=1
	ldr	x1, [x2, x8]
	str	x1, [x6, x10]
	add	x8, x8, #8
	b	LBB1_3
LBB1_7:                                 ;   in Loop: Header=BB1_4 Depth=1
	sub	x21, x3, x8
	cmp	x21, #7
	b.ls	LBB1_9
; %bb.8:                                ;   in Loop: Header=BB1_4 Depth=1
	ldr	x19, [x2, x8]
	b	LBB1_18
LBB1_9:                                 ;   in Loop: Header=BB1_4 Depth=1
	cmp	x3, x8
	b.ne	LBB1_11
; %bb.10:                               ;   in Loop: Header=BB1_4 Depth=1
	mov	x19, #0                         ; =0x0
	b	LBB1_18
LBB1_11:                                ;   in Loop: Header=BB1_4 Depth=1
	cmp	x21, #4
	b.hs	LBB1_13
; %bb.12:                               ;   in Loop: Header=BB1_4 Depth=1
	mov	x20, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	b	LBB1_16
LBB1_13:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x19, x2, x8
	and	x20, x21, #0x4
	movi.2d	v4, #0000000000000000
	and	x22, x21, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB1_14:                                ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x19], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	dup.2d	v16, x16
	add.2d	v7, v7, v16
	add.2d	v5, v5, v16
	subs	x22, x22, #4
	b.ne	LBB1_14
; %bb.15:                               ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x19, d4
	cmp	x21, x20
	b.eq	LBB1_18
LBB1_16:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x22, x20, x8
	add	x21, x22, x12
	lsl	x20, x20, #3
	add	x22, x2, x22
LBB1_17:                                ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w23, [x22], #1
	lsl	x23, x23, x20
	orr	x19, x23, x19
	add	x20, x20, #8
	adds	x21, x21, #1
	b.lo	LBB1_17
LBB1_18:                                ;   in Loop: Header=BB1_4 Depth=1
	sub	x21, x5, x9
	cmp	x21, #7
	b.ls	LBB1_20
; %bb.19:                               ;   in Loop: Header=BB1_4 Depth=1
	ldr	x22, [x4, x9]
	b	LBB1_29
LBB1_20:                                ;   in Loop: Header=BB1_4 Depth=1
	cmp	x5, x9
	b.ne	LBB1_22
; %bb.21:                               ;   in Loop: Header=BB1_4 Depth=1
	mov	x22, #0                         ; =0x0
	b	LBB1_29
LBB1_22:                                ;   in Loop: Header=BB1_4 Depth=1
	cmp	x21, #4
	b.hs	LBB1_24
; %bb.23:                               ;   in Loop: Header=BB1_4 Depth=1
	mov	x20, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	b	LBB1_27
LBB1_24:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x22, x4, x9
	and	x20, x21, #0x4
	movi.2d	v4, #0000000000000000
	and	x23, x21, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB1_25:                                ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x22], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	add.2d	v7, v7, v3
	add.2d	v5, v5, v3
	subs	x23, x23, #4
	b.ne	LBB1_25
; %bb.26:                               ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x22, d4
	cmp	x21, x20
	b.eq	LBB1_29
LBB1_27:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x23, x20, x9
	add	x21, x23, x13
	lsl	x20, x20, #3
	add	x23, x4, x23
LBB1_28:                                ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w24, [x23], #1
	lsl	x24, x24, x20
	orr	x22, x24, x22
	add	x20, x20, #8
	adds	x21, x21, #1
	b.lo	LBB1_28
LBB1_29:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x1, x1, x1, lsl #3
	add	x1, x17, x1
	ldrb	w20, [x1, #8]
	stp	x19, x22, [sp, #8]
	add	x19, x6, x10
	ldrb	w21, [x1]
	ldrb	w21, [x14, x21]
	strb	w21, [x19]
	ldrb	w21, [x1, #1]
	ldrb	w21, [x14, x21]
	strb	w21, [x19, #1]
	ldrb	w21, [x1, #2]
	ldrb	w21, [x14, x21]
	strb	w21, [x19, #2]
	ldrb	w21, [x1, #3]
	ldrb	w21, [x14, x21]
	strb	w21, [x19, #3]
	ldrb	w21, [x1, #4]
	ldrb	w21, [x14, x21]
	strb	w21, [x19, #4]
	ldrb	w21, [x1, #5]
	ldrb	w21, [x14, x21]
	strb	w21, [x19, #5]
	ldrb	w21, [x1, #6]
	ldrb	w21, [x14, x21]
	strb	w21, [x19, #6]
	ldrb	w1, [x1, #7]
	ldrb	w1, [x14, x1]
	strb	w1, [x19, #7]
	sub	w1, w15, w20
	add	x8, x1, x8
	add	x9, x9, x20
	b	LBB1_3
LBB1_30:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB1_31:
	cmp	x10, x7
	b.hs	LBB1_34
; %bb.32:
	mov	w11, #1                         ; =0x1
LBB1_33:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB1_33
LBB1_34:
	ldr	x8, [sp, #24]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_36
; %bb.35:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB1_36:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAdd	Lloh7, Lloh8
	.loh AdrpLdr	Lloh5, Lloh6
	.loh AdrpLdr	Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
lCPI2_0:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI2_1:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI2_2:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI2_3:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI2_4:
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
lCPI2_5:
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB2_30
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	movi.4h	v0, #8
Lloh12:
	adrp	x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh13:
	add	x12, x12, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	movi.4h	v1, #56
	movi.2d	v2, #0x000000000000ff
Lloh14:
	adrp	x13, lCPI2_2@PAGE
Lloh15:
	ldr	q3, [x13, lCPI2_2@PAGEOFF]
Lloh16:
	adrp	x13, lCPI2_3@PAGE
Lloh17:
	ldr	q4, [x13, lCPI2_3@PAGEOFF]
Lloh18:
	adrp	x13, lCPI2_4@PAGE
Lloh19:
	ldr	q5, [x13, lCPI2_4@PAGEOFF]
Lloh20:
	adrp	x13, lCPI2_5@PAGE
Lloh21:
	ldr	q6, [x13, lCPI2_5@PAGEOFF]
	mov	w13, #8                         ; =0x8
Lloh22:
	adrp	x14, lCPI2_0@PAGE
Lloh23:
	ldr	q7, [x14, lCPI2_0@PAGEOFF]
Lloh24:
	adrp	x14, lCPI2_1@PAGE
Lloh25:
	ldr	q16, [x14, lCPI2_1@PAGEOFF]
	mov	w14, #4                         ; =0x4
	dup.2d	v17, x14
	b	LBB2_4
LBB2_2:                                 ;   in Loop: Header=BB2_4 Depth=1
	ldr	x15, [x4, x9]
	str	x15, [x6, x10]
	add	x9, x9, #8
LBB2_3:                                 ;   in Loop: Header=BB2_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB2_31
LBB2_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_14 Depth 2
                                        ;     Child Loop BB2_17 Depth 2
                                        ;     Child Loop BB2_25 Depth 2
                                        ;     Child Loop BB2_28 Depth 2
	lsr	x15, x10, #3
	ldrb	w15, [x0, x15]
	cmp	w15, #255
	b.eq	LBB2_2
; %bb.5:                                ;   in Loop: Header=BB2_4 Depth=1
	cbnz	w15, LBB2_7
; %bb.6:                                ;   in Loop: Header=BB2_4 Depth=1
	ldr	x15, [x2, x8]
	str	x15, [x6, x10]
	add	x8, x8, #8
	b	LBB2_3
LBB2_7:                                 ;   in Loop: Header=BB2_4 Depth=1
	sub	x1, x3, x8
	cmp	x1, #7
	b.ls	LBB2_9
; %bb.8:                                ;   in Loop: Header=BB2_4 Depth=1
	ldr	x16, [x2, x8]
	b	LBB2_18
LBB2_9:                                 ;   in Loop: Header=BB2_4 Depth=1
	cmp	x3, x8
	b.ne	LBB2_11
; %bb.10:                               ;   in Loop: Header=BB2_4 Depth=1
	mov	x16, #0                         ; =0x0
	b	LBB2_18
LBB2_11:                                ;   in Loop: Header=BB2_4 Depth=1
	cmp	x1, #4
	b.hs	LBB2_13
; %bb.12:                               ;   in Loop: Header=BB2_4 Depth=1
	mov	x17, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	b	LBB2_16
LBB2_13:                                ;   in Loop: Header=BB2_4 Depth=1
	add	x16, x2, x8
	and	x17, x1, #0x4
	movi.2d	v18, #0000000000000000
	and	x19, x1, #0x4
	mov.16b	v19, v16
	movi.2d	v20, #0000000000000000
	mov.16b	v21, v7
LBB2_14:                                ;   Parent Loop BB2_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s22, [x16], #4
	ushll.8h	v22, v22, #0
	ushll.4s	v22, v22, #0
	ushll2.2d	v23, v22, #0
	and.16b	v23, v23, v2
	ushll.2d	v22, v22, #0
	and.16b	v22, v22, v2
	shl.2d	v24, v21, #3
	shl.2d	v25, v19, #3
	ushl.2d	v22, v22, v25
	ushl.2d	v23, v23, v24
	orr.16b	v18, v23, v18
	orr.16b	v20, v22, v20
	dup.2d	v22, x14
	add.2d	v21, v21, v22
	add.2d	v19, v19, v22
	subs	x19, x19, #4
	b.ne	LBB2_14
; %bb.15:                               ;   in Loop: Header=BB2_4 Depth=1
	orr.16b	v18, v20, v18
	mov	d19, v18[1]
	orr.8b	v18, v18, v19
	fmov	x16, d18
	cmp	x1, x17
	b.eq	LBB2_18
LBB2_16:                                ;   in Loop: Header=BB2_4 Depth=1
	sub	x1, x3, x17
	sub	x1, x1, x8
	lsl	x19, x17, #3
	add	x17, x8, x17
	add	x17, x2, x17
LBB2_17:                                ;   Parent Loop BB2_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w20, [x17], #1
	lsl	x20, x20, x19
	orr	x16, x20, x16
	add	x19, x19, #8
	subs	x1, x1, #1
	b.ne	LBB2_17
LBB2_18:                                ;   in Loop: Header=BB2_4 Depth=1
	sub	x19, x5, x9
	cmp	x19, #7
	b.ls	LBB2_20
; %bb.19:                               ;   in Loop: Header=BB2_4 Depth=1
	ldr	x17, [x4, x9]
	b	LBB2_29
LBB2_20:                                ;   in Loop: Header=BB2_4 Depth=1
	cmp	x5, x9
	b.ne	LBB2_22
; %bb.21:                               ;   in Loop: Header=BB2_4 Depth=1
	mov	x17, #0                         ; =0x0
	b	LBB2_29
LBB2_22:                                ;   in Loop: Header=BB2_4 Depth=1
	cmp	x19, #4
	b.hs	LBB2_24
; %bb.23:                               ;   in Loop: Header=BB2_4 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x17, #0                         ; =0x0
	b	LBB2_27
LBB2_24:                                ;   in Loop: Header=BB2_4 Depth=1
	add	x17, x4, x9
	and	x1, x19, #0x4
	movi.2d	v18, #0000000000000000
	and	x20, x19, #0x4
	mov.16b	v19, v16
	movi.2d	v20, #0000000000000000
	mov.16b	v21, v7
LBB2_25:                                ;   Parent Loop BB2_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s22, [x17], #4
	ushll.8h	v22, v22, #0
	ushll.4s	v22, v22, #0
	ushll2.2d	v23, v22, #0
	and.16b	v23, v23, v2
	ushll.2d	v22, v22, #0
	and.16b	v22, v22, v2
	shl.2d	v24, v21, #3
	shl.2d	v25, v19, #3
	ushl.2d	v22, v22, v25
	ushl.2d	v23, v23, v24
	orr.16b	v18, v23, v18
	orr.16b	v20, v22, v20
	add.2d	v21, v21, v17
	add.2d	v19, v19, v17
	subs	x20, x20, #4
	b.ne	LBB2_25
; %bb.26:                               ;   in Loop: Header=BB2_4 Depth=1
	orr.16b	v18, v20, v18
	mov	d19, v18[1]
	orr.8b	v18, v18, v19
	fmov	x17, d18
	cmp	x19, x1
	b.eq	LBB2_29
LBB2_27:                                ;   in Loop: Header=BB2_4 Depth=1
	sub	x19, x5, x1
	sub	x19, x19, x9
	lsl	x20, x1, #3
	add	x1, x9, x1
	add	x1, x4, x1
LBB2_28:                                ;   Parent Loop BB2_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w21, [x1], #1
	lsl	x21, x21, x20
	orr	x17, x21, x17
	add	x20, x20, #8
	subs	x19, x19, #1
	b.ne	LBB2_28
LBB2_29:                                ;   in Loop: Header=BB2_4 Depth=1
	add	x1, x15, x15, lsl #3
	add	x1, x12, x1
	ldr	s18, [x1]
	ushll.8h	v18, v18, #0
	cmhi.4h	v19, v0, v18
	ushll.4s	v19, v19, #0
	ushll2.2d	v20, v19, #0
	shl.2d	v20, v20, #56
	sshr.2d	v20, v20, #56
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #56
	dup.2d	v21, x16
	dup.2d	v22, x17
	sshr.2d	v19, v19, #56
	bsl.16b	v19, v21, v22
	bsl.16b	v20, v21, v22
	shl.4h	v18, v18, #3
	and.8b	v18, v18, v1
	ushll.4s	v18, v18, #0
	ushll.2d	v21, v18, #0
	and.16b	v21, v21, v2
	ushll2.2d	v18, v18, #0
	and.16b	v18, v18, v2
	neg.2d	v18, v18
	ushl.2d	v18, v20, v18
	neg.2d	v20, v21
	ushl.2d	v19, v19, v20
	ushl.2d	v19, v19, v3
	ushl.2d	v18, v18, v4
	and.16b	v18, v18, v5
	and.16b	v19, v19, v6
	ldrb	w19, [x1, #4]
	tst	w19, #0xf8
	csel	x20, x16, x17, eq
	ubfiz	x19, x19, #3, #3
	lsr	x19, x20, x19
	ubfiz	x19, x19, #32, #8
	ldrb	w20, [x1, #5]
	tst	w20, #0xf8
	csel	x21, x16, x17, eq
	ubfiz	x20, x20, #3, #3
	lsr	x20, x21, x20
	ldrb	w21, [x1, #6]
	tst	w21, #0xf8
	csel	x22, x16, x17, eq
	ubfiz	x21, x21, #3, #3
	lsr	x21, x22, x21
	ubfiz	x21, x21, #48, #8
	ldrb	w22, [x1, #7]
	tst	w15, #0x80
	csel	x15, x17, x16, ne
	ubfiz	x16, x22, #3, #3
	lsr	x15, x15, x16
	orr.16b	v18, v19, v18
	mov	d19, v18[1]
	orr.8b	v18, v18, v19
	fmov	x16, d18
	orr	x16, x16, x19
	bfi	x21, x20, #40, #8
	orr	x16, x16, x21
	orr	x15, x16, x15, lsl #56
	ldrb	w16, [x1, #8]
	str	x15, [x6, x10]
	sub	w15, w13, w16
	add	x8, x15, x8
	add	x9, x9, x16
	b	LBB2_3
LBB2_30:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB2_31:
	cmp	x10, x7
	b.hs	LBB2_34
; %bb.32:
	mov	w11, #1                         ; =0x1
LBB2_33:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB2_33
LBB2_34:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
lCPI3_0:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI3_1:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB3_30
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w12, #48                        ; =0x30
	mov	w13, #8                         ; =0x8
	mov	x14, #-1                        ; =0xffffffffffffffff
Lloh26:
	adrp	x15, lCPI3_0@PAGE
Lloh27:
	ldr	q0, [x15, lCPI3_0@PAGEOFF]
Lloh28:
	adrp	x15, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh29:
	add	x15, x15, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
Lloh30:
	adrp	x16, lCPI3_1@PAGE
Lloh31:
	ldr	q1, [x16, lCPI3_1@PAGEOFF]
	movi.2d	v2, #0x000000000000ff
	mov	w16, #4                         ; =0x4
	dup.2d	v3, x16
Lloh32:
	adrp	x17, __ZN16cngcompress_bulk12_GLOBAL__N_18movementE@PAGE
Lloh33:
	add	x17, x17, __ZN16cngcompress_bulk12_GLOBAL__N_18movementE@PAGEOFF
	b	LBB3_4
LBB3_2:                                 ;   in Loop: Header=BB3_4 Depth=1
	ldr	x1, [x4, x9]
	str	x1, [x6, x10]
	add	x9, x9, #8
LBB3_3:                                 ;   in Loop: Header=BB3_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB3_31
LBB3_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_14 Depth 2
                                        ;     Child Loop BB3_17 Depth 2
                                        ;     Child Loop BB3_25 Depth 2
                                        ;     Child Loop BB3_28 Depth 2
	lsr	x1, x10, #3
	ldrb	w1, [x0, x1]
	cmp	w1, #255
	b.eq	LBB3_2
; %bb.5:                                ;   in Loop: Header=BB3_4 Depth=1
	cbnz	w1, LBB3_7
; %bb.6:                                ;   in Loop: Header=BB3_4 Depth=1
	ldr	x1, [x2, x8]
	str	x1, [x6, x10]
	add	x8, x8, #8
	b	LBB3_3
LBB3_7:                                 ;   in Loop: Header=BB3_4 Depth=1
	sub	x21, x3, x8
	cmp	x21, #7
	b.ls	LBB3_9
; %bb.8:                                ;   in Loop: Header=BB3_4 Depth=1
	ldr	x19, [x2, x8]
	b	LBB3_18
LBB3_9:                                 ;   in Loop: Header=BB3_4 Depth=1
	cmp	x3, x8
	b.ne	LBB3_11
; %bb.10:                               ;   in Loop: Header=BB3_4 Depth=1
	mov	x19, #0                         ; =0x0
	b	LBB3_18
LBB3_11:                                ;   in Loop: Header=BB3_4 Depth=1
	cmp	x21, #4
	b.hs	LBB3_13
; %bb.12:                               ;   in Loop: Header=BB3_4 Depth=1
	mov	x20, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	b	LBB3_16
LBB3_13:                                ;   in Loop: Header=BB3_4 Depth=1
	add	x19, x2, x8
	and	x20, x21, #0x4
	movi.2d	v4, #0000000000000000
	and	x22, x21, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB3_14:                                ;   Parent Loop BB3_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x19], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	dup.2d	v16, x16
	add.2d	v7, v7, v16
	add.2d	v5, v5, v16
	subs	x22, x22, #4
	b.ne	LBB3_14
; %bb.15:                               ;   in Loop: Header=BB3_4 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x19, d4
	cmp	x21, x20
	b.eq	LBB3_18
LBB3_16:                                ;   in Loop: Header=BB3_4 Depth=1
	sub	x21, x3, x20
	sub	x21, x21, x8
	lsl	x22, x20, #3
	add	x20, x8, x20
	add	x20, x2, x20
LBB3_17:                                ;   Parent Loop BB3_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w23, [x20], #1
	lsl	x23, x23, x22
	orr	x19, x23, x19
	add	x22, x22, #8
	subs	x21, x21, #1
	b.ne	LBB3_17
LBB3_18:                                ;   in Loop: Header=BB3_4 Depth=1
	sub	x22, x5, x9
	cmp	x22, #7
	b.ls	LBB3_20
; %bb.19:                               ;   in Loop: Header=BB3_4 Depth=1
	ldr	x20, [x4, x9]
	b	LBB3_29
LBB3_20:                                ;   in Loop: Header=BB3_4 Depth=1
	cmp	x5, x9
	b.ne	LBB3_22
; %bb.21:                               ;   in Loop: Header=BB3_4 Depth=1
	mov	x20, #0                         ; =0x0
	b	LBB3_29
LBB3_22:                                ;   in Loop: Header=BB3_4 Depth=1
	cmp	x22, #4
	b.hs	LBB3_24
; %bb.23:                               ;   in Loop: Header=BB3_4 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	b	LBB3_27
LBB3_24:                                ;   in Loop: Header=BB3_4 Depth=1
	add	x20, x4, x9
	and	x21, x22, #0x4
	movi.2d	v4, #0000000000000000
	and	x23, x22, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB3_25:                                ;   Parent Loop BB3_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x20], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	add.2d	v7, v7, v3
	add.2d	v5, v5, v3
	subs	x23, x23, #4
	b.ne	LBB3_25
; %bb.26:                               ;   in Loop: Header=BB3_4 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x20, d4
	cmp	x22, x21
	b.eq	LBB3_29
LBB3_27:                                ;   in Loop: Header=BB3_4 Depth=1
	sub	x22, x5, x21
	sub	x22, x22, x9
	lsl	x23, x21, #3
	add	x21, x9, x21
	add	x21, x4, x21
LBB3_28:                                ;   Parent Loop BB3_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w24, [x21], #1
	lsl	x24, x24, x23
	orr	x20, x24, x20
	add	x23, x23, #8
	subs	x22, x22, #1
	b.ne	LBB3_28
LBB3_29:                                ;   in Loop: Header=BB3_4 Depth=1
	add	x21, x1, x1, lsl #3
	add	x21, x15, x21
	ldrb	w21, [x21, #8]
	umaddl	x1, w1, w12, x17
	sub	w22, w13, w21
	add	x8, x8, x22
	lsl	w22, w22, #3
	lsl	x22, x14, x22
	bic	x19, x19, x22
	ldp	x22, x23, [x1]
	and	x22, x22, x19
	eor	x19, x22, x19
	orr	x19, x19, x22, lsl #32
	and	x22, x19, x23
	eor	x19, x22, x19
	orr	x19, x19, x22, lsl #16
	ldp	x22, x23, [x1, #16]
	and	x22, x19, x22
	eor	x19, x22, x19
	lsl	x24, x21, #3
	lsl	x24, x14, x24
	bic	x20, x20, x24
	and	x23, x23, x20
	eor	x20, x23, x20
	orr	x20, x20, x23, lsl #32
	ldp	x23, x1, [x1, #32]
	and	x23, x20, x23
	eor	x20, x23, x20
	orr	x20, x20, x23, lsl #16
	and	x1, x20, x1
	eor	x20, x1, x20
	orr	x1, x1, x22
	orr	x19, x20, x19
	orr	x1, x19, x1, lsl #8
	str	x1, [x6, x10]
	add	x9, x9, w21, uxtw
	b	LBB3_3
LBB3_30:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB3_31:
	cmp	x10, x7
	b.hs	LBB3_34
; %bb.32:
	mov	w11, #1                         ; =0x1
LBB3_33:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB3_33
LBB3_34:
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
lCPI4_0:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI4_1:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ; @_ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	ands	x11, x7, #0xfffffffffffffff8
	b.eq	LBB4_30
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w12, #8                         ; =0x8
Lloh34:
	adrp	x13, lCPI4_0@PAGE
Lloh35:
	ldr	q0, [x13, lCPI4_0@PAGEOFF]
Lloh36:
	adrp	x13, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh37:
	add	x13, x13, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
Lloh38:
	adrp	x14, lCPI4_1@PAGE
Lloh39:
	ldr	q1, [x14, lCPI4_1@PAGEOFF]
	movi.2d	v2, #0x000000000000ff
	mov	w14, #4                         ; =0x4
	dup.2d	v3, x14
Lloh40:
	adrp	x15, __ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE@PAGE
Lloh41:
	add	x15, x15, __ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE@PAGEOFF
	b	LBB4_4
LBB4_2:                                 ;   in Loop: Header=BB4_4 Depth=1
	ldr	x16, [x4, x9]
	str	x16, [x6, x10]
	add	x9, x9, #8
LBB4_3:                                 ;   in Loop: Header=BB4_4 Depth=1
	add	x10, x10, #8
	cmp	x10, x11
	b.hs	LBB4_31
LBB4_4:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_14 Depth 2
                                        ;     Child Loop BB4_17 Depth 2
                                        ;     Child Loop BB4_25 Depth 2
                                        ;     Child Loop BB4_28 Depth 2
	lsr	x16, x10, #3
	ldrb	w16, [x0, x16]
	cmp	w16, #255
	b.eq	LBB4_2
; %bb.5:                                ;   in Loop: Header=BB4_4 Depth=1
	cbnz	w16, LBB4_7
; %bb.6:                                ;   in Loop: Header=BB4_4 Depth=1
	ldr	x16, [x2, x8]
	str	x16, [x6, x10]
	add	x8, x8, #8
	b	LBB4_3
LBB4_7:                                 ;   in Loop: Header=BB4_4 Depth=1
	sub	x19, x3, x8
	cmp	x19, #7
	b.ls	LBB4_9
; %bb.8:                                ;   in Loop: Header=BB4_4 Depth=1
	ldr	x17, [x2, x8]
	b	LBB4_18
LBB4_9:                                 ;   in Loop: Header=BB4_4 Depth=1
	cmp	x3, x8
	b.ne	LBB4_11
; %bb.10:                               ;   in Loop: Header=BB4_4 Depth=1
	mov	x17, #0                         ; =0x0
	b	LBB4_18
LBB4_11:                                ;   in Loop: Header=BB4_4 Depth=1
	cmp	x19, #4
	b.hs	LBB4_13
; %bb.12:                               ;   in Loop: Header=BB4_4 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x17, #0                         ; =0x0
	b	LBB4_16
LBB4_13:                                ;   in Loop: Header=BB4_4 Depth=1
	add	x17, x2, x8
	and	x1, x19, #0x4
	movi.2d	v4, #0000000000000000
	and	x20, x19, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB4_14:                                ;   Parent Loop BB4_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x17], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	dup.2d	v16, x14
	add.2d	v7, v7, v16
	add.2d	v5, v5, v16
	subs	x20, x20, #4
	b.ne	LBB4_14
; %bb.15:                               ;   in Loop: Header=BB4_4 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x17, d4
	cmp	x19, x1
	b.eq	LBB4_18
LBB4_16:                                ;   in Loop: Header=BB4_4 Depth=1
	sub	x19, x3, x1
	sub	x19, x19, x8
	lsl	x20, x1, #3
	add	x1, x8, x1
	add	x1, x2, x1
LBB4_17:                                ;   Parent Loop BB4_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w21, [x1], #1
	lsl	x21, x21, x20
	orr	x17, x21, x17
	add	x20, x20, #8
	subs	x19, x19, #1
	b.ne	LBB4_17
LBB4_18:                                ;   in Loop: Header=BB4_4 Depth=1
	sub	x19, x5, x9
	cmp	x19, #7
	b.ls	LBB4_20
; %bb.19:                               ;   in Loop: Header=BB4_4 Depth=1
	ldr	x20, [x4, x9]
	b	LBB4_29
LBB4_20:                                ;   in Loop: Header=BB4_4 Depth=1
	cmp	x5, x9
	b.ne	LBB4_22
; %bb.21:                               ;   in Loop: Header=BB4_4 Depth=1
	mov	x20, #0                         ; =0x0
	b	LBB4_29
LBB4_22:                                ;   in Loop: Header=BB4_4 Depth=1
	cmp	x19, #4
	b.hs	LBB4_24
; %bb.23:                               ;   in Loop: Header=BB4_4 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x20, #0                         ; =0x0
	b	LBB4_27
LBB4_24:                                ;   in Loop: Header=BB4_4 Depth=1
	add	x20, x4, x9
	and	x1, x19, #0x4
	movi.2d	v4, #0000000000000000
	and	x21, x19, #0x4
	mov.16b	v5, v1
	movi.2d	v6, #0000000000000000
	mov.16b	v7, v0
LBB4_25:                                ;   Parent Loop BB4_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s16, [x20], #4
	ushll.8h	v16, v16, #0
	ushll.4s	v16, v16, #0
	ushll2.2d	v17, v16, #0
	and.16b	v17, v17, v2
	ushll.2d	v16, v16, #0
	and.16b	v16, v16, v2
	shl.2d	v18, v7, #3
	shl.2d	v19, v5, #3
	ushl.2d	v16, v16, v19
	ushl.2d	v17, v17, v18
	orr.16b	v4, v17, v4
	orr.16b	v6, v16, v6
	add.2d	v7, v7, v3
	add.2d	v5, v5, v3
	subs	x21, x21, #4
	b.ne	LBB4_25
; %bb.26:                               ;   in Loop: Header=BB4_4 Depth=1
	orr.16b	v4, v6, v4
	mov	d5, v4[1]
	orr.8b	v4, v4, v5
	fmov	x20, d4
	cmp	x19, x1
	b.eq	LBB4_29
LBB4_27:                                ;   in Loop: Header=BB4_4 Depth=1
	sub	x19, x5, x1
	sub	x19, x19, x9
	lsl	x21, x1, #3
	add	x1, x9, x1
	add	x1, x4, x1
LBB4_28:                                ;   Parent Loop BB4_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w22, [x1], #1
	lsl	x22, x22, x21
	orr	x20, x22, x20
	add	x21, x21, #8
	subs	x19, x19, #1
	b.ne	LBB4_28
LBB4_29:                                ;   in Loop: Header=BB4_4 Depth=1
	add	x1, x15, x16, lsl #6
	fmov	d4, x17
	mov.d	v4[1], x20
	ldp	q5, q6, [x1]
	and.16b	v4, v5, v4
	and.16b	v5, v6, v4
	eor.16b	v4, v5, v4
	shl.2d	v5, v5, #32
	orr.16b	v4, v4, v5
	ldp	q5, q6, [x1, #32]
	and.16b	v5, v4, v5
	eor.16b	v4, v5, v4
	shl.2d	v5, v5, #16
	orr.16b	v4, v4, v5
	add	x16, x16, x16, lsl #3
	add	x16, x13, x16
	and.16b	v5, v4, v6
	eor.16b	v4, v5, v4
	mov.d	x17, v4[1]
	fmov	x1, d4
	dup.2d	v4, v5[1]
	orr.16b	v4, v5, v4
	fmov	x19, d4
	orr	x1, x1, x19, lsl #8
	orr	x17, x1, x17
	ldrb	w16, [x16, #8]
	str	x17, [x6, x10]
	sub	w17, w12, w16
	add	x8, x17, x8
	add	x9, x9, x16
	b	LBB4_3
LBB4_30:
	mov	x9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB4_31:
	cmp	x10, x7
	b.hs	LBB4_34
; %bb.32:
	mov	w11, #1                         ; =0x1
LBB4_33:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x10, #3
	ldrb	w12, [x0, x12]
	and	w13, w10, #0x7
	lsl	w13, w11, w13
	add	x14, x2, x8
	add	x15, x4, x9
	tst	w13, w12
	csel	x12, x14, x15, eq
	cinc	x8, x8, eq
	cinc	x9, x9, ne
	ldrb	w12, [x12]
	strb	w12, [x6, x10]
	add	x10, x10, #1
	cmp	x7, x10
	b.ne	LBB4_33
LBB4_34:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
lCPI5_0:
	.quad	9                               ; 0x9
	.quad	49                              ; 0x31
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.p2align	2
__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm: ; @_ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.cfi_startproc
; %bb.0:
	add	x9, x3, x2
	add	x10, x9, #7
	str	x9, [x8, #24]
	lsr	x10, x10, #3
	stp	x10, x9, [x8]
	cmp	x9, #8
	b.lo	LBB5_6
; %bb.1:
	mov	x10, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	mov	w13, #8                         ; =0x8
Lloh42:
	adrp	x14, lCPI5_0@PAGE
Lloh43:
	ldr	q1, [x14, lCPI5_0@PAGEOFF]
Lloh44:
	adrp	x14, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGE
Lloh45:
	add	x14, x14, __ZN16cngcompress_bulk12_GLOBAL__N_19selectionE@PAGEOFF
	b	LBB5_4
LBB5_2:                                 ;   in Loop: Header=BB5_4 Depth=1
	cmp	x2, #8
	csel	x16, x2, x13, lo
	cmp	x3, #8
	csel	x17, x3, x13, lo
	add	x16, x16, x17
	add	x10, x16, x10
	add.2d	v0, v0, v1
	add	x12, x12, #1
LBB5_3:                                 ;   in Loop: Header=BB5_4 Depth=1
	add	x15, x15, w15, uxtw #3
	add	x15, x14, x15
	ldrb	w15, [x15, #8]
	sub	w16, w13, w15
	sub	x2, x2, x16
	sub	x3, x3, x15
	sub	x9, x9, #8
	cmp	x9, #7
	b.ls	LBB5_7
LBB5_4:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w15, [x0], #1
	sub	w16, w15, #255
	cmn	w16, #255
	b.hi	LBB5_2
; %bb.5:                                ;   in Loop: Header=BB5_4 Depth=1
	add	x10, x10, #8
	add	x11, x11, #1
	b	LBB5_3
LBB5_6:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
LBB5_7:
	str	q0, [x8, #32]
	stp	x12, x11, [x8, #48]
	add	x9, x10, x9
	str	x9, [x8, #16]
	ret
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE: ; @_ZN16cngcompress_bulk12_GLOBAL__N_19selectionE
	.ascii	"\000\001\002\003\004\005\006\007"
	.byte	0                               ; 0x0
	.ascii	"\b\000\001\002\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\000\b\001\002\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\t\000\001\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\001\b\002\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\t\001\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\t\001\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\n\000\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\002\b\003\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\t\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\t\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\n\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\t\002\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\n\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\n\001\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\013\000\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\003\b\004\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\t\003\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\n\002\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\013\001\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\f\000\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\004\b\005\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\003\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\002\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\001\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\000\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\b\t\004\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\t\n\003\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\n\013\002\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\013\f\001\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\f\r\000\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\004\005\b\006"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\003\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\002\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\001\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\000\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\b\004\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\t\003\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\n\002\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\013\001\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\f\000\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\004\b\t\005"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\003\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\002\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\001\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\000\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\b\t\n\004"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\013\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\t\n\013\003"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\013\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\n\013\f\002"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\013\f\r\001"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\013\f\r\001"
	.byte	6                               ; 0x6
	.asciz	"\b\t\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\004\005\006\b"
	.byte	1                               ; 0x1
	.ascii	"\b\000\001\002\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\000\b\001\002\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\t\000\001\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\001\b\002\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\t\001\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\t\001\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\n\000\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\002\b\003\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\t\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\t\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\n\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\t\002\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\n\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\n\001\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\013\000\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\003\b\004\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\t\003\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\n\002\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\013\001\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\f\000\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\004\b\005\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\003\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\002\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\001\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\000\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\b\t\004\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\t\n\003\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\n\013\002\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\013\f\001\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\013\f\r\000\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\004\005\b\t"
	.byte	2                               ; 0x2
	.ascii	"\b\000\001\002\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\000\b\001\002\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\t\000\001\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\001\b\002\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\t\001\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\t\001\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\n\000\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\002\b\003\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\t\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\t\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\n\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\t\002\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\n\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\n\001\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\013\000\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\003\b\004\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\t\003\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\n\002\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\013\001\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\013\f\000\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\004\b\t\n"
	.byte	3                               ; 0x3
	.ascii	"\b\000\001\002\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\000\b\001\002\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\t\000\001\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\001\b\002\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\t\001\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\t\001\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\n\000\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\002\b\003\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\t\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\t\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\n\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\t\002\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\n\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\n\001\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\013\000\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\003\b\t\n\013"
	.byte	4                               ; 0x4
	.ascii	"\b\000\001\002\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\000\b\001\002\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\t\000\001\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\001\b\002\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\t\001\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\t\001\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\n\000\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\002\b\t\n\013\f"
	.byte	5                               ; 0x5
	.ascii	"\b\000\001\t\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\000\b\001\t\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\t\000\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\001\b\t\n\013\f\r"
	.byte	6                               ; 0x6
	.ascii	"\b\000\t\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\000\b\t\n\013\f\r\016"
	.byte	7                               ; 0x7
	.ascii	"\b\t\n\013\f\r\016\017"
	.byte	8                               ; 0x8

	.p2align	3, 0x0                          ; @_ZN16cngcompress_bulk12_GLOBAL__N_18movementE
__ZN16cngcompress_bulk12_GLOBAL__N_18movementE:
	.space	48
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594037862400               ; 0xffffffffff0000
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.space	24
	.space	24
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65280                           ; 0xff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.space	24
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	0                               ; 0x0
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.space	24
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.space	24
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.space	24
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.space	24
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927680               ; 0xffffffffffff00
	.space	24
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	48

	.p2align	3, 0x0                          ; @_ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE
__ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE:
	.space	64
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.space	16
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	255                             ; 0xff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.space	16
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65280                           ; 0xff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	65535                           ; 0xffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.space	16
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.space	16
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65280                           ; 0xff00
	.quad	16776960                        ; 0xffff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	65280                           ; 0xff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	65535                           ; 0xffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.space	16
	.quad	281474959933440                 ; 0xffffff000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	255                             ; 0xff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	255                             ; 0xff
	.quad	4294967040                      ; 0xffffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.space	16
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16711680                        ; 0xff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	281470681743360                 ; 0xffff00000000
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16776960                        ; 0xffff00
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	4278190335                      ; 0xff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16776960                        ; 0xffff00
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	4294901760                      ; 0xffff0000
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.space	16
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.space	16
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65280                           ; 0xff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65535                           ; 0xffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	280375465082880                 ; 0xff0000000000
	.quad	255                             ; 0xff
	.quad	1099494850560                   ; 0xffff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	255                             ; 0xff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4278190080                      ; 0xff000000
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4278190080                      ; 0xff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	4278190080                      ; 0xff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	1095216660735                   ; 0xff000000ff
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4278190080                      ; 0xff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	4294967040                      ; 0xffffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	255                             ; 0xff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	255                             ; 0xff
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	65535                           ; 0xffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	65280                           ; 0xff00
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	16777215                        ; 0xffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	16777215                        ; 0xffffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	16776960                        ; 0xffff00
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	16711680                        ; 0xff0000
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65535                           ; 0xffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4278190080                      ; 0xff000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	255                             ; 0xff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	255                             ; 0xff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65280                           ; 0xff00
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	281474959933695                 ; 0xffffff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	281474959933440                 ; 0xffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65280                           ; 0xff00
	.quad	16776960                        ; 0xffff00
	.quad	71776123339407615               ; 0xff0000ff0000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	16711680                        ; 0xff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	281470681743615                 ; 0xffff000000ff
	.quad	65280                           ; 0xff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	65535                           ; 0xffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	16711680                        ; 0xff0000
	.quad	71776123339407360               ; 0xff0000ff000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	281470681808895                 ; 0xffff0000ffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	281470681808640                 ; 0xffff0000ff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356119040               ; 0xff0000ffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	71776123356184320               ; 0xff0000ffffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	71776123356184575               ; 0xff0000ffffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	16711680                        ; 0xff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294967040                      ; 0xffffff00
	.quad	16711680                        ; 0xff0000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	71776119061217280               ; 0xff000000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	1095216660480                   ; 0xff00000000
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	280375465148415                 ; 0xff000000ffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16776960                        ; 0xffff00
	.quad	280375465148160                 ; 0xff000000ff00
	.quad	1095216660735                   ; 0xff000000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	71776119077928960               ; 0xff000000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	4278190335                      ; 0xff0000ff
	.quad	71776119077994240               ; 0xff000000ffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	71776119077994495               ; 0xff000000ffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1095216660480                   ; 0xff00000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	280375481860095                 ; 0xff0000ffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16776960                        ; 0xffff00
	.quad	280375481859840                 ; 0xff0000ffff00
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	255                             ; 0xff
	.quad	71776119061282560               ; 0xff00000000ff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	65280                           ; 0xff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	71776119061282815               ; 0xff00000000ffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375481794560                 ; 0xff0000ff0000
	.quad	1099494850560                   ; 0xffff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4278190080                      ; 0xff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65535                           ; 0xffff
	.quad	71776119061217280               ; 0xff000000000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	71776119061217535               ; 0xff0000000000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465083135                 ; 0xff00000000ff
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	280375465082880                 ; 0xff0000000000
	.quad	280375465082880                 ; 0xff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	1095216660480                   ; 0xff00000000
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	71776119061217280               ; 0xff000000000000
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.space	16
	.quad	1099511627520                   ; 0xffffffff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099511562240                   ; 0xffffff0000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16776960                        ; 0xffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65280                           ; 0xff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543011840               ; 0xffff0000ff0000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4294901760                      ; 0xffff0000
	.quad	65535                           ; 0xffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099494850815                   ; 0xffff0000ff
	.quad	72056494543077120               ; 0xffff0000ffff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099494850560                   ; 0xffff000000
	.quad	1099494850560                   ; 0xffff000000
	.quad	72056494543077375               ; 0xffff0000ffffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.space	16
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65280                           ; 0xff00
	.quad	16777215                        ; 0xffffff
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65280                           ; 0xff00
	.quad	16776960                        ; 0xffff00
	.quad	4278190335                      ; 0xff0000ff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65535                           ; 0xffff
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	1095216660735                   ; 0xff000000ff
	.quad	72056494526365440               ; 0xffff000000ff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526365695               ; 0xffff000000ffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	16711680                        ; 0xff0000
	.quad	4278190080                      ; 0xff000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	4278190080                      ; 0xff000000
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	1095216726015                   ; 0xff0000ffff
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	1095216725760                   ; 0xff0000ff00
	.quad	72056494526300415               ; 0xffff00000000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294901760                      ; 0xffff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	255                             ; 0xff
	.quad	4294967040                      ; 0xffffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.quad	65280                           ; 0xff00
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	281470681743360                 ; 0xffff00000000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.space	16
	.quad	1095216660480                   ; 0xff00000000
	.quad	72056494526300160               ; 0xffff0000000000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16777215                        ; 0xffffff
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.space	16
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.space	16
	.quad	4294967040                      ; 0xffffff00
	.quad	255                             ; 0xff
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	255                             ; 0xff
	.quad	72057589743025920               ; 0xffffff0000ff00
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16776960                        ; 0xffff00
	.quad	1099511562240                   ; 0xffffff0000
	.quad	0                               ; 0x0
	.quad	72057589743026175               ; 0xffffff0000ffff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65535                           ; 0xffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4294901760                      ; 0xffff0000
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967040                      ; 0xffffff00
	.quad	0                               ; 0x0
	.quad	255                             ; 0xff
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65535                           ; 0xffff
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627520                   ; 0xffffffff00
	.quad	65280                           ; 0xff00
	.quad	72057589742960895               ; 0xffffff000000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65535                           ; 0xffff
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16711680                        ; 0xff0000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	16711680                        ; 0xff0000
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190335                      ; 0xff0000ff
	.quad	16776960                        ; 0xffff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474959933440                 ; 0xffffff000000
	.quad	4278190080                      ; 0xff000000
	.quad	16777215                        ; 0xffffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.space	16
	.quad	0                               ; 0x0
	.quad	72057589742960640               ; 0xffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.quad	4294967295                      ; 0xffffffff
	.quad	0                               ; 0x0
	.quad	4294967295                      ; 0xffffffff
	.space	16
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16777215                        ; 0xffffff
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627520                   ; 0xffffffff00
	.quad	16776960                        ; 0xffff00
	.quad	72057594021150975               ; 0xffffffff0000ff
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65535                           ; 0xffff
	.quad	281474976645120                 ; 0xffffffff0000
	.space	16
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	16711680                        ; 0xff0000
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	255                             ; 0xff
	.quad	65280                           ; 0xff00
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	65280                           ; 0xff00
	.quad	281474976645120                 ; 0xffffffff0000
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	16711680                        ; 0xff0000
	.quad	72057594021150720               ; 0xffffffff000000
	.quad	16777215                        ; 0xffffff
	.quad	1099511627775                   ; 0xffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	1099511627775                   ; 0xffffffffff
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65535                           ; 0xffff
	.quad	0                               ; 0x0
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	281474976710400                 ; 0xffffffffff00
	.quad	65280                           ; 0xff00
	.quad	255                             ; 0xff
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.quad	255                             ; 0xff
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.quad	72057594037862400               ; 0xffffffffff0000
	.quad	65535                           ; 0xffff
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	0                               ; 0x0
	.quad	281474976710655                 ; 0xffffffffffff
	.space	16
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.space	16
	.quad	255                             ; 0xff
	.quad	72057594037927680               ; 0xffffffffffff00
	.quad	255                             ; 0xff
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	16
	.space	16
	.quad	0                               ; 0x0
	.quad	72057594037927935               ; 0xffffffffffffff
	.space	64

.subsections_via_symbols
