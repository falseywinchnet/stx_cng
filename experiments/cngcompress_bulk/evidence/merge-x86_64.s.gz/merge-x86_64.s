	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.globl	__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk12merge_scalarENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	24(%rbp), %rax
	testq	%rax, %rax
	je	LBB0_3
## %bb.1:
	movq	16(%rbp), %rsi
	xorl	%r9d, %r9d
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	.p2align	4
LBB0_2:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rbx
	movq	%rcx, %r10
	movq	%r9, %r11
	shrq	$3, %r11
	movl	%r9d, %ecx
	andb	$7, %cl
	movl	$1, %r14d
	shll	%cl, %r14d
	movzbl	(%rdi,%r11), %r15d
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	testl	%r15d, %r14d
	leaq	(%rdx,%rbx), %r14
	leaq	(%r8,%r10), %r15
	cmoveq	%r14, %r15
	setne	%cl
	sete	%r11b
	addq	%rbx, %r11
	addq	%r10, %rcx
	movzbl	(%r15), %r10d
	movb	%r10b, (%rsi,%r9)
	incq	%r9
	cmpq	%r9, %rax
	jne	LBB0_2
LBB0_3:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk13merge_indexedENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %r15
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	movq	16(%rbp), %rsi
	movq	24(%rbp), %rcx
	movq	%rcx, -80(%rbp)                 ## 8-byte Spill
	andq	$-8, %rcx
	movq	%rdi, -88(%rbp)                 ## 8-byte Spill
	je	LBB1_1
## %bb.2:
	xorl	%r11d, %r11d
	movq	%rdi, %r13
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movq	%rcx, -104(%rbp)                ## 8-byte Spill
	movq	%rdx, -96(%rbp)                 ## 8-byte Spill
	jmp	LBB1_3
	.p2align	4
LBB1_6:                                 ##   in Loop: Header=BB1_3 Depth=1
	movq	(%r8,%rbx), %rax
	movq	%rax, (%rsi,%r11)
	addq	$8, %rbx
LBB1_26:                                ##   in Loop: Header=BB1_3 Depth=1
	addq	$8, %r11
	incq	%r13
	cmpq	%rcx, %r11
	jae	LBB1_27
LBB1_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13), %r12d
	cmpl	$255, %r12d
	je	LBB1_6
## %bb.4:                               ##   in Loop: Header=BB1_3 Depth=1
	testl	%r12d, %r12d
	jne	LBB1_7
## %bb.5:                               ##   in Loop: Header=BB1_3 Depth=1
	movq	(%rdx,%r14), %rax
	movq	%rax, (%rsi,%r11)
	addq	$8, %r14
	jmp	LBB1_26
	.p2align	4
LBB1_7:                                 ##   in Loop: Header=BB1_3 Depth=1
	movq	%r15, %rax
	subq	%r14, %rax
	cmpq	$8, %rax
	jb	LBB1_9
## %bb.8:                               ##   in Loop: Header=BB1_3 Depth=1
	movq	(%rdx,%r14), %r8
	jmp	LBB1_16
LBB1_9:                                 ##   in Loop: Header=BB1_3 Depth=1
	cmpq	$4, %rax
	jb	LBB1_10
## %bb.11:                              ##   in Loop: Header=BB1_3 Depth=1
	movl	(%rdx,%r14), %r8d
	leaq	4(%r14), %r10
	addq	$-4, %rax
	movl	$32, %ecx
	cmpq	$2, %rax
	jae	LBB1_13
	jmp	LBB1_14
LBB1_10:                                ##   in Loop: Header=BB1_3 Depth=1
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	movq	%r14, %r10
	cmpq	$2, %rax
	jb	LBB1_14
LBB1_13:                                ##   in Loop: Header=BB1_3 Depth=1
	movzwl	(%rdx,%r10), %edi
	shlq	%cl, %rdi
	orq	%rdi, %r8
	addq	$2, %r10
	addq	$-2, %rax
	orl	$16, %ecx
LBB1_14:                                ##   in Loop: Header=BB1_3 Depth=1
	testq	%rax, %rax
	je	LBB1_16
## %bb.15:                              ##   in Loop: Header=BB1_3 Depth=1
	movzbl	(%rdx,%r10), %edi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%rdi, %r8
LBB1_16:                                ##   in Loop: Header=BB1_3 Depth=1
	movq	%r9, %r10
	subq	%rbx, %r10
	cmpq	$8, %r10
	jb	LBB1_18
## %bb.17:                              ##   in Loop: Header=BB1_3 Depth=1
	movq	-72(%rbp), %rax                 ## 8-byte Reload
	movq	(%rax,%rbx), %rax
	jmp	LBB1_25
LBB1_18:                                ##   in Loop: Header=BB1_3 Depth=1
	cmpq	$4, %r10
	jb	LBB1_19
## %bb.20:                              ##   in Loop: Header=BB1_3 Depth=1
	movq	-72(%rbp), %rax                 ## 8-byte Reload
	movl	(%rax,%rbx), %eax
	leaq	4(%rbx), %rdi
	addq	$-4, %r10
	movl	$32, %ecx
	cmpq	$2, %r10
	jae	LBB1_22
	jmp	LBB1_23
LBB1_19:                                ##   in Loop: Header=BB1_3 Depth=1
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	%rbx, %rdi
	cmpq	$2, %r10
	jb	LBB1_23
LBB1_22:                                ##   in Loop: Header=BB1_3 Depth=1
	movq	%r15, %rdx
	movq	-72(%rbp), %r15                 ## 8-byte Reload
	movzwl	(%r15,%rdi), %r15d
	shlq	%cl, %r15
	orq	%r15, %rax
	movq	%rdx, %r15
	movq	-96(%rbp), %rdx                 ## 8-byte Reload
	addq	$2, %rdi
	addq	$-2, %r10
	orl	$16, %ecx
LBB1_23:                                ##   in Loop: Header=BB1_3 Depth=1
	testq	%r10, %r10
	je	LBB1_25
## %bb.24:                              ##   in Loop: Header=BB1_3 Depth=1
	movq	-72(%rbp), %r10                 ## 8-byte Reload
	movzbl	(%r10,%rdi), %edi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%rdi, %rax
LBB1_25:                                ##   in Loop: Header=BB1_3 Depth=1
	leaq	(%r12,%r12,8), %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %r10
	leaq	(%r10,%rcx), %rdi
	movzbl	8(%r10,%rcx), %ecx
	movq	%r8, -64(%rbp)
	movq	%rax, -56(%rbp)
	movzbl	(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, (%rsi,%r11)
	movzbl	1(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 1(%rsi,%r11)
	movzbl	2(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 2(%rsi,%r11)
	movzbl	3(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 3(%rsi,%r11)
	movzbl	4(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 4(%rsi,%r11)
	movzbl	5(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 5(%rsi,%r11)
	movzbl	6(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 6(%rsi,%r11)
	movzbl	7(%rdi), %eax
	movzbl	-64(%rbp,%rax), %eax
	movb	%al, 7(%rsi,%r11)
	movl	$8, %eax
	subl	%ecx, %eax
	addq	%rax, %r14
	addq	%rcx, %rbx
	movq	-72(%rbp), %r8                  ## 8-byte Reload
	movq	-104(%rbp), %rcx                ## 8-byte Reload
	jmp	LBB1_26
LBB1_1:
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	xorl	%r11d, %r11d
LBB1_27:
	movq	-80(%rbp), %r12                 ## 8-byte Reload
	cmpq	%r12, %r11
	movq	-88(%rbp), %r15                 ## 8-byte Reload
	jae	LBB1_29
	.p2align	4
LBB1_28:                                ## =>This Inner Loop Header: Depth=1
	movq	%r14, %rdi
	movq	%rbx, %rax
	movq	%r11, %r9
	shrq	$3, %r9
	movl	%r11d, %ecx
	andb	$7, %cl
	movl	$1, %r10d
	shll	%cl, %r10d
	movzbl	(%r15,%r9), %ecx
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	testl	%ecx, %r10d
	leaq	(%rdx,%rdi), %rcx
	leaq	(%r8,%rax), %r9
	cmoveq	%rcx, %r9
	setne	%bl
	sete	%r14b
	addq	%rdi, %r14
	addq	%rax, %rbx
	movzbl	(%r9), %eax
	movb	%al, (%rsi,%r11)
	incq	%r11
	cmpq	%r11, %r12
	jne	LBB1_28
LBB1_29:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB1_31
## %bb.30:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB1_31:
	callq	___stack_chk_fail
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk11merge_wordsENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -96(%rbp)                  ## 8-byte Spill
	movq	%rcx, -88(%rbp)                 ## 8-byte Spill
	movq	16(%rbp), %rsi
	movq	24(%rbp), %rcx
	movq	%rcx, -56(%rbp)                 ## 8-byte Spill
	andq	$-8, %rcx
	movq	%rdi, -64(%rbp)                 ## 8-byte Spill
	je	LBB2_1
## %bb.2:
	xorl	%r11d, %r11d
	movq	%rdi, %r13
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	movq	%r8, -48(%rbp)                  ## 8-byte Spill
	movq	%rdx, -80(%rbp)                 ## 8-byte Spill
	movq	%rcx, -72(%rbp)                 ## 8-byte Spill
	jmp	LBB2_3
	.p2align	4
LBB2_6:                                 ##   in Loop: Header=BB2_3 Depth=1
	movq	(%r8,%rbx), %rax
	movq	%rax, (%rsi,%r11)
	addq	$8, %rbx
LBB2_27:                                ##   in Loop: Header=BB2_3 Depth=1
	addq	$8, %r11
	incq	%r13
	cmpq	%rcx, %r11
	jae	LBB2_28
LBB2_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13), %r12d
	cmpl	$255, %r12d
	je	LBB2_6
## %bb.4:                               ##   in Loop: Header=BB2_3 Depth=1
	testl	%r12d, %r12d
	jne	LBB2_7
## %bb.5:                               ##   in Loop: Header=BB2_3 Depth=1
	movq	(%rdx,%r14), %rax
	movq	%rax, (%rsi,%r11)
	addq	$8, %r14
	jmp	LBB2_27
	.p2align	4
LBB2_7:                                 ##   in Loop: Header=BB2_3 Depth=1
	movq	-88(%rbp), %rdi                 ## 8-byte Reload
	subq	%r14, %rdi
	cmpq	$8, %rdi
	jb	LBB2_9
## %bb.8:                               ##   in Loop: Header=BB2_3 Depth=1
	movq	(%rdx,%r14), %rax
	jmp	LBB2_17
LBB2_9:                                 ##   in Loop: Header=BB2_3 Depth=1
	cmpq	$4, %rdi
	jb	LBB2_10
## %bb.11:                              ##   in Loop: Header=BB2_3 Depth=1
	movl	(%rdx,%r14), %eax
	leaq	4(%r14), %r9
	addq	$-4, %rdi
	movl	$32, %ecx
	cmpq	$2, %rdi
	jae	LBB2_13
	jmp	LBB2_14
LBB2_10:                                ##   in Loop: Header=BB2_3 Depth=1
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	%r14, %r9
	cmpq	$2, %rdi
	jb	LBB2_14
LBB2_13:                                ##   in Loop: Header=BB2_3 Depth=1
	movzwl	(%rdx,%r9), %r8d
	shlq	%cl, %r8
	orq	%r8, %rax
	addq	$2, %r9
	addq	$-2, %rdi
	orl	$16, %ecx
LBB2_14:                                ##   in Loop: Header=BB2_3 Depth=1
	testq	%rdi, %rdi
	je	LBB2_16
## %bb.15:                              ##   in Loop: Header=BB2_3 Depth=1
	movzbl	(%rdx,%r9), %edi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rdi
	orq	%rdi, %rax
LBB2_16:                                ##   in Loop: Header=BB2_3 Depth=1
	movq	-48(%rbp), %r8                  ## 8-byte Reload
LBB2_17:                                ##   in Loop: Header=BB2_3 Depth=1
	leaq	(%r12,%r12,8), %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rdx
	leaq	(%rdx,%rcx), %r10
	movzbl	8(%rdx,%rcx), %edx
	movq	-96(%rbp), %r15                 ## 8-byte Reload
	subq	%rbx, %r15
	cmpq	$8, %r15
	jb	LBB2_19
## %bb.18:                              ##   in Loop: Header=BB2_3 Depth=1
	movq	(%r8,%rbx), %rdi
	jmp	LBB2_26
LBB2_19:                                ##   in Loop: Header=BB2_3 Depth=1
	cmpq	$4, %r15
	jb	LBB2_20
## %bb.21:                              ##   in Loop: Header=BB2_3 Depth=1
	movl	(%r8,%rbx), %edi
	leaq	4(%rbx), %r9
	addq	$-4, %r15
	movl	$32, %ecx
	cmpq	$2, %r15
	jae	LBB2_23
	jmp	LBB2_24
LBB2_20:                                ##   in Loop: Header=BB2_3 Depth=1
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	movq	%rbx, %r9
	cmpq	$2, %r15
	jb	LBB2_24
LBB2_23:                                ##   in Loop: Header=BB2_3 Depth=1
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movzwl	(%r8,%r9), %r8d
	shlq	%cl, %r8
	orq	%r8, %rdi
	addq	$2, %r9
	addq	$-2, %r15
	orl	$16, %ecx
LBB2_24:                                ##   in Loop: Header=BB2_3 Depth=1
	testq	%r15, %r15
	je	LBB2_26
## %bb.25:                              ##   in Loop: Header=BB2_3 Depth=1
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movzbl	(%r8,%r9), %r8d
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r8
	orq	%r8, %rdi
LBB2_26:                                ##   in Loop: Header=BB2_3 Depth=1
	movzbl	(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r8
	cmovbq	%rax, %r8
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r8
	movzbl	1(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r9
	cmovbq	%rax, %r9
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r9
	movzbl	%r8b, %ecx
	shll	$8, %r9d
	movzwl	%r9w, %r8d
	orq	%rcx, %r8
	movzbl	2(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r9
	cmovbq	%rax, %r9
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r9
	movzbl	%r9b, %r15d
	shll	$16, %r15d
	orq	%r8, %r15
	movzbl	3(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r9
	cmovbq	%rax, %r9
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r9
	shll	$24, %r9d
	orq	%r15, %r9
	movzbl	4(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r8
	cmovbq	%rax, %r8
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r8
	movzbl	%r8b, %r8d
	shlq	$32, %r8
	orq	%r9, %r8
	movzbl	5(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r9
	cmovbq	%rax, %r9
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r9
	movzbl	%r9b, %r9d
	shlq	$40, %r9
	orq	%r8, %r9
	movzbl	6(%r10), %ecx
	cmpb	$8, %cl
	movq	%rdi, %r8
	cmovbq	%rax, %r8
	shll	$3, %ecx
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r8
	movzbl	%r8b, %r8d
	shlq	$48, %r8
	orq	%r9, %r8
	movzbl	7(%r10), %ecx
	shlb	$3, %cl
	testb	%r12b, %r12b
	cmovsq	%rdi, %rax
	shrq	%cl, %rax
	shlq	$56, %rax
	orq	%r8, %rax
	movq	%rax, (%rsi,%r11)
	movl	$8, %eax
	subl	%edx, %eax
	addq	%rax, %r14
	addq	%rdx, %rbx
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	movq	-72(%rbp), %rcx                 ## 8-byte Reload
	jmp	LBB2_27
LBB2_1:
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	xorl	%r11d, %r11d
LBB2_28:
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	cmpq	%r12, %r11
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	jae	LBB2_30
	.p2align	4
LBB2_29:                                ## =>This Inner Loop Header: Depth=1
	movq	%r14, %rdi
	movq	%rbx, %rax
	movq	%r11, %r10
	shrq	$3, %r10
	movl	%r11d, %ecx
	andb	$7, %cl
	movl	$1, %r9d
	shll	%cl, %r9d
	movzbl	(%r15,%r10), %ecx
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	testl	%ecx, %r9d
	leaq	(%rdx,%rdi), %rcx
	leaq	(%r8,%rax), %r9
	cmoveq	%rcx, %r9
	setne	%bl
	sete	%r14b
	addq	%rdi, %r14
	addq	%rax, %rbx
	movzbl	(%r9), %eax
	movb	%al, (%rsi,%r11)
	incq	%r11
	cmpq	%r11, %r12
	jne	LBB2_29
LBB2_30:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk12merge_spreadENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -96(%rbp)                  ## 8-byte Spill
	movq	%rcx, -88(%rbp)                 ## 8-byte Spill
	movq	16(%rbp), %r15
	movq	24(%rbp), %rcx
	movq	%rcx, -56(%rbp)                 ## 8-byte Spill
	andq	$-8, %rcx
	je	LBB3_1
## %bb.2:
	xorl	%r11d, %r11d
	movq	%rdi, %r12
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	movq	%r8, -48(%rbp)                  ## 8-byte Spill
	movq	%rdx, -80(%rbp)                 ## 8-byte Spill
	movq	%r15, -72(%rbp)                 ## 8-byte Spill
	movq	%rcx, -64(%rbp)                 ## 8-byte Spill
	jmp	LBB3_3
	.p2align	4
LBB3_6:                                 ##   in Loop: Header=BB3_3 Depth=1
	movq	(%r8,%rbx), %rax
	movq	%rax, (%r15,%r11)
	addq	$8, %rbx
LBB3_26:                                ##   in Loop: Header=BB3_3 Depth=1
	addq	$8, %r11
	incq	%r12
	cmpq	%rcx, %r11
	jae	LBB3_27
LBB3_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r12), %r9d
	cmpl	$255, %r9d
	je	LBB3_6
## %bb.4:                               ##   in Loop: Header=BB3_3 Depth=1
	testl	%r9d, %r9d
	jne	LBB3_7
## %bb.5:                               ##   in Loop: Header=BB3_3 Depth=1
	movq	(%rdx,%r14), %rax
	movq	%rax, (%r15,%r11)
	addq	$8, %r14
	jmp	LBB3_26
	.p2align	4
LBB3_7:                                 ##   in Loop: Header=BB3_3 Depth=1
	movq	-88(%rbp), %r10                 ## 8-byte Reload
	subq	%r14, %r10
	cmpq	$8, %r10
	jb	LBB3_9
## %bb.8:                               ##   in Loop: Header=BB3_3 Depth=1
	movq	(%rdx,%r14), %rax
	jmp	LBB3_16
LBB3_9:                                 ##   in Loop: Header=BB3_3 Depth=1
	cmpq	$4, %r10
	jb	LBB3_10
## %bb.11:                              ##   in Loop: Header=BB3_3 Depth=1
	movl	(%rdx,%r14), %eax
	leaq	4(%r14), %rsi
	addq	$-4, %r10
	movl	$32, %ecx
	cmpq	$2, %r10
	jae	LBB3_13
	jmp	LBB3_14
LBB3_10:                                ##   in Loop: Header=BB3_3 Depth=1
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	%r14, %rsi
	cmpq	$2, %r10
	jb	LBB3_14
LBB3_13:                                ##   in Loop: Header=BB3_3 Depth=1
	movzwl	(%rdx,%rsi), %r15d
	shlq	%cl, %r15
	orq	%r15, %rax
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	addq	$2, %rsi
	addq	$-2, %r10
	orl	$16, %ecx
LBB3_14:                                ##   in Loop: Header=BB3_3 Depth=1
	testq	%r10, %r10
	je	LBB3_16
## %bb.15:                              ##   in Loop: Header=BB3_3 Depth=1
	movzbl	(%rdx,%rsi), %r10d
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r10
	orq	%r10, %rax
LBB3_16:                                ##   in Loop: Header=BB3_3 Depth=1
	leaq	(%r9,%r9,8), %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rdx
	movzbl	8(%rdx,%rcx), %edx
	movq	-96(%rbp), %r13                 ## 8-byte Reload
	subq	%rbx, %r13
	cmpq	$8, %r13
	jb	LBB3_18
## %bb.17:                              ##   in Loop: Header=BB3_3 Depth=1
	movq	(%r8,%rbx), %r10
	jmp	LBB3_25
LBB3_18:                                ##   in Loop: Header=BB3_3 Depth=1
	cmpq	$4, %r13
	jb	LBB3_19
## %bb.20:                              ##   in Loop: Header=BB3_3 Depth=1
	movl	(%r8,%rbx), %r10d
	leaq	4(%rbx), %r15
	addq	$-4, %r13
	movl	$32, %ecx
	cmpq	$2, %r13
	jae	LBB3_22
	jmp	LBB3_23
LBB3_19:                                ##   in Loop: Header=BB3_3 Depth=1
	xorl	%r10d, %r10d
	xorl	%ecx, %ecx
	movq	%rbx, %r15
	cmpq	$2, %r13
	jb	LBB3_23
LBB3_22:                                ##   in Loop: Header=BB3_3 Depth=1
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	movzwl	(%rsi,%r15), %esi
	shlq	%cl, %rsi
	orq	%rsi, %r10
	addq	$2, %r15
	addq	$-2, %r13
	orl	$16, %ecx
LBB3_23:                                ##   in Loop: Header=BB3_3 Depth=1
	testq	%r13, %r13
	je	LBB3_25
## %bb.24:                              ##   in Loop: Header=BB3_3 Depth=1
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	movzbl	(%rsi,%r15), %esi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rsi
	orq	%rsi, %r10
LBB3_25:                                ##   in Loop: Header=BB3_3 Depth=1
	leaq	(%r9,%r9,2), %r13
	shll	$4, %r13d
	movl	$8, %r9d
	subl	%edx, %r9d
	leal	(,%r9,8), %ecx
	movq	$-1, %rsi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rsi
	notq	%rsi
	andq	%rsi, %rax
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_18movementE(%rip), %r8
	movq	(%r13,%r8), %rcx
	andq	%rax, %rcx
	xorq	%rcx, %rax
	shlq	$32, %rcx
	orq	%rax, %rcx
	movq	8(%r13,%r8), %rax
	andq	%rcx, %rax
	xorq	%rax, %rcx
	shlq	$16, %rax
	orq	%rcx, %rax
	movq	16(%r13,%r8), %r15
	andq	%rax, %r15
	leal	(,%rdx,8), %ecx
	movq	$-1, %rsi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rsi
	xorq	%r15, %rax
	notq	%rsi
	andq	%r10, %rsi
	movq	24(%r13,%r8), %rcx
	andq	%rsi, %rcx
	xorq	%rcx, %rsi
	shlq	$32, %rcx
	orq	%rsi, %rcx
	movq	32(%r13,%r8), %rsi
	andq	%rcx, %rsi
	xorq	%rsi, %rcx
	shlq	$16, %rsi
	orq	%rcx, %rsi
	movq	40(%r13,%r8), %rcx
	andq	%rsi, %rcx
	xorq	%rcx, %rsi
	orq	%rax, %rsi
	orq	%r15, %rcx
	shlq	$8, %rcx
	orq	%rsi, %rcx
	movq	-72(%rbp), %r15                 ## 8-byte Reload
	movq	%rcx, (%r15,%r11)
	addq	%r9, %r14
	movl	%edx, %eax
	addq	%rax, %rbx
	movq	-48(%rbp), %r8                  ## 8-byte Reload
	movq	-80(%rbp), %rdx                 ## 8-byte Reload
	movq	-64(%rbp), %rcx                 ## 8-byte Reload
	jmp	LBB3_26
LBB3_1:
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	xorl	%r11d, %r11d
LBB3_27:
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	cmpq	%r12, %r11
	jae	LBB3_29
	.p2align	4
LBB3_28:                                ## =>This Inner Loop Header: Depth=1
	movq	%r14, %r10
	movq	%rbx, %rax
	movq	%r11, %rsi
	shrq	$3, %rsi
	movl	%r11d, %ecx
	andb	$7, %cl
	movl	$1, %r9d
	shll	%cl, %r9d
	movzbl	(%rdi,%rsi), %ecx
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	testl	%ecx, %r9d
	leaq	(%rdx,%r10), %rcx
	leaq	(%r8,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%bl
	sete	%r14b
	addq	%r10, %r14
	addq	%rax, %rbx
	movzbl	(%rsi), %eax
	movb	%al, (%r15,%r11)
	incq	%r11
	cmpq	%r11, %r12
	jne	LBB3_28
LBB3_29:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE ## -- Begin function _ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE: ## @_ZN16cngcompress_bulk11merge_lanesENSt3__14spanIKhLm18446744073709551615EEES3_S3_NS1_IhLm18446744073709551615EEE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %rsi
	movq	16(%rbp), %r15
	movq	24(%rbp), %r12
	movq	%r12, %rcx
	andq	$-8, %rcx
	movq	%rdi, -80(%rbp)                 ## 8-byte Spill
	je	LBB4_1
## %bb.2:
	xorl	%r11d, %r11d
	movq	%rdi, %r13
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	movq	%r8, -56(%rbp)                  ## 8-byte Spill
	movq	%rdx, -48(%rbp)                 ## 8-byte Spill
	movq	%r15, -64(%rbp)                 ## 8-byte Spill
	movq	%r9, -96(%rbp)                  ## 8-byte Spill
	movq	%rsi, -72(%rbp)                 ## 8-byte Spill
	movq	%rcx, -88(%rbp)                 ## 8-byte Spill
	movq	%r12, -104(%rbp)                ## 8-byte Spill
	jmp	LBB4_3
	.p2align	4
LBB4_6:                                 ##   in Loop: Header=BB4_3 Depth=1
	movq	(%r8,%rbx), %rax
	movq	%rax, (%r15,%r11)
	addq	$8, %rbx
LBB4_29:                                ##   in Loop: Header=BB4_3 Depth=1
	addq	$8, %r11
	incq	%r13
	cmpq	%rcx, %r11
	jae	LBB4_30
LBB4_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13), %eax
	cmpl	$255, %eax
	je	LBB4_6
## %bb.4:                               ##   in Loop: Header=BB4_3 Depth=1
	testl	%eax, %eax
	jne	LBB4_7
## %bb.5:                               ##   in Loop: Header=BB4_3 Depth=1
	movq	(%rdx,%r14), %rax
	movq	%rax, (%r15,%r11)
	addq	$8, %r14
	jmp	LBB4_29
	.p2align	4
LBB4_7:                                 ##   in Loop: Header=BB4_3 Depth=1
	movq	%rsi, %r12
	subq	%r14, %r12
	cmpq	$8, %r12
	jb	LBB4_9
## %bb.8:                               ##   in Loop: Header=BB4_3 Depth=1
	movq	(%rdx,%r14), %r9
	jmp	LBB4_17
LBB4_9:                                 ##   in Loop: Header=BB4_3 Depth=1
	cmpq	$4, %r12
	jb	LBB4_10
## %bb.11:                              ##   in Loop: Header=BB4_3 Depth=1
	movl	(%rdx,%r14), %r9d
	leaq	4(%r14), %r10
	addq	$-4, %r12
	movl	$32, %ecx
	cmpq	$2, %r12
	jae	LBB4_13
	jmp	LBB4_14
LBB4_10:                                ##   in Loop: Header=BB4_3 Depth=1
	xorl	%r9d, %r9d
	xorl	%ecx, %ecx
	movq	%r14, %r10
	cmpq	$2, %r12
	jb	LBB4_14
LBB4_13:                                ##   in Loop: Header=BB4_3 Depth=1
	movzwl	(%rdx,%r10), %r15d
	shlq	%cl, %r15
	orq	%r15, %r9
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	addq	$2, %r10
	addq	$-2, %r12
	orl	$16, %ecx
LBB4_14:                                ##   in Loop: Header=BB4_3 Depth=1
	testq	%r12, %r12
	je	LBB4_15
## %bb.16:                              ##   in Loop: Header=BB4_3 Depth=1
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	movzbl	(%rdx,%r10), %r10d
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %r10
	orq	%r10, %r9
	jmp	LBB4_17
LBB4_15:                                ##   in Loop: Header=BB4_3 Depth=1
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	.p2align	4
LBB4_17:                                ##   in Loop: Header=BB4_3 Depth=1
	leaq	(%rax,%rax,8), %rcx
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %rdi
	movzbl	8(%rdi,%rcx), %edi
	movq	-96(%rbp), %r10                 ## 8-byte Reload
	subq	%rbx, %r10
	cmpq	$8, %r10
	jb	LBB4_19
## %bb.18:                              ##   in Loop: Header=BB4_3 Depth=1
	movq	(%r8,%rbx), %r12
	jmp	LBB4_28
LBB4_19:                                ##   in Loop: Header=BB4_3 Depth=1
	cmpq	$4, %r10
	jb	LBB4_20
## %bb.21:                              ##   in Loop: Header=BB4_3 Depth=1
	movl	(%r8,%rbx), %r12d
	leaq	4(%rbx), %r15
	addq	$-4, %r10
	movl	$32, %ecx
	cmpq	$2, %r10
	jae	LBB4_23
	jmp	LBB4_24
LBB4_20:                                ##   in Loop: Header=BB4_3 Depth=1
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	movq	%rbx, %r15
	cmpq	$2, %r10
	jb	LBB4_24
LBB4_23:                                ##   in Loop: Header=BB4_3 Depth=1
	movq	-56(%rbp), %rsi                 ## 8-byte Reload
	movzwl	(%rsi,%r15), %esi
	shlq	%cl, %rsi
	orq	%rsi, %r12
	addq	$2, %r15
	addq	$-2, %r10
	orl	$16, %ecx
LBB4_24:                                ##   in Loop: Header=BB4_3 Depth=1
	testq	%r10, %r10
	je	LBB4_25
## %bb.26:                              ##   in Loop: Header=BB4_3 Depth=1
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	movzbl	(%r8,%r15), %esi
                                        ## kill: def $cl killed $cl killed $ecx
	shlq	%cl, %rsi
	orq	%rsi, %r12
	jmp	LBB4_27
LBB4_25:                                ##   in Loop: Header=BB4_3 Depth=1
	movq	-56(%rbp), %r8                  ## 8-byte Reload
LBB4_27:                                ##   in Loop: Header=BB4_3 Depth=1
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	movq	-72(%rbp), %rsi                 ## 8-byte Reload
LBB4_28:                                ##   in Loop: Header=BB4_3 Depth=1
	shll	$6, %eax
	movq	%r12, %xmm0
	movq	%r9, %xmm1
	punpcklqdq	%xmm0, %xmm1            ## xmm1 = xmm1[0],xmm0[0]
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE(%rip), %rcx
	movdqu	(%rax,%rcx), %xmm0
	pand	%xmm1, %xmm0
	movdqu	16(%rax,%rcx), %xmm1
	movdqu	32(%rax,%rcx), %xmm2
	movdqu	48(%rax,%rcx), %xmm3
	pand	%xmm0, %xmm1
	pxor	%xmm1, %xmm0
	psllq	$32, %xmm1
	por	%xmm0, %xmm1
	pand	%xmm1, %xmm2
	pxor	%xmm2, %xmm1
	psllq	$16, %xmm2
	por	%xmm1, %xmm2
	pand	%xmm2, %xmm3
	pxor	%xmm3, %xmm2
	movq	%xmm2, %rax
	pshufd	$238, %xmm2, %xmm0              ## xmm0 = xmm2[2,3,2,3]
	movq	%xmm0, %rcx
	orq	%rax, %rcx
	pshufd	$238, %xmm3, %xmm0              ## xmm0 = xmm3[2,3,2,3]
	por	%xmm3, %xmm0
	movq	%xmm0, %rax
	shlq	$8, %rax
	orq	%rcx, %rax
	movq	%rax, (%r15,%r11)
	movl	$8, %eax
	subl	%edi, %eax
	addq	%rax, %r14
	addq	%rdi, %rbx
	movq	-104(%rbp), %r12                ## 8-byte Reload
	movq	-88(%rbp), %rcx                 ## 8-byte Reload
	jmp	LBB4_29
LBB4_1:
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	xorl	%r11d, %r11d
LBB4_30:
	cmpq	%r12, %r11
	movq	-80(%rbp), %rdi                 ## 8-byte Reload
	jae	LBB4_32
	.p2align	4
LBB4_31:                                ## =>This Inner Loop Header: Depth=1
	movq	%r14, %r10
	movq	%rbx, %rax
	movq	%r11, %rsi
	shrq	$3, %rsi
	movl	%r11d, %ecx
	andb	$7, %cl
	movl	$1, %r9d
	shll	%cl, %r9d
	movzbl	(%rdi,%rsi), %ecx
	xorl	%ebx, %ebx
	xorl	%r14d, %r14d
	testl	%ecx, %r9d
	leaq	(%rdx,%r10), %rcx
	leaq	(%r8,%rax), %rsi
	cmoveq	%rcx, %rsi
	setne	%bl
	sete	%r14b
	addq	%r10, %r14
	addq	%rax, %rbx
	movzbl	(%rsi), %eax
	movb	%al, (%r15,%r11)
	incq	%r11
	cmpq	%r11, %r12
	jne	LBB4_31
LBB4_32:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
LCPI5_0:
	.quad	9                               ## 0x9
	.quad	49                              ## 0x31
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.p2align	4
__ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm: ## @_ZN16cngcompress_bulk7trafficENSt3__14spanIKhLm18446744073709551615EEEmm
	.cfi_startproc
## %bb.0:
	movq	%rdi, %rax
	leaq	(%r8,%rcx), %rdx
	leaq	(%r8,%rcx), %rdi
	addq	$7, %rdi
	shrq	$3, %rdi
	movq	%rdi, (%rax)
	movq	%rdx, 24(%rax)
	movq	%rdx, 8(%rax)
	cmpq	$8, %rdx
	jb	LBB5_1
## %bb.3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	pxor	%xmm0, %xmm0
	xorl	%edi, %edi
	leaq	__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE(%rip), %r11
	movdqa	LCPI5_0(%rip), %xmm1            ## xmm1 = [9,49]
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	jmp	LBB5_4
	.p2align	4
LBB5_8:                                 ##   in Loop: Header=BB5_4 Depth=1
	cmpq	$8, %r8
	cmovbq	%r8, %r14
	addq	%r15, %r14
	addq	%r14, %rdi
	paddq	%xmm1, %xmm0
	incq	%r10
LBB5_9:                                 ##   in Loop: Header=BB5_4 Depth=1
	movl	$8, %r14d
	subl	%ebx, %r14d
	subq	%r14, %rcx
	subq	%rbx, %r8
	addq	$-8, %rdx
	incq	%rsi
	cmpq	$7, %rdx
	jbe	LBB5_10
LBB5_4:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rsi), %r14d
	leaq	(%r14,%r14,8), %rbx
	movzbl	8(%r11,%rbx), %ebx
	incl	%r14d
	cmpb	$1, %r14b
	ja	LBB5_6
## %bb.5:                               ##   in Loop: Header=BB5_4 Depth=1
	addq	$8, %rdi
	incq	%r9
	jmp	LBB5_9
	.p2align	4
LBB5_6:                                 ##   in Loop: Header=BB5_4 Depth=1
	movl	$8, %r14d
	movq	%rcx, %r15
	cmpq	$8, %rcx
	jb	LBB5_8
## %bb.7:                               ##   in Loop: Header=BB5_4 Depth=1
	movl	$8, %r15d
	jmp	LBB5_8
LBB5_1:
	pxor	%xmm0, %xmm0
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	xorl	%edi, %edi
	jmp	LBB5_2
LBB5_10:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
LBB5_2:
	addq	%rdx, %rdi
	movdqu	%xmm0, 32(%rax)
	movq	%r10, 48(%rax)
	movq	%r9, 56(%rax)
	movq	%rdi, 16(%rax)
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
__ZN16cngcompress_bulk12_GLOBAL__N_19selectionE: ## @_ZN16cngcompress_bulk12_GLOBAL__N_19selectionE
	.ascii	"\000\001\002\003\004\005\006\007"
	.byte	0                               ## 0x0
	.ascii	"\b\000\001\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\000\b\001\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\t\000\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\001\b\002\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\t\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\t\001\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\n\000\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\002\b\003\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\t\002\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\n\001\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\013\000\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\003\b\004\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\t\003\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\n\002\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\013\001\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\f\000\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\004\b\005\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\t\004\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\n\003\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\013\002\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\f\001\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\r\000\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\005\b\006"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\004\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\003\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\002\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\001\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\000\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\b\t\005"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\t\n\004"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\n\013\003"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\013\f\002"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\f\r\001"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\f\r\001"
	.byte	6                               ## 0x6
	.asciz	"\b\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\005\006\b"
	.byte	1                               ## 0x1
	.ascii	"\b\000\001\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\000\b\001\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\t\000\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\001\b\002\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\t\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\t\001\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\n\000\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\002\b\003\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\t\002\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\n\001\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\013\000\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\003\b\004\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\t\003\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\n\002\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\013\001\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\f\000\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\004\b\005\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\t\004\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\n\003\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\013\002\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\f\001\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\f\r\000\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\005\b\t"
	.byte	2                               ## 0x2
	.ascii	"\b\000\001\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\000\b\001\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\t\000\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\001\b\002\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\t\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\t\001\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\n\000\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\002\b\003\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\t\002\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\n\001\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\013\000\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\003\b\004\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\t\003\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\n\002\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\013\001\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\f\000\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\004\b\t\n"
	.byte	3                               ## 0x3
	.ascii	"\b\000\001\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\000\b\001\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\t\000\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\001\b\002\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\t\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\t\001\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\n\000\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\002\b\003\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\t\002\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\n\001\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\013\000\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\003\b\t\n\013"
	.byte	4                               ## 0x4
	.ascii	"\b\000\001\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\000\b\001\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\t\000\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\001\b\002\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\t\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\t\001\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\n\000\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\002\b\t\n\013\f"
	.byte	5                               ## 0x5
	.ascii	"\b\000\001\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\000\b\001\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\t\000\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\001\b\t\n\013\f\r"
	.byte	6                               ## 0x6
	.ascii	"\b\000\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\000\b\t\n\013\f\r\016"
	.byte	7                               ## 0x7
	.ascii	"\b\t\n\013\f\r\016\017"
	.byte	8                               ## 0x8

	.p2align	3, 0x0                          ## @_ZN16cngcompress_bulk12_GLOBAL__N_18movementE
__ZN16cngcompress_bulk12_GLOBAL__N_18movementE:
	.space	48
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.space	24
	.space	24
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.space	24
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	0                               ## 0x0
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.space	24
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.space	24
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.space	24
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.space	24
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927680               ## 0xffffffffffff00
	.space	24
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	48

	.p2align	3, 0x0                          ## @_ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE
__ZN16cngcompress_bulk12_GLOBAL__N_113lane_movementE:
	.space	64
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.space	16
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	255                             ## 0xff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.space	16
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65280                           ## 0xff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	65535                           ## 0xffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.space	16
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.space	16
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65280                           ## 0xff00
	.quad	16776960                        ## 0xffff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	65280                           ## 0xff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	65535                           ## 0xffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.space	16
	.quad	281474959933440                 ## 0xffffff000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	255                             ## 0xff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.space	16
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16711680                        ## 0xff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	281470681743360                 ## 0xffff00000000
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16776960                        ## 0xffff00
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	4278190335                      ## 0xff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16776960                        ## 0xffff00
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	4294901760                      ## 0xffff0000
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.space	16
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.space	16
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65535                           ## 0xffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	280375465082880                 ## 0xff0000000000
	.quad	255                             ## 0xff
	.quad	1099494850560                   ## 0xffff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	255                             ## 0xff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4278190080                      ## 0xff000000
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4278190080                      ## 0xff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	4278190080                      ## 0xff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	1095216660735                   ## 0xff000000ff
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4278190080                      ## 0xff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	4294967040                      ## 0xffffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	255                             ## 0xff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	255                             ## 0xff
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	65535                           ## 0xffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	65280                           ## 0xff00
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	16777215                        ## 0xffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	16777215                        ## 0xffffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	16776960                        ## 0xffff00
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	16711680                        ## 0xff0000
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65535                           ## 0xffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4278190080                      ## 0xff000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	255                             ## 0xff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	255                             ## 0xff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65280                           ## 0xff00
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	281474959933695                 ## 0xffffff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	281474959933440                 ## 0xffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65280                           ## 0xff00
	.quad	16776960                        ## 0xffff00
	.quad	71776123339407615               ## 0xff0000ff0000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16711680                        ## 0xff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	281470681743615                 ## 0xffff000000ff
	.quad	65280                           ## 0xff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	65535                           ## 0xffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	16711680                        ## 0xff0000
	.quad	71776123339407360               ## 0xff0000ff000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	281470681808895                 ## 0xffff0000ffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	281470681808640                 ## 0xffff0000ff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356119040               ## 0xff0000ffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	71776123356184320               ## 0xff0000ffffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	71776123356184575               ## 0xff0000ffffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	16711680                        ## 0xff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294967040                      ## 0xffffff00
	.quad	16711680                        ## 0xff0000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	71776119061217280               ## 0xff000000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	1095216660480                   ## 0xff00000000
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	280375465148415                 ## 0xff000000ffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16776960                        ## 0xffff00
	.quad	280375465148160                 ## 0xff000000ff00
	.quad	1095216660735                   ## 0xff000000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	71776119077928960               ## 0xff000000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	4278190335                      ## 0xff0000ff
	.quad	71776119077994240               ## 0xff000000ffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	71776119077994495               ## 0xff000000ffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1095216660480                   ## 0xff00000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	280375481860095                 ## 0xff0000ffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16776960                        ## 0xffff00
	.quad	280375481859840                 ## 0xff0000ffff00
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	255                             ## 0xff
	.quad	71776119061282560               ## 0xff00000000ff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	65280                           ## 0xff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	71776119061282815               ## 0xff00000000ffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375481794560                 ## 0xff0000ff0000
	.quad	1099494850560                   ## 0xffff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4278190080                      ## 0xff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65535                           ## 0xffff
	.quad	71776119061217280               ## 0xff000000000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	71776119061217535               ## 0xff0000000000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465083135                 ## 0xff00000000ff
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	280375465082880                 ## 0xff0000000000
	.quad	280375465082880                 ## 0xff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	1095216660480                   ## 0xff00000000
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	71776119061217280               ## 0xff000000000000
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.space	16
	.quad	1099511627520                   ## 0xffffffff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099511562240                   ## 0xffffff0000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16776960                        ## 0xffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65280                           ## 0xff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543011840               ## 0xffff0000ff0000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4294901760                      ## 0xffff0000
	.quad	65535                           ## 0xffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099494850815                   ## 0xffff0000ff
	.quad	72056494543077120               ## 0xffff0000ffff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099494850560                   ## 0xffff000000
	.quad	1099494850560                   ## 0xffff000000
	.quad	72056494543077375               ## 0xffff0000ffffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.space	16
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	16777215                        ## 0xffffff
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65280                           ## 0xff00
	.quad	16776960                        ## 0xffff00
	.quad	4278190335                      ## 0xff0000ff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65535                           ## 0xffff
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	1095216660735                   ## 0xff000000ff
	.quad	72056494526365440               ## 0xffff000000ff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526365695               ## 0xffff000000ffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	16711680                        ## 0xff0000
	.quad	4278190080                      ## 0xff000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	4278190080                      ## 0xff000000
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	1095216726015                   ## 0xff0000ffff
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	1095216725760                   ## 0xff0000ff00
	.quad	72056494526300415               ## 0xffff00000000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294901760                      ## 0xffff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	255                             ## 0xff
	.quad	4294967040                      ## 0xffffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.quad	65280                           ## 0xff00
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	281470681743360                 ## 0xffff00000000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.space	16
	.quad	1095216660480                   ## 0xff00000000
	.quad	72056494526300160               ## 0xffff0000000000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16777215                        ## 0xffffff
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.space	16
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.space	16
	.quad	4294967040                      ## 0xffffff00
	.quad	255                             ## 0xff
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	255                             ## 0xff
	.quad	72057589743025920               ## 0xffffff0000ff00
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16776960                        ## 0xffff00
	.quad	1099511562240                   ## 0xffffff0000
	.quad	0                               ## 0x0
	.quad	72057589743026175               ## 0xffffff0000ffff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65535                           ## 0xffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4294901760                      ## 0xffff0000
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967040                      ## 0xffffff00
	.quad	0                               ## 0x0
	.quad	255                             ## 0xff
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65535                           ## 0xffff
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627520                   ## 0xffffffff00
	.quad	65280                           ## 0xff00
	.quad	72057589742960895               ## 0xffffff000000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65535                           ## 0xffff
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16711680                        ## 0xff0000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	16711680                        ## 0xff0000
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190335                      ## 0xff0000ff
	.quad	16776960                        ## 0xffff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474959933440                 ## 0xffffff000000
	.quad	4278190080                      ## 0xff000000
	.quad	16777215                        ## 0xffffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.space	16
	.quad	0                               ## 0x0
	.quad	72057589742960640               ## 0xffffff00000000
	.quad	4294967295                      ## 0xffffffff
	.quad	4294967295                      ## 0xffffffff
	.quad	0                               ## 0x0
	.quad	4294967295                      ## 0xffffffff
	.space	16
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16777215                        ## 0xffffff
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627520                   ## 0xffffffff00
	.quad	16776960                        ## 0xffff00
	.quad	72057594021150975               ## 0xffffffff0000ff
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65535                           ## 0xffff
	.quad	281474976645120                 ## 0xffffffff0000
	.space	16
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	16711680                        ## 0xff0000
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	255                             ## 0xff
	.quad	65280                           ## 0xff00
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	65280                           ## 0xff00
	.quad	281474976645120                 ## 0xffffffff0000
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	16711680                        ## 0xff0000
	.quad	72057594021150720               ## 0xffffffff000000
	.quad	16777215                        ## 0xffffff
	.quad	1099511627775                   ## 0xffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	1099511627775                   ## 0xffffffffff
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65535                           ## 0xffff
	.quad	0                               ## 0x0
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	281474976710400                 ## 0xffffffffff00
	.quad	65280                           ## 0xff00
	.quad	255                             ## 0xff
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.quad	255                             ## 0xff
	.quad	0                               ## 0x0
	.quad	0                               ## 0x0
	.quad	72057594037862400               ## 0xffffffffff0000
	.quad	65535                           ## 0xffff
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	0                               ## 0x0
	.quad	281474976710655                 ## 0xffffffffffff
	.space	16
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.space	16
	.quad	255                             ## 0xff
	.quad	72057594037927680               ## 0xffffffffffff00
	.quad	255                             ## 0xff
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	16
	.space	16
	.quad	0                               ## 0x0
	.quad	72057594037927935               ## 0xffffffffffffff
	.space	64

.subsections_via_symbols
