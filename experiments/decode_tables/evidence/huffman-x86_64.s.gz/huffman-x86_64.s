	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
LCPI0_0:
	.byte	0                               ## 0x0
	.byte	1                               ## 0x1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI0_1:
	.byte	2                               ## 0x2
	.byte	2                               ## 0x2
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI0_2:
	.quad	1                               ## 0x1
	.quad	1                               ## 0x1
LCPI0_3:
	.byte	4                               ## 0x4
	.byte	4                               ## 0x4
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
LCPI0_4:
	.byte	0                               ## 0x0
	.byte	1                               ## 0x1
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.byte	0                               ## 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ## @_ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$15192, %rsp                    ## imm = 0x3B58
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	cmpq	$2097160, %rsi                  ## imm = 0x200008
	ja	LBB0_136
## %bb.1:
	movq	%rsi, %rbx
	leaq	512(,%rsi,2), %rax
	cmpq	%rax, %rcx
	jb	LBB0_136
## %bb.2:
	movb	$0, (%rdx)
	movb	%bl, 1(%rdx)
	movb	%bh, 2(%rdx)
	movl	%ebx, %eax
	shrl	$16, %eax
	movb	%al, 3(%rdx)
	movb	$0, 4(%rdx)
	testq	%rbx, %rbx
	je	LBB0_18
## %bb.3:
	movq	%rdi, %r13
	movq	%rdx, -312(%rbp)                ## 8-byte Spill
	leaq	-1408(%rbp), %rdi
	movl	$1024, %esi                     ## imm = 0x400
	callq	___bzero
	leaq	-11132(%rbp), %rdi
	movl	$3072, %esi                     ## imm = 0xC00
	callq	___bzero
	movq	%rbx, %rcx
	xorl	%eax, %eax
	andq	$4194300, %rcx                  ## imm = 0x3FFFFC
	je	LBB0_5
	.p2align	4
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13,%rax), %edx
	incl	-1408(%rbp,%rdx,4)
	movzbl	1(%r13,%rax), %edx
	incl	-11132(%rbp,%rdx,4)
	movzbl	2(%r13,%rax), %edx
	incl	-10108(%rbp,%rdx,4)
	movzbl	3(%r13,%rax), %edx
	incl	-9084(%rbp,%rdx,4)
	addq	$4, %rax
	cmpq	%rcx, %rax
	jb	LBB0_4
LBB0_5:
	movq	%rax, %rcx
	subq	%rbx, %rcx
	jae	LBB0_10
## %bb.6:
	movl	%ebx, %edx
	subl	%eax, %edx
	andl	$3, %edx
	je	LBB0_8
	.p2align	4
LBB0_7:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13,%rax), %esi
	incl	-1408(%rbp,%rsi,4)
	incq	%rax
	decq	%rdx
	jne	LBB0_7
LBB0_8:
	cmpq	$-4, %rcx
	ja	LBB0_10
	.p2align	4
LBB0_9:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%r13,%rax), %ecx
	incl	-1408(%rbp,%rcx,4)
	movzbl	1(%r13,%rax), %ecx
	incl	-1408(%rbp,%rcx,4)
	movzbl	2(%r13,%rax), %ecx
	incl	-1408(%rbp,%rcx,4)
	movzbl	3(%r13,%rax), %ecx
	incl	-1408(%rbp,%rcx,4)
	addq	$4, %rax
	cmpq	%rax, %rbx
	jne	LBB0_9
LBB0_10:
	xorl	%eax, %eax
	movq	-312(%rbp), %rdi                ## 8-byte Reload
	.p2align	4
LBB0_11:                                ## =>This Inner Loop Header: Depth=1
	movdqu	-11132(%rbp,%rax,4), %xmm0
	movdqu	-11116(%rbp,%rax,4), %xmm1
	movdqu	-1408(%rbp,%rax,4), %xmm2
	paddd	%xmm0, %xmm2
	movdqu	-1392(%rbp,%rax,4), %xmm0
	paddd	%xmm1, %xmm0
	movdqu	-10108(%rbp,%rax,4), %xmm1
	movdqu	-10092(%rbp,%rax,4), %xmm3
	movdqu	-9084(%rbp,%rax,4), %xmm4
	paddd	%xmm1, %xmm4
	paddd	%xmm2, %xmm4
	movdqu	-9068(%rbp,%rax,4), %xmm1
	paddd	%xmm3, %xmm1
	paddd	%xmm0, %xmm1
	movdqu	%xmm4, -1408(%rbp,%rax,4)
	movdqu	%xmm1, -1392(%rbp,%rax,4)
	addq	$8, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	jne	LBB0_11
## %bb.12:
	movd	%ebx, %xmm0
	pshufd	$0, %xmm0, %xmm13               ## xmm13 = xmm0[0,0,0,0]
	movd	LCPI0_4(%rip), %xmm10           ## xmm10 = [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
	pxor	%xmm4, %xmm4
	xorl	%eax, %eax
	pxor	%xmm14, %xmm14
	pxor	%xmm8, %xmm8
	pxor	%xmm2, %xmm2
	pxor	%xmm6, %xmm6
	pxor	%xmm5, %xmm5
	pxor	%xmm3, %xmm3
	pxor	%xmm7, %xmm7
	movdqa	%xmm13, %xmm12
	.p2align	4
LBB0_13:                                ## =>This Inner Loop Header: Depth=1
	movdqa	%xmm2, -336(%rbp)               ## 16-byte Spill
	movdqa	%xmm8, %xmm1
	movdqa	%xmm10, %xmm2
	paddb	LCPI0_1(%rip), %xmm2            ## [2,2,u,u,u,u,u,u,u,u,u,u,u,u,u,u]
	movq	-1408(%rbp,%rax,4), %xmm11      ## xmm11 = mem[0],zero
	movq	-1400(%rbp,%rax,4), %xmm9       ## xmm9 = mem[0],zero
	movdqa	%xmm11, %xmm0
	pxor	%xmm8, %xmm8
	pcmpeqd	%xmm8, %xmm0
	movdqa	%xmm0, %xmm15
	packssdw	%xmm0, %xmm0
	packsswb	%xmm0, %xmm0
	movdqa	%xmm10, %xmm8
	pblendvb	%xmm0, %xmm1, %xmm8
	movdqa	%xmm9, %xmm0
	pxor	%xmm1, %xmm1
	pcmpeqd	%xmm1, %xmm0
	movdqa	%xmm0, %xmm1
	packssdw	%xmm0, %xmm0
	packsswb	%xmm0, %xmm0
	pblendvb	%xmm0, -336(%rbp), %xmm2        ## 16-byte Folded Reload
	pminud	%xmm11, %xmm13
	pmaxud	%xmm11, %xmm3
	pminud	%xmm9, %xmm12
	pmaxud	%xmm9, %xmm7
	pcmpeqd	%xmm9, %xmm9
	pxor	%xmm9, %xmm15
	pmovsxdq	%xmm15, %xmm0
	por	%xmm0, %xmm6
	pxor	%xmm9, %xmm1
	pmovsxdq	%xmm1, %xmm0
	por	%xmm0, %xmm5
	pmovzxdq	%xmm15, %xmm0                   ## xmm0 = xmm15[0],zero,xmm15[1],zero
	movdqa	LCPI0_2(%rip), %xmm9            ## xmm9 = [1,1]
	pand	%xmm9, %xmm0
	paddq	%xmm0, %xmm14
	pmovzxdq	%xmm1, %xmm0                    ## xmm0 = xmm1[0],zero,xmm1[1],zero
	pand	%xmm9, %xmm0
	paddq	%xmm0, %xmm4
	addq	$4, %rax
	paddb	LCPI0_3(%rip), %xmm10           ## [4,4,u,u,u,u,u,u,u,u,u,u,u,u,u,u]
	cmpq	$256, %rax                      ## imm = 0x100
	jne	LBB0_13
## %bb.14:
	paddq	%xmm14, %xmm4
	pshufd	$238, %xmm4, %xmm0              ## xmm0 = xmm4[2,3,2,3]
	paddq	%xmm4, %xmm0
	movq	%xmm0, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB0_19
## %bb.15:
	cmpq	$1, %rax
	jne	LBB0_20
## %bb.16:
	por	%xmm6, %xmm5
	psllq	$63, %xmm5
	movmskpd	%xmm5, %eax
	testl	%eax, %eax
	je	LBB0_57
## %bb.17:
	pmaxub	%xmm2, %xmm8
	movdqa	%xmm8, %xmm0
	psrlw	$8, %xmm0
	pmaxub	%xmm8, %xmm0
	movd	%xmm0, %eax
	jmp	LBB0_58
LBB0_18:
	movl	$5, %eax
	jmp	LBB0_130
LBB0_19:
	pminud	%xmm12, %xmm13
	pshufd	$85, %xmm13, %xmm0              ## xmm0 = xmm13[1,1,1,1]
	pminud	%xmm13, %xmm0
	movd	%xmm0, %eax
	pmaxud	%xmm7, %xmm3
	pshufd	$85, %xmm3, %xmm0               ## xmm0 = xmm3[1,1,1,1]
	pmaxud	%xmm3, %xmm0
	movd	%xmm0, %ecx
	addl	%eax, %eax
	cmpl	%eax, %ecx
	jbe	LBB0_56
LBB0_20:
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, -64(%rbp)
	movdqa	%xmm0, -80(%rbp)
	movdqa	%xmm0, -96(%rbp)
	movdqa	%xmm0, -112(%rbp)
	movdqa	%xmm0, -128(%rbp)
	movdqa	%xmm0, -144(%rbp)
	movdqa	%xmm0, -160(%rbp)
	movdqa	%xmm0, -176(%rbp)
	movdqa	%xmm0, -192(%rbp)
	movdqa	%xmm0, -208(%rbp)
	movdqa	%xmm0, -224(%rbp)
	movdqa	%xmm0, -240(%rbp)
	movdqa	%xmm0, -256(%rbp)
	movdqa	%xmm0, -272(%rbp)
	movdqa	%xmm0, -288(%rbp)
	movdqa	%xmm0, -304(%rbp)
	leaq	-3968(%rbp), %rdi
	movl	$512, %esi                      ## imm = 0x200
	callq	___bzero
	leaq	-3456(%rbp), %rdi
	movl	$2048, %esi                     ## imm = 0x800
	callq	___bzero
	movl	$28, %eax
	.p2align	4
LBB0_21:                                ## =>This Inner Loop Header: Depth=1
	movl	$0, -3484(%rbp,%rax)
	movw	$0, -3480(%rbp,%rax)
	movl	$0, -3476(%rbp,%rax)
	movw	$0, -3472(%rbp,%rax)
	movl	$0, -3468(%rbp,%rax)
	movw	$0, -3464(%rbp,%rax)
	movl	$0, -3460(%rbp,%rax)
	movw	$0, -3456(%rbp,%rax)
	addq	$32, %rax
	cmpq	$2076, %rax                     ## imm = 0x81C
	jne	LBB0_21
## %bb.22:
	leaq	-6012(%rbp), %rdi
	movl	$2044, %esi                     ## imm = 0x7FC
	callq	___bzero
	leaq	-15224(%rbp), %rdi
	movl	$4088, %esi                     ## imm = 0xFF8
	callq	___bzero
	xorl	%r15d, %r15d
	xorl	%eax, %eax
	jmp	LBB0_24
	.p2align	4
LBB0_23:                                ##   in Loop: Header=BB0_24 Depth=1
	addq	$2, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB0_28
LBB0_24:                                ## =>This Inner Loop Header: Depth=1
	movl	-1408(%rbp,%rax,4), %ecx
	testl	%ecx, %ecx
	je	LBB0_26
## %bb.25:                              ##   in Loop: Header=BB0_24 Depth=1
	movl	%ecx, -3456(%rbp,%r15,8)
	movw	%ax, -3452(%rbp,%r15,8)
	incq	%r15
LBB0_26:                                ##   in Loop: Header=BB0_24 Depth=1
	movl	-1404(%rbp,%rax,4), %ecx
	testl	%ecx, %ecx
	je	LBB0_23
## %bb.27:                              ##   in Loop: Header=BB0_24 Depth=1
	movl	%ecx, -3456(%rbp,%r15,8)
	leal	1(%rax), %ecx
	movw	%cx, -3452(%rbp,%r15,8)
	incq	%r15
	jmp	LBB0_23
LBB0_28:
	cmpq	$1, %r15
	jbe	LBB0_141
## %bb.29:
	leaq	-3456(,%r15,8), %rsi
	addq	%rbp, %rsi
	bsrq	%r15, %rdx
	xorl	$63, %edx
	addl	%edx, %edx
	xorq	$126, %rdx
	leaq	-3456(%rbp), %rdi
	movl	$1, %ecx
	callq	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	cmpq	$8, %r15
	ja	LBB0_31
## %bb.30:
	xorl	%eax, %eax
	jmp	LBB0_33
LBB0_31:
	movl	%r15d, %eax
	andl	$7, %eax
	movl	$8, %ecx
	cmovneq	%rax, %rcx
	movq	%r15, %rax
	subq	%rcx, %rax
	xorl	%ecx, %ecx
	.p2align	4
LBB0_32:                                ## =>This Inner Loop Header: Depth=1
	movups	-3456(%rbp,%rcx,8), %xmm0
	movups	-3440(%rbp,%rcx,8), %xmm1
	shufps	$136, %xmm1, %xmm0              ## xmm0 = xmm0[0,2],xmm1[0,2]
	movups	-3424(%rbp,%rcx,8), %xmm1
	movups	-3408(%rbp,%rcx,8), %xmm2
	shufps	$136, %xmm2, %xmm1              ## xmm1 = xmm1[0,2],xmm2[0,2]
	movups	%xmm0, -6012(%rbp,%rcx,4)
	movups	%xmm1, -5996(%rbp,%rcx,4)
	addq	$8, %rcx
	cmpq	%rcx, %rax
	jne	LBB0_32
LBB0_33:
	movq	%rbx, -336(%rbp)                ## 8-byte Spill
	.p2align	4
LBB0_34:                                ## =>This Inner Loop Header: Depth=1
	movl	-3456(%rbp,%rax,8), %ecx
	movl	%ecx, -6012(%rbp,%rax,4)
	incq	%rax
	cmpq	%rax, %r15
	jne	LBB0_34
## %bb.35:
	movq	$0, -352(%rbp)
	movq	%r15, -344(%rbp)
	leaq	(%r15,%r15), %rax
	leaq	-1(,%r15,2), %rcx
	cmpq	%rcx, %r15
	jae	LBB0_48
## %bb.36:
	leaq	-1(%r15), %rcx
	leaq	-6012(,%r15,4), %rdx
	addq	%rbp, %rdx
	xorl	%esi, %esi
	leaq	-352(%rbp), %rdi
	leaq	-344(%rbp), %r8
	jmp	LBB0_39
	.p2align	4
LBB0_37:                                ##   in Loop: Header=BB0_39 Depth=1
	movq	%rbx, %r11
	movq	%r8, %r14
LBB0_38:                                ##   in Loop: Header=BB0_39 Depth=1
	leaq	1(%r11), %rbx
	movq	%rbx, (%r14)
	movl	-6012(%rbp,%r11,4), %ebx
	addl	-6012(%rbp,%r10,4), %ebx
	movl	%ebx, (%rdx,%rsi,4)
	movq	%r9, -15224(%rbp,%r10,8)
	movq	%r9, -15224(%rbp,%r11,8)
	incq	%rsi
	cmpq	%rsi, %rcx
	je	LBB0_48
LBB0_39:                                ## =>This Inner Loop Header: Depth=1
	leaq	(%r15,%rsi), %r9
	movq	-352(%rbp), %r10
	movq	-344(%rbp), %r11
	cmpq	%r15, %r10
	jae	LBB0_43
## %bb.40:                              ##   in Loop: Header=BB0_39 Depth=1
	cmpq	%r11, %r9
	jne	LBB0_42
## %bb.41:                              ##   in Loop: Header=BB0_39 Depth=1
	movq	%rdi, %rbx
	jmp	LBB0_44
	.p2align	4
LBB0_42:                                ##   in Loop: Header=BB0_39 Depth=1
	movl	-6012(%rbp,%r10,4), %r14d
	movq	%rdi, %rbx
	cmpl	-6012(%rbp,%r11,4), %r14d
	jbe	LBB0_44
	.p2align	4
LBB0_43:                                ##   in Loop: Header=BB0_39 Depth=1
	movq	%r11, %r10
	movq	%r8, %rbx
LBB0_44:                                ##   in Loop: Header=BB0_39 Depth=1
	leaq	1(%r10), %r11
	movq	%r11, (%rbx)
	movq	-352(%rbp), %r11
	movq	-344(%rbp), %rbx
	cmpq	%r15, %r11
	jae	LBB0_37
## %bb.45:                              ##   in Loop: Header=BB0_39 Depth=1
	cmpq	%rbx, %r9
	jne	LBB0_47
## %bb.46:                              ##   in Loop: Header=BB0_39 Depth=1
	movq	%rdi, %r14
	jmp	LBB0_38
	.p2align	4
LBB0_47:                                ##   in Loop: Header=BB0_39 Depth=1
	movl	-6012(%rbp,%r11,4), %r12d
	movq	%rdi, %r14
	cmpl	-6012(%rbp,%rbx,4), %r12d
	jbe	LBB0_38
	jmp	LBB0_37
LBB0_48:
	addq	$-2, %rax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	movq	-336(%rbp), %rbx                ## 8-byte Reload
	jmp	LBB0_50
	.p2align	4
LBB0_49:                                ##   in Loop: Header=BB0_50 Depth=1
	cmpl	%esi, %edx
	cmovbel	%esi, %edx
	movzwl	-3452(%rbp,%rcx,8), %edi
	movb	%sil, -304(%rbp,%rdi)
	incq	%rcx
	cmpq	%r15, %rcx
	je	LBB0_53
LBB0_50:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_52 Depth 2
	movl	$0, %esi
	cmpq	%rax, %rcx
	je	LBB0_49
## %bb.51:                              ##   in Loop: Header=BB0_50 Depth=1
	xorl	%esi, %esi
	movq	%rcx, %rdi
	.p2align	4
LBB0_52:                                ##   Parent Loop BB0_50 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	incl	%esi
	movq	-15224(%rbp,%rdi,8), %rdi
	cmpq	%rax, %rdi
	jne	LBB0_52
	jmp	LBB0_49
LBB0_53:
	cmpl	$13, %edx
	jb	LBB0_65
## %bb.54:
	leaq	-8060(%rbp), %rdi
	movl	$2048, %esi                     ## imm = 0x800
	callq	___bzero
	movl	%r15d, %eax
	andl	$3, %eax
	cmpq	$4, %r15
	jae	LBB0_59
## %bb.55:
	xorl	%ecx, %ecx
	jmp	LBB0_62
LBB0_56:
	addq	$5, %rdi
	movq	%r13, %rsi
	movq	%rbx, %rdx
	callq	_memcpy
	addq	$5, %rbx
	jmp	LBB0_129
LBB0_57:
	xorl	%eax, %eax
LBB0_58:
	movb	$4, (%rdi)
	movb	%al, 5(%rdi)
	movl	$6, %eax
	jmp	LBB0_130
LBB0_59:
	movq	%r15, %rdx
	andq	$-4, %rdx
	xorl	%ecx, %ecx
	.p2align	4
LBB0_60:                                ## =>This Inner Loop Header: Depth=1
	movl	-3456(%rbp,%rcx,8), %esi
	movzwl	-3452(%rbp,%rcx,8), %edi
	movl	%esi, -8060(%rbp,%rcx,8)
	movw	%di, -8056(%rbp,%rcx,8)
	movl	-3448(%rbp,%rcx,8), %esi
	movzwl	-3444(%rbp,%rcx,8), %edi
	movl	%esi, -8052(%rbp,%rcx,8)
	movw	%di, -8048(%rbp,%rcx,8)
	movl	-3440(%rbp,%rcx,8), %esi
	movzwl	-3436(%rbp,%rcx,8), %edi
	movl	%esi, -8044(%rbp,%rcx,8)
	movw	%di, -8040(%rbp,%rcx,8)
	movl	-3432(%rbp,%rcx,8), %esi
	movzwl	-3428(%rbp,%rcx,8), %edi
	movl	%esi, -8036(%rbp,%rcx,8)
	movw	%di, -8032(%rbp,%rcx,8)
	addq	$4, %rcx
	cmpq	%rcx, %rdx
	jne	LBB0_60
## %bb.61:
	testq	%rax, %rax
	je	LBB0_64
LBB0_62:
	leaq	-8056(,%rcx,8), %rdx
	addq	%rbp, %rdx
	leaq	-3452(,%rcx,8), %rcx
	addq	%rbp, %rcx
	xorl	%esi, %esi
	.p2align	4
LBB0_63:                                ## =>This Inner Loop Header: Depth=1
	movl	-4(%rcx,%rsi,8), %edi
	movzwl	(%rcx,%rsi,8), %r8d
	movl	%edi, -4(%rdx,%rsi,8)
	movw	%r8w, (%rdx,%rsi,8)
	incq	%rsi
	cmpq	%rsi, %rax
	jne	LBB0_63
LBB0_64:
	leaq	-8060(%rbp), %rdi
	leaq	-304(%rbp), %rcx
	movq	%r15, %rsi
	movl	$12, %edx
	callq	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
LBB0_65:
	leaq	-304(%rbp), %rdi
	leaq	-3968(%rbp), %rsi
	callq	__ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	pxor	%xmm0, %xmm0
	xorl	%eax, %eax
	pxor	%xmm1, %xmm1
	.p2align	4
LBB0_66:                                ## =>This Inner Loop Header: Depth=1
	movq	-1408(%rbp,%rax,4), %xmm2       ## xmm2 = mem[0],zero
	movq	-1400(%rbp,%rax,4), %xmm3       ## xmm3 = mem[0],zero
	movzwl	-304(%rbp,%rax), %ecx
	movd	%ecx, %xmm4
	movzwl	-302(%rbp,%rax), %ecx
	movd	%ecx, %xmm5
	pmovzxbd	%xmm4, %xmm4                    ## xmm4 = xmm4[0],zero,zero,zero,xmm4[1],zero,zero,zero,xmm4[2],zero,zero,zero,xmm4[3],zero,zero,zero
	pmulld	%xmm2, %xmm4
	pmovzxbd	%xmm5, %xmm2                    ## xmm2 = xmm5[0],zero,zero,zero,xmm5[1],zero,zero,zero,xmm5[2],zero,zero,zero,xmm5[3],zero,zero,zero
	pmulld	%xmm3, %xmm2
	pmovzxdq	%xmm4, %xmm3                    ## xmm3 = xmm4[0],zero,xmm4[1],zero
	movdqa	%xmm0, %xmm4
	paddq	%xmm3, %xmm4
	pmovzxdq	%xmm2, %xmm0                    ## xmm0 = xmm2[0],zero,xmm2[1],zero
	movdqa	%xmm1, %xmm2
	paddq	%xmm0, %xmm2
	movq	-1392(%rbp,%rax,4), %xmm0       ## xmm0 = mem[0],zero
	movq	-1384(%rbp,%rax,4), %xmm1       ## xmm1 = mem[0],zero
	movzwl	-300(%rbp,%rax), %ecx
	movd	%ecx, %xmm3
	movzwl	-298(%rbp,%rax), %ecx
	movd	%ecx, %xmm5
	pmovzxbd	%xmm3, %xmm3                    ## xmm3 = xmm3[0],zero,zero,zero,xmm3[1],zero,zero,zero,xmm3[2],zero,zero,zero,xmm3[3],zero,zero,zero
	pmulld	%xmm0, %xmm3
	pmovzxbd	%xmm5, %xmm5                    ## xmm5 = xmm5[0],zero,zero,zero,xmm5[1],zero,zero,zero,xmm5[2],zero,zero,zero,xmm5[3],zero,zero,zero
	pmulld	%xmm1, %xmm5
	pmovzxdq	%xmm3, %xmm0                    ## xmm0 = xmm3[0],zero,xmm3[1],zero
	paddq	%xmm4, %xmm0
	pmovzxdq	%xmm5, %xmm1                    ## xmm1 = xmm5[0],zero,xmm5[1],zero
	paddq	%xmm2, %xmm1
	addq	$8, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	jne	LBB0_66
## %bb.67:
	paddq	%xmm0, %xmm1
	pshufd	$238, %xmm1, %xmm0              ## xmm0 = xmm1[2,3,2,3]
	paddq	%xmm1, %xmm0
	movq	%xmm0, %rcx
	movq	-312(%rbp), %rax                ## 8-byte Reload
	leaq	5(%rax), %r14
	xorl	%edx, %edx
	xorl	%esi, %esi
	xorl	%eax, %eax
	jmp	LBB0_72
LBB0_101:                               ##   in Loop: Header=BB0_72 Depth=1
	movq	%r11, %rax
	movq	-336(%rbp), %rbx                ## 8-byte Reload
	.p2align	4
LBB0_71:                                ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$256, %rdx                      ## imm = 0x100
	jae	LBB0_110
LBB0_72:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_74 Depth 2
	movq	%rdx, %rdi
	movzbl	-304(%rbp,%rdx), %r9d
	movl	$256, %edx                      ## imm = 0x100
	cmpq	$255, %rdi
	je	LBB0_77
## %bb.73:                              ##   in Loop: Header=BB0_72 Depth=1
	leaq	1(%rdi), %rdx
	.p2align	4
LBB0_74:                                ##   Parent Loop BB0_72 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	cmpb	%r9b, -304(%rbp,%rdx)
	jne	LBB0_77
## %bb.75:                              ##   in Loop: Header=BB0_74 Depth=2
	incq	%rdx
	cmpq	$256, %rdx                      ## imm = 0x100
	jne	LBB0_74
## %bb.76:                              ##   in Loop: Header=BB0_72 Depth=1
	movl	$256, %edx                      ## imm = 0x100
LBB0_77:                                ##   in Loop: Header=BB0_72 Depth=1
	movq	%rdx, %r8
	subq	%rdi, %r8
	cmpb	%sil, %r9b
	je	LBB0_84
## %bb.78:                              ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$255, %rax
	ja	LBB0_134
## %bb.79:                              ##   in Loop: Header=BB0_72 Depth=1
	cmpb	$16, %r9b
	jae	LBB0_134
## %bb.80:                              ##   in Loop: Header=BB0_72 Depth=1
	testb	$1, %al
	jne	LBB0_82
## %bb.81:                              ##   in Loop: Header=BB0_72 Depth=1
	movq	%rax, %rsi
	shrq	%rsi
	movb	%r9b, (%r14,%rsi)
	jmp	LBB0_83
	.p2align	4
LBB0_82:                                ##   in Loop: Header=BB0_72 Depth=1
	movl	%r9d, %esi
	shlb	$4, %sil
	movq	%rax, %rdi
	shrq	%rdi
	orb	%sil, (%r14,%rdi)
LBB0_83:                                ##   in Loop: Header=BB0_72 Depth=1
	incq	%rax
	decq	%r8
	movl	%r9d, %esi
LBB0_84:                                ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$19, %r8
	jb	LBB0_90
## %bb.85:                              ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$256, %rax                      ## imm = 0x100
	jae	LBB0_132
## %bb.86:                              ##   in Loop: Header=BB0_72 Depth=1
	movq	%rax, %rdi
	shrq	%rdi
	testb	$1, %al
	jne	LBB0_102
## %bb.87:                              ##   in Loop: Header=BB0_72 Depth=1
	addq	$-19, %r8
	movl	%r8d, %r9d
	shlb	$4, %r9b
	orb	$15, %r9b
	movb	%r9b, (%r14,%rdi)
	cmpq	$253, %rax
	ja	LBB0_133
## %bb.88:                              ##   in Loop: Header=BB0_72 Depth=1
	shrl	$4, %r8d
	cmpb	$16, %r8b
	jae	LBB0_133
## %bb.89:                              ##   in Loop: Header=BB0_72 Depth=1
	leaq	2(%rax), %rdi
	shrq	%rdi
	movb	%r8b, (%r14,%rdi)
	addq	$3, %rax
	jmp	LBB0_71
	.p2align	4
LBB0_90:                                ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$2, %r8
	jbe	LBB0_95
## %bb.91:                              ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$256, %rax                      ## imm = 0x100
	jae	LBB0_137
## %bb.92:                              ##   in Loop: Header=BB0_72 Depth=1
	movq	%rax, %rdi
	shrq	%rdi
	testb	$1, %al
	jne	LBB0_93
## %bb.68:                              ##   in Loop: Header=BB0_72 Depth=1
	shlb	$4, %r8b
	addb	$-34, %r8b
	jmp	LBB0_69
	.p2align	4
LBB0_95:                                ##   in Loop: Header=BB0_72 Depth=1
	testq	%r8, %r8
	je	LBB0_71
## %bb.96:                              ##   in Loop: Header=BB0_72 Depth=1
	cmpb	$15, %r9b
	ja	LBB0_135
## %bb.97:                              ##   in Loop: Header=BB0_72 Depth=1
	movl	$256, %edi                      ## imm = 0x100
	subq	%rax, %rdi
	movl	$0, %r10d
	cmovaeq	%rdi, %r10
	cmpq	$255, %rax
	ja	LBB0_135
## %bb.98:                              ##   in Loop: Header=BB0_72 Depth=1
	movl	%r9d, %edi
	shlb	$4, %dil
	movq	%rax, %r11
	shrq	%r11
	movl	%r9d, %ebx
	testb	$1, %al
	je	LBB0_100
## %bb.99:                              ##   in Loop: Header=BB0_72 Depth=1
	movzbl	(%r14,%r11), %ebx
	orb	%dil, %bl
LBB0_100:                               ##   in Loop: Header=BB0_72 Depth=1
	movb	%bl, (%r14,%r11)
	leaq	1(%rax), %r11
	cmpq	$1, %r8
	je	LBB0_101
## %bb.106:                             ##   in Loop: Header=BB0_72 Depth=1
	cmpq	$1, %r10
	movq	-336(%rbp), %rbx                ## 8-byte Reload
	je	LBB0_135
## %bb.107:                             ##   in Loop: Header=BB0_72 Depth=1
	shrq	%r11
	testb	$1, %al
	jne	LBB0_109
## %bb.108:                             ##   in Loop: Header=BB0_72 Depth=1
	orb	(%r14,%r11), %dil
	movl	%edi, %r9d
LBB0_109:                               ##   in Loop: Header=BB0_72 Depth=1
	movb	%r9b, (%r14,%r11)
	jmp	LBB0_70
	.p2align	4
LBB0_102:                               ##   in Loop: Header=BB0_72 Depth=1
	orb	$-16, (%r14,%rdi)
	cmpq	$255, %rax
	je	LBB0_138
## %bb.103:                             ##   in Loop: Header=BB0_72 Depth=1
	leaq	1(%rax), %rdi
	addq	$-19, %r8
	movl	%r8d, %r9d
	andb	$15, %r9b
	shrq	%rdi
	movb	%r9b, (%r14,%rdi)
	cmpq	$253, %rax
	ja	LBB0_133
## %bb.104:                             ##   in Loop: Header=BB0_72 Depth=1
	shrl	$4, %r8d
	cmpb	$16, %r8b
	jae	LBB0_133
## %bb.105:                             ##   in Loop: Header=BB0_72 Depth=1
	leaq	2(%rax), %rdi
	shlb	$4, %r8b
	shrq	%rdi
	orb	%r8b, (%r14,%rdi)
	addq	$3, %rax
	jmp	LBB0_71
LBB0_93:                                ##   in Loop: Header=BB0_72 Depth=1
	orb	$-32, (%r14,%rdi)
	cmpq	$255, %rax
	je	LBB0_140
## %bb.94:                              ##   in Loop: Header=BB0_72 Depth=1
	leaq	1(%rax), %rdi
	addb	$-3, %r8b
	shrq	%rdi
LBB0_69:                                ##   in Loop: Header=BB0_72 Depth=1
	movb	%r8b, (%r14,%rdi)
LBB0_70:                                ##   in Loop: Header=BB0_72 Depth=1
	addq	$2, %rax
	jmp	LBB0_71
LBB0_110:
	incq	%rax
	shrq	%rax
	xorl	%edx, %edx
	cmpq	$1025, %rbx                     ## imm = 0x401
	setae	%dl
	leaq	(%rdx,%rdx,2), %rsi
	leaq	(%rax,%rsi,4), %rdi
	addq	$9, %rdi
	shrq	$3, %rcx
	addq	%rdi, %rcx
	addq	$-4, %rcx
	leaq	5(%rbx), %r8
	cmpq	%r8, %rcx
	jae	LBB0_124
## %bb.111:
	movq	%r8, -384(%rbp)                 ## 8-byte Spill
	movq	%r14, -368(%rbp)                ## 8-byte Spill
	leaq	(%rdx,%rdx,2), %rdi
	incq	%rdi
	leaq	(%rax,%rsi,4), %r9
	addq	$5, %r9
	addq	$5, %rax
	cmpq	$1025, %rbx                     ## imm = 0x401
	setae	%cl
	addb	%cl, %cl
	movq	%rbx, %rsi
	shrq	%cl, %rsi
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	addq	%rdx, %rax
	xorl	%r12d, %r12d
	movq	%r13, -376(%rbp)                ## 8-byte Spill
	movq	%r13, %r10
	xorl	%r11d, %r11d
	movq	%r9, %r15
	movq	%rdi, -360(%rbp)                ## 8-byte Spill
	jmp	LBB0_113
	.p2align	4
LBB0_112:                               ##   in Loop: Header=BB0_113 Depth=1
	subq	%rsi, %r11
	addq	%rsi, %r10
	movq	%r13, %r12
	movq	%r15, %r9
	cmpq	%rdi, %r13
	je	LBB0_125
LBB0_113:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_116 Depth 2
                                        ##     Child Loop BB0_120 Depth 2
	movq	%r12, %rcx
	imulq	%rsi, %rcx
	leaq	1(%r12), %r13
	leaq	(%rcx,%rsi), %rbx
	cmpq	%rdi, %r13
	cmoveq	-336(%rbp), %rbx                ## 8-byte Folded Reload
	cmpq	%rbx, %rcx
	jae	LBB0_121
## %bb.114:                             ##   in Loop: Header=BB0_113 Depth=1
	addq	%r11, %rbx
	xorl	%r14d, %r14d
	xorl	%edx, %edx
	xorl	%r8d, %r8d
	movq	%r9, %r15
	jmp	LBB0_116
	.p2align	4
LBB0_115:                               ##   in Loop: Header=BB0_116 Depth=2
	incq	%rdx
	cmpq	%rdx, %rbx
	je	LBB0_118
LBB0_116:                               ##   Parent Loop BB0_113 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r8, %rdi
	movl	%r14d, %ecx
	movzbl	(%r10,%rdx), %r14d
	movzwl	-3968(%rbp,%r14,2), %r8d
	shlq	%cl, %r8
	orq	%rdi, %r8
	movzbl	-304(%rbp,%r14), %r14d
	addl	%ecx, %r14d
	cmpl	$32, %r14d
	jb	LBB0_115
## %bb.117:                             ##   in Loop: Header=BB0_116 Depth=2
	movq	-312(%rbp), %rcx                ## 8-byte Reload
	movl	%r8d, (%rcx,%r15)
	addq	$4, %r15
	shrq	$32, %r8
	addl	$-32, %r14d
	jmp	LBB0_115
	.p2align	4
LBB0_118:                               ##   in Loop: Header=BB0_113 Depth=1
	testl	%r14d, %r14d
	je	LBB0_123
## %bb.119:                             ##   in Loop: Header=BB0_113 Depth=1
	addl	$8, %r14d
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	movq	-360(%rbp), %rdi                ## 8-byte Reload
	.p2align	4
LBB0_120:                               ##   Parent Loop BB0_113 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movb	%r8b, (%rdx,%r15)
	incq	%r15
	shrq	$8, %r8
	addl	$-8, %r14d
	cmpl	$8, %r14d
	ja	LBB0_120
LBB0_121:                               ##   in Loop: Header=BB0_113 Depth=1
	cmpq	%rdi, %r13
	je	LBB0_112
LBB0_122:                               ##   in Loop: Header=BB0_113 Depth=1
	movl	%r15d, %ecx
	subl	%r9d, %ecx
	movl	%ecx, (%rax,%r12,4)
	jmp	LBB0_112
LBB0_123:                               ##   in Loop: Header=BB0_113 Depth=1
	movq	-312(%rbp), %rdx                ## 8-byte Reload
	movq	-360(%rbp), %rdi                ## 8-byte Reload
	cmpq	%rdi, %r13
	jne	LBB0_122
	jmp	LBB0_112
LBB0_124:
	movq	%r14, %rdi
	movq	%r13, %rsi
	movq	%rbx, %rdx
	movq	%r8, %rbx
	jmp	LBB0_128
LBB0_125:
	movq	-384(%rbp), %rbx                ## 8-byte Reload
	cmpq	%rbx, %r15
	jae	LBB0_127
## %bb.126:
	movb	$36, (%rdx)
	movq	%r15, %rax
	jmp	LBB0_130
LBB0_127:
	movq	-368(%rbp), %rdi                ## 8-byte Reload
	movq	-376(%rbp), %rsi                ## 8-byte Reload
	movq	-336(%rbp), %rdx                ## 8-byte Reload
LBB0_128:
	callq	_memcpy
LBB0_129:
	movq	%rbx, %rax
LBB0_130:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rcx
	movq	(%rcx), %rcx
	cmpq	-48(%rbp), %rcx
	jne	LBB0_139
## %bb.131:
	addq	$15192, %rsp                    ## imm = 0x3B58
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB0_132:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp15:                                 ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ## EH_LABEL
	jmp	LBB0_142
LBB0_133:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp21:                                 ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ## EH_LABEL
	jmp	LBB0_142
LBB0_134:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp3:                                  ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ## EH_LABEL
	jmp	LBB0_142
LBB0_135:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp6:                                  ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ## EH_LABEL
	jmp	LBB0_142
LBB0_136:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp24:                                 ## EH_LABEL
	leaq	L_.str(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ## EH_LABEL
	jmp	LBB0_142
LBB0_137:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp9:                                  ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ## EH_LABEL
	jmp	LBB0_142
LBB0_138:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp18:                                 ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ## EH_LABEL
	jmp	LBB0_142
LBB0_139:
	callq	___stack_chk_fail
LBB0_140:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp12:                                 ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ## EH_LABEL
	jmp	LBB0_142
LBB0_141:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp0:                                  ## EH_LABEL
	leaq	L_.str.8(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ## EH_LABEL
LBB0_142:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB0_143:
Ltmp2:                                  ## EH_LABEL
	jmp	LBB0_152
LBB0_144:
Ltmp14:                                 ## EH_LABEL
	jmp	LBB0_152
LBB0_145:
Ltmp20:                                 ## EH_LABEL
	jmp	LBB0_152
LBB0_146:
Ltmp11:                                 ## EH_LABEL
	jmp	LBB0_152
LBB0_147:
Ltmp26:                                 ## EH_LABEL
	jmp	LBB0_152
LBB0_148:
Ltmp8:                                  ## EH_LABEL
	jmp	LBB0_152
LBB0_149:
Ltmp5:                                  ## EH_LABEL
	jmp	LBB0_152
LBB0_150:
Ltmp23:                                 ## EH_LABEL
	jmp	LBB0_152
LBB0_151:
Ltmp17:                                 ## EH_LABEL
LBB0_152:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ## >> Call Site 1 <<
	.uleb128 Ltmp15-Lfunc_begin0            ##   Call between Lfunc_begin0 and Ltmp15
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin0            ## >> Call Site 2 <<
	.uleb128 Ltmp16-Ltmp15                  ##   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin0            ##     jumps to Ltmp17
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin0            ## >> Call Site 3 <<
	.uleb128 Ltmp21-Ltmp16                  ##   Call between Ltmp16 and Ltmp21
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin0            ## >> Call Site 4 <<
	.uleb128 Ltmp22-Ltmp21                  ##   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin0            ##     jumps to Ltmp23
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin0            ## >> Call Site 5 <<
	.uleb128 Ltmp3-Ltmp22                   ##   Call between Ltmp22 and Ltmp3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ## >> Call Site 6 <<
	.uleb128 Ltmp4-Ltmp3                    ##   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ##     jumps to Ltmp5
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ## >> Call Site 7 <<
	.uleb128 Ltmp6-Ltmp4                    ##   Call between Ltmp4 and Ltmp6
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ## >> Call Site 8 <<
	.uleb128 Ltmp7-Ltmp6                    ##   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin0             ##     jumps to Ltmp8
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin0             ## >> Call Site 9 <<
	.uleb128 Ltmp24-Ltmp7                   ##   Call between Ltmp7 and Ltmp24
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin0            ## >> Call Site 10 <<
	.uleb128 Ltmp25-Ltmp24                  ##   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin0            ##     jumps to Ltmp26
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin0            ## >> Call Site 11 <<
	.uleb128 Ltmp9-Ltmp25                   ##   Call between Ltmp25 and Ltmp9
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ## >> Call Site 12 <<
	.uleb128 Ltmp10-Ltmp9                   ##   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin0            ##     jumps to Ltmp11
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin0            ## >> Call Site 13 <<
	.uleb128 Ltmp18-Ltmp10                  ##   Call between Ltmp10 and Ltmp18
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin0            ## >> Call Site 14 <<
	.uleb128 Ltmp19-Ltmp18                  ##   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin0            ##     jumps to Ltmp20
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin0            ## >> Call Site 15 <<
	.uleb128 Ltmp12-Ltmp19                  ##   Call between Ltmp19 and Ltmp12
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin0            ## >> Call Site 16 <<
	.uleb128 Ltmp13-Ltmp12                  ##   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin0            ##     jumps to Ltmp14
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin0            ## >> Call Site 17 <<
	.uleb128 Ltmp0-Ltmp13                   ##   Call between Ltmp13 and Ltmp0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ## >> Call Site 18 <<
	.uleb128 Ltmp1-Ltmp0                    ##   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ##     jumps to Ltmp2
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ## >> Call Site 19 <<
	.uleb128 Lfunc_end0-Ltmp1               ##   Call between Ltmp1 and Lfunc_end0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
__ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE: ## @_ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	subq	$128, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	xorps	%xmm0, %xmm0
	movaps	%xmm0, -48(%rbp)
	movaps	%xmm0, -64(%rbp)
	movaps	%xmm0, -80(%rbp)
	movl	$0, -32(%rbp)
	xorl	%eax, %eax
	jmp	LBB1_1
	.p2align	4
LBB1_11:                                ##   in Loop: Header=BB1_1 Depth=1
	addq	$2, %rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB1_12
LBB1_1:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%rax), %ecx
	cmpq	$13, %rcx
	jae	LBB1_2
## %bb.6:                               ##   in Loop: Header=BB1_1 Depth=1
	testq	%rcx, %rcx
	je	LBB1_8
## %bb.7:                               ##   in Loop: Header=BB1_1 Depth=1
	incl	-80(%rbp,%rcx,4)
LBB1_8:                                 ##   in Loop: Header=BB1_1 Depth=1
	movzbl	1(%rdi,%rax), %ecx
	cmpq	$12, %rcx
	ja	LBB1_2
## %bb.9:                               ##   in Loop: Header=BB1_1 Depth=1
	testq	%rcx, %rcx
	je	LBB1_11
## %bb.10:                              ##   in Loop: Header=BB1_1 Depth=1
	incl	-80(%rbp,%rcx,4)
	jmp	LBB1_11
LBB1_12:
	movl	-76(%rbp), %ecx
	cmpl	$2, %ecx
	ja	LBB1_13
## %bb.17:
	movl	$0, -128(%rbp)
	addl	%ecx, %ecx
	movl	-72(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$4, %eax
	ja	LBB1_13
## %bb.18:
	movl	%ecx, -124(%rbp)
	addl	%eax, %eax
	movl	-68(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$8, %ecx
	ja	LBB1_13
## %bb.19:
	movl	%eax, -120(%rbp)
	addl	%ecx, %ecx
	movl	-64(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$16, %eax
	ja	LBB1_13
## %bb.20:
	movl	%ecx, -116(%rbp)
	addl	%eax, %eax
	movl	-60(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$32, %ecx
	ja	LBB1_13
## %bb.21:
	movl	%eax, -112(%rbp)
	addl	%ecx, %ecx
	movl	-56(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$64, %eax
	ja	LBB1_13
## %bb.22:
	movl	%ecx, -108(%rbp)
	addl	%eax, %eax
	movl	-52(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$128, %ecx
	ja	LBB1_13
## %bb.23:
	movl	%eax, -104(%rbp)
	addl	%ecx, %ecx
	movl	-48(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$256, %eax                      ## imm = 0x100
	ja	LBB1_13
## %bb.24:
	movl	%ecx, -100(%rbp)
	addl	%eax, %eax
	movl	-44(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$512, %ecx                      ## imm = 0x200
	ja	LBB1_13
## %bb.25:
	movl	%eax, -96(%rbp)
	addl	%ecx, %ecx
	movl	-40(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$1024, %eax                     ## imm = 0x400
	ja	LBB1_13
## %bb.26:
	movl	%ecx, -92(%rbp)
	addl	%eax, %eax
	movl	-36(%rbp), %ecx
	addl	%eax, %ecx
	cmpl	$2048, %ecx                     ## imm = 0x800
	ja	LBB1_13
## %bb.27:
	movl	%eax, -88(%rbp)
	addl	%ecx, %ecx
	movl	-32(%rbp), %eax
	addl	%ecx, %eax
	cmpl	$4096, %eax                     ## imm = 0x1000
	ja	LBB1_13
## %bb.28:
	movl	%ecx, -84(%rbp)
	jne	LBB1_14
## %bb.29:
	xorl	%eax, %eax
	jmp	LBB1_30
	.p2align	4
LBB1_36:                                ##   in Loop: Header=BB1_30 Depth=1
	movw	%r9w, (%rsi,%rax,2)
LBB1_37:                                ##   in Loop: Header=BB1_30 Depth=1
	incq	%rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB1_38
LBB1_30:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_33 Depth 2
                                        ##     Child Loop BB1_35 Depth 2
	movzbl	(%rdi,%rax), %r8d
	testl	%r8d, %r8d
	je	LBB1_37
## %bb.31:                              ##   in Loop: Header=BB1_30 Depth=1
	movl	-132(%rbp,%r8,4), %ecx
	leal	1(%rcx), %edx
	movl	%edx, -132(%rbp,%r8,4)
	movl	%r8d, %edx
	andl	$3, %edx
	xorl	%r9d, %r9d
	cmpb	$4, %r8b
	jb	LBB1_35
## %bb.32:                              ##   in Loop: Header=BB1_30 Depth=1
	andl	$-4, %r8d
	xorl	%r9d, %r9d
	.p2align	4
LBB1_33:                                ##   Parent Loop BB1_30 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	andl	$16383, %r9d                    ## imm = 0x3FFF
	movl	%ecx, %r10d
	andl	$1, %r10d
	leal	(%r10,%r9,2), %r9d
	movl	%ecx, %r10d
	andl	$2, %r10d
	leal	(%r10,%r9,4), %r9d
	movl	%ecx, %r10d
	shrl	$2, %r10d
	andl	$1, %r10d
	orl	%r9d, %r10d
	movl	%ecx, %r9d
	shrl	$3, %r9d
	movzwl	%r10w, %r10d
	andl	$1, %r9d
	leal	(%r9,%r10,2), %r9d
	shrl	$4, %ecx
	addl	$-4, %r8d
	jne	LBB1_33
## %bb.34:                              ##   in Loop: Header=BB1_30 Depth=1
	testl	%edx, %edx
	je	LBB1_36
	.p2align	4
LBB1_35:                                ##   Parent Loop BB1_30 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	%r9w, %r8d
	movl	%ecx, %r9d
	andl	$1, %r9d
	leal	(%r9,%r8,2), %r9d
	shrl	%ecx
	decl	%edx
	jne	LBB1_35
	jmp	LBB1_36
LBB1_38:
	addq	$128, %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	retq
LBB1_2:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp27:                                 ## EH_LABEL
	leaq	L_.str.11(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ## EH_LABEL
LBB1_3:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB1_13:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp33:                                 ## EH_LABEL
	leaq	L_.str.12(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ## EH_LABEL
	jmp	LBB1_3
LBB1_14:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp30:                                 ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ## EH_LABEL
	jmp	LBB1_3
LBB1_15:
Ltmp32:                                 ## EH_LABEL
	jmp	LBB1_5
LBB1_16:
Ltmp35:                                 ## EH_LABEL
	jmp	LBB1_5
LBB1_4:
Ltmp29:                                 ## EH_LABEL
LBB1_5:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ## >> Call Site 1 <<
	.uleb128 Ltmp27-Lfunc_begin1            ##   Call between Lfunc_begin1 and Ltmp27
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin1            ## >> Call Site 2 <<
	.uleb128 Ltmp28-Ltmp27                  ##   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin1            ##     jumps to Ltmp29
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin1            ## >> Call Site 3 <<
	.uleb128 Ltmp33-Ltmp28                  ##   Call between Ltmp28 and Ltmp33
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin1            ## >> Call Site 4 <<
	.uleb128 Ltmp34-Ltmp33                  ##   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin1            ##     jumps to Ltmp35
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin1            ## >> Call Site 5 <<
	.uleb128 Ltmp30-Ltmp34                  ##   Call between Ltmp34 and Ltmp30
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin1            ## >> Call Site 6 <<
	.uleb128 Ltmp31-Ltmp30                  ##   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin1            ##     jumps to Ltmp32
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin1            ## >> Call Site 7 <<
	.uleb128 Lfunc_end1-Ltmp31              ##   Call between Ltmp31 and Lfunc_end1
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
LCPI2_0:
	.long	0                               ## 0x0
	.long	1                               ## 0x1
	.long	2                               ## 0x2
	.long	3                               ## 0x3
LCPI2_1:
	.long	32                              ## 0x20
	.long	32                              ## 0x20
	.long	32                              ## 0x20
	.long	32                              ## 0x20
LCPI2_2:
	.long	1065353216                      ## 0x3f800000
	.long	1065353216                      ## 0x3f800000
	.long	1065353216                      ## 0x3f800000
	.long	1065353216                      ## 0x3f800000
LCPI2_3:
	.long	8                               ## 0x8
	.long	8                               ## 0x8
	.long	8                               ## 0x8
	.long	8                               ## 0x8
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	4
__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ## @_ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$25896, %rsp                    ## imm = 0x6528
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)
	cmpq	$5, %rsi
	jb	LBB2_216
## %bb.1:
	cmpq	$2097160, %rcx                  ## imm = 0x200008
	ja	LBB2_216
## %bb.2:
	movq	%rdi, %r8
	movl	1(%rdi), %eax
	cmpq	%rax, %rcx
	jne	LBB2_216
## %bb.3:
	movzbl	(%r8), %eax
	cmpl	$36, %eax
	je	LBB2_14
## %bb.4:
	cmpl	$4, %eax
	je	LBB2_10
## %bb.5:
	testl	%eax, %eax
	jne	LBB2_218
## %bb.6:
	leaq	5(%rcx), %rax
	cmpq	%rax, %rsi
	jne	LBB2_220
## %bb.7:
	testq	%rcx, %rcx
	je	LBB2_72
## %bb.8:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB2_217
## %bb.9:
	addq	$5, %r8
	movq	%rdx, %rdi
	movq	%r8, %rsi
	movq	%rcx, %rdx
	addq	$25896, %rsp                    ## imm = 0x6528
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	_memcpy                         ## TAILCALL
LBB2_10:
	cmpq	$6, %rsi
	jne	LBB2_221
## %bb.11:
	testq	%rcx, %rcx
	je	LBB2_221
## %bb.12:
	movzbl	5(%r8), %esi
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB2_217
## %bb.13:
	movq	%rdx, %rdi
	movq	%rcx, %rdx
	addq	$25896, %rsp                    ## imm = 0x6528
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	_memset                         ## TAILCALL
LBB2_14:
	cmpq	$6, %rsi
	jbe	LBB2_218
## %bb.15:
	movq	%rcx, -488(%rbp)                ## 8-byte Spill
	movq	%rdx, -408(%rbp)                ## 8-byte Spill
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, -64(%rbp)
	movdqa	%xmm0, -80(%rbp)
	movdqa	%xmm0, -96(%rbp)
	movdqa	%xmm0, -112(%rbp)
	movdqa	%xmm0, -128(%rbp)
	movdqa	%xmm0, -144(%rbp)
	movdqa	%xmm0, -160(%rbp)
	movdqa	%xmm0, -176(%rbp)
	movdqa	%xmm0, -192(%rbp)
	movdqa	%xmm0, -208(%rbp)
	movdqa	%xmm0, -224(%rbp)
	movdqa	%xmm0, -240(%rbp)
	movdqa	%xmm0, -256(%rbp)
	movdqa	%xmm0, -272(%rbp)
	movdqa	%xmm0, -288(%rbp)
	movdqa	%xmm0, -304(%rbp)
	leaq	-1360(%rbp), %rdi
	movq	%rsi, %rbx
	movl	$512, %esi                      ## imm = 0x200
	movq	%r8, -336(%rbp)                 ## 8-byte Spill
	callq	___bzero
	movq	-336(%rbp), %rdi                ## 8-byte Reload
	movq	%rbx, -448(%rbp)                ## 8-byte Spill
	leaq	-5(%rbx), %r14
	xorl	%r13d, %r13d
	xorl	%r15d, %r15d
	xorl	%r8d, %r8d
	jmp	LBB2_17
	.p2align	4
LBB2_16:                                ##   in Loop: Header=BB2_17 Depth=1
	movb	%dl, -304(%rbp,%r15)
	incq	%r15
	movq	%rcx, %r8
	movl	%edx, %r13d
	cmpq	$256, %r15                      ## imm = 0x100
	jae	LBB2_27
LBB2_17:                                ## =>This Inner Loop Header: Depth=1
	movq	%r8, %rcx
	shrq	%rcx
	cmpq	%r14, %rcx
	jae	LBB2_211
## %bb.18:                              ##   in Loop: Header=BB2_17 Depth=1
	leal	(,%r8,4), %eax
	andb	$4, %al
	movzbl	5(%rdi,%rcx), %edx
	movl	%eax, %ecx
	shrb	%cl, %dl
	andb	$15, %dl
	leaq	1(%r8), %rcx
	cmpb	$12, %dl
	jbe	LBB2_16
## %bb.19:                              ##   in Loop: Header=BB2_17 Depth=1
	cmpb	$13, %dl
	je	LBB2_212
## %bb.20:                              ##   in Loop: Header=BB2_17 Depth=1
	movq	%rcx, %rsi
	shrq	%rsi
	cmpq	%r14, %rsi
	jae	LBB2_214
## %bb.21:                              ##   in Loop: Header=BB2_17 Depth=1
	shll	$2, %ecx
	movzbl	5(%rdi,%rsi), %r12d
	andb	$4, %cl
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r12
	andl	$15, %r12d
	leaq	2(%r8), %rbx
	cmpb	$15, %dl
	jne	LBB2_24
## %bb.22:                              ##   in Loop: Header=BB2_17 Depth=1
	shrq	%rbx
	cmpq	%r14, %rbx
	jae	LBB2_215
## %bb.23:                              ##   in Loop: Header=BB2_17 Depth=1
	movzbl	5(%rdi,%rbx), %edx
	movl	%eax, %ecx
	shrb	%cl, %dl
	addq	$3, %r8
	shlb	$4, %dl
	orb	%r12b, %dl
	movzbl	%dl, %r12d
	addq	$19, %r12
	movq	%r8, %rbx
	jmp	LBB2_25
	.p2align	4
LBB2_24:                                ##   in Loop: Header=BB2_17 Depth=1
	addq	$3, %r12
LBB2_25:                                ##   in Loop: Header=BB2_17 Depth=1
	movl	$256, %eax                      ## imm = 0x100
	subl	%r15d, %eax
	cmpl	%eax, %r12d
	ja	LBB2_213
## %bb.26:                              ##   in Loop: Header=BB2_17 Depth=1
	leaq	(%r15,%rbp), %rdi
	addq	$-304, %rdi                     ## imm = 0xFED0
	movzbl	%r13b, %esi
	movq	%r12, %rdx
	callq	_memset
	addq	%r12, %r15
	movq	%rbx, %r8
	movq	-336(%rbp), %rdi                ## 8-byte Reload
	cmpq	$256, %r15                      ## imm = 0x100
	jb	LBB2_17
LBB2_27:
	cmpq	$257, %r8                       ## imm = 0x101
	jae	LBB2_222
## %bb.28:
	testb	$1, %r8b
	movq	-488(%rbp), %r13                ## 8-byte Reload
	je	LBB2_30
## %bb.29:
	movq	%r8, %rax
	shrq	%rax
	cmpb	$16, 5(%rdi,%rax)
	jae	LBB2_224
LBB2_30:
	incq	%r8
	shrq	%r8
	leaq	5(%r8), %r14
	movq	%r8, -352(%rbp)                 ## 8-byte Spill
	leaq	17(%r8), %rax
	cmpq	$1025, %r13                     ## imm = 0x401
	movq	%rax, %rbx
	cmovbq	%r14, %rax
	cmpq	%rax, -448(%rbp)                ## 8-byte Folded Reload
	jb	LBB2_223
## %bb.31:
	leaq	-304(%rbp), %rdi
	leaq	-1360(%rbp), %rsi
	callq	__ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	leaq	-25936(%rbp), %rdi
	movl	$8192, %esi                     ## imm = 0x2000
	callq	___bzero
	xorl	%eax, %eax
	movq	-336(%rbp), %r8                 ## 8-byte Reload
	jmp	LBB2_33
	.p2align	4
LBB2_32:                                ##   in Loop: Header=BB2_33 Depth=1
	incq	%rax
	cmpq	$256, %rax                      ## imm = 0x100
	je	LBB2_37
LBB2_33:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_36 Depth 2
	movzbl	-304(%rbp,%rax), %ecx
	testq	%rcx, %rcx
	je	LBB2_32
## %bb.34:                              ##   in Loop: Header=BB2_33 Depth=1
	movzwl	-1360(%rbp,%rax,2), %edx
	cmpq	$4095, %rdx                     ## imm = 0xFFF
	ja	LBB2_32
## %bb.35:                              ##   in Loop: Header=BB2_33 Depth=1
	movl	%ecx, %esi
	shll	$8, %esi
	orl	%eax, %esi
	movl	$1, %edi
                                        ## kill: def $cl killed $cl killed $rcx
	shlq	%cl, %rdi
	.p2align	4
LBB2_36:                                ##   Parent Loop BB2_33 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movw	%si, -25936(%rbp,%rdx,2)
	addq	%rdi, %rdx
	cmpq	$4096, %rdx                     ## imm = 0x1000
	jb	LBB2_36
	jmp	LBB2_32
LBB2_37:
	cmpq	$1025, %r13                     ## imm = 0x401
	jae	LBB2_53
## %bb.38:
	movq	-448(%rbp), %rdx                ## 8-byte Reload
	subq	%r14, %rdx
	leaq	(%r8,%r14), %rsi
	movq	%rsi, -17744(%rbp)
	movq	%rdx, -17736(%rbp)
	testq	%r13, %r13
	movq	-408(%rbp), %rdi                ## 8-byte Reload
	je	LBB2_70
## %bb.39:
	movq	-352(%rbp), %rax                ## 8-byte Reload
	addq	%rax, %r8
	addq	$9, %r8
	xorl	%ebx, %ebx
	movdqa	LCPI2_0(%rip), %xmm0            ## xmm0 = [0,1,2,3]
	movdqa	LCPI2_1(%rip), %xmm1            ## xmm1 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm2            ## xmm2 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm3            ## xmm3 = [8,8,8,8]
	xorl	%r11d, %r11d
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	xorl	%r10d, %r10d
	jmp	LBB2_43
	.p2align	4
LBB2_40:                                ##   in Loop: Header=BB2_43 Depth=1
	movl	(%rsi,%rbx), %r12d
LBB2_41:                                ##   in Loop: Header=BB2_43 Depth=1
	movl	%r12d, %ebx
	movl	%eax, %ecx
	shlq	%cl, %rbx
	orq	%rbx, %r9
	orl	$32, %eax
	movq	%r10, %rbx
LBB2_42:                                ##   in Loop: Header=BB2_43 Depth=1
	movl	%r9d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movzwl	-25936(%rbp,%rcx,2), %ecx
	movb	%cl, (%rdi,%r11)
	shrl	$8, %ecx
	shrq	%cl, %r9
	subl	%ecx, %eax
	incq	%r11
	cmpq	%r13, %r11
	je	LBB2_71
LBB2_43:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_49 Depth 2
                                        ##     Child Loop BB2_52 Depth 2
	cmpl	$11, %eax
	ja	LBB2_42
## %bb.44:                              ##   in Loop: Header=BB2_43 Depth=1
	leaq	4(%rbx), %r10
	cmpq	%rdx, %r10
	jbe	LBB2_40
## %bb.45:                              ##   in Loop: Header=BB2_43 Depth=1
	xorl	%r12d, %r12d
	movq	%rdx, %r15
	subq	%rbx, %r15
	jbe	LBB2_41
## %bb.46:                              ##   in Loop: Header=BB2_43 Depth=1
	cmpq	$8, %r15
	jae	LBB2_48
## %bb.47:                              ##   in Loop: Header=BB2_43 Depth=1
	xorl	%ecx, %ecx
	xorl	%r12d, %r12d
	jmp	LBB2_51
LBB2_48:                                ##   in Loop: Header=BB2_43 Depth=1
	movq	%r15, %rcx
	andq	$-8, %rcx
	leaq	(%r8,%rbx), %r12
	pxor	%xmm4, %xmm4
	xorl	%r13d, %r13d
	pxor	%xmm5, %xmm5
	movdqa	%xmm0, %xmm6
LBB2_49:                                ##   Parent Loop BB2_43 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	pmovzxbd	-4(%r12,%r13), %xmm7            ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%r12,%r13), %xmm8              ## xmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm6, %xmm9
	pslld	$3, %xmm9
	paddd	%xmm1, %xmm9
	movdqa	%xmm6, %xmm10
	pslld	$26, %xmm10
	paddd	%xmm2, %xmm10
	cvttps2dq	%xmm10, %xmm10
	pmulld	%xmm7, %xmm10
	por	%xmm10, %xmm5
	pslld	$23, %xmm9
	paddd	%xmm2, %xmm9
	cvttps2dq	%xmm9, %xmm7
	pmulld	%xmm8, %xmm7
	por	%xmm7, %xmm4
	addq	$8, %r13
	paddd	%xmm3, %xmm6
	cmpq	%r13, %rcx
	jne	LBB2_49
## %bb.50:                              ##   in Loop: Header=BB2_43 Depth=1
	por	%xmm5, %xmm4
	pshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	por	%xmm4, %xmm5
	pshufd	$85, %xmm5, %xmm4               ## xmm4 = xmm5[1,1,1,1]
	por	%xmm5, %xmm4
	movd	%xmm4, %r12d
	cmpq	%rcx, %r15
	movq	-488(%rbp), %r13                ## 8-byte Reload
	je	LBB2_41
LBB2_51:                                ##   in Loop: Header=BB2_43 Depth=1
	addq	%r14, %rbx
	addq	%rcx, %rbx
	shll	$3, %ecx
LBB2_52:                                ##   Parent Loop BB2_43 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-336(%rbp), %r15                ## 8-byte Reload
	movzbl	(%r15,%rbx), %r15d
	shll	%cl, %r15d
	orl	%r15d, %r12d
	incq	%rbx
	addl	$8, %ecx
	cmpq	%rbx, -448(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_52
	jmp	LBB2_41
LBB2_53:
	leaq	-17744(%rbp), %rdi
	movl	$16384, %esi                    ## imm = 0x4000
	callq	___bzero
	movq	-336(%rbp), %r8                 ## 8-byte Reload
	xorl	%eax, %eax
	movq	-408(%rbp), %r9                 ## 8-byte Reload
	jmp	LBB2_56
	.p2align	4
LBB2_54:                                ##   in Loop: Header=BB2_56 Depth=1
	shll	$16, %ecx
	movl	$16777216, %edi                 ## imm = 0x1000000
	movl	%ecx, %esi
LBB2_55:                                ##   in Loop: Header=BB2_56 Depth=1
	movzbl	%dl, %ecx
	orl	%esi, %ecx
	orl	%edi, %ecx
	movl	%ecx, -17744(%rbp,%rax,4)
	incq	%rax
	cmpq	$4096, %rax                     ## imm = 0x1000
	je	LBB2_58
LBB2_56:                                ## =>This Inner Loop Header: Depth=1
	movzwl	-25936(%rbp,%rax,2), %edx
	movl	%edx, %ecx
	shrl	$8, %ecx
	movq	%rax, %rsi
	shrq	%cl, %rsi
	movzwl	-25936(%rbp,%rsi,2), %edi
	movl	%edi, %esi
	shrl	$8, %esi
	addl	%ecx, %esi
	cmpl	$12, %esi
	ja	LBB2_54
## %bb.57:                              ##   in Loop: Header=BB2_56 Depth=1
	shll	$8, %edi
	movzwl	%di, %ecx
	shll	$16, %esi
	orl	%ecx, %esi
	movl	$33554432, %edi                 ## imm = 0x2000000
	jmp	LBB2_55
LBB2_58:
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, -592(%rbp)
	movdqa	%xmm0, -608(%rbp)
	movdqa	%xmm0, -624(%rbp)
	movdqa	%xmm0, -640(%rbp)
	movdqa	%xmm0, -656(%rbp)
	movdqa	%xmm0, -672(%rbp)
	movdqa	%xmm0, -688(%rbp)
	movdqa	%xmm0, -704(%rbp)
	movdqa	%xmm0, -720(%rbp)
	movdqa	%xmm0, -736(%rbp)
	movdqa	%xmm0, -560(%rbp)
	movdqa	%xmm0, -576(%rbp)
	movq	-352(%rbp), %rax                ## 8-byte Reload
	movl	5(%r8,%rax), %esi
	movq	-448(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, %rax
	subq	%rbx, %rax
	movq	%rsi, -328(%rbp)                ## 8-byte Spill
	cmpq	%rsi, %rax
	jb	LBB2_219
## %bb.59:
	movq	%r13, %r11
	shrq	$2, %r11
	leaq	(%r8,%rbx), %rax
	movq	%rax, -464(%rbp)                ## 8-byte Spill
	movq	%rax, -736(%rbp)
	movq	-328(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -728(%rbp)
	addq	%rax, %rbx
	movq	%r9, -848(%rbp)
	movq	%r11, -840(%rbp)
	movl	4(%r8,%r14), %edi
	movq	%rcx, %rax
	subq	%rbx, %rax
	cmpq	%rdi, %rax
	jb	LBB2_219
## %bb.60:
	leaq	(%r8,%rbx), %rax
	movq	%rax, -456(%rbp)                ## 8-byte Spill
	movq	%rax, -696(%rbp)
	movq	%rdi, -688(%rbp)
	addq	%rdi, %rbx
	leaq	(%r9,%r11), %rax
	movq	%rax, -512(%rbp)                ## 8-byte Spill
	movq	%rax, -832(%rbp)
	movq	%r11, -824(%rbp)
	movl	8(%r8,%r14), %r14d
	movq	%rcx, %rax
	subq	%rbx, %rax
	cmpq	%r14, %rax
	movq	%rdi, -368(%rbp)                ## 8-byte Spill
	movq	%r14, -424(%rbp)                ## 8-byte Spill
	movq	%r11, -536(%rbp)                ## 8-byte Spill
	jb	LBB2_219
## %bb.61:
	leaq	(%r11,%r11,2), %rdx
	subq	%rdx, %r13
	leaq	(%r8,%rbx), %rax
	movq	%rax, -520(%rbp)                ## 8-byte Spill
	movq	%rax, -656(%rbp)
	movq	%r14, -648(%rbp)
	addq	%r14, %rbx
	leaq	(%r9,%r11,2), %rax
	movq	%rax, -496(%rbp)                ## 8-byte Spill
	movq	%rax, -816(%rbp)
	movq	%r11, -808(%rbp)
	subq	%rbx, %rcx
	addq	%r8, %rbx
	movq	%rbx, -528(%rbp)                ## 8-byte Spill
	movq	%rbx, -616(%rbp)
	cmpq	$-1, %r13
	cmoveq	%r13, %r13
	movq	%rcx, -472(%rbp)                ## 8-byte Spill
	movq	%rcx, -608(%rbp)
	addq	%r9, %rdx
	movq	%rdx, -504(%rbp)                ## 8-byte Spill
	movq	%rdx, -800(%rbp)
	movq	%r13, -792(%rbp)
	xorl	%r8d, %r8d
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	xorl	%r10d, %r10d
	xorl	%esi, %esi
	movq	$0, -320(%rbp)                  ## 8-byte Folded Spill
	movq	$0, -312(%rbp)                  ## 8-byte Folded Spill
	movq	$0, -344(%rbp)                  ## 8-byte Folded Spill
	movq	%r13, -488(%rbp)                ## 8-byte Spill
	.p2align	4
LBB2_62:                                ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rax
	subq	%r12, %rax
	cmpq	$8, %rax
	jb	LBB2_77
## %bb.63:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	%r11, %rax
	subq	%r15, %rax
	cmpq	$8, %rax
	jb	LBB2_77
## %bb.64:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	-488(%rbp), %rax                ## 8-byte Reload
	subq	%r8, %rax
	cmpq	$8, %rax
	jb	LBB2_77
## %bb.65:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	movq	%r9, %rax
	shrq	$3, %rax
	movq	-328(%rbp), %rcx                ## 8-byte Reload
	subq	%rax, %rcx
	cmpq	$8, %rcx
	jb	LBB2_77
## %bb.66:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	-320(%rbp), %rdx                ## 8-byte Reload
	shrq	$3, %rdx
	movq	%rdi, %rcx
	subq	%rdx, %rcx
	cmpq	$8, %rcx
	jb	LBB2_77
## %bb.67:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	%rsi, %r11
	shrq	$3, %rsi
	movq	%r14, %rcx
	subq	%rsi, %rcx
	cmpq	$8, %rcx
	jb	LBB2_76
## %bb.68:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	%r10, %rdi
	shrq	$3, %rdi
	movq	-472(%rbp), %rcx                ## 8-byte Reload
	subq	%rdi, %rcx
	cmpq	$8, %rcx
	jb	LBB2_75
## %bb.69:                              ##   in Loop: Header=BB2_62 Depth=1
	movq	-464(%rbp), %rcx                ## 8-byte Reload
	movq	(%rcx,%rax), %r14
	movl	%r9d, %ecx
	andb	$7, %cl
	shrq	%cl, %r14
	movq	-456(%rbp), %rax                ## 8-byte Reload
	movq	%r10, %r13
	movq	%r10, -400(%rbp)                ## 8-byte Spill
	movq	(%rax,%rdx), %r10
	movq	-320(%rbp), %rax                ## 8-byte Reload
	movl	%eax, %ecx
	andb	$7, %cl
	shrq	%cl, %r10
	movq	-520(%rbp), %rax                ## 8-byte Reload
	movq	(%rax,%rsi), %rax
	movq	%r11, -360(%rbp)                ## 8-byte Spill
	movl	%r11d, %ecx
	andb	$7, %cl
	shrq	%cl, %rax
	movq	%rax, %r11
	movq	%rax, -376(%rbp)                ## 8-byte Spill
	movq	-528(%rbp), %rax                ## 8-byte Reload
	movq	-344(%rbp), %rcx                ## 8-byte Reload
	movq	(%rax,%rdi), %rdx
	movl	%r14d, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %edi
	movq	-408(%rbp), %rax                ## 8-byte Reload
	movw	%di, (%rax,%rcx)
	movl	%edi, %eax
	shrl	$24, %edi
	addq	%rcx, %rdi
	movl	%r10d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %esi
	movq	-512(%rbp), %rcx                ## 8-byte Reload
	movw	%si, (%rcx,%r12)
	movq	%r9, -312(%rbp)                 ## 8-byte Spill
	movl	%esi, %r9d
	shrl	$24, %esi
	addq	%r12, %rsi
	movl	%r13d, %ecx
	andb	$7, %cl
	shrq	%cl, %rdx
	movl	%r11d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %r12d
	movq	-496(%rbp), %rcx                ## 8-byte Reload
	movw	%r12w, (%rcx,%r15)
	movl	%r12d, %r11d
	shrl	$24, %r12d
	addq	%r15, %r12
	movl	%edx, %ecx
	movq	%rdx, %rbx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %r15d
	movq	-504(%rbp), %rcx                ## 8-byte Reload
	movw	%r15w, (%rcx,%r8)
	movl	%r15d, %edx
	shrl	$24, %r15d
	addq	%r8, %r15
	shrl	$16, %eax
	movzbl	%al, %ecx
	movq	-312(%rbp), %rax                ## 8-byte Reload
	addq	%rcx, %rax
	movq	%rax, -344(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r14
	shrl	$16, %r9d
	movzbl	%r9b, %ecx
	movq	-320(%rbp), %rax                ## 8-byte Reload
	addq	%rcx, %rax
	movq	%rax, -320(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r10
	movl	%r14d, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %r8d
	movq	-408(%rbp), %rax                ## 8-byte Reload
	movw	%r8w, (%rax,%rdi)
	movl	%r8d, %r13d
	shrl	$24, %r8d
	addq	%rdi, %r8
	movl	%r10d, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %r9d
	movq	-512(%rbp), %rax                ## 8-byte Reload
	movw	%r9w, (%rax,%rsi)
	movl	%r9d, %edi
	shrl	$24, %r9d
	addq	%rsi, %r9
	shrl	$16, %r11d
	movzbl	%r11b, %ecx
	movq	-360(%rbp), %rax                ## 8-byte Reload
	addq	%rcx, %rax
	movq	%rax, -312(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	movq	-376(%rbp), %rsi                ## 8-byte Reload
	shrq	%cl, %rsi
	shrl	$16, %edx
	movzbl	%dl, %ecx
	movq	-400(%rbp), %rax                ## 8-byte Reload
	addq	%rcx, %rax
	movq	%rax, -376(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rbx
	movl	%esi, %eax
	movq	%rsi, %rdx
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %r11d
	movq	-496(%rbp), %rax                ## 8-byte Reload
	movw	%r11w, (%rax,%r12)
	movl	%r11d, -416(%rbp)               ## 4-byte Spill
	shrl	$24, %r11d
	addq	%r12, %r11
	movl	%ebx, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %r12d
	movq	-504(%rbp), %rax                ## 8-byte Reload
	movw	%r12w, (%rax,%r15)
	movl	%r12d, %eax
	shrl	$24, %r12d
	addq	%r15, %r12
	shrl	$16, %r13d
	movzbl	%r13b, %ecx
	movq	-344(%rbp), %rsi                ## 8-byte Reload
	addq	%rcx, %rsi
	movq	%rsi, -344(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r14
	shrl	$16, %edi
	movzbl	%dil, %ecx
	movq	-320(%rbp), %rsi                ## 8-byte Reload
	addq	%rcx, %rsi
	movq	%rsi, -320(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r10
	movl	%r14d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %edi
	movq	-408(%rbp), %rcx                ## 8-byte Reload
	movw	%di, (%rcx,%r8)
	movl	%edi, %r13d
	shrl	$24, %edi
	addq	%r8, %rdi
	movl	%r10d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %esi
	movq	-512(%rbp), %rcx                ## 8-byte Reload
	movw	%si, (%rcx,%r9)
	movl	%esi, %r15d
	shrl	$24, %esi
	addq	%r9, %rsi
	movl	-416(%rbp), %ecx                ## 4-byte Reload
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	movq	-312(%rbp), %r8                 ## 8-byte Reload
	addq	%rcx, %r8
	movq	%r8, -416(%rbp)                 ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdx
	shrl	$16, %eax
	movzbl	%al, %ecx
	movq	-376(%rbp), %rax                ## 8-byte Reload
	addq	%rcx, %rax
	movq	%rax, -376(%rbp)                ## 8-byte Spill
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rbx
	movl	%edx, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %r8d
	movq	-496(%rbp), %rax                ## 8-byte Reload
	movw	%r8w, (%rax,%r11)
	movl	%r8d, %eax
	shrl	$24, %r8d
	addq	%r11, %r8
	movl	%ebx, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %r9d
	movq	-504(%rbp), %rcx                ## 8-byte Reload
	movw	%r9w, (%rcx,%r12)
	movl	%r9d, %r11d
	shrl	$24, %r9d
	addq	%r12, %r9
	shrl	$16, %r13d
	movzbl	%r13b, %ecx
	movq	-344(%rbp), %r12                ## 8-byte Reload
	addq	%rcx, %r12
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r14
	shrl	$16, %r15d
	movzbl	%r15b, %ecx
	movq	-320(%rbp), %r15                ## 8-byte Reload
	leaq	(%rcx,%r15), %r13
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r10
	andl	$4095, %r14d                    ## imm = 0xFFF
	movl	-17744(%rbp,%r14,4), %r15d
	movq	-424(%rbp), %r14                ## 8-byte Reload
	movl	%r15d, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	addq	%r12, %rcx
	movq	%rcx, -312(%rbp)                ## 8-byte Spill
	shrl	$16, %eax
	movzbl	%al, %ecx
	movq	-416(%rbp), %rax                ## 8-byte Reload
	addq	%rcx, %rax
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdx
	movq	-408(%rbp), %rcx                ## 8-byte Reload
	movw	%r15w, (%rcx,%rdi)
	shrl	$24, %r15d
	addq	%rdi, %r15
	andl	$4095, %r10d                    ## imm = 0xFFF
	movl	-17744(%rbp,%r10,4), %r12d
	movl	%r12d, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	addq	%r13, %rcx
	movq	%rcx, -320(%rbp)                ## 8-byte Spill
	movq	%r15, %r13
	shrl	$16, %r11d
	movzbl	%r11b, %ecx
	movq	-536(%rbp), %r11                ## 8-byte Reload
	movq	-376(%rbp), %rdi                ## 8-byte Reload
	addq	%rcx, %rdi
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rbx
	movq	-512(%rbp), %rcx                ## 8-byte Reload
	movw	%r12w, (%rcx,%rsi)
	shrl	$24, %r12d
	addq	%rsi, %r12
	andl	$4095, %edx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rdx,4), %r15d
	movl	%r15d, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %esi
	addq	%rax, %rsi
	movq	-496(%rbp), %rax                ## 8-byte Reload
	movw	%r15w, (%rax,%r8)
	shrl	$24, %r15d
	addq	%r8, %r15
	andl	$4095, %ebx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rbx,4), %r8d
	movl	%r8d, %eax
	shrl	$16, %eax
	movzbl	%al, %r10d
	addq	%rdi, %r10
	movq	-504(%rbp), %rax                ## 8-byte Reload
	movw	%r8w, (%rax,%r9)
	shrl	$24, %r8d
	addq	%r9, %r8
	movq	%r11, %rax
	movq	%r13, -344(%rbp)                ## 8-byte Spill
	subq	%r13, %rax
	cmpq	$7, %rax
	movq	-368(%rbp), %rdi                ## 8-byte Reload
	ja	LBB2_62
	jmp	LBB2_77
LBB2_70:
	xorl	%eax, %eax
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
LBB2_71:
	movq	%r9, -17720(%rbp)
	movq	%r10, -17728(%rbp)
	movl	%eax, -17712(%rbp)
	leaq	-17744(%rbp), %rdi
	callq	__ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
LBB2_72:
	movq	___stack_chk_guard@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	cmpq	-48(%rbp), %rax
	jne	LBB2_217
## %bb.73:
	addq	$25896, %rsp                    ## imm = 0x6528
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB2_75:
	movq	-368(%rbp), %rdi                ## 8-byte Reload
LBB2_76:
	movq	%r11, %rsi
LBB2_77:
	movq	%rsi, -360(%rbp)                ## 8-byte Spill
	movq	%r10, -400(%rbp)                ## 8-byte Spill
	movq	%r12, -568(%rbp)
	movq	%r15, -560(%rbp)
	movq	%r8, -552(%rbp)
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	movq	%r9, %rax
	shrq	$3, %rax
	leaq	4(%rax), %r13
	cmpq	-328(%rbp), %r13                ## 8-byte Folded Reload
	ja	LBB2_179
## %bb.78:
	movq	-464(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%rax), %esi
LBB2_79:
	movl	%esi, %eax
	movl	%r9d, %ecx
	andb	$7, %cl
	shrq	%cl, %rax
	movq	%rax, -376(%rbp)                ## 8-byte Spill
	movq	-320(%rbp), %rax                ## 8-byte Reload
	shrq	$3, %rax
	leaq	4(%rax), %rcx
	movq	%rcx, -432(%rbp)                ## 8-byte Spill
	cmpq	%rdi, %rcx
	ja	LBB2_182
## %bb.80:
	movq	-456(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%rax), %esi
LBB2_81:
	movl	%esi, %eax
	movq	-320(%rbp), %rcx                ## 8-byte Reload
                                        ## kill: def $cl killed $cl killed $rcx
	andb	$7, %cl
	shrq	%cl, %rax
	movq	%rax, -416(%rbp)                ## 8-byte Spill
	movq	-360(%rbp), %rax                ## 8-byte Reload
	shrq	$3, %rax
	leaq	4(%rax), %rcx
	movq	%rcx, -480(%rbp)                ## 8-byte Spill
	cmpq	%r14, %rcx
	ja	LBB2_185
## %bb.82:
	movq	-520(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%rax), %esi
LBB2_83:
	andl	$7, %r9d
	movq	%r9, -312(%rbp)                 ## 8-byte Spill
	movq	-320(%rbp), %rax                ## 8-byte Reload
	andl	$7, %eax
	movq	%rax, -320(%rbp)                ## 8-byte Spill
	movl	%esi, %edx
	movq	-360(%rbp), %rcx                ## 8-byte Reload
	movl	%ecx, %eax
	andl	$7, %eax
	andb	$7, %cl
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %rdx
	movq	-400(%rbp), %rdi                ## 8-byte Reload
	shrq	$3, %rdi
	leaq	4(%rdi), %rsi
	movq	%rsi, -384(%rbp)                ## 8-byte Spill
	cmpq	-472(%rbp), %rsi                ## 8-byte Folded Reload
	movq	%rdx, -360(%rbp)                ## 8-byte Spill
	ja	LBB2_188
## %bb.84:
	movq	-528(%rbp), %rcx                ## 8-byte Reload
	movl	(%rcx,%rdi), %r11d
LBB2_85:
	movl	$32, %r14d
	subl	-312(%rbp), %r14d               ## 4-byte Folded Reload
	movl	$32, %esi
	subl	-320(%rbp), %esi                ## 4-byte Folded Reload
	movl	$32, %edi
	subl	%eax, %edi
	movl	%r11d, %r9d
	movq	-400(%rbp), %rcx                ## 8-byte Reload
	movl	%ecx, %eax
	andl	$7, %eax
	andb	$7, %cl
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r9
	movl	$32, %ecx
	subl	%eax, %ecx
	movl	%ecx, -312(%rbp)                ## 4-byte Spill
	movq	-536(%rbp), %rax                ## 8-byte Reload
	subq	-344(%rbp), %rax                ## 8-byte Folded Reload
	cmpq	$2, %rax
	jb	LBB2_143
## %bb.86:
	movq	%r9, -320(%rbp)                 ## 8-byte Spill
	movq	-336(%rbp), %rcx                ## 8-byte Reload
	movl	%edi, -400(%rbp)                ## 4-byte Spill
	movl	%r14d, -436(%rbp)               ## 4-byte Spill
	movq	-352(%rbp), %rdx                ## 8-byte Reload
	leaq	(%rcx,%rdx), %rax
	leaq	21(%rcx,%rdx), %r10
	movq	-328(%rbp), %r9                 ## 8-byte Reload
	leaq	21(%r9,%rax), %rcx
	movq	%rcx, -760(%rbp)                ## 8-byte Spill
	movq	-368(%rbp), %r11                ## 8-byte Reload
	leaq	(%r9,%r11), %rcx
	leaq	21(%rax,%rcx), %rdi
	movq	%rdi, -752(%rbp)                ## 8-byte Spill
	leaq	17(%rax,%rcx), %rax
	movq	%rax, -784(%rbp)                ## 8-byte Spill
	movq	-424(%rbp), %rax                ## 8-byte Reload
	leaq	(%r9,%rax), %rdi
	addq	%r11, %rdi
	movq	-536(%rbp), %r9                 ## 8-byte Reload
	movq	%r10, -768(%rbp)                ## 8-byte Spill
	addq	%r10, %rdi
	movq	%rdi, -744(%rbp)                ## 8-byte Spill
	addq	%rax, %rcx
	leaq	(%rdx,%rcx), %rax
	addq	$17, %rax
	movq	%rax, -776(%rbp)                ## 8-byte Spill
	movl	-436(%rbp), %r14d               ## 4-byte Reload
	movl	-400(%rbp), %edi                ## 4-byte Reload
	movdqa	LCPI2_0(%rip), %xmm0            ## xmm0 = [0,1,2,3]
	movdqa	LCPI2_1(%rip), %xmm1            ## xmm1 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm2            ## xmm2 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm3            ## xmm3 = [8,8,8,8]
	movq	-480(%rbp), %rbx                ## 8-byte Reload
	movq	-432(%rbp), %rdx                ## 8-byte Reload
	jmp	LBB2_89
	.p2align	4
LBB2_87:                                ##   in Loop: Header=BB2_89 Depth=1
	movq	-384(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -392(%rbp)                ## 8-byte Spill
LBB2_88:                                ##   in Loop: Header=BB2_89 Depth=1
	movzbl	-480(%rbp), %ecx                ## 1-byte Folded Reload
	subl	%ecx, %r14d
	movzbl	-436(%rbp), %ecx                ## 1-byte Folded Reload
	subl	%ecx, %esi
	addq	%rbx, %r12
	movzbl	%r10b, %ebx
	movl	%r11d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %r10d
	movl	%r10d, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	shrq	%cl, %r11
	movq	%r11, -320(%rbp)                ## 8-byte Spill
	subl	%ebx, %edi
	addq	%rax, %r15
	subl	%ecx, %r9d
	movl	%r9d, -312(%rbp)                ## 4-byte Spill
	movq	-504(%rbp), %rax                ## 8-byte Reload
	movw	%r10w, (%rax,%r8)
	shrl	$24, %r10d
	addq	%r10, %r8
	movq	-536(%rbp), %r9                 ## 8-byte Reload
	movq	%r9, %rax
	subq	-344(%rbp), %rax                ## 8-byte Folded Reload
	movq	-400(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, %r13
	movq	-432(%rbp), %r11                ## 8-byte Reload
	movq	%r11, %rbx
	movq	-352(%rbp), %r10                ## 8-byte Reload
	movq	%r10, %rdx
	cmpq	$1, %rax
	jbe	LBB2_145
LBB2_89:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_124 Depth 2
                                        ##     Child Loop BB2_127 Depth 2
                                        ##     Child Loop BB2_129 Depth 2
                                        ##     Child Loop BB2_132 Depth 2
                                        ##     Child Loop BB2_134 Depth 2
                                        ##     Child Loop BB2_137 Depth 2
                                        ##     Child Loop BB2_139 Depth 2
                                        ##     Child Loop BB2_142 Depth 2
	movq	%r9, %rax
	subq	%r12, %rax
	cmpq	$2, %rax
	jb	LBB2_144
## %bb.90:                              ##   in Loop: Header=BB2_89 Depth=1
	movq	%r9, %rax
	subq	%r15, %rax
	cmpq	$2, %rax
	jb	LBB2_144
## %bb.91:                              ##   in Loop: Header=BB2_89 Depth=1
	movq	-488(%rbp), %rax                ## 8-byte Reload
	subq	%r8, %rax
	cmpq	$2, %rax
	jb	LBB2_144
## %bb.92:                              ##   in Loop: Header=BB2_89 Depth=1
	cmpl	$11, %r14d
	ja	LBB2_96
## %bb.93:                              ##   in Loop: Header=BB2_89 Depth=1
	leaq	4(%r13), %rax
	cmpq	-328(%rbp), %rax                ## 8-byte Folded Reload
	movq	%rax, -400(%rbp)                ## 8-byte Spill
	ja	LBB2_111
## %bb.94:                              ##   in Loop: Header=BB2_89 Depth=1
	movq	-464(%rbp), %rax                ## 8-byte Reload
	movl	(%rax,%r13), %r9d
LBB2_95:                                ##   in Loop: Header=BB2_89 Depth=1
	movl	%r9d, %eax
	movl	%r14d, %ecx
	shlq	%cl, %rax
	movq	-376(%rbp), %r9                 ## 8-byte Reload
	orq	%rax, %r9
	orl	$32, %r14d
	jmp	LBB2_97
	.p2align	4
LBB2_96:                                ##   in Loop: Header=BB2_89 Depth=1
	movq	%r13, -400(%rbp)                ## 8-byte Spill
	movq	-376(%rbp), %r9                 ## 8-byte Reload
LBB2_97:                                ##   in Loop: Header=BB2_89 Depth=1
	movl	%r9d, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %r10d
	movl	%r10d, %ecx
	shrl	$16, %ecx
	movl	%ecx, -480(%rbp)                ## 4-byte Spill
                                        ## kill: def $cl killed $cl killed $ecx
	shrq	%cl, %r9
	movq	-408(%rbp), %rax                ## 8-byte Reload
	movq	-344(%rbp), %rcx                ## 8-byte Reload
	movw	%r10w, (%rax,%rcx)
	cmpl	$11, %esi
	movq	%r9, -376(%rbp)                 ## 8-byte Spill
	ja	LBB2_101
## %bb.98:                              ##   in Loop: Header=BB2_89 Depth=1
	leaq	4(%rdx), %rax
	cmpq	-368(%rbp), %rax                ## 8-byte Folded Reload
	movl	%esi, -432(%rbp)                ## 4-byte Spill
	movq	%rax, -352(%rbp)                ## 8-byte Spill
	ja	LBB2_114
## %bb.99:                              ##   in Loop: Header=BB2_89 Depth=1
	movq	-456(%rbp), %rax                ## 8-byte Reload
	movl	(%rax,%rdx), %esi
LBB2_100:                               ##   in Loop: Header=BB2_89 Depth=1
	movq	%rbx, %r11
	movq	-360(%rbp), %r13                ## 8-byte Reload
	movl	%esi, %eax
	movl	-432(%rbp), %esi                ## 4-byte Reload
	movl	%esi, %ecx
	shlq	%cl, %rax
	movq	-416(%rbp), %rdx                ## 8-byte Reload
	orq	%rax, %rdx
	orl	$32, %esi
	jmp	LBB2_102
	.p2align	4
LBB2_101:                               ##   in Loop: Header=BB2_89 Depth=1
	movq	%rbx, %r11
	movq	-360(%rbp), %r13                ## 8-byte Reload
	movq	%rdx, -352(%rbp)                ## 8-byte Spill
	movq	-416(%rbp), %rdx                ## 8-byte Reload
LBB2_102:                               ##   in Loop: Header=BB2_89 Depth=1
	movl	%edx, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %ebx
	movl	%ebx, %ecx
	shrl	$16, %ecx
	movl	%ecx, -436(%rbp)                ## 4-byte Spill
                                        ## kill: def $cl killed $cl killed $ecx
	shrq	%cl, %rdx
	movq	%rdx, -416(%rbp)                ## 8-byte Spill
	movq	-512(%rbp), %rax                ## 8-byte Reload
	movw	%bx, (%rax,%r12)
	cmpl	$11, %edi
	ja	LBB2_106
## %bb.103:                             ##   in Loop: Header=BB2_89 Depth=1
	leaq	4(%r11), %rax
	cmpq	-424(%rbp), %rax                ## 8-byte Folded Reload
	movq	%r13, %rdx
	movq	%rax, -432(%rbp)                ## 8-byte Spill
	ja	LBB2_117
## %bb.104:                             ##   in Loop: Header=BB2_89 Depth=1
	movq	-520(%rbp), %rax                ## 8-byte Reload
	movl	(%rax,%r11), %r13d
	movl	-312(%rbp), %r9d                ## 4-byte Reload
LBB2_105:                               ##   in Loop: Header=BB2_89 Depth=1
	movl	%r13d, %eax
	movl	%edi, %ecx
	shlq	%cl, %rax
	orq	%rax, %rdx
	orl	$32, %edi
	jmp	LBB2_107
	.p2align	4
LBB2_106:                               ##   in Loop: Header=BB2_89 Depth=1
	movq	%r11, -432(%rbp)                ## 8-byte Spill
	movq	%r13, %rdx
	movl	-312(%rbp), %r9d                ## 4-byte Reload
LBB2_107:                               ##   in Loop: Header=BB2_89 Depth=1
	shrl	$24, %r10d
	addq	%r10, -344(%rbp)                ## 8-byte Folded Spill
	movl	%edx, %eax
	andl	$4095, %eax                     ## imm = 0xFFF
	movl	-17744(%rbp,%rax,4), %eax
	movl	%eax, %r10d
	shrl	$16, %r10d
	movl	%r10d, %ecx
	shrq	%cl, %rdx
	shrl	$24, %ebx
	movq	-496(%rbp), %rcx                ## 8-byte Reload
	movw	%ax, (%rcx,%r15)
	shrl	$24, %eax
	cmpl	$11, %r9d
	movq	-320(%rbp), %r11                ## 8-byte Reload
	movq	%rdx, -360(%rbp)                ## 8-byte Spill
	ja	LBB2_87
## %bb.108:                             ##   in Loop: Header=BB2_89 Depth=1
	movq	-384(%rbp), %rcx                ## 8-byte Reload
	leaq	4(%rcx), %r11
	movq	%r11, -392(%rbp)                ## 8-byte Spill
	cmpq	-472(%rbp), %r11                ## 8-byte Folded Reload
	ja	LBB2_120
## %bb.109:                             ##   in Loop: Header=BB2_89 Depth=1
	movq	-528(%rbp), %r11                ## 8-byte Reload
	movl	(%r11,%rcx), %r13d
LBB2_110:                               ##   in Loop: Header=BB2_89 Depth=1
	movl	%r13d, %r13d
	movl	%r9d, %ecx
	shlq	%cl, %r13
	movq	-320(%rbp), %r11                ## 8-byte Reload
	orq	%r13, %r11
	orl	$32, %r9d
	movq	-392(%rbp), %rcx                ## 8-byte Reload
	movq	%rcx, -384(%rbp)                ## 8-byte Spill
	jmp	LBB2_88
LBB2_111:                               ##   in Loop: Header=BB2_89 Depth=1
	xorl	%r9d, %r9d
	movq	-328(%rbp), %rax                ## 8-byte Reload
	subq	%r13, %rax
	jbe	LBB2_95
## %bb.112:                             ##   in Loop: Header=BB2_89 Depth=1
	cmpq	$8, %rax
	jae	LBB2_123
## %bb.113:                             ##   in Loop: Header=BB2_89 Depth=1
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	jmp	LBB2_126
LBB2_114:                               ##   in Loop: Header=BB2_89 Depth=1
	xorl	%esi, %esi
	movq	-368(%rbp), %rax                ## 8-byte Reload
	subq	%rdx, %rax
	jbe	LBB2_100
## %bb.115:                             ##   in Loop: Header=BB2_89 Depth=1
	cmpq	$8, %rax
	jae	LBB2_128
## %bb.116:                             ##   in Loop: Header=BB2_89 Depth=1
	xorl	%ecx, %ecx
	xorl	%esi, %esi
	jmp	LBB2_131
LBB2_117:                               ##   in Loop: Header=BB2_89 Depth=1
	xorl	%r13d, %r13d
	movq	-424(%rbp), %rax                ## 8-byte Reload
	subq	%r11, %rax
	movl	-312(%rbp), %r9d                ## 4-byte Reload
	jbe	LBB2_105
## %bb.118:                             ##   in Loop: Header=BB2_89 Depth=1
	cmpq	$8, %rax
	movq	%rax, -544(%rbp)                ## 8-byte Spill
	jae	LBB2_133
## %bb.119:                             ##   in Loop: Header=BB2_89 Depth=1
	xorl	%r13d, %r13d
	xorl	%eax, %eax
	jmp	LBB2_136
LBB2_120:                               ##   in Loop: Header=BB2_89 Depth=1
	xorl	%r13d, %r13d
	movq	-472(%rbp), %r11                ## 8-byte Reload
	subq	%rcx, %r11
	jbe	LBB2_110
## %bb.121:                             ##   in Loop: Header=BB2_89 Depth=1
	cmpq	$8, %r11
	jae	LBB2_138
## %bb.122:                             ##   in Loop: Header=BB2_89 Depth=1
	xorl	%ecx, %ecx
	xorl	%r13d, %r13d
	movq	-384(%rbp), %r11                ## 8-byte Reload
	jmp	LBB2_141
LBB2_123:                               ##   in Loop: Header=BB2_89 Depth=1
	movq	%rbx, -480(%rbp)                ## 8-byte Spill
	movl	%eax, %ecx
	andl	$-8, %ecx
	movq	-768(%rbp), %r9                 ## 8-byte Reload
	addq	%r13, %r9
	pxor	%xmm4, %xmm4
	xorl	%r11d, %r11d
	pxor	%xmm5, %xmm5
	movdqa	%xmm0, %xmm6
LBB2_124:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	pmovzxbd	-4(%r9,%r11), %xmm7             ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%r9,%r11), %xmm8               ## xmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm6, %xmm9
	pslld	$3, %xmm9
	paddd	%xmm1, %xmm9
	movdqa	%xmm6, %xmm10
	pslld	$26, %xmm10
	paddd	%xmm2, %xmm10
	cvttps2dq	%xmm10, %xmm10
	pmulld	%xmm7, %xmm10
	por	%xmm10, %xmm5
	pslld	$23, %xmm9
	paddd	%xmm2, %xmm9
	cvttps2dq	%xmm9, %xmm7
	pmulld	%xmm8, %xmm7
	por	%xmm7, %xmm4
	addq	$8, %r11
	paddd	%xmm3, %xmm6
	cmpq	%r11, %rcx
	jne	LBB2_124
## %bb.125:                             ##   in Loop: Header=BB2_89 Depth=1
	por	%xmm5, %xmm4
	pshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	por	%xmm4, %xmm5
	pshufd	$85, %xmm5, %xmm4               ## xmm4 = xmm5[1,1,1,1]
	por	%xmm5, %xmm4
	movd	%xmm4, %r9d
	cmpl	%ecx, %eax
	movq	-480(%rbp), %rbx                ## 8-byte Reload
	je	LBB2_95
LBB2_126:                               ##   in Loop: Header=BB2_89 Depth=1
	addq	%rcx, %r13
	shll	$3, %ecx
LBB2_127:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-464(%rbp), %rax                ## 8-byte Reload
	movzbl	(%rax,%r13), %eax
	shll	%cl, %eax
	orl	%eax, %r9d
	incq	%r13
	addl	$8, %ecx
	cmpq	%r13, -328(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_127
	jmp	LBB2_95
LBB2_128:                               ##   in Loop: Header=BB2_89 Depth=1
	movl	%eax, %ecx
	andl	$-8, %ecx
	movq	-760(%rbp), %rsi                ## 8-byte Reload
	leaq	(%rsi,%rdx), %r9
	pxor	%xmm4, %xmm4
	xorl	%esi, %esi
	pxor	%xmm5, %xmm5
	movdqa	%xmm0, %xmm6
LBB2_129:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	pmovzxbd	-4(%r9,%rsi), %xmm7             ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%r9,%rsi), %xmm8               ## xmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm6, %xmm9
	pslld	$3, %xmm9
	paddd	%xmm1, %xmm9
	movdqa	%xmm6, %xmm10
	pslld	$26, %xmm10
	paddd	%xmm2, %xmm10
	cvttps2dq	%xmm10, %xmm10
	pmulld	%xmm7, %xmm10
	por	%xmm10, %xmm5
	pslld	$23, %xmm9
	paddd	%xmm2, %xmm9
	cvttps2dq	%xmm9, %xmm7
	pmulld	%xmm8, %xmm7
	por	%xmm7, %xmm4
	addq	$8, %rsi
	paddd	%xmm3, %xmm6
	cmpq	%rsi, %rcx
	jne	LBB2_129
## %bb.130:                             ##   in Loop: Header=BB2_89 Depth=1
	por	%xmm5, %xmm4
	pshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	por	%xmm4, %xmm5
	pshufd	$85, %xmm5, %xmm4               ## xmm4 = xmm5[1,1,1,1]
	por	%xmm5, %xmm4
	movd	%xmm4, %esi
	cmpl	%ecx, %eax
	je	LBB2_100
LBB2_131:                               ##   in Loop: Header=BB2_89 Depth=1
	addq	%rcx, %rdx
	shll	$3, %ecx
LBB2_132:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-456(%rbp), %rax                ## 8-byte Reload
	movzbl	(%rax,%rdx), %eax
	shll	%cl, %eax
	orl	%eax, %esi
	incq	%rdx
	addl	$8, %ecx
	cmpq	%rdx, -368(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_132
	jmp	LBB2_100
LBB2_133:                               ##   in Loop: Header=BB2_89 Depth=1
	movl	%eax, %r13d
	andl	$-8, %r13d
	movq	-752(%rbp), %rax                ## 8-byte Reload
	leaq	(%rax,%r11), %rcx
	movq	%r13, %rax
	pxor	%xmm4, %xmm4
	xorl	%r13d, %r13d
	pxor	%xmm5, %xmm5
	movdqa	%xmm0, %xmm6
LBB2_134:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	pmovzxbd	-4(%rcx,%r13), %xmm7            ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%rcx,%r13), %xmm8              ## xmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm6, %xmm9
	pslld	$3, %xmm9
	paddd	%xmm1, %xmm9
	movdqa	%xmm6, %xmm10
	pslld	$26, %xmm10
	paddd	%xmm2, %xmm10
	cvttps2dq	%xmm10, %xmm10
	pmulld	%xmm7, %xmm10
	por	%xmm10, %xmm5
	pslld	$23, %xmm9
	paddd	%xmm2, %xmm9
	cvttps2dq	%xmm9, %xmm7
	pmulld	%xmm8, %xmm7
	por	%xmm7, %xmm4
	addq	$8, %r13
	paddd	%xmm3, %xmm6
	cmpq	%r13, %rax
	jne	LBB2_134
## %bb.135:                             ##   in Loop: Header=BB2_89 Depth=1
	por	%xmm5, %xmm4
	pshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	por	%xmm4, %xmm5
	pshufd	$85, %xmm5, %xmm4               ## xmm4 = xmm5[1,1,1,1]
	por	%xmm5, %xmm4
	movd	%xmm4, %r13d
	cmpl	%eax, -544(%rbp)                ## 4-byte Folded Reload
	je	LBB2_105
LBB2_136:                               ##   in Loop: Header=BB2_89 Depth=1
	subq	%rax, -544(%rbp)                ## 8-byte Folded Spill
	leal	(,%rax,8), %ecx
	addq	%rax, %r11
	addq	-784(%rbp), %r11                ## 8-byte Folded Reload
	xorl	%eax, %eax
LBB2_137:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rax, -392(%rbp)                ## 8-byte Spill
	movq	-392(%rbp), %rax                ## 8-byte Reload
	movzbl	(%r11,%rax), %eax
	movl	%eax, -360(%rbp)                ## 4-byte Spill
	movq	-392(%rbp), %rax                ## 8-byte Reload
	shll	%cl, -360(%rbp)                 ## 4-byte Folded Spill
	orl	-360(%rbp), %r13d               ## 4-byte Folded Reload
	incq	%rax
	addl	$8, %ecx
	cmpq	%rax, -544(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_137
	jmp	LBB2_105
LBB2_138:                               ##   in Loop: Header=BB2_89 Depth=1
	movq	%r11, -312(%rbp)                ## 8-byte Spill
	movq	%r11, %r13
	andq	$-8, %r13
	movq	-384(%rbp), %rcx                ## 8-byte Reload
	movq	-744(%rbp), %r11                ## 8-byte Reload
	addq	%rcx, %r11
	movq	%r13, %rcx
	pxor	%xmm4, %xmm4
	xorl	%r13d, %r13d
	pxor	%xmm5, %xmm5
	movdqa	%xmm0, %xmm6
LBB2_139:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	pmovzxbd	-4(%r11,%r13), %xmm7            ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%r11,%r13), %xmm8              ## xmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm6, %xmm9
	pslld	$3, %xmm9
	paddd	%xmm1, %xmm9
	movdqa	%xmm6, %xmm10
	pslld	$26, %xmm10
	paddd	%xmm2, %xmm10
	cvttps2dq	%xmm10, %xmm10
	pmulld	%xmm7, %xmm10
	por	%xmm10, %xmm5
	pslld	$23, %xmm9
	paddd	%xmm2, %xmm9
	cvttps2dq	%xmm9, %xmm7
	pmulld	%xmm8, %xmm7
	por	%xmm7, %xmm4
	addq	$8, %r13
	paddd	%xmm3, %xmm6
	cmpq	%r13, %rcx
	jne	LBB2_139
## %bb.140:                             ##   in Loop: Header=BB2_89 Depth=1
	por	%xmm5, %xmm4
	pshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	por	%xmm4, %xmm5
	pshufd	$85, %xmm5, %xmm4               ## xmm4 = xmm5[1,1,1,1]
	por	%xmm5, %xmm4
	movd	%xmm4, %r13d
	cmpq	%rcx, -312(%rbp)                ## 8-byte Folded Reload
	movq	-384(%rbp), %r11                ## 8-byte Reload
	je	LBB2_110
LBB2_141:                               ##   in Loop: Header=BB2_89 Depth=1
	addq	-776(%rbp), %r11                ## 8-byte Folded Reload
	addq	%rcx, %r11
	shll	$3, %ecx
LBB2_142:                               ##   Parent Loop BB2_89 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	-336(%rbp), %rdx                ## 8-byte Reload
	movzbl	(%rdx,%r11), %edx
	movl	%edx, -312(%rbp)                ## 4-byte Spill
	shll	%cl, -312(%rbp)                 ## 4-byte Folded Spill
	orl	-312(%rbp), %r13d               ## 4-byte Folded Reload
	incq	%r11
	addl	$8, %ecx
	cmpq	%r11, -448(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_142
	jmp	LBB2_110
LBB2_143:
	movq	-376(%rbp), %r11                ## 8-byte Reload
	movq	-384(%rbp), %rcx                ## 8-byte Reload
	movq	-480(%rbp), %r8                 ## 8-byte Reload
	movq	-432(%rbp), %rdx                ## 8-byte Reload
	jmp	LBB2_146
LBB2_144:
	movq	%rdx, %r10
	movq	%rbx, %r11
	movq	%r13, %rcx
	movq	-384(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -392(%rbp)                ## 8-byte Spill
LBB2_145:
	movq	%r12, -568(%rbp)
	movq	%r15, -560(%rbp)
	movq	%r8, -552(%rbp)
	movq	%r10, %rdx
	movq	%r11, %r8
	movq	%rcx, %r13
	movq	-392(%rbp), %rcx                ## 8-byte Reload
	movq	-320(%rbp), %r9                 ## 8-byte Reload
	movq	-376(%rbp), %r11                ## 8-byte Reload
LBB2_146:
	movq	-344(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -576(%rbp)
	movq	-464(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -736(%rbp)
	movq	-328(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -728(%rbp)
	movq	%r13, -720(%rbp)
	movq	%r11, -712(%rbp)
	movl	%r14d, -704(%rbp)
	movq	-456(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -696(%rbp)
	movq	-368(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -688(%rbp)
	movq	%rdx, -680(%rbp)
	movq	-416(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -672(%rbp)
	movl	%esi, -664(%rbp)
	movq	-520(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -656(%rbp)
	movq	-424(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -648(%rbp)
	movq	%r8, -640(%rbp)
	movq	-360(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -632(%rbp)
	movl	%edi, -624(%rbp)
	movq	-528(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -616(%rbp)
	movq	-472(%rbp), %rax                ## 8-byte Reload
	movq	%rax, -608(%rbp)
	movq	%rcx, -600(%rbp)
	movq	%r9, -592(%rbp)
	movl	-312(%rbp), %eax                ## 4-byte Reload
	movl	%eax, -584(%rbp)
	xorl	%ebx, %ebx
	movdqa	LCPI2_1(%rip), %xmm6            ## xmm6 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm7            ## xmm7 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm8            ## xmm8 = [8,8,8,8]
	jmp	LBB2_150
	.p2align	4
LBB2_147:                               ##   in Loop: Header=BB2_150 Depth=1
	movq	24(%r8), %r10
LBB2_148:                               ##   in Loop: Header=BB2_150 Depth=1
	andl	$4095, %r10d                    ## imm = 0xFFF
	movzwl	-25936(%rbp,%r10,2), %ecx
	movq	(%r15), %rax
	movb	%cl, (%rax,%rdi)
	shrl	$8, %ecx
	shrq	%cl, 24(%r8)
	subl	%ecx, 32(%r8)
LBB2_149:                               ##   in Loop: Header=BB2_150 Depth=1
	leaq	-736(,%rdx,8), %rdi
	addq	%rbp, %rdi
	callq	__ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
	incq	%rbx
	cmpq	$4, %rbx
	movdqa	LCPI2_1(%rip), %xmm6            ## xmm6 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm7            ## xmm7 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm8            ## xmm8 = [8,8,8,8]
	je	LBB2_72
LBB2_150:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_155 Depth 2
                                        ##       Child Loop BB2_161 Depth 3
                                        ##       Child Loop BB2_164 Depth 3
                                        ##     Child Loop BB2_175 Depth 2
                                        ##     Child Loop BB2_178 Depth 2
	movq	%rbx, %rax
	shlq	$4, %rax
	leaq	(%rax,%rbp), %r15
	addq	$-848, %r15                     ## imm = 0xFCB0
	movq	-840(%rbp,%rax), %r8
	movq	-576(%rbp,%rbx,8), %rdi
	movq	%r8, %rax
	subq	%rdi, %rax
	leaq	(%rbx,%rbx,4), %rdx
	cmpq	$2, %rax
	jb	LBB2_166
## %bb.151:                             ##   in Loop: Header=BB2_150 Depth=1
	leaq	-736(,%rdx,8), %r9
	addq	%rbp, %r9
	movq	%r15, -336(%rbp)                ## 8-byte Spill
	movq	(%r15), %r11
	movl	-704(%rbp,%rdx,8), %eax
	movq	-712(%rbp,%rdx,8), %r10
	jmp	LBB2_155
	.p2align	4
LBB2_152:                               ##   in Loop: Header=BB2_155 Depth=2
	movq	(%r9), %rcx
	movl	(%rcx,%r15), %r13d
LBB2_153:                               ##   in Loop: Header=BB2_155 Depth=2
	movl	%r13d, %esi
	movl	%eax, %ecx
	shlq	%cl, %rsi
	orq	%rsi, %r10
	movq	%r14, 16(%r9)
	orl	$32, %eax
LBB2_154:                               ##   in Loop: Header=BB2_155 Depth=2
	movl	%r10d, %ecx
	andl	$4095, %ecx                     ## imm = 0xFFF
	movl	-17744(%rbp,%rcx,4), %esi
	movl	%esi, %ecx
	shrl	$16, %ecx
	movzbl	%cl, %ecx
	shrq	%cl, %r10
	subl	%ecx, %eax
	movw	%si, (%r11,%rdi)
	shrl	$24, %esi
	addq	%rsi, %rdi
	movq	%r8, %rcx
	subq	%rdi, %rcx
	cmpq	$1, %rcx
	jbe	LBB2_165
LBB2_155:                               ##   Parent Loop BB2_150 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB2_161 Depth 3
                                        ##       Child Loop BB2_164 Depth 3
	cmpl	$11, %eax
	ja	LBB2_154
## %bb.156:                             ##   in Loop: Header=BB2_155 Depth=2
	movq	8(%r9), %r12
	movq	16(%r9), %r15
	leaq	4(%r15), %r14
	cmpq	%r12, %r14
	jbe	LBB2_152
## %bb.157:                             ##   in Loop: Header=BB2_155 Depth=2
	xorl	%r13d, %r13d
	movq	%r12, %rcx
	subq	%r15, %rcx
	jbe	LBB2_153
## %bb.158:                             ##   in Loop: Header=BB2_155 Depth=2
	movq	(%r9), %rsi
	movq	%rsi, -344(%rbp)                ## 8-byte Spill
	cmpq	$8, %rcx
	jae	LBB2_160
## %bb.159:                             ##   in Loop: Header=BB2_155 Depth=2
	xorl	%ecx, %ecx
	xorl	%r13d, %r13d
	jmp	LBB2_163
LBB2_160:                               ##   in Loop: Header=BB2_155 Depth=2
	movq	%rcx, -408(%rbp)                ## 8-byte Spill
	andq	$-8, %rcx
	pxor	%xmm0, %xmm0
	xorl	%r13d, %r13d
	pxor	%xmm1, %xmm1
	movdqa	LCPI2_0(%rip), %xmm2            ## xmm2 = [0,1,2,3]
LBB2_161:                               ##   Parent Loop BB2_150 Depth=1
                                        ##     Parent Loop BB2_155 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	-344(%rbp), %rsi                ## 8-byte Reload
	addq	%r15, %rsi
	addq	$4, %rsi
	pmovzxbd	-4(%rsi,%r13), %xmm3            ## xmm3 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%rsi,%r13), %xmm4              ## xmm4 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm2, %xmm5
	pslld	$3, %xmm5
	paddd	%xmm6, %xmm5
	movdqa	%xmm2, %xmm6
	pslld	$26, %xmm6
	paddd	%xmm7, %xmm6
	cvttps2dq	%xmm6, %xmm6
	pmulld	%xmm3, %xmm6
	por	%xmm6, %xmm1
	movdqa	LCPI2_1(%rip), %xmm6            ## xmm6 = [32,32,32,32]
	pslld	$23, %xmm5
	paddd	%xmm7, %xmm5
	cvttps2dq	%xmm5, %xmm3
	pmulld	%xmm4, %xmm3
	por	%xmm3, %xmm0
	addq	$8, %r13
	paddd	%xmm8, %xmm2
	cmpq	%r13, %rcx
	jne	LBB2_161
## %bb.162:                             ##   in Loop: Header=BB2_155 Depth=2
	por	%xmm1, %xmm0
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	por	%xmm1, %xmm0
	movd	%xmm0, %r13d
	cmpq	%rcx, -408(%rbp)                ## 8-byte Folded Reload
	je	LBB2_153
LBB2_163:                               ##   in Loop: Header=BB2_155 Depth=2
	addq	%rcx, %r15
	shll	$3, %ecx
	.p2align	4
LBB2_164:                               ##   Parent Loop BB2_150 Depth=1
                                        ##     Parent Loop BB2_155 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	-344(%rbp), %rsi                ## 8-byte Reload
	movzbl	(%rsi,%r15), %esi
	shll	%cl, %esi
	orl	%esi, %r13d
	incq	%r15
	addl	$8, %ecx
	cmpq	%r15, %r12
	jne	LBB2_164
	jmp	LBB2_153
	.p2align	4
LBB2_165:                               ##   in Loop: Header=BB2_150 Depth=1
	movl	%eax, 32(%r9)
	movq	%r10, 24(%r9)
	movq	-336(%rbp), %r15                ## 8-byte Reload
LBB2_166:                               ##   in Loop: Header=BB2_150 Depth=1
	movq	%rdi, -576(%rbp,%rbx,8)
	cmpq	%r8, %rdi
	jae	LBB2_149
## %bb.167:                             ##   in Loop: Header=BB2_150 Depth=1
	leaq	-736(,%rdx,8), %r8
	addq	%rbp, %r8
	movl	-704(%rbp,%rdx,8), %eax
	cmpq	$12, %rax
	jae	LBB2_147
## %bb.168:                             ##   in Loop: Header=BB2_150 Depth=1
	movq	8(%r8), %r11
	movq	16(%r8), %r10
	leaq	4(%r10), %r9
	cmpq	%r11, %r9
	ja	LBB2_171
## %bb.169:                             ##   in Loop: Header=BB2_150 Depth=1
	movq	(%r8), %rcx
	movl	(%rcx,%r10), %r12d
LBB2_170:                               ##   in Loop: Header=BB2_150 Depth=1
	movl	%r12d, %r10d
	movl	%eax, %ecx
	shlq	%cl, %r10
	orq	24(%r8), %r10
	movq	%r10, 24(%r8)
	movq	%r9, 16(%r8)
	addl	$32, %eax
	movl	%eax, 32(%r8)
	jmp	LBB2_148
LBB2_171:                               ##   in Loop: Header=BB2_150 Depth=1
	xorl	%r12d, %r12d
	movq	%r11, %rsi
	subq	%r10, %rsi
	jbe	LBB2_170
## %bb.172:                             ##   in Loop: Header=BB2_150 Depth=1
	movq	(%r8), %r14
	cmpq	$8, %rsi
	jae	LBB2_174
## %bb.173:                             ##   in Loop: Header=BB2_150 Depth=1
	xorl	%ecx, %ecx
	xorl	%r12d, %r12d
	jmp	LBB2_177
LBB2_174:                               ##   in Loop: Header=BB2_150 Depth=1
	movq	%rsi, %rcx
	andq	$-8, %rcx
	leaq	(%r14,%r10), %r12
	addq	$4, %r12
	pxor	%xmm0, %xmm0
	xorl	%r13d, %r13d
	pxor	%xmm1, %xmm1
	movdqa	LCPI2_0(%rip), %xmm2            ## xmm2 = [0,1,2,3]
	movdqa	LCPI2_1(%rip), %xmm7            ## xmm7 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm8            ## xmm8 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm9            ## xmm9 = [8,8,8,8]
LBB2_175:                               ##   Parent Loop BB2_150 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	pmovzxbd	-4(%r12,%r13), %xmm3            ## xmm3 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%r12,%r13), %xmm4              ## xmm4 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm2, %xmm5
	pslld	$3, %xmm5
	paddd	%xmm7, %xmm5
	movdqa	%xmm2, %xmm6
	pslld	$26, %xmm6
	paddd	%xmm8, %xmm6
	cvttps2dq	%xmm6, %xmm6
	pmulld	%xmm3, %xmm6
	por	%xmm6, %xmm1
	pslld	$23, %xmm5
	paddd	%xmm8, %xmm5
	cvttps2dq	%xmm5, %xmm3
	pmulld	%xmm4, %xmm3
	por	%xmm3, %xmm0
	addq	$8, %r13
	paddd	%xmm9, %xmm2
	cmpq	%r13, %rcx
	jne	LBB2_175
## %bb.176:                             ##   in Loop: Header=BB2_150 Depth=1
	por	%xmm1, %xmm0
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	por	%xmm1, %xmm0
	movd	%xmm0, %r12d
	cmpq	%rcx, %rsi
	je	LBB2_170
LBB2_177:                               ##   in Loop: Header=BB2_150 Depth=1
	addq	%rcx, %r10
	shll	$3, %ecx
LBB2_178:                               ##   Parent Loop BB2_150 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r14,%r10), %esi
	shll	%cl, %esi
	orl	%esi, %r12d
	incq	%r10
	addl	$8, %ecx
	cmpq	%r10, %r11
	jne	LBB2_178
	jmp	LBB2_170
LBB2_179:
	xorl	%esi, %esi
	movq	-328(%rbp), %rdx                ## 8-byte Reload
	subq	%rax, %rdx
	jbe	LBB2_79
## %bb.180:
	movq	%rdi, %r9
	cmpq	$8, %rdx
	jae	LBB2_191
## %bb.181:
	xorl	%ecx, %ecx
	xorl	%esi, %esi
	movq	%r9, %rdi
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	jmp	LBB2_194
LBB2_182:
	xorl	%esi, %esi
	movq	%rdi, %rdx
	subq	%rax, %rdx
	jbe	LBB2_81
## %bb.183:
	movq	%rdi, %r9
	cmpq	$8, %rdx
	jae	LBB2_196
## %bb.184:
	xorl	%ecx, %ecx
	xorl	%esi, %esi
	movq	%r9, %rdi
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	jmp	LBB2_199
LBB2_185:
	xorl	%esi, %esi
	movq	%r14, %rcx
	subq	%rax, %rcx
	jbe	LBB2_83
## %bb.186:
	cmpq	$8, %rcx
	jae	LBB2_201
## %bb.187:
	xorl	%edx, %edx
	xorl	%esi, %esi
	jmp	LBB2_204
LBB2_188:
	xorl	%r11d, %r11d
	movq	-472(%rbp), %r9                 ## 8-byte Reload
	subq	%rdi, %r9
	jbe	LBB2_85
## %bb.189:
	cmpq	$8, %r9
	jae	LBB2_206
## %bb.190:
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	jmp	LBB2_209
LBB2_191:
	movl	%edx, %ecx
	andl	$-8, %ecx
	movq	-336(%rbp), %rsi                ## 8-byte Reload
	addq	%rax, %rsi
	movq	-352(%rbp), %rdi                ## 8-byte Reload
	addq	%rdi, %rsi
	addq	$21, %rsi
	movdqa	LCPI2_0(%rip), %xmm1            ## xmm1 = [0,1,2,3]
	pxor	%xmm0, %xmm0
	xorl	%edi, %edi
	movdqa	LCPI2_1(%rip), %xmm2            ## xmm2 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm3            ## xmm3 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm5            ## xmm5 = [8,8,8,8]
	pxor	%xmm4, %xmm4
LBB2_192:                               ## =>This Inner Loop Header: Depth=1
	pmovzxbd	-4(%rsi,%rdi), %xmm6            ## xmm6 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%rsi,%rdi), %xmm7              ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm1, %xmm8
	pslld	$3, %xmm8
	paddd	%xmm2, %xmm8
	movdqa	%xmm1, %xmm9
	pslld	$26, %xmm9
	paddd	%xmm3, %xmm9
	cvttps2dq	%xmm9, %xmm9
	pmulld	%xmm6, %xmm9
	por	%xmm9, %xmm4
	pslld	$23, %xmm8
	paddd	%xmm3, %xmm8
	cvttps2dq	%xmm8, %xmm6
	pmulld	%xmm7, %xmm6
	por	%xmm6, %xmm0
	addq	$8, %rdi
	paddd	%xmm5, %xmm1
	cmpq	%rdi, %rcx
	jne	LBB2_192
## %bb.193:
	por	%xmm4, %xmm0
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	por	%xmm1, %xmm0
	movd	%xmm0, %esi
	cmpl	%ecx, %edx
	movq	%r9, %rdi
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	je	LBB2_79
LBB2_194:
	addq	%rcx, %rax
	shll	$3, %ecx
LBB2_195:                               ## =>This Inner Loop Header: Depth=1
	movq	-464(%rbp), %rdx                ## 8-byte Reload
	movzbl	(%rdx,%rax), %edx
	shll	%cl, %edx
	orl	%edx, %esi
	incq	%rax
	addl	$8, %ecx
	cmpq	%rax, -328(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_195
	jmp	LBB2_79
LBB2_196:
	movl	%edx, %ecx
	andl	$-8, %ecx
	movq	-328(%rbp), %rsi                ## 8-byte Reload
	addq	%rax, %rsi
	addq	-336(%rbp), %rsi                ## 8-byte Folded Reload
	movq	-352(%rbp), %rdi                ## 8-byte Reload
	addq	%rdi, %rsi
	addq	$21, %rsi
	movdqa	LCPI2_0(%rip), %xmm1            ## xmm1 = [0,1,2,3]
	pxor	%xmm0, %xmm0
	xorl	%edi, %edi
	movdqa	LCPI2_1(%rip), %xmm2            ## xmm2 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm3            ## xmm3 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm5            ## xmm5 = [8,8,8,8]
	pxor	%xmm4, %xmm4
LBB2_197:                               ## =>This Inner Loop Header: Depth=1
	pmovzxbd	-4(%rsi,%rdi), %xmm6            ## xmm6 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%rsi,%rdi), %xmm7              ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm1, %xmm8
	pslld	$3, %xmm8
	paddd	%xmm2, %xmm8
	movdqa	%xmm1, %xmm9
	pslld	$26, %xmm9
	paddd	%xmm3, %xmm9
	cvttps2dq	%xmm9, %xmm9
	pmulld	%xmm6, %xmm9
	por	%xmm9, %xmm4
	pslld	$23, %xmm8
	paddd	%xmm3, %xmm8
	cvttps2dq	%xmm8, %xmm6
	pmulld	%xmm7, %xmm6
	por	%xmm6, %xmm0
	addq	$8, %rdi
	paddd	%xmm5, %xmm1
	cmpq	%rdi, %rcx
	jne	LBB2_197
## %bb.198:
	por	%xmm4, %xmm0
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	por	%xmm1, %xmm0
	movd	%xmm0, %esi
	cmpl	%ecx, %edx
	movq	%r9, %rdi
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	je	LBB2_81
LBB2_199:
	addq	%rcx, %rax
	shll	$3, %ecx
LBB2_200:                               ## =>This Inner Loop Header: Depth=1
	movq	-456(%rbp), %rdx                ## 8-byte Reload
	movzbl	(%rdx,%rax), %edx
	shll	%cl, %edx
	orl	%edx, %esi
	incq	%rax
	addl	$8, %ecx
	cmpq	%rax, %rdi
	jne	LBB2_200
	jmp	LBB2_81
LBB2_201:
	movl	%ecx, %edx
	andl	$-8, %edx
	movq	-328(%rbp), %rsi                ## 8-byte Reload
	addq	%rax, %rsi
	movq	-336(%rbp), %rdi                ## 8-byte Reload
	movq	-368(%rbp), %r9                 ## 8-byte Reload
	addq	%r9, %rdi
	addq	%rsi, %rdi
	movq	-352(%rbp), %rsi                ## 8-byte Reload
	addq	%rdi, %rsi
	addq	$21, %rsi
	movdqa	LCPI2_0(%rip), %xmm1            ## xmm1 = [0,1,2,3]
	pxor	%xmm0, %xmm0
	xorl	%edi, %edi
	movdqa	LCPI2_1(%rip), %xmm2            ## xmm2 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm3            ## xmm3 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm5            ## xmm5 = [8,8,8,8]
	pxor	%xmm4, %xmm4
LBB2_202:                               ## =>This Inner Loop Header: Depth=1
	pmovzxbd	-4(%rsi,%rdi), %xmm6            ## xmm6 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%rsi,%rdi), %xmm7              ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm1, %xmm8
	pslld	$3, %xmm8
	paddd	%xmm2, %xmm8
	movdqa	%xmm1, %xmm9
	pslld	$26, %xmm9
	paddd	%xmm3, %xmm9
	cvttps2dq	%xmm9, %xmm9
	pmulld	%xmm6, %xmm9
	por	%xmm9, %xmm4
	pslld	$23, %xmm8
	paddd	%xmm3, %xmm8
	cvttps2dq	%xmm8, %xmm6
	pmulld	%xmm7, %xmm6
	por	%xmm6, %xmm0
	addq	$8, %rdi
	paddd	%xmm5, %xmm1
	cmpq	%rdi, %rdx
	jne	LBB2_202
## %bb.203:
	por	%xmm4, %xmm0
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	por	%xmm1, %xmm0
	movd	%xmm0, %esi
	cmpl	%edx, %ecx
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	je	LBB2_83
LBB2_204:
	movq	%r14, %rdi
	subq	%rdx, %rdi
	subq	%rax, %rdi
	leal	(,%rdx,8), %ecx
	addq	%rax, %rdx
	movq	-328(%rbp), %rax                ## 8-byte Reload
	movq	-368(%rbp), %r9                 ## 8-byte Reload
	addq	%r9, %rax
	addq	%rax, %rdx
	addq	-336(%rbp), %rdx                ## 8-byte Folded Reload
	movq	-352(%rbp), %rax                ## 8-byte Reload
	addq	%rdx, %rax
	addq	$17, %rax
	xorl	%edx, %edx
LBB2_205:                               ## =>This Inner Loop Header: Depth=1
	movzbl	(%rax,%rdx), %r9d
	shll	%cl, %r9d
	orl	%r9d, %esi
	movq	-312(%rbp), %r9                 ## 8-byte Reload
	incq	%rdx
	addl	$8, %ecx
	cmpq	%rdx, %rdi
	jne	LBB2_205
	jmp	LBB2_83
LBB2_206:
	movq	%r9, %rcx
	andq	$-8, %rcx
	movq	-328(%rbp), %rdx                ## 8-byte Reload
	leaq	(%rdi,%rdx), %r11
	movq	-368(%rbp), %rdx                ## 8-byte Reload
	movq	-424(%rbp), %rbx                ## 8-byte Reload
	addq	%rdx, %rbx
	addq	-336(%rbp), %rbx                ## 8-byte Folded Reload
	addq	%r11, %rbx
	movq	-352(%rbp), %rdx                ## 8-byte Reload
	leaq	(%rdx,%rbx), %r11
	addq	$21, %r11
	movdqa	LCPI2_0(%rip), %xmm1            ## xmm1 = [0,1,2,3]
	pxor	%xmm0, %xmm0
	xorl	%r14d, %r14d
	movdqa	LCPI2_1(%rip), %xmm2            ## xmm2 = [32,32,32,32]
	movdqa	LCPI2_2(%rip), %xmm3            ## xmm3 = [1065353216,1065353216,1065353216,1065353216]
	movdqa	LCPI2_3(%rip), %xmm5            ## xmm5 = [8,8,8,8]
	pxor	%xmm4, %xmm4
LBB2_207:                               ## =>This Inner Loop Header: Depth=1
	pmovzxbd	-4(%r11,%r14), %xmm6            ## xmm6 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	pmovzxbd	(%r11,%r14), %xmm7              ## xmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero
	movdqa	%xmm1, %xmm8
	pslld	$3, %xmm8
	paddd	%xmm2, %xmm8
	movdqa	%xmm1, %xmm9
	pslld	$26, %xmm9
	paddd	%xmm3, %xmm9
	cvttps2dq	%xmm9, %xmm9
	pmulld	%xmm6, %xmm9
	por	%xmm9, %xmm4
	pslld	$23, %xmm8
	paddd	%xmm3, %xmm8
	cvttps2dq	%xmm8, %xmm6
	pmulld	%xmm7, %xmm6
	por	%xmm6, %xmm0
	addq	$8, %r14
	paddd	%xmm5, %xmm1
	cmpq	%r14, %rcx
	jne	LBB2_207
## %bb.208:
	por	%xmm4, %xmm0
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	por	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	por	%xmm1, %xmm0
	movd	%xmm0, %r11d
	cmpq	%rcx, %r9
	je	LBB2_85
LBB2_209:
	addq	%rcx, %rdi
	movq	-328(%rbp), %r9                 ## 8-byte Reload
	movq	-368(%rbp), %rbx                ## 8-byte Reload
	addq	%rbx, %r9
	addq	%r9, %rdi
	addq	-424(%rbp), %rdi                ## 8-byte Folded Reload
	movq	-352(%rbp), %r9                 ## 8-byte Reload
	addq	%r9, %rdi
	addq	$17, %rdi
	shll	$3, %ecx
LBB2_210:                               ## =>This Inner Loop Header: Depth=1
	movq	-336(%rbp), %r9                 ## 8-byte Reload
	movzbl	(%r9,%rdi), %r9d
	shll	%cl, %r9d
	orl	%r9d, %r11d
	incq	%rdi
	addl	$8, %ecx
	cmpq	%rdi, -448(%rbp)                ## 8-byte Folded Reload
	jne	LBB2_210
	jmp	LBB2_85
LBB2_211:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp39:                                 ## EH_LABEL
	leaq	L_.str.19(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_212:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp51:                                 ## EH_LABEL
	leaq	L_.str.15(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_213:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp48:                                 ## EH_LABEL
	leaq	L_.str.16(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_214:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp42:                                 ## EH_LABEL
	leaq	L_.str.19(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_215:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp45:                                 ## EH_LABEL
	leaq	L_.str.19(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_216:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp36:                                 ## EH_LABEL
	leaq	L_.str.1(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_217:
	callq	___stack_chk_fail
LBB2_218:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp72:                                 ## EH_LABEL
	leaq	L_.str.4(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp73:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_219:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp60:                                 ## EH_LABEL
	leaq	L_.str.6(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_220:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp69:                                 ## EH_LABEL
	leaq	L_.str.2(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp70:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_221:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp66:                                 ## EH_LABEL
	leaq	L_.str.3(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_222:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp54:                                 ## EH_LABEL
	leaq	L_.str.17(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_223:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp63:                                 ## EH_LABEL
	leaq	L_.str.5(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ## EH_LABEL
	jmp	LBB2_225
LBB2_224:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp57:                                 ## EH_LABEL
	leaq	L_.str.18(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ## EH_LABEL
LBB2_225:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB2_226:
Ltmp59:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_227:
Ltmp65:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_228:
Ltmp56:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_229:
Ltmp68:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_230:
Ltmp71:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_231:
Ltmp62:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_232:
Ltmp74:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_233:
Ltmp38:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_234:
Ltmp47:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_235:
Ltmp44:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_236:
Ltmp50:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_237:
Ltmp53:                                 ## EH_LABEL
	jmp	LBB2_239
LBB2_238:
Ltmp41:                                 ## EH_LABEL
LBB2_239:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ## >> Call Site 1 <<
	.uleb128 Ltmp39-Lfunc_begin2            ##   Call between Lfunc_begin2 and Ltmp39
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin2            ## >> Call Site 2 <<
	.uleb128 Ltmp40-Ltmp39                  ##   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin2            ##     jumps to Ltmp41
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin2            ## >> Call Site 3 <<
	.uleb128 Ltmp51-Ltmp40                  ##   Call between Ltmp40 and Ltmp51
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin2            ## >> Call Site 4 <<
	.uleb128 Ltmp52-Ltmp51                  ##   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin2            ##     jumps to Ltmp53
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin2            ## >> Call Site 5 <<
	.uleb128 Ltmp48-Ltmp52                  ##   Call between Ltmp52 and Ltmp48
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin2            ## >> Call Site 6 <<
	.uleb128 Ltmp49-Ltmp48                  ##   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin2            ##     jumps to Ltmp50
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin2            ## >> Call Site 7 <<
	.uleb128 Ltmp42-Ltmp49                  ##   Call between Ltmp49 and Ltmp42
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin2            ## >> Call Site 8 <<
	.uleb128 Ltmp43-Ltmp42                  ##   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin2            ##     jumps to Ltmp44
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin2            ## >> Call Site 9 <<
	.uleb128 Ltmp45-Ltmp43                  ##   Call between Ltmp43 and Ltmp45
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin2            ## >> Call Site 10 <<
	.uleb128 Ltmp46-Ltmp45                  ##   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin2            ##     jumps to Ltmp47
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin2            ## >> Call Site 11 <<
	.uleb128 Ltmp36-Ltmp46                  ##   Call between Ltmp46 and Ltmp36
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin2            ## >> Call Site 12 <<
	.uleb128 Ltmp37-Ltmp36                  ##   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin2            ##     jumps to Ltmp38
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin2            ## >> Call Site 13 <<
	.uleb128 Ltmp72-Ltmp37                  ##   Call between Ltmp37 and Ltmp72
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp72-Lfunc_begin2            ## >> Call Site 14 <<
	.uleb128 Ltmp73-Ltmp72                  ##   Call between Ltmp72 and Ltmp73
	.uleb128 Ltmp74-Lfunc_begin2            ##     jumps to Ltmp74
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp73-Lfunc_begin2            ## >> Call Site 15 <<
	.uleb128 Ltmp60-Ltmp73                  ##   Call between Ltmp73 and Ltmp60
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin2            ## >> Call Site 16 <<
	.uleb128 Ltmp61-Ltmp60                  ##   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin2            ##     jumps to Ltmp62
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin2            ## >> Call Site 17 <<
	.uleb128 Ltmp69-Ltmp61                  ##   Call between Ltmp61 and Ltmp69
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp69-Lfunc_begin2            ## >> Call Site 18 <<
	.uleb128 Ltmp70-Ltmp69                  ##   Call between Ltmp69 and Ltmp70
	.uleb128 Ltmp71-Lfunc_begin2            ##     jumps to Ltmp71
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp70-Lfunc_begin2            ## >> Call Site 19 <<
	.uleb128 Ltmp66-Ltmp70                  ##   Call between Ltmp70 and Ltmp66
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin2            ## >> Call Site 20 <<
	.uleb128 Ltmp67-Ltmp66                  ##   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin2            ##     jumps to Ltmp68
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin2            ## >> Call Site 21 <<
	.uleb128 Ltmp54-Ltmp67                  ##   Call between Ltmp67 and Ltmp54
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin2            ## >> Call Site 22 <<
	.uleb128 Ltmp55-Ltmp54                  ##   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin2            ##     jumps to Ltmp56
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin2            ## >> Call Site 23 <<
	.uleb128 Ltmp63-Ltmp55                  ##   Call between Ltmp55 and Ltmp63
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin2            ## >> Call Site 24 <<
	.uleb128 Ltmp64-Ltmp63                  ##   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin2            ##     jumps to Ltmp65
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin2            ## >> Call Site 25 <<
	.uleb128 Ltmp57-Ltmp64                  ##   Call between Ltmp64 and Ltmp57
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin2            ## >> Call Site 26 <<
	.uleb128 Ltmp58-Ltmp57                  ##   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin2            ##     jumps to Ltmp59
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin2            ## >> Call Site 27 <<
	.uleb128 Lfunc_end2-Ltmp58              ##   Call between Ltmp58 and Lfunc_end2
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
__ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv: ## @_ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception3
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	16(%rdi), %rcx
	shlq	$3, %rcx
	movl	32(%rdi), %eax
	subq	%rax, %rcx
	leaq	7(%rcx), %rax
	shrq	$3, %rax
	cmpq	8(%rdi), %rax
	jne	LBB3_1
## %bb.5:
	andq	$7, %rcx
	je	LBB3_9
## %bb.6:
	movq	(%rdi), %rdx
	movzbl	-1(%rdx,%rax), %eax
                                        ## kill: def $cl killed $cl killed $rcx
	shrl	%cl, %eax
	testl	%eax, %eax
	jne	LBB3_7
LBB3_9:
	popq	%rbx
	popq	%r14
	popq	%rbp
	retq
LBB3_1:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp75:                                 ## EH_LABEL
	leaq	L_.str.20(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp76:                                 ## EH_LABEL
	jmp	LBB3_2
LBB3_7:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp78:                                 ## EH_LABEL
	leaq	L_.str.21(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp79:                                 ## EH_LABEL
LBB3_2:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB3_8:
Ltmp80:                                 ## EH_LABEL
	jmp	LBB3_4
LBB3_3:
Ltmp77:                                 ## EH_LABEL
LBB3_4:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception3:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3      ## >> Call Site 1 <<
	.uleb128 Ltmp75-Lfunc_begin3            ##   Call between Lfunc_begin3 and Ltmp75
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp75-Lfunc_begin3            ## >> Call Site 2 <<
	.uleb128 Ltmp76-Ltmp75                  ##   Call between Ltmp75 and Ltmp76
	.uleb128 Ltmp77-Lfunc_begin3            ##     jumps to Ltmp77
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp76-Lfunc_begin3            ## >> Call Site 3 <<
	.uleb128 Ltmp78-Ltmp76                  ##   Call between Ltmp76 and Ltmp78
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp78-Lfunc_begin3            ## >> Call Site 4 <<
	.uleb128 Ltmp79-Ltmp78                  ##   Call between Ltmp78 and Ltmp79
	.uleb128 Ltmp80-Lfunc_begin3            ##     jumps to Ltmp80
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp79-Lfunc_begin3            ## >> Call Site 5 <<
	.uleb128 Lfunc_end3-Ltmp79              ##   Call between Ltmp79 and Lfunc_end3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end3:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE ## -- Begin function _ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.weak_def_can_be_hidden	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.p2align	4
__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE: ## @_ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception4
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$16392, %rsp                    ## imm = 0x4008
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %rbx
	movl	%edx, %r13d
	leaq	-257(%rsi), %rdx
	movl	$1, %eax
	movl	%r13d, %ecx
	shll	%cl, %eax
	cmpq	$-255, %rdx
	jb	LBB4_3
## %bb.1:
	leal	-13(%r13), %ecx
	cmpl	$-12, %ecx
	jb	LBB4_3
## %bb.2:
	movq	%rsi, %r14
	cmpq	%rax, %rsi
	ja	LBB4_3
## %bb.7:
	movq	%rdi, %r15
	leaq	-4144(%rbp), %rdi
	movl	$4096, %esi                     ## imm = 0x1000
	callq	___bzero
	leaq	-16432(%rbp), %r12
	movl	$12288, %esi                    ## imm = 0x3000
	movq	%r12, %rdi
	callq	___bzero
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 240(%rbx)
	movdqu	%xmm0, 224(%rbx)
	movdqu	%xmm0, 208(%rbx)
	movdqu	%xmm0, 192(%rbx)
	movdqu	%xmm0, 176(%rbx)
	movdqu	%xmm0, 160(%rbx)
	movdqu	%xmm0, 144(%rbx)
	movdqu	%xmm0, 128(%rbx)
	movdqu	%xmm0, 112(%rbx)
	movdqu	%xmm0, 96(%rbx)
	movdqu	%xmm0, 80(%rbx)
	movdqu	%xmm0, 64(%rbx)
	movdqu	%xmm0, 48(%rbx)
	movdqu	%xmm0, 32(%rbx)
	movdqu	%xmm0, 16(%rbx)
	movdqu	%xmm0, (%rbx)
	cmpq	$4, %r14
	ja	LBB4_18
## %bb.8:
	xorl	%eax, %eax
	jmp	LBB4_9
LBB4_18:
	movl	%r14d, %eax
	andl	$3, %eax
	movl	$4, %ecx
	cmovneq	%rax, %rcx
	movq	%r14, %rax
	subq	%rcx, %rax
	xorl	%ecx, %ecx
	.p2align	4
LBB4_19:                                ## =>This Inner Loop Header: Depth=1
	movups	(%r15,%rcx,8), %xmm0
	movups	16(%r15,%rcx,8), %xmm1
	shufps	$136, %xmm1, %xmm0              ## xmm0 = xmm0[0,2],xmm1[0,2]
	movups	%xmm0, -4144(%rbp,%rcx,4)
	movdqu	(%r15,%rcx,8), %xmm0
	pshufd	$85, %xmm0, %xmm0               ## xmm0 = xmm0[1,1,1,1]
	pinsrw	$1, 12(%r15,%rcx,8), %xmm0
	pinsrw	$2, 20(%r15,%rcx,8), %xmm0
	pinsrw	$3, 28(%r15,%rcx,8), %xmm0
	movq	%xmm0, -16432(%rbp,%rcx,2)
	addq	$4, %rcx
	cmpq	%rcx, %rax
	jne	LBB4_19
	.p2align	4
LBB4_9:                                 ## =>This Inner Loop Header: Depth=1
	movl	(%r15,%rax,8), %ecx
	movl	%ecx, -4144(%rbp,%rax,4)
	movzwl	4(%r15,%rax,8), %ecx
	movw	%cx, -16432(%rbp,%rax,2)
	incq	%rax
	cmpq	%rax, %r14
	jne	LBB4_9
## %bb.10:
	movl	%r13d, %r9d
	cmpl	$2, %r13d
	jb	LBB4_26
## %bb.11:
	movl	$1, %ecx
	leaq	-15408(%rbp), %rdx
	movq	%r14, %rsi
	movq	%r9, -48(%rbp)                  ## 8-byte Spill
	jmp	LBB4_12
	.p2align	4
LBB4_23:                                ##   in Loop: Header=BB4_12 Depth=1
	incq	%rcx
	addq	$1024, %rdx                     ## imm = 0x400
	movq	-48(%rbp), %r9                  ## 8-byte Reload
	cmpq	%r9, %rcx
	je	LBB4_24
LBB4_12:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB4_13 Depth 2
	movl	%ecx, %eax
	andl	$1, %eax
	shll	$11, %eax
	leaq	(%rax,%rbp), %rdi
	addq	$-4144, %rdi                    ## imm = 0xEFD0
	movl	%ecx, %eax
	notl	%eax
	andl	$1, %eax
	shll	$11, %eax
	leaq	(%rax,%rbp), %r8
	addq	$-4144, %r8                     ## imm = 0xEFD0
	movq	%rsi, %r9
	shrq	%r9
	setne	%al
	movb	$1, %r13b
	xorl	%esi, %esi
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	jmp	LBB4_13
	.p2align	4
LBB4_21:                                ##   in Loop: Header=BB4_13 Depth=2
	movl	%r12d, (%rdi,%rsi,4)
	leal	256(,%r10,2), %eax
	movw	%ax, (%rdx,%rsi,2)
	incq	%r10
LBB4_22:                                ##   in Loop: Header=BB4_13 Depth=2
	incq	%rsi
	cmpq	%r14, %r11
	setb	%r13b
	cmpq	%r9, %r10
	setb	%al
	movl	%r13d, %r12d
	orb	%al, %r12b
	je	LBB4_23
LBB4_13:                                ##   Parent Loop BB4_12 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	xorl	%r12d, %r12d
	testb	$1, %al
	je	LBB4_15
## %bb.14:                              ##   in Loop: Header=BB4_13 Depth=2
	movl	4(%r8,%r10,8), %r12d
	addl	(%r8,%r10,8), %r12d
	testb	$1, %r13b
	je	LBB4_15
## %bb.20:                              ##   in Loop: Header=BB4_13 Depth=2
	movl	(%r15,%r11,8), %eax
	cmpl	%r12d, %eax
	ja	LBB4_21
	jmp	LBB4_17
	.p2align	4
LBB4_15:                                ##   in Loop: Header=BB4_13 Depth=2
	cmpq	%r9, %r10
	jne	LBB4_21
## %bb.16:                              ##   in Loop: Header=BB4_13 Depth=2
	movl	(%r15,%r11,8), %eax
LBB4_17:                                ##   in Loop: Header=BB4_13 Depth=2
	movl	%eax, (%rdi,%rsi,4)
	movzwl	4(%r15,%r11,8), %eax
	movw	%ax, (%rdx,%rsi,2)
	incq	%r11
	jmp	LBB4_22
LBB4_26:
	leaq	-2(,%r14,2), %rdi
	cmpq	%r14, %rdi
	jbe	LBB4_27
LBB4_25:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp81:                                 ## EH_LABEL
	leaq	L_.str.10(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp82:                                 ## EH_LABEL
	jmp	LBB4_4
LBB4_24:
	leaq	-2(,%r14,2), %rdi
	cmpq	%rsi, %rdi
	leaq	-16432(%rbp), %r12
	ja	LBB4_25
LBB4_27:
	movq	%r9, %rax
	shlq	$10, %rax
	leaq	(%rax,%r12), %rcx
	addq	$-1024, %rcx                    ## imm = 0xFC00
	jmp	LBB4_28
LBB4_33:                                ##   in Loop: Header=BB4_28 Depth=1
	incb	(%rbx,%rax)
LBB4_34:                                ##   in Loop: Header=BB4_28 Depth=1
	addq	%rdx, %rdx
LBB4_35:                                ##   in Loop: Header=BB4_28 Depth=1
	decq	%r9
	addq	$-1024, %rcx                    ## imm = 0xFC00
	movq	%rdx, %rdi
	testl	%r9d, %r9d
	je	LBB4_36
LBB4_28:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB4_38 Depth 2
	testq	%rdi, %rdi
	je	LBB4_29
## %bb.37:                              ##   in Loop: Header=BB4_28 Depth=1
	movq	%rdi, %r8
	andq	$-2, %r8
	xorl	%esi, %esi
	xorl	%edx, %edx
	jmp	LBB4_38
	.p2align	4
LBB4_43:                                ##   in Loop: Header=BB4_38 Depth=2
	incb	(%rbx,%rax)
	addq	$2, %rsi
	cmpq	%rsi, %r8
	je	LBB4_30
LBB4_38:                                ##   Parent Loop BB4_28 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%rcx,%rsi,2), %eax
	cmpq	$255, %rax
	ja	LBB4_40
## %bb.39:                              ##   in Loop: Header=BB4_38 Depth=2
	incb	(%rbx,%rax)
	movzwl	2(%rcx,%rsi,2), %eax
	cmpq	$256, %rax                      ## imm = 0x100
	jb	LBB4_43
	jmp	LBB4_42
	.p2align	4
LBB4_40:                                ##   in Loop: Header=BB4_38 Depth=2
	incq	%rdx
	movzwl	2(%rcx,%rsi,2), %eax
	cmpq	$256, %rax                      ## imm = 0x100
	jb	LBB4_43
LBB4_42:                                ##   in Loop: Header=BB4_38 Depth=2
	incq	%rdx
	addq	$2, %rsi
	cmpq	%rsi, %r8
	jne	LBB4_38
LBB4_30:                                ##   in Loop: Header=BB4_28 Depth=1
	testb	$1, %dil
	je	LBB4_34
## %bb.31:                              ##   in Loop: Header=BB4_28 Depth=1
	movzwl	(%rcx,%rsi,2), %eax
	cmpq	$256, %rax                      ## imm = 0x100
	jb	LBB4_33
## %bb.32:                              ##   in Loop: Header=BB4_28 Depth=1
	incq	%rdx
	jmp	LBB4_34
	.p2align	4
LBB4_29:                                ##   in Loop: Header=BB4_28 Depth=1
	xorl	%edx, %edx
	jmp	LBB4_35
LBB4_36:
	addq	$16392, %rsp                    ## imm = 0x4008
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB4_3:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp84:                                 ## EH_LABEL
	leaq	L_.str.9(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp85:                                 ## EH_LABEL
LBB4_4:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB4_45:
Ltmp83:                                 ## EH_LABEL
	jmp	LBB4_6
LBB4_5:
Ltmp86:                                 ## EH_LABEL
LBB4_6:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end4:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table4:
Lexception4:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end4-Lcst_begin4
Lcst_begin4:
	.uleb128 Lfunc_begin4-Lfunc_begin4      ## >> Call Site 1 <<
	.uleb128 Ltmp81-Lfunc_begin4            ##   Call between Lfunc_begin4 and Ltmp81
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp81-Lfunc_begin4            ## >> Call Site 2 <<
	.uleb128 Ltmp82-Ltmp81                  ##   Call between Ltmp81 and Ltmp82
	.uleb128 Ltmp83-Lfunc_begin4            ##     jumps to Ltmp83
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp82-Lfunc_begin4            ## >> Call Site 3 <<
	.uleb128 Ltmp84-Ltmp82                  ##   Call between Ltmp82 and Ltmp84
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp84-Lfunc_begin4            ## >> Call Site 4 <<
	.uleb128 Ltmp85-Ltmp84                  ##   Call between Ltmp84 and Ltmp85
	.uleb128 Ltmp86-Lfunc_begin4            ##     jumps to Ltmp86
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp85-Lfunc_begin4            ## >> Call Site 5 <<
	.uleb128 Lfunc_end4-Ltmp85              ##   Call between Ltmp85 and Lfunc_end4
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end4:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb: ## @_ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%ecx, -44(%rbp)                 ## 4-byte Spill
	movq	%rdx, %r12
	movq	%rsi, %r15
	movq	%rdi, %rbx
LBB5_1:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB5_2 Depth 2
                                        ##       Child Loop BB5_116 Depth 3
                                        ##       Child Loop BB5_119 Depth 3
                                        ##       Child Loop BB5_122 Depth 3
                                        ##       Child Loop BB5_123 Depth 3
                                        ##         Child Loop BB5_125 Depth 4
                                        ##         Child Loop BB5_126 Depth 4
                                        ##       Child Loop BB5_131 Depth 3
                                        ##       Child Loop BB5_137 Depth 3
                                        ##       Child Loop BB5_134 Depth 3
                                        ##       Child Loop BB5_140 Depth 3
                                        ##         Child Loop BB5_141 Depth 4
                                        ##         Child Loop BB5_142 Depth 4
	leaq	-8(%r15), %rax
	movq	%rax, -56(%rbp)                 ## 8-byte Spill
	leaq	-16(%r15), %rax
	movq	%rax, -88(%rbp)                 ## 8-byte Spill
	leaq	-24(%r15), %rax
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
LBB5_2:                                 ##   Parent Loop BB5_1 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB5_116 Depth 3
                                        ##       Child Loop BB5_119 Depth 3
                                        ##       Child Loop BB5_122 Depth 3
                                        ##       Child Loop BB5_123 Depth 3
                                        ##         Child Loop BB5_125 Depth 4
                                        ##         Child Loop BB5_126 Depth 4
                                        ##       Child Loop BB5_131 Depth 3
                                        ##       Child Loop BB5_137 Depth 3
                                        ##       Child Loop BB5_134 Depth 3
                                        ##       Child Loop BB5_140 Depth 3
                                        ##         Child Loop BB5_141 Depth 4
                                        ##         Child Loop BB5_142 Depth 4
	movq	%rbx, %r13
	movq	%r15, %rcx
	subq	%rbx, %rcx
	sarq	$3, %rcx
	cmpq	$5, %rcx
	jbe	LBB5_3
## %bb.21:                              ##   in Loop: Header=BB5_2 Depth=2
	cmpq	$23, %rcx
	jle	LBB5_22
## %bb.38:                              ##   in Loop: Header=BB5_2 Depth=2
	testq	%r12, %r12
	je	LBB5_39
## %bb.70:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	%rcx, %rax
	andq	$-2, %rax
	leaq	(,%rax,4), %rax
	addq	%r13, %rax
	movl	-8(%r15), %edx
	movzwl	-4(%r15), %esi
	cmpq	$129, %rcx
	jb	LBB5_104
## %bb.71:                              ##   in Loop: Header=BB5_2 Depth=2
	movl	(%rax), %ecx
	movzwl	4(%rax), %edi
	xorl	%r8d, %r8d
	cmpw	4(%r13), %di
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	(%r13), %ecx
	setb	%r9b
	cmovel	%r8d, %r9d
	xorl	%r8d, %r8d
	cmpw	%di, %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	%ecx, %edx
	setb	%sil
	cmovel	%r8d, %esi
	testb	%r9b, %r9b
	je	LBB5_72
## %bb.75:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rcx
	testb	%sil, %sil
	je	LBB5_77
## %bb.76:                              ##   in Loop: Header=BB5_2 Depth=2
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%r13)
	movl	(%rsi), %edx
	movl	%edx, (%r13)
	movq	%rcx, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%rsi)
	movl	%ecx, (%rsi)
	jmp	LBB5_79
	.p2align	4
LBB5_104:                               ##   in Loop: Header=BB5_2 Depth=2
	movl	(%r13), %ecx
	movzwl	4(%r13), %edi
	xorl	%r8d, %r8d
	cmpw	4(%rax), %di
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	(%rax), %ecx
	setb	%r9b
	cmovel	%r8d, %r9d
	xorl	%r8d, %r8d
	cmpw	%di, %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	%ecx, %edx
	setb	%sil
	cmovel	%r8d, %esi
	testb	%r9b, %r9b
	je	LBB5_105
## %bb.108:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rax), %rcx
	testb	%sil, %sil
	je	LBB5_110
## %bb.109:                             ##   in Loop: Header=BB5_2 Depth=2
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movq	%rcx, %rax
	shrq	$32, %rax
	movw	%ax, 4(%rsi)
	movl	%ecx, (%rsi)
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	je	LBB5_113
	jmp	LBB5_130
LBB5_72:                                ##   in Loop: Header=BB5_2 Depth=2
	testb	%sil, %sil
	je	LBB5_79
## %bb.73:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rax), %rcx
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	movl	(%rax), %ecx
	movzwl	4(%rax), %edx
	xorl	%esi, %esi
	cmpw	4(%r13), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r13), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB5_79
## %bb.74:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movl	%ecx, (%rax)
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	jmp	LBB5_79
LBB5_105:                               ##   in Loop: Header=BB5_2 Depth=2
	testb	%sil, %sil
	je	LBB5_112
## %bb.106:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rcx
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%r13)
	movl	(%rsi), %edx
	movl	%edx, (%r13)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	movl	(%r13), %ecx
	movzwl	4(%r13), %edx
	xorl	%esi, %esi
	cmpw	4(%rax), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%rax), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB5_112
## %bb.107:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rax), %rcx
	movzwl	4(%r13), %edx
	movw	%dx, 4(%rax)
	movl	(%r13), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%r13)
	shrq	$32, %rcx
	movw	%cx, 4(%r13)
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	je	LBB5_113
	jmp	LBB5_130
LBB5_77:                                ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movq	%rcx, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%rax)
	movl	%ecx, (%rax)
	xorl	%esi, %esi
	cmpw	%dx, -4(%r15)
	setb	%sil
	xorl	%edx, %edx
	cmpl	%ecx, -8(%r15)
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB5_79
## %bb.78:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rax), %rcx
	leaq	-8(%r15), %rsi
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	.p2align	4
LBB5_79:                                ##   in Loop: Header=BB5_2 Depth=2
	movl	-8(%rax), %esi
	movzwl	-4(%rax), %edi
	xorl	%ecx, %ecx
	cmpw	12(%r13), %di
	setb	%cl
	xorl	%r8d, %r8d
	cmpl	8(%r13), %esi
	leaq	8(%r13), %rdx
	setb	%r8b
	cmovel	%ecx, %r8d
	leaq	-8(%rax), %rcx
	xorl	%r9d, %r9d
	cmpw	%di, -12(%r15)
	setb	%r9b
	xorl	%edi, %edi
	cmpl	%esi, -16(%r15)
	setb	%dil
	cmovel	%r9d, %edi
	testb	%r8b, %r8b
	je	LBB5_80
## %bb.83:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rdx), %rsi
	testb	%dil, %dil
	je	LBB5_85
## %bb.84:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	-88(%rbp), %r8                  ## 8-byte Reload
	movzwl	4(%r8), %edi
	movw	%di, 4(%rdx)
	movl	(%r8), %edi
	movl	%edi, (%rdx)
	movq	%rsi, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%r8)
	movl	%esi, (%r8)
	jmp	LBB5_87
LBB5_80:                                ##   in Loop: Header=BB5_2 Depth=2
	testb	%dil, %dil
	je	LBB5_87
## %bb.81:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	-8(%rax), %rsi
	movq	-88(%rbp), %r8                  ## 8-byte Reload
	movzwl	4(%r8), %edi
	movw	%di, 4(%rcx)
	movl	(%r8), %edi
	movl	%edi, (%rcx)
	movl	%esi, (%r8)
	shrq	$32, %rsi
	movw	%si, 4(%r8)
	movl	-8(%rax), %esi
	movzwl	-4(%rax), %edi
	xorl	%r8d, %r8d
	cmpw	12(%r13), %di
	setb	%r8b
	xorl	%edi, %edi
	cmpl	8(%r13), %esi
	setb	%dil
	cmovel	%r8d, %edi
	cmpb	$1, %dil
	jne	LBB5_87
## %bb.82:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rdx), %rsi
	movzwl	4(%rcx), %edi
	movw	%di, 4(%rdx)
	movl	(%rcx), %edi
	movl	%edi, (%rdx)
	movl	%esi, (%rcx)
	shrq	$32, %rsi
	movw	%si, 4(%rcx)
	jmp	LBB5_87
LBB5_110:                               ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%r13), %edx
	movw	%dx, 4(%rax)
	movl	(%r13), %edx
	movl	%edx, (%rax)
	movq	%rcx, %rax
	shrq	$32, %rax
	movw	%ax, 4(%r13)
	movl	%ecx, (%r13)
	xorl	%edx, %edx
	cmpw	%ax, -4(%r15)
	setb	%dl
	xorl	%eax, %eax
	cmpl	%ecx, -8(%r15)
	setb	%al
	cmovel	%edx, %eax
	cmpb	$1, %al
	jne	LBB5_112
## %bb.111:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rax
	leaq	-8(%r15), %rdx
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%r13)
	movl	(%rdx), %ecx
	movl	%ecx, (%r13)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	.p2align	4
LBB5_112:                               ##   in Loop: Header=BB5_2 Depth=2
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	je	LBB5_113
	jmp	LBB5_130
LBB5_85:                                ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%rcx), %edi
	movw	%di, 4(%rdx)
	movl	(%rcx), %edi
	movl	%edi, (%rdx)
	movq	%rsi, %rdx
	shrq	$32, %rdx
	movw	%dx, 4(%rcx)
	movl	%esi, (%rcx)
	xorl	%edi, %edi
	cmpw	%dx, -12(%r15)
	setb	%dil
	xorl	%edx, %edx
	cmpl	%esi, -16(%r15)
	setb	%dl
	cmovel	%edi, %edx
	cmpb	$1, %dl
	jne	LBB5_87
## %bb.86:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rcx), %rdx
	movq	-88(%rbp), %rdi                 ## 8-byte Reload
	movzwl	4(%rdi), %esi
	movw	%si, 4(%rcx)
	movl	(%rdi), %esi
	movl	%esi, (%rcx)
	movl	%edx, (%rdi)
	shrq	$32, %rdx
	movw	%dx, 4(%rdi)
	.p2align	4
LBB5_87:                                ##   in Loop: Header=BB5_2 Depth=2
	movl	8(%rax), %edi
	movzwl	12(%rax), %r8d
	xorl	%edx, %edx
	cmpw	20(%r13), %r8w
	setb	%dl
	xorl	%r9d, %r9d
	cmpl	16(%r13), %edi
	leaq	16(%r13), %rsi
	setb	%r9b
	cmovel	%edx, %r9d
	leaq	8(%rax), %rdx
	xorl	%r10d, %r10d
	cmpw	%r8w, -20(%r15)
	setb	%r10b
	xorl	%r8d, %r8d
	cmpl	%edi, -24(%r15)
	setb	%r8b
	cmovel	%r10d, %r8d
	testb	%r9b, %r9b
	je	LBB5_88
## %bb.91:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rsi), %rdi
	testb	%r8b, %r8b
	je	LBB5_93
## %bb.92:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	-80(%rbp), %r9                  ## 8-byte Reload
	movzwl	4(%r9), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%r9), %r8d
	movl	%r8d, (%rsi)
	movq	%rdi, %rsi
	shrq	$32, %rsi
	movw	%si, 4(%r9)
	movl	%edi, (%r9)
	jmp	LBB5_95
LBB5_88:                                ##   in Loop: Header=BB5_2 Depth=2
	testb	%r8b, %r8b
	je	LBB5_95
## %bb.89:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	8(%rax), %rdi
	movq	-80(%rbp), %r9                  ## 8-byte Reload
	movzwl	4(%r9), %r8d
	movw	%r8w, 4(%rdx)
	movl	(%r9), %r8d
	movl	%r8d, (%rdx)
	movl	%edi, (%r9)
	shrq	$32, %rdi
	movw	%di, 4(%r9)
	movl	8(%rax), %edi
	movzwl	12(%rax), %r8d
	xorl	%r9d, %r9d
	cmpw	20(%r13), %r8w
	setb	%r9b
	xorl	%r8d, %r8d
	cmpl	16(%r13), %edi
	setb	%r8b
	cmovel	%r9d, %r8d
	cmpb	$1, %r8b
	jne	LBB5_95
## %bb.90:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rsi), %rdi
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movl	%edi, (%rdx)
	shrq	$32, %rdi
	movw	%di, 4(%rdx)
	jmp	LBB5_95
LBB5_93:                                ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movq	%rdi, %rsi
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	movl	%edi, (%rdx)
	xorl	%r8d, %r8d
	cmpw	%si, -20(%r15)
	setb	%r8b
	xorl	%esi, %esi
	cmpl	%edi, -24(%r15)
	setb	%sil
	cmovel	%r8d, %esi
	cmpb	$1, %sil
	jne	LBB5_95
## %bb.94:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rdx), %rsi
	movq	-80(%rbp), %r8                  ## 8-byte Reload
	movzwl	4(%r8), %edi
	movw	%di, 4(%rdx)
	movl	(%r8), %edi
	movl	%edi, (%rdx)
	movl	%esi, (%r8)
	shrq	$32, %rsi
	movw	%si, 4(%r8)
	.p2align	4
LBB5_95:                                ##   in Loop: Header=BB5_2 Depth=2
	movl	(%rax), %r11d
	movzwl	4(%rax), %r10d
	movl	-8(%rax), %esi
	movzwl	-4(%rax), %edi
	xorl	%r8d, %r8d
	cmpw	%di, %r10w
	setb	%r8b
	xorl	%ebx, %ebx
	cmpl	%esi, %r11d
	setb	%bl
	cmovel	%r8d, %ebx
	movl	8(%rax), %r8d
	movzwl	12(%rax), %r9d
	xorl	%r14d, %r14d
	cmpw	%r10w, %r9w
	setb	%r14b
	xorl	%r10d, %r10d
	cmpl	%r11d, %r8d
	setb	%r10b
	cmovel	%r14d, %r10d
	testb	%bl, %bl
	je	LBB5_96
## %bb.99:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rcx), %rsi
	testb	%r10b, %r10b
	je	LBB5_101
## %bb.100:                             ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%rdx), %edi
	movw	%di, 4(%rcx)
	movl	(%rdx), %edi
	movl	%edi, (%rcx)
	movq	%rsi, %rcx
	shrq	$32, %rcx
	movw	%cx, 4(%rdx)
	movl	%esi, (%rdx)
	jmp	LBB5_103
LBB5_96:                                ##   in Loop: Header=BB5_2 Depth=2
	testb	%r10b, %r10b
	je	LBB5_103
## %bb.97:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rax), %r8
	movzwl	4(%rdx), %r9d
	movw	%r9w, 4(%rax)
	movl	(%rdx), %edx
	movl	%edx, (%rax)
	movl	%r8d, 8(%rax)
	shrq	$32, %r8
	movw	%r8w, 12(%rax)
	xorl	%r8d, %r8d
	cmpw	%di, %r9w
	setb	%r8b
	xorl	%edi, %edi
	cmpl	%esi, %edx
	setb	%dil
	cmovel	%r8d, %edi
	cmpb	$1, %dil
	jne	LBB5_103
## %bb.98:                              ##   in Loop: Header=BB5_2 Depth=2
	movq	-8(%rax), %rdx
	movzwl	4(%rax), %esi
	movw	%si, 4(%rcx)
	movl	(%rax), %esi
	movl	%esi, (%rcx)
	movl	%edx, (%rax)
	shrq	$32, %rdx
	movw	%dx, 4(%rax)
	jmp	LBB5_103
LBB5_101:                               ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%rax), %edi
	movw	%di, 4(%rcx)
	movl	(%rax), %edi
	movl	%edi, (%rcx)
	movq	%rsi, %rcx
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	movl	%esi, (%rax)
	xorl	%edi, %edi
	cmpw	%cx, %r9w
	setb	%dil
	xorl	%ecx, %ecx
	cmpl	%esi, %r8d
	setb	%cl
	cmovnel	%ecx, %edi
	cmpb	$1, %dil
	jne	LBB5_103
## %bb.102:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	(%rax), %rcx
	movzwl	4(%rdx), %esi
	movw	%si, 4(%rax)
	movl	(%rdx), %edx
	movl	%edx, (%rax)
	movl	%ecx, 8(%rax)
	shrq	$32, %rcx
	movw	%cx, 12(%rax)
	.p2align	4
LBB5_103:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movl	%ecx, (%rax)
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	decq	%r12
	testb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	jne	LBB5_130
LBB5_113:                               ##   in Loop: Header=BB5_2 Depth=2
	movl	-8(%r13), %eax
	movzwl	-4(%r13), %ecx
	xorl	%edx, %edx
	cmpw	4(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	testb	%cl, %cl
	je	LBB5_114
LBB5_130:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rax
	movl	%eax, %ecx
	shrq	$32, %rax
	xorl	%edi, %edi
	.p2align	4
LBB5_131:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%edx, %edx
	cmpw	%ax, 12(%r13,%rdi)
	setb	%dl
	xorl	%esi, %esi
	cmpl	%ecx, 8(%r13,%rdi)
	setb	%sil
	cmovel	%edx, %esi
	addq	$8, %rdi
	testb	%sil, %sil
	jne	LBB5_131
## %bb.132:                             ##   in Loop: Header=BB5_2 Depth=2
	leaq	(%rdi,%r13), %rdx
	movq	%r15, %rsi
	cmpq	$8, %rdi
	jne	LBB5_137
## %bb.133:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	%r15, %rdi
	.p2align	4
LBB5_134:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	cmpq	%rdi, %rdx
	jae	LBB5_135
## %bb.136:                             ##   in Loop: Header=BB5_134 Depth=3
	leaq	-8(%rdi), %rsi
	xorl	%r8d, %r8d
	cmpw	%ax, -4(%rdi)
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	%ecx, -8(%rdi)
	setb	%r9b
	cmovel	%r8d, %r9d
	movq	%rsi, %rdi
	testb	%r9b, %r9b
	je	LBB5_134
	jmp	LBB5_138
	.p2align	4
LBB5_137:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%edi, %edi
	cmpw	%ax, -4(%rsi)
	setb	%dil
	xorl	%r8d, %r8d
	cmpl	%ecx, -8(%rsi)
	leaq	-8(%rsi), %rsi
	setb	%r8b
	cmovel	%edi, %r8d
	cmpb	$1, %r8b
	jne	LBB5_137
LBB5_138:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	%rdx, %rbx
	cmpq	%rsi, %rdx
	jb	LBB5_139
	jmp	LBB5_144
LBB5_135:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	%rdi, %rsi
	movq	%rdx, %rbx
	cmpq	%rsi, %rdx
	jae	LBB5_144
LBB5_139:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	%rdx, %rbx
	movq	%rsi, %rdi
	.p2align	4
LBB5_140:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Loop Header: Depth=3
                                        ##         Child Loop BB5_141 Depth 4
                                        ##         Child Loop BB5_142 Depth 4
	movq	(%rbx), %r8
	movzwl	4(%rdi), %r9d
	movw	%r9w, 4(%rbx)
	movl	(%rdi), %r9d
	movl	%r9d, (%rbx)
	movl	%r8d, (%rdi)
	shrq	$32, %r8
	movw	%r8w, 4(%rdi)
	.p2align	4
LBB5_141:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ##       Parent Loop BB5_140 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%r8d, %r8d
	cmpw	%ax, 12(%rbx)
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	%ecx, 8(%rbx)
	leaq	8(%rbx), %rbx
	setb	%r9b
	cmovel	%r8d, %r9d
	testb	%r9b, %r9b
	jne	LBB5_141
	.p2align	4
LBB5_142:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ##       Parent Loop BB5_140 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%r8d, %r8d
	cmpw	%ax, -4(%rdi)
	setb	%r8b
	xorl	%r9d, %r9d
	cmpl	%ecx, -8(%rdi)
	leaq	-8(%rdi), %rdi
	setb	%r9b
	cmovel	%r8d, %r9d
	cmpb	$1, %r9b
	jne	LBB5_142
## %bb.143:                             ##   in Loop: Header=BB5_140 Depth=3
	cmpq	%rdi, %rbx
	jb	LBB5_140
LBB5_144:                               ##   in Loop: Header=BB5_2 Depth=2
	leaq	-8(%rbx), %r8
	cmpq	%r8, %r13
	je	LBB5_146
## %bb.145:                             ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%r8), %edi
	movw	%di, 4(%r13)
	movl	(%r8), %edi
	movl	%edi, (%r13)
LBB5_146:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	%r13, -64(%rbp)                 ## 8-byte Spill
	movl	%ecx, -8(%rbx)
	movw	%ax, -4(%rbx)
	cmpq	%rsi, %rdx
	jb	LBB5_150
## %bb.147:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	%r12, -72(%rbp)                 ## 8-byte Spill
	movq	-64(%rbp), %rdi                 ## 8-byte Reload
	movq	%r8, %r14
	movq	%r8, %rsi
	callq	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	movl	%eax, %r12d
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	testb	%al, %al
	jne	LBB5_148
## %bb.149:                             ##   in Loop: Header=BB5_2 Depth=2
	testb	%r12b, %r12b
	movq	-72(%rbp), %r12                 ## 8-byte Reload
	movq	%r14, %r8
	jne	LBB5_2
LBB5_150:                               ##   in Loop: Header=BB5_2 Depth=2
	movzbl	-44(%rbp), %ecx                 ## 1-byte Folded Reload
	movq	-64(%rbp), %rdi                 ## 8-byte Reload
	movq	%r8, %rsi
	movq	%r12, %rdx
	callq	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	movl	$0, -44(%rbp)                   ## 4-byte Folded Spill
	jmp	LBB5_2
LBB5_114:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	(%r13), %rax
	movl	%eax, %ecx
	shrq	$32, %rax
	xorl	%edx, %edx
	cmpw	%ax, -4(%r15)
	seta	%dl
	xorl	%esi, %esi
	cmpl	%ecx, -8(%r15)
	seta	%sil
	cmovnel	%esi, %edx
	testb	%dl, %dl
	je	LBB5_115
## %bb.118:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	%r13, %rbx
	.p2align	4
LBB5_119:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%edx, %edx
	cmpw	%ax, 12(%rbx)
	seta	%dl
	xorl	%esi, %esi
	cmpl	%ecx, 8(%rbx)
	seta	%sil
	leaq	8(%rbx), %rbx
	cmovel	%edx, %esi
	testb	%sil, %sil
	je	LBB5_119
	jmp	LBB5_120
LBB5_115:                               ##   in Loop: Header=BB5_2 Depth=2
	leaq	8(%r13), %rdx
	.p2align	4
LBB5_116:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	%rdx, %rbx
	cmpq	%r15, %rdx
	jae	LBB5_120
## %bb.117:                             ##   in Loop: Header=BB5_116 Depth=3
	xorl	%edx, %edx
	cmpw	%ax, 4(%rbx)
	seta	%dl
	xorl	%esi, %esi
	cmpl	%ecx, (%rbx)
	seta	%sil
	cmovel	%edx, %esi
	leaq	8(%rbx), %rdx
	cmpb	$1, %sil
	jne	LBB5_116
LBB5_120:                               ##   in Loop: Header=BB5_2 Depth=2
	movq	%r15, %rdx
	cmpq	%r15, %rbx
	jae	LBB5_123
## %bb.121:                             ##   in Loop: Header=BB5_2 Depth=2
	movq	%r15, %rdx
	.p2align	4
LBB5_122:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	xorl	%esi, %esi
	cmpw	%ax, -4(%rdx)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%ecx, -8(%rdx)
	seta	%dil
	leaq	-8(%rdx), %rdx
	cmovel	%esi, %edi
	testb	%dil, %dil
	jne	LBB5_122
	jmp	LBB5_123
	.p2align	4
LBB5_124:                               ##   in Loop: Header=BB5_123 Depth=3
	movq	(%rbx), %rsi
	movzwl	4(%rdx), %edi
	movw	%di, 4(%rbx)
	movl	(%rdx), %edi
	movl	%edi, (%rbx)
	movl	%esi, (%rdx)
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	.p2align	4
LBB5_125:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ##       Parent Loop BB5_123 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%esi, %esi
	cmpw	%ax, 12(%rbx)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%ecx, 8(%rbx)
	seta	%dil
	leaq	8(%rbx), %rbx
	cmovel	%esi, %edi
	cmpb	$1, %dil
	jne	LBB5_125
	.p2align	4
LBB5_126:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ##       Parent Loop BB5_123 Depth=3
                                        ## =>      This Inner Loop Header: Depth=4
	xorl	%esi, %esi
	cmpw	%ax, -4(%rdx)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%ecx, -8(%rdx)
	seta	%dil
	leaq	-8(%rdx), %rdx
	cmovel	%esi, %edi
	testb	%dil, %dil
	jne	LBB5_126
LBB5_123:                               ##   Parent Loop BB5_1 Depth=1
                                        ##     Parent Loop BB5_2 Depth=2
                                        ## =>    This Loop Header: Depth=3
                                        ##         Child Loop BB5_125 Depth 4
                                        ##         Child Loop BB5_126 Depth 4
	cmpq	%rdx, %rbx
	jb	LBB5_124
## %bb.127:                             ##   in Loop: Header=BB5_2 Depth=2
	leaq	-8(%rbx), %rdx
	cmpq	%rdx, %r13
	je	LBB5_129
## %bb.128:                             ##   in Loop: Header=BB5_2 Depth=2
	movzwl	4(%rdx), %esi
	movw	%si, 4(%r13)
	movl	(%rdx), %edx
	movl	%edx, (%r13)
LBB5_129:                               ##   in Loop: Header=BB5_2 Depth=2
	movl	%ecx, -8(%rbx)
	movw	%ax, -4(%rbx)
	movl	$0, -44(%rbp)                   ## 4-byte Folded Spill
	jmp	LBB5_2
LBB5_148:                               ##   in Loop: Header=BB5_1 Depth=1
	testb	%r12b, %r12b
	movq	-72(%rbp), %r12                 ## 8-byte Reload
	movq	%r14, %r15
	movq	-64(%rbp), %rbx                 ## 8-byte Reload
	je	LBB5_1
	jmp	LBB5_20
LBB5_3:
	leaq	LJTI5_0(%rip), %rax
	movslq	(%rax,%rcx,4), %rcx
	addq	%rax, %rcx
	jmpq	*%rcx
LBB5_20:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB5_6:
	movl	8(%r13), %ecx
	movzwl	12(%r13), %edx
	xorl	%eax, %eax
	cmpw	4(%r13), %dx
	setb	%al
	xorl	%esi, %esi
	cmpl	(%r13), %ecx
	setb	%sil
	cmovel	%eax, %esi
	leaq	8(%r13), %rax
	xorl	%edi, %edi
	cmpw	%dx, -4(%r15)
	setb	%dil
	xorl	%edx, %edx
	cmpl	%ecx, -8(%r15)
	setb	%dl
	cmovel	%edi, %edx
	testb	%sil, %sil
	je	LBB5_7
## %bb.10:
	movq	(%r13), %rcx
	testb	%dl, %dl
	je	LBB5_12
## %bb.11:
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movzwl	4(%rdx), %eax
	movw	%ax, 4(%r13)
	movl	(%rdx), %eax
	movl	%eax, (%r13)
	movq	%rcx, %rax
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	movl	%ecx, (%rdx)
	jmp	LBB5_20
LBB5_4:
	movl	-8(%r15), %eax
	movzwl	-4(%r15), %ecx
	xorl	%edx, %edx
	cmpw	4(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB5_20
## %bb.5:
	movq	(%r13), %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%r13)
	movl	(%rdx), %ecx
	movl	%ecx, (%r13)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	jmp	LBB5_20
LBB5_15:
	leaq	8(%r13), %r14
	leaq	16(%r13), %r12
	leaq	24(%r13), %rbx
	movq	%r13, %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	movq	%rbx, %rcx
	callq	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	movl	-8(%r15), %eax
	movzwl	-4(%r15), %ecx
	xorl	%edx, %edx
	cmpw	28(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	24(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB5_20
## %bb.16:
	movq	24(%r13), %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%rbx)
	movl	(%rdx), %ecx
	movl	%ecx, (%rbx)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	movl	24(%r13), %eax
	movzwl	28(%r13), %ecx
	xorl	%edx, %edx
	cmpw	20(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	16(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB5_20
## %bb.17:
	movq	16(%r13), %rax
	movzwl	4(%rbx), %ecx
	movw	%cx, 4(%r12)
	movl	(%rbx), %ecx
	movl	%ecx, (%r12)
	movl	%eax, 24(%r13)
	shrq	$32, %rax
	movw	%ax, 28(%r13)
	movl	16(%r13), %eax
	movzwl	20(%r13), %ecx
	xorl	%edx, %edx
	cmpw	12(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	8(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB5_20
## %bb.18:
	movq	8(%r13), %rax
	movzwl	4(%r12), %ecx
	movw	%cx, 4(%r14)
	movl	(%r12), %ecx
	movl	%ecx, (%r14)
	movl	%eax, 16(%r13)
	shrq	$32, %rax
	movw	%ax, 20(%r13)
	movl	8(%r13), %eax
	movzwl	12(%r13), %ecx
	xorl	%edx, %edx
	cmpw	4(%r13), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%r13), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB5_20
## %bb.19:
	movq	(%r13), %rax
	movzwl	4(%r14), %ecx
	movw	%cx, 4(%r13)
	movl	(%r14), %ecx
	movl	%ecx, (%r13)
	movl	%eax, 8(%r13)
	shrq	$32, %rax
	movw	%ax, 12(%r13)
	jmp	LBB5_20
LBB5_14:
	leaq	8(%r13), %rsi
	leaq	16(%r13), %rdx
	movq	%r13, %rdi
	movq	-56(%rbp), %rcx                 ## 8-byte Reload
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_ ## TAILCALL
LBB5_22:
	cmpq	%r15, %r13
	sete	%cl
	leaq	8(%r13), %rdx
	cmpq	%r15, %rdx
	sete	%al
	orb	%cl, %al
	cmpb	$1, -44(%rbp)                   ## 1-byte Folded Reload
	jne	LBB5_32
## %bb.23:
	testb	%al, %al
	jne	LBB5_20
## %bb.24:
	xorl	%eax, %eax
	movq	%r13, %rdi
	jmp	LBB5_25
LBB5_29:                                ##   in Loop: Header=BB5_25 Depth=1
	movq	%r13, %r9
LBB5_30:                                ##   in Loop: Header=BB5_25 Depth=1
	movl	%esi, (%r9)
	movw	%dx, 4(%r9)
LBB5_31:                                ##   in Loop: Header=BB5_25 Depth=1
	leaq	8(%rcx), %rdx
	addq	$8, %rax
	movq	%rcx, %rdi
	cmpq	%r15, %rdx
	je	LBB5_20
LBB5_25:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB5_27 Depth 2
	movq	%rdx, %rcx
	movl	8(%rdi), %edx
	movzwl	12(%rdi), %esi
	xorl	%r8d, %r8d
	cmpw	4(%rdi), %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	(%rdi), %edx
	setb	%sil
	cmovel	%r8d, %esi
	cmpb	$1, %sil
	jne	LBB5_31
## %bb.26:                              ##   in Loop: Header=BB5_25 Depth=1
	movq	8(%rdi), %rdx
	movl	%edx, %esi
	shrq	$32, %rdx
	movzwl	4(%rdi), %r8d
	movw	%r8w, 4(%rcx)
	movl	(%rdi), %r8d
	movl	%r8d, (%rcx)
	movq	%rax, %r8
	movq	%r13, %r9
	cmpq	%r13, %rdi
	je	LBB5_30
	.p2align	4
LBB5_27:                                ##   Parent Loop BB5_25 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	xorl	%edi, %edi
	cmpw	%dx, -4(%r13,%r8)
	seta	%dil
	xorl	%r10d, %r10d
	cmpl	%esi, -8(%r13,%r8)
	seta	%r10b
	leaq	(%r13,%r8), %r9
	cmovel	%edi, %r10d
	testb	%r10b, %r10b
	je	LBB5_30
## %bb.28:                              ##   in Loop: Header=BB5_27 Depth=2
	leaq	(%r8,%r13), %rdi
	addq	$-8, %rdi
	movzwl	4(%rdi), %r10d
	movw	%r10w, 4(%r9)
	movl	(%rdi), %edi
	movl	%edi, (%r9)
	addq	$-8, %r8
	jne	LBB5_27
	jmp	LBB5_29
LBB5_39:
	cmpq	%r15, %r13
	je	LBB5_20
## %bb.40:
	leaq	-2(%rcx), %r12
	shrq	%r12
	movq	%r12, %rax
	jmp	LBB5_41
	.p2align	4
LBB5_54:                                ##   in Loop: Header=BB5_41 Depth=1
	leaq	(,%r9,8), %rax
	addq	%r13, %rax
	movl	%edx, (%rax)
	movw	%di, 4(%rax)
	movq	-72(%rbp), %rax                 ## 8-byte Reload
LBB5_55:                                ##   in Loop: Header=BB5_41 Depth=1
	subq	$1, %rax
	jb	LBB5_56
LBB5_41:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB5_47 Depth 2
	cmpq	%rax, %r12
	jb	LBB5_55
## %bb.42:                              ##   in Loop: Header=BB5_41 Depth=1
	leaq	1(,%rax,2), %rsi
	leaq	2(,%rax,2), %r9
	cmpq	%rcx, %r9
	jae	LBB5_43
## %bb.44:                              ##   in Loop: Header=BB5_41 Depth=1
	leaq	(%rax,%rax), %r10
	movl	(%r13,%rsi,8), %edi
	movl	4(%r13,%rsi,8), %r8d
	movl	16(%r13,%r10,8), %r11d
	movl	20(%r13,%r10,8), %r10d
	xorl	%ebx, %ebx
	cmpw	%r10w, %r8w
	setb	%bl
	xorl	%r14d, %r14d
	cmpl	%r11d, %edi
	setb	%r14b
	cmovnel	%r14d, %ebx
	testb	%bl, %bl
	cmovneq	%r9, %rsi
	cmovnel	%r11d, %edi
	cmovnel	%r10d, %r8d
	jmp	LBB5_45
	.p2align	4
LBB5_43:                                ##   in Loop: Header=BB5_41 Depth=1
	movl	(%r13,%rsi,8), %edi
	movzwl	4(%r13,%rsi,8), %r8d
LBB5_45:                                ##   in Loop: Header=BB5_41 Depth=1
	xorl	%r9d, %r9d
	cmpw	4(%r13,%rax,8), %r8w
	setb	%r9b
	xorl	%r8d, %r8d
	cmpl	(%r13,%rax,8), %edi
	setb	%r8b
	cmovel	%r9d, %r8d
	testb	%r8b, %r8b
	jne	LBB5_55
## %bb.46:                              ##   in Loop: Header=BB5_41 Depth=1
	movq	(%r13,%rax,8), %rdi
	movl	%edi, %edx
	shrq	$32, %rdi
	movq	%rax, -72(%rbp)                 ## 8-byte Spill
	movq	%rax, %r10
	movl	%edx, -64(%rbp)                 ## 4-byte Spill
	jmp	LBB5_47
	.p2align	4
LBB5_52:                                ##   in Loop: Header=BB5_47 Depth=2
	movq	%r11, %rsi
	movq	%r8, %r15
	movq	%rdi, %r12
	movq	%rdx, %rdi
	movl	-64(%rbp), %edx                 ## 4-byte Reload
LBB5_53:                                ##   in Loop: Header=BB5_47 Depth=2
	xorl	%eax, %eax
	cmpw	%di, %bx
	setb	%al
	xorl	%r11d, %r11d
	cmpl	%edx, %r10d
	setb	%r11b
	cmovel	%eax, %r11d
	movq	%r9, %r10
	cmpb	$1, %r11b
	je	LBB5_54
LBB5_47:                                ##   Parent Loop BB5_41 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rsi, %r9
	movzwl	4(%r13,%rsi,8), %esi
	movw	%si, 4(%r13,%r10,8)
	movl	(%r13,%r9,8), %esi
	movl	%esi, (%r13,%r10,8)
	cmpq	%r9, %r12
	jl	LBB5_54
## %bb.48:                              ##   in Loop: Header=BB5_47 Depth=2
	leaq	1(,%r9,2), %rsi
	leaq	2(,%r9,2), %r11
	cmpq	%rcx, %r11
	jge	LBB5_49
## %bb.50:                              ##   in Loop: Header=BB5_47 Depth=2
	movq	%rdi, %rdx
	movq	%r12, %rdi
	movq	%r15, %r8
	leaq	(%r9,%r9), %rbx
	movl	(%r13,%rsi,8), %r14d
	movl	4(%r13,%rsi,8), %r12d
	movl	16(%r13,%rbx,8), %r10d
	movl	20(%r13,%rbx,8), %ebx
	xorl	%r15d, %r15d
	cmpw	%bx, %r12w
	setb	%r15b
	xorl	%eax, %eax
	cmpl	%r10d, %r14d
	setb	%al
	cmovnel	%eax, %r15d
	testb	%r15b, %r15b
	jne	LBB5_52
## %bb.51:                              ##   in Loop: Header=BB5_47 Depth=2
	movq	%rsi, %r11
	movl	%r14d, %r10d
	movl	%r12d, %ebx
	jmp	LBB5_52
	.p2align	4
LBB5_49:                                ##   in Loop: Header=BB5_47 Depth=2
	movl	(%r13,%rsi,8), %r10d
	movzwl	4(%r13,%rsi,8), %ebx
	jmp	LBB5_53
	.p2align	4
LBB5_62:                                ##   in Loop: Header=BB5_56 Depth=1
	movl	%edx, (%rax)
	shrq	$32, %rdx
	movw	%dx, 4(%rax)
LBB5_69:                                ##   in Loop: Header=BB5_56 Depth=1
	cmpq	$2, %rcx
	leaq	-1(%rcx), %rcx
	jle	LBB5_20
LBB5_56:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB5_57 Depth 2
                                        ##     Child Loop BB5_66 Depth 2
	movq	(%r13), %rdx
	leaq	-2(%rcx), %rsi
	shrq	%rsi
	movq	%r13, %rdi
	xorl	%r10d, %r10d
	jmp	LBB5_57
	.p2align	4
LBB5_60:                                ##   in Loop: Header=BB5_57 Depth=2
	movzwl	4(%rax), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rax), %r9d
	movl	%r9d, (%rdi)
	movq	%rax, %rdi
	movq	%r8, %r10
	cmpq	%rsi, %r8
	jg	LBB5_61
LBB5_57:                                ##   Parent Loop BB5_56 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	leaq	(%rdi,%r10,8), %rax
	addq	$8, %rax
	leaq	1(,%r10,2), %r8
	leaq	2(,%r10,2), %r9
	cmpq	%rcx, %r9
	jge	LBB5_60
## %bb.58:                              ##   in Loop: Header=BB5_57 Depth=2
	leaq	(%rdi,%r10,8), %r10
	movl	8(%r10), %r11d
	movzwl	12(%r10), %ebx
	xorl	%r14d, %r14d
	cmpw	20(%r10), %bx
	setb	%r14b
	xorl	%ebx, %ebx
	cmpl	16(%r10), %r11d
	setb	%bl
	cmovel	%r14d, %ebx
	testb	%bl, %bl
	je	LBB5_60
## %bb.59:                              ##   in Loop: Header=BB5_57 Depth=2
	addq	$16, %r10
	movq	%r10, %rax
	movq	%r9, %r8
	jmp	LBB5_60
	.p2align	4
LBB5_61:                                ##   in Loop: Header=BB5_56 Depth=1
	addq	$-8, %r15
	cmpq	%r15, %rax
	je	LBB5_62
## %bb.63:                              ##   in Loop: Header=BB5_56 Depth=1
	movzwl	4(%r15), %esi
	movw	%si, 4(%rax)
	movl	(%r15), %esi
	movl	%esi, (%rax)
	movq	%rdx, %rsi
	shrq	$32, %rsi
	movw	%si, 4(%r15)
	movl	%edx, (%r15)
	movq	%rax, %rdx
	subq	%r13, %rdx
	addq	$8, %rdx
	sarq	$3, %rdx
	cmpq	$2, %rdx
	jl	LBB5_69
## %bb.64:                              ##   in Loop: Header=BB5_56 Depth=1
	addq	$-2, %rdx
	shrq	%rdx
	movl	(%r13,%rdx,8), %esi
	movzwl	4(%r13,%rdx,8), %edi
	xorl	%r8d, %r8d
	cmpw	4(%rax), %di
	setb	%r8b
	xorl	%edi, %edi
	cmpl	(%rax), %esi
	setb	%dil
	cmovel	%r8d, %edi
	cmpb	$1, %dil
	jne	LBB5_69
## %bb.65:                              ##   in Loop: Header=BB5_56 Depth=1
	leaq	(,%rdx,8), %r8
	addq	%r13, %r8
	movq	(%rax), %rsi
	movl	%esi, %edi
	shrq	$32, %rsi
	.p2align	4
LBB5_66:                                ##   Parent Loop BB5_56 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rax, %r9
	movq	%r8, %rax
	movzwl	4(%r8), %r8d
	movw	%r8w, 4(%r9)
	movl	(%rax), %r8d
	movl	%r8d, (%r9)
	testq	%rdx, %rdx
	je	LBB5_68
## %bb.67:                              ##   in Loop: Header=BB5_66 Depth=2
	decq	%rdx
	shrq	%rdx
	leaq	(,%rdx,8), %r8
	addq	%r13, %r8
	xorl	%r9d, %r9d
	cmpw	%si, 4(%r13,%rdx,8)
	setb	%r9b
	xorl	%r10d, %r10d
	cmpl	%edi, (%r13,%rdx,8)
	setb	%r10b
	cmovel	%r9d, %r10d
	testb	%r10b, %r10b
	jne	LBB5_66
LBB5_68:                                ##   in Loop: Header=BB5_56 Depth=1
	movl	%edi, (%rax)
	movw	%si, 4(%rax)
	jmp	LBB5_69
LBB5_7:
	testb	%dl, %dl
	je	LBB5_20
## %bb.8:
	movq	8(%r13), %rcx
	movq	-56(%rbp), %rsi                 ## 8-byte Reload
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	movl	8(%r13), %ecx
	movzwl	12(%r13), %edx
	xorl	%esi, %esi
	cmpw	4(%r13), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r13), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB5_20
## %bb.9:
	movq	(%r13), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %eax
	movl	%eax, (%r13)
	movl	%ecx, 8(%r13)
	shrq	$32, %rcx
	movw	%cx, 12(%r13)
	jmp	LBB5_20
LBB5_32:
	testb	%al, %al
	je	LBB5_33
	jmp	LBB5_20
	.p2align	4
LBB5_37:                                ##   in Loop: Header=BB5_33 Depth=1
	leaq	8(%rax), %rdx
	movq	%rax, %r13
	cmpq	%r15, %rdx
	je	LBB5_20
LBB5_33:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB5_35 Depth 2
	movq	%rdx, %rax
	movl	8(%r13), %ecx
	movzwl	12(%r13), %edx
	xorl	%esi, %esi
	cmpw	4(%r13), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r13), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB5_37
## %bb.34:                              ##   in Loop: Header=BB5_33 Depth=1
	movq	(%rax), %rcx
	movl	%ecx, %edx
	shrq	$32, %rcx
	.p2align	4
LBB5_35:                                ##   Parent Loop BB5_33 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	4(%r13), %esi
	movw	%si, 12(%r13)
	movl	(%r13), %esi
	movl	%esi, 8(%r13)
	xorl	%esi, %esi
	cmpw	%cx, -4(%r13)
	seta	%sil
	xorl	%edi, %edi
	cmpl	%edx, -8(%r13)
	seta	%dil
	leaq	-8(%r13), %r13
	cmovel	%esi, %edi
	testb	%dil, %dil
	jne	LBB5_35
## %bb.36:                              ##   in Loop: Header=BB5_33 Depth=1
	movl	%edx, 8(%r13)
	movw	%cx, 12(%r13)
	jmp	LBB5_37
LBB5_12:
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r13)
	movl	(%rax), %edx
	movl	%edx, (%r13)
	movl	%ecx, %edx
	movl	%ecx, 8(%r13)
	shrq	$32, %rcx
	movw	%cx, 12(%r13)
	xorl	%esi, %esi
	cmpw	%cx, -4(%r15)
	setb	%sil
	xorl	%ecx, %ecx
	cmpl	%edx, -8(%r15)
	setb	%cl
	cmovel	%esi, %ecx
	cmpb	$1, %cl
	jne	LBB5_20
## %bb.13:
	movq	(%rax), %rcx
	movq	-56(%rbp), %rsi                 ## 8-byte Reload
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rax)
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	jmp	LBB5_20
	.cfi_endproc
	.p2align	2
	.data_region jt32
L5_0_set_20 = LBB5_20-LJTI5_0
L5_0_set_4 = LBB5_4-LJTI5_0
L5_0_set_6 = LBB5_6-LJTI5_0
L5_0_set_14 = LBB5_14-LJTI5_0
L5_0_set_15 = LBB5_15-LJTI5_0
LJTI5_0:
	.long	L5_0_set_20
	.long	L5_0_set_20
	.long	L5_0_set_4
	.long	L5_0_set_6
	.long	L5_0_set_14
	.long	L5_0_set_15
	.end_data_region
                                        ## -- End function
	.p2align	4                               ## -- Begin function _ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_: ## @_ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	movl	(%rsi), %r9d
	movzwl	4(%rsi), %r10d
	xorl	%eax, %eax
	cmpw	4(%rdi), %r10w
	setb	%al
	xorl	%r11d, %r11d
	cmpl	(%rdi), %r9d
	setb	%r11b
	cmovel	%eax, %r11d
	movl	(%rdx), %eax
	movzwl	4(%rdx), %r8d
	xorl	%ebx, %ebx
	cmpw	%r10w, %r8w
	setb	%bl
	xorl	%r10d, %r10d
	cmpl	%r9d, %eax
	setb	%r10b
	cmovel	%ebx, %r10d
	testb	%r11b, %r11b
	je	LBB6_1
## %bb.4:
	movq	(%rdi), %r9
	testb	%r10b, %r10b
	je	LBB6_6
## %bb.5:
	movzwl	4(%rdx), %eax
	movw	%ax, 4(%rdi)
	movl	(%rdx), %eax
	movl	%eax, (%rdi)
	movq	%r9, %r8
	shrq	$32, %r8
	movw	%r8w, 4(%rdx)
	movl	%r9d, (%rdx)
	movl	%r9d, %eax
	jmp	LBB6_8
LBB6_1:
	testb	%r10b, %r10b
	je	LBB6_8
## %bb.2:
	movq	(%rsi), %rax
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movl	%eax, (%rdx)
	movq	%rax, %r8
	shrq	$32, %r8
	movw	%r8w, 4(%rdx)
	movl	(%rsi), %r9d
	movzwl	4(%rsi), %r10d
	xorl	%r11d, %r11d
	cmpw	4(%rdi), %r10w
	setb	%r11b
	xorl	%r10d, %r10d
	cmpl	(%rdi), %r9d
	setb	%r10b
	cmovel	%r11d, %r10d
	cmpb	$1, %r10b
	jne	LBB6_8
## %bb.3:
	movq	(%rdi), %rax
	movzwl	4(%rsi), %r8d
	movw	%r8w, 4(%rdi)
	movl	(%rsi), %r8d
	movl	%r8d, (%rdi)
	movl	%eax, (%rsi)
	shrq	$32, %rax
	movw	%ax, 4(%rsi)
	movl	(%rdx), %eax
	movzwl	4(%rdx), %r8d
	jmp	LBB6_8
LBB6_6:
	movzwl	4(%rsi), %eax
	movw	%ax, 4(%rdi)
	movl	(%rsi), %eax
	movl	%eax, (%rdi)
	movq	%r9, %r10
	shrq	$32, %r10
	movw	%r10w, 4(%rsi)
	movl	%r9d, (%rsi)
	movl	(%rdx), %eax
	movzwl	4(%rdx), %r8d
	xorl	%r11d, %r11d
	cmpw	%r10w, %r8w
	setb	%r11b
	xorl	%r10d, %r10d
	cmpl	%r9d, %eax
	setb	%r10b
	cmovel	%r11d, %r10d
	cmpb	$1, %r10b
	jne	LBB6_8
## %bb.7:
	movq	(%rsi), %rax
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rsi)
	movl	(%rdx), %r8d
	movl	%r8d, (%rsi)
	movl	%eax, (%rdx)
	movq	%rax, %r8
	shrq	$32, %r8
	movw	%r8w, 4(%rdx)
LBB6_8:
	xorl	%r9d, %r9d
	cmpw	%r8w, 4(%rcx)
	setb	%r9b
	xorl	%r8d, %r8d
	cmpl	%eax, (%rcx)
	setb	%r8b
	cmovel	%r9d, %r8d
	cmpb	$1, %r8b
	jne	LBB6_12
## %bb.9:
	movq	(%rdx), %rax
	movzwl	4(%rcx), %r8d
	movw	%r8w, 4(%rdx)
	movl	(%rcx), %r8d
	movl	%r8d, (%rdx)
	movl	%eax, (%rcx)
	shrq	$32, %rax
	movw	%ax, 4(%rcx)
	movl	(%rdx), %eax
	movzwl	4(%rdx), %ecx
	xorl	%r8d, %r8d
	cmpw	4(%rsi), %cx
	setb	%r8b
	xorl	%ecx, %ecx
	cmpl	(%rsi), %eax
	setb	%cl
	cmovel	%r8d, %ecx
	cmpb	$1, %cl
	jne	LBB6_12
## %bb.10:
	movq	(%rsi), %rax
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%rsi)
	movl	(%rdx), %ecx
	movl	%ecx, (%rsi)
	movl	%eax, (%rdx)
	shrq	$32, %rax
	movw	%ax, 4(%rdx)
	movl	(%rsi), %eax
	movzwl	4(%rsi), %ecx
	xorl	%edx, %edx
	cmpw	4(%rdi), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	(%rdi), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	jne	LBB6_12
## %bb.11:
	movq	(%rdi), %rax
	movzwl	4(%rsi), %ecx
	movw	%cx, 4(%rdi)
	movl	(%rsi), %ecx
	movl	%ecx, (%rdi)
	movl	%eax, (%rsi)
	shrq	$32, %rax
	movw	%ax, 4(%rsi)
LBB6_12:
	popq	%rbx
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4                               ## -- Begin function _ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_: ## @_ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rcx
	subq	%rdi, %rcx
	sarq	$3, %rcx
	movb	$1, %al
	cmpq	$5, %rcx
	ja	LBB7_19
## %bb.1:
	leaq	LJTI7_0(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
LBB7_2:
	movl	-8(%rsi), %ecx
	movzwl	-4(%rsi), %edx
	xorl	%r8d, %r8d
	cmpw	4(%rdi), %dx
	setb	%r8b
	xorl	%edx, %edx
	cmpl	(%rdi), %ecx
	setb	%dl
	cmovel	%r8d, %edx
	cmpb	$1, %dl
	jne	LBB7_37
## %bb.3:
	addq	$-8, %rsi
	movq	(%rdi), %rcx
	movzwl	4(%rsi), %edx
	movw	%dx, 4(%rdi)
	movl	(%rsi), %edx
	movl	%edx, (%rdi)
	movl	%ecx, (%rsi)
	shrq	$32, %rcx
	movw	%cx, 4(%rsi)
	jmp	LBB7_37
LBB7_4:
	movl	8(%rdi), %r8d
	movzwl	12(%rdi), %r9d
	xorl	%edx, %edx
	cmpw	4(%rdi), %r9w
	setb	%dl
	xorl	%r10d, %r10d
	cmpl	(%rdi), %r8d
	leaq	8(%rdi), %rcx
	setb	%r10b
	cmovel	%edx, %r10d
	leaq	-8(%rsi), %rdx
	xorl	%r11d, %r11d
	cmpw	%r9w, -4(%rsi)
	setb	%r11b
	xorl	%r9d, %r9d
	cmpl	%r8d, -8(%rsi)
	setb	%r9b
	cmovel	%r11d, %r9d
	testb	%r10b, %r10b
	je	LBB7_5
## %bb.8:
	movq	(%rdi), %r8
	testb	%r9b, %r9b
	je	LBB7_10
## %bb.9:
	movzwl	4(%rdx), %ecx
	movw	%cx, 4(%rdi)
	movl	(%rdx), %ecx
	movl	%ecx, (%rdi)
	movq	%r8, %rcx
	shrq	$32, %rcx
	movw	%cx, 4(%rdx)
	movl	%r8d, (%rdx)
	jmp	LBB7_37
LBB7_13:
	leaq	8(%rdi), %rbx
	leaq	16(%rdi), %r14
	leaq	24(%rdi), %r15
	movq	%rdi, %r12
	movq	%rsi, %r13
	movq	%rbx, %rsi
	movq	%r14, %rdx
	movq	%r15, %rcx
	callq	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	movl	-8(%r13), %ecx
	movzwl	-4(%r13), %edx
	xorl	%esi, %esi
	cmpw	28(%r12), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	24(%r12), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB7_14
## %bb.15:
	movq	%r13, %rax
	addq	$-8, %rax
	movq	24(%r12), %rcx
	movzwl	4(%rax), %edx
	movw	%dx, 4(%r15)
	movl	(%rax), %edx
	movl	%edx, (%r15)
	movl	%ecx, (%rax)
	shrq	$32, %rcx
	movw	%cx, 4(%rax)
	movl	24(%r12), %eax
	movzwl	28(%r12), %ecx
	xorl	%edx, %edx
	cmpw	20(%r12), %cx
	setb	%dl
	xorl	%ecx, %ecx
	cmpl	16(%r12), %eax
	setb	%cl
	cmovel	%edx, %ecx
	cmpb	$1, %cl
	movb	$1, %al
	jne	LBB7_37
## %bb.16:
	movq	16(%r12), %rcx
	movzwl	4(%r15), %edx
	movw	%dx, 4(%r14)
	movl	(%r15), %edx
	movl	%edx, (%r14)
	movl	%ecx, 24(%r12)
	shrq	$32, %rcx
	movw	%cx, 28(%r12)
	movl	16(%r12), %ecx
	movzwl	20(%r12), %edx
	xorl	%esi, %esi
	cmpw	12(%r12), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	8(%r12), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB7_37
## %bb.17:
	movq	8(%r12), %rcx
	movzwl	4(%r14), %edx
	movw	%dx, 4(%rbx)
	movl	(%r14), %edx
	movl	%edx, (%rbx)
	movl	%ecx, 16(%r12)
	shrq	$32, %rcx
	movw	%cx, 20(%r12)
	movl	8(%r12), %ecx
	movzwl	12(%r12), %edx
	xorl	%esi, %esi
	cmpw	4(%r12), %dx
	setb	%sil
	xorl	%edx, %edx
	cmpl	(%r12), %ecx
	setb	%dl
	cmovel	%esi, %edx
	cmpb	$1, %dl
	jne	LBB7_37
## %bb.18:
	movq	(%r12), %rcx
	movzwl	4(%rbx), %edx
	movw	%dx, 4(%r12)
	movl	(%rbx), %edx
	movl	%edx, (%r12)
	movl	%ecx, 8(%r12)
	shrq	$32, %rcx
	movw	%cx, 12(%r12)
	jmp	LBB7_37
LBB7_19:
	leaq	16(%rdi), %rcx
	movl	8(%rdi), %r14d
	movzwl	12(%rdi), %ebx
	movl	(%rdi), %r8d
	movzwl	4(%rdi), %r9d
	xorl	%edx, %edx
	cmpw	%r9w, %bx
	setb	%dl
	xorl	%r15d, %r15d
	cmpl	%r8d, %r14d
	setb	%r15b
	cmovel	%edx, %r15d
	leaq	8(%rdi), %rdx
	movl	16(%rdi), %r10d
	movzwl	20(%rdi), %r11d
	xorl	%r12d, %r12d
	cmpw	%bx, %r11w
	setb	%r12b
	xorl	%ebx, %ebx
	cmpl	%r14d, %r10d
	setb	%bl
	cmovel	%r12d, %ebx
	testb	%r15b, %r15b
	je	LBB7_20
## %bb.23:
	movq	(%rdi), %r8
	testb	%bl, %bl
	je	LBB7_25
## %bb.24:
	movzwl	4(%rcx), %edx
	movw	%dx, 4(%rdi)
	movl	(%rcx), %edx
	movl	%edx, (%rdi)
	movl	%r8d, 16(%rdi)
	shrq	$32, %r8
	movw	%r8w, 20(%rdi)
	jmp	LBB7_27
LBB7_12:
	leaq	8(%rdi), %rax
	leaq	16(%rdi), %rdx
	addq	$-8, %rsi
	movq	%rsi, %rcx
	movq	%rax, %rsi
	callq	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	movb	$1, %al
	jmp	LBB7_37
LBB7_5:
	testb	%r9b, %r9b
	je	LBB7_37
## %bb.6:
	movq	8(%rdi), %rsi
	movzwl	4(%rdx), %r8d
	movw	%r8w, 4(%rcx)
	movl	(%rdx), %r8d
	movl	%r8d, (%rcx)
	movl	%esi, (%rdx)
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	movl	8(%rdi), %edx
	movzwl	12(%rdi), %esi
	xorl	%r8d, %r8d
	cmpw	4(%rdi), %si
	setb	%r8b
	xorl	%esi, %esi
	cmpl	(%rdi), %edx
	setb	%sil
	cmovel	%r8d, %esi
	cmpb	$1, %sil
	jne	LBB7_37
## %bb.7:
	movq	(%rdi), %rdx
	movzwl	4(%rcx), %esi
	movw	%si, 4(%rdi)
	movl	(%rcx), %ecx
	movl	%ecx, (%rdi)
	movl	%edx, 8(%rdi)
	shrq	$32, %rdx
	movw	%dx, 12(%rdi)
	jmp	LBB7_37
LBB7_14:
	movb	$1, %al
	jmp	LBB7_37
LBB7_20:
	testb	%bl, %bl
	je	LBB7_27
## %bb.21:
	movq	8(%rdi), %r10
	movzwl	4(%rcx), %r11d
	movw	%r11w, 4(%rdx)
	movl	(%rcx), %r11d
	movl	%r11d, (%rdx)
	movl	%r10d, 16(%rdi)
	shrq	$32, %r10
	movw	%r10w, 20(%rdi)
	xorl	%r10d, %r10d
	cmpw	%r9w, 12(%rdi)
	setb	%r10b
	xorl	%r9d, %r9d
	cmpl	%r8d, 8(%rdi)
	setb	%r9b
	cmovel	%r10d, %r9d
	cmpb	$1, %r9b
	jne	LBB7_27
## %bb.22:
	movq	(%rdi), %r8
	movzwl	4(%rdx), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rdx), %edx
	movl	%edx, (%rdi)
	movl	%r8d, 8(%rdi)
	shrq	$32, %r8
	movw	%r8w, 12(%rdi)
	jmp	LBB7_27
LBB7_10:
	movzwl	4(%rcx), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rcx), %r9d
	movl	%r9d, (%rdi)
	movl	%r8d, %r9d
	movl	%r8d, 8(%rdi)
	shrq	$32, %r8
	movw	%r8w, 12(%rdi)
	xorl	%edi, %edi
	cmpw	%r8w, -4(%rsi)
	setb	%dil
	xorl	%r8d, %r8d
	cmpl	%r9d, -8(%rsi)
	setb	%r8b
	cmovel	%edi, %r8d
	cmpb	$1, %r8b
	jne	LBB7_37
## %bb.11:
	movq	(%rcx), %rsi
	movzwl	4(%rdx), %edi
	movw	%di, 4(%rcx)
	movl	(%rdx), %edi
	movl	%edi, (%rcx)
	movl	%esi, (%rdx)
	shrq	$32, %rsi
	movw	%si, 4(%rdx)
	jmp	LBB7_37
LBB7_25:
	movzwl	4(%rdx), %r9d
	movw	%r9w, 4(%rdi)
	movl	(%rdx), %r9d
	movl	%r9d, (%rdi)
	movl	%r8d, %r9d
	movl	%r8d, 8(%rdi)
	shrq	$32, %r8
	movw	%r8w, 12(%rdi)
	xorl	%ebx, %ebx
	cmpw	%r8w, %r11w
	setb	%bl
	xorl	%r8d, %r8d
	cmpl	%r9d, %r10d
	setb	%r8b
	cmovnel	%r8d, %ebx
	cmpb	$1, %bl
	jne	LBB7_27
## %bb.26:
	movq	(%rdx), %r8
	movzwl	4(%rcx), %r9d
	movw	%r9w, 4(%rdx)
	movl	(%rcx), %r9d
	movl	%r9d, (%rdx)
	movl	%r8d, (%rcx)
	shrq	$32, %r8
	movw	%r8w, 4(%rcx)
LBB7_27:
	leaq	24(%rdi), %rdx
	cmpq	%rsi, %rdx
	je	LBB7_37
## %bb.28:
	xorl	%r8d, %r8d
	movl	$16, %r9d
	jmp	LBB7_29
	.p2align	4
LBB7_33:                                ##   in Loop: Header=BB7_29 Depth=1
	movq	%rdi, %rbx
LBB7_34:                                ##   in Loop: Header=BB7_29 Depth=1
	movl	%r11d, (%rbx)
	movw	%r10w, 4(%rbx)
	incl	%r8d
	cmpl	$8, %r8d
	je	LBB7_35
LBB7_36:                                ##   in Loop: Header=BB7_29 Depth=1
	movq	%rdx, %rcx
	addq	$8, %rdx
	addq	$8, %r9
	cmpq	%rsi, %rdx
	je	LBB7_37
LBB7_29:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB7_31 Depth 2
	movl	(%rdx), %r10d
	movzwl	4(%rdx), %r11d
	xorl	%ebx, %ebx
	cmpw	4(%rcx), %r11w
	setb	%bl
	xorl	%r11d, %r11d
	cmpl	(%rcx), %r10d
	setb	%r11b
	cmovel	%ebx, %r11d
	cmpb	$1, %r11b
	jne	LBB7_36
## %bb.30:                              ##   in Loop: Header=BB7_29 Depth=1
	movq	(%rdx), %r10
	movl	%r10d, %r11d
	shrq	$32, %r10
	movzwl	4(%rcx), %ebx
	movw	%bx, 4(%rdx)
	movl	(%rcx), %ecx
	movl	%ecx, (%rdx)
	movq	%r9, %rcx
	.p2align	4
LBB7_31:                                ##   Parent Loop BB7_29 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	xorl	%r14d, %r14d
	cmpw	%r10w, -4(%rdi,%rcx)
	seta	%r14b
	xorl	%r15d, %r15d
	cmpl	%r11d, -8(%rdi,%rcx)
	seta	%r15b
	leaq	(%rdi,%rcx), %rbx
	cmovel	%r14d, %r15d
	testb	%r15b, %r15b
	je	LBB7_34
## %bb.32:                              ##   in Loop: Header=BB7_31 Depth=2
	leaq	(%rdi,%rcx), %r14
	addq	$-8, %r14
	movzwl	4(%r14), %r15d
	movw	%r15w, 4(%rbx)
	movl	(%r14), %r14d
	movl	%r14d, (%rbx)
	addq	$-8, %rcx
	jne	LBB7_31
	jmp	LBB7_33
LBB7_35:
	addq	$8, %rdx
	cmpq	%rsi, %rdx
	sete	%al
LBB7_37:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
	.p2align	2
	.data_region jt32
L7_0_set_37 = LBB7_37-LJTI7_0
L7_0_set_2 = LBB7_2-LJTI7_0
L7_0_set_4 = LBB7_4-LJTI7_0
L7_0_set_12 = LBB7_12-LJTI7_0
L7_0_set_13 = LBB7_13-LJTI7_0
LJTI7_0:
	.long	L7_0_set_37
	.long	L7_0_set_37
	.long	L7_0_set_2
	.long	L7_0_set_4
	.long	L7_0_set_12
	.long	L7_0_set_13
	.end_data_region
                                        ## -- End function
	.section	__TEXT,__cstring,cstring_literals
L_.str:                                 ## @.str
	.asciz	"Huffman capacity"

L_.str.1:                               ## @.str.1
	.asciz	"Huffman output extent"

L_.str.2:                               ## @.str.2
	.asciz	"Huffman stored extent"

L_.str.3:                               ## @.str.3
	.asciz	"Huffman constant extent"

L_.str.4:                               ## @.str.4
	.asciz	"Huffman coding"

L_.str.5:                               ## @.str.5
	.asciz	"Huffman coded extent"

L_.str.6:                               ## @.str.6
	.asciz	"Huffman stream extent"

L_.str.8:                               ## @.str.8
	.asciz	"Huffman nondegenerate population"

L_.str.9:                               ## @.str.9
	.asciz	"package-merge shape"

L_.str.10:                              ## @.str.10
	.asciz	"package-merge feasibility"

L_.str.11:                              ## @.str.11
	.asciz	"Huffman code length"

L_.str.12:                              ## @.str.12
	.asciz	"Huffman prefix population"

L_.str.13:                              ## @.str.13
	.asciz	"Huffman complete tree"

L_.str.14:                              ## @.str.14
	.asciz	"Huffman table capacity"

L_.str.15:                              ## @.str.15
	.asciz	"Huffman reserved table token"

L_.str.16:                              ## @.str.16
	.asciz	"Huffman table run"

L_.str.17:                              ## @.str.17
	.asciz	"Huffman table bound"

L_.str.18:                              ## @.str.18
	.asciz	"Huffman table padding"

L_.str.19:                              ## @.str.19
	.asciz	"Huffman table extent"

L_.str.20:                              ## @.str.20
	.asciz	"Huffman exact byte extent"

L_.str.21:                              ## @.str.21
	.asciz	"Huffman bit padding"

.subsections_via_symbols
