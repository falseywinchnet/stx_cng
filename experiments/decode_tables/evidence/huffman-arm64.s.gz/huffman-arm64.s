	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
lCPI0_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	6
__ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ; @_ZN18cng_huffman_kernel6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
; %bb.0:
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #2848
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset b8, -88
	.cfi_offset b9, -96
	.cfi_offset b10, -104
	.cfi_offset b11, -112
	.cfi_offset b12, -120
	.cfi_offset b13, -128
	.cfi_offset b14, -136
	.cfi_offset b15, -144
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-136]
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x1, x8
	b.hi	LBB0_124
; %bb.1:
	mov	x20, x1
	lsl	x8, x1, #1
	add	x8, x8, #512
	cmp	x3, x8
	b.lo	LBB0_124
; %bb.2:
	mov	x19, x2
	strb	wzr, [x2]
	strb	w20, [x2, #1]
	lsr	x8, x20, #8
	strb	w8, [x2, #2]
	lsr	x8, x20, #16
	strb	w8, [x2, #3]
	strb	wzr, [x2, #4]
	cbz	x20, LBB0_16
; %bb.3:
	mov	x21, x0
	add	x22, sp, #3592
	add	x0, sp, #3592
	mov	w1, #1024                       ; =0x400
	bl	_bzero
	add	x23, sp, #520
	add	x0, sp, #520
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	mov	x8, #0                          ; =0x0
	ands	x9, x20, #0x3ffffc
	b.eq	LBB0_6
; %bb.4:
	add	x10, x23, #1024
	add	x11, x23, #2048
LBB0_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x12, x21, x8
	ldrb	w13, [x12]
	ldr	w14, [x22, x13, lsl #2]
	add	w14, w14, #1
	str	w14, [x22, x13, lsl #2]
	ldrb	w13, [x12, #1]
	ldr	w14, [x23, x13, lsl #2]
	add	w14, w14, #1
	str	w14, [x23, x13, lsl #2]
	ldrb	w13, [x12, #2]
	ldr	w14, [x10, x13, lsl #2]
	add	w14, w14, #1
	str	w14, [x10, x13, lsl #2]
	ldrb	w12, [x12, #3]
	ldr	w13, [x11, x12, lsl #2]
	add	w13, w13, #1
	str	w13, [x11, x12, lsl #2]
	add	x8, x8, #4
	cmp	x8, x9
	b.lo	LBB0_5
LBB0_6:
	subs	x9, x20, x8
	b.ls	LBB0_9
; %bb.7:
	add	x8, x21, x8
	add	x10, sp, #3592
LBB0_8:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x8], #1
	ldr	w12, [x10, x11, lsl #2]
	add	w12, w12, #1
	str	w12, [x10, x11, lsl #2]
	subs	x9, x9, #1
	b.ne	LBB0_8
LBB0_9:
	add	x23, sp, #3592
	add	x8, sp, #520
	mov	w9, #2096                       ; =0x830
	add	x10, sp, #3592
LBB0_10:                                ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	add	x11, x10, x9
	sub	x12, x11, #2096
	sub	x13, x11, #2080
	sub	x14, x11, #2064
	sub	x11, x11, #2048
	ldr	q4, [x12]
	ldr	q5, [x13]
	ldr	q6, [x14]
	ldr	q7, [x11]
	ldr	q16, [x8, #1024]
	ldr	q17, [x8, #1040]
	ldr	q18, [x8, #1056]
	ldr	q19, [x8, #1072]
	add.4s	v0, v16, v0
	add.4s	v1, v17, v1
	add.4s	v2, v18, v2
	add.4s	v3, v19, v3
	ldr	q16, [x8, #2048]
	ldr	q17, [x8, #2064]
	ldr	q18, [x8, #2080]
	ldr	q19, [x8, #2096]
	add.4s	v0, v16, v0
	add.4s	v0, v0, v4
	add.4s	v1, v17, v1
	add.4s	v1, v1, v5
	add.4s	v2, v18, v2
	add.4s	v2, v2, v6
	add.4s	v3, v19, v3
	add.4s	v3, v3, v7
	str	q0, [x12]
	str	q1, [x13]
	str	q2, [x14]
	str	q3, [x11]
	add	x9, x9, #64
	add	x8, x8, #64
	cmp	x9, #3120
	b.ne	LBB0_10
; %bb.11:
	mov	x8, #0                          ; =0x0
	dup.4s	v1, w20
	movi.2d	v0, #0000000000000000
	mov	w9, #1                          ; =0x1
	dup.2d	v16, x9
	movi.16b	v17, #16
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
Lloh3:
	adrp	x9, lCPI0_0@PAGE
Lloh4:
	ldr	q23, [x9, lCPI0_0@PAGEOFF]
	movi.2d	v20, #0000000000000000
	add	x9, sp, #3592
	movi.2d	v19, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	mov.16b	v21, v1
	mov.16b	v22, v1
	mov.16b	v25, v1
LBB0_12:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x9, x8
	ldp	q30, q29, [x10, #32]
	cmtst.4s	v31, v29, v29
	cmtst.4s	v8, v30, v30
	uzp1.8h	v9, v8, v31
	ldp	q11, q10, [x10]
	cmtst.4s	v12, v10, v10
	cmtst.4s	v13, v11, v11
	uzp1.8h	v14, v13, v12
	uzp1.16b	v9, v14, v9
	orr.16b	v4, v4, v9
	bit.16b	v2, v23, v9
	ushll2.2d	v9, v8, #0
	and.16b	v9, v9, v16
	add.2d	v24, v24, v9
	ushll2.2d	v9, v12, #0
	and.16b	v9, v9, v16
	add.2d	v19, v19, v9
	ushll2.2d	v9, v13, #0
	and.16b	v9, v9, v16
	add.2d	v7, v7, v9
	ushll2.2d	v9, v31, #0
	and.16b	v9, v9, v16
	add.2d	v26, v26, v9
	ushll.2d	v31, v31, #0
	and.16b	v31, v31, v16
	add.2d	v28, v28, v31
	ushll.2d	v31, v8, #0
	and.16b	v31, v31, v16
	add.2d	v27, v27, v31
	ushll.2d	v31, v12, #0
	and.16b	v31, v31, v16
	add.2d	v20, v20, v31
	ushll.2d	v31, v13, #0
	and.16b	v31, v31, v16
	add.2d	v18, v18, v31
	umin.4s	v1, v29, v1
	umax.4s	v6, v6, v29
	umin.4s	v25, v30, v25
	umax.4s	v5, v5, v30
	umin.4s	v22, v10, v22
	umax.4s	v0, v0, v10
	umin.4s	v21, v11, v21
	umax.4s	v3, v3, v11
	add	x8, x8, #64
	add.16b	v23, v23, v17
	cmp	x8, #1024
	b.ne	LBB0_12
; %bb.13:
	add.2d	v16, v18, v27
	add.2d	v17, v20, v28
	add.2d	v16, v16, v17
	add.2d	v7, v7, v24
	add.2d	v17, v19, v26
	add.2d	v7, v7, v17
	add.2d	v7, v16, v7
	addp.2d	d7, v7
	fmov	x8, d7
	cmp	x8, #256
	b.eq	LBB0_17
; %bb.14:
	cmp	x8, #1
	b.ne	LBB0_18
; %bb.15:
	shl.16b	v0, v4, #7
	cmlt.16b	v0, v0, #0
	addp.2d	d0, v0
	umaxv.16b	b1, v2
	fmov	w8, s1
	fmov	x9, d0
	cmp	x9, #0
	csel	w8, wzr, w8, eq
	mov	w9, #4                          ; =0x4
	strb	w9, [x19]
	strb	w8, [x19, #5]
	mov	w22, #6                         ; =0x6
	b	LBB0_118
LBB0_16:
	mov	w22, #5                         ; =0x5
	b	LBB0_118
LBB0_17:
	umin.4s	v2, v21, v25
	umin.4s	v1, v22, v1
	umin.4s	v1, v2, v1
	uminv.4s	s1, v1
	fmov	w8, s1
	umax.4s	v1, v3, v5
	umax.4s	v0, v0, v6
	umax.4s	v0, v1, v0
	umaxv.4s	s0, v0
	fmov	w9, s0
	cmp	w9, w8, lsl #1
	b.ls	LBB0_29
LBB0_18:
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #15104]
	str	q0, [sp, #15088]
	str	q0, [sp, #15072]
	str	q0, [sp, #15056]
	str	q0, [sp, #15040]
	str	q0, [sp, #15024]
	str	q0, [sp, #15008]
	str	q0, [sp, #14992]
	str	q0, [sp, #14976]
	str	q0, [sp, #14960]
	str	q0, [sp, #14944]
	str	q0, [sp, #14928]
	str	q0, [sp, #14912]
	str	q0, [sp, #14896]
	str	q0, [sp, #14880]
	str	q0, [sp, #14864]
	stp	q0, q0, [sp, #480]
	stp	q0, q0, [sp, #448]
	stp	q0, q0, [sp, #416]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #320]
	stp	q0, q0, [sp, #288]
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	add	x22, sp, #3, lsl #12            ; =12288
	add	x22, x22, #528
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #528
	mov	w1, #2048                       ; =0x800
	bl	_bzero
	mov	x8, #0                          ; =0x0
LBB0_19:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x22, x8
	str	wzr, [x9]
	str	wzr, [x9, #8]
	str	wzr, [x9, #16]
	str	wzr, [x9, #24]
	strh	wzr, [x9, #4]
	strh	wzr, [x9, #12]
	strh	wzr, [x9, #20]
	add	x8, x8, #32
	strh	wzr, [x9, #28]
	cmp	x8, #2048
	b.ne	LBB0_19
; %bb.20:
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #2580
	mov	w1, #2044                       ; =0x7fc
	bl	_bzero
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2584
	mov	w1, #4088                       ; =0xff8
	bl	_bzero
	mov	x22, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	add	x9, sp, #3592
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #528
	b	LBB0_22
LBB0_21:                                ;   in Loop: Header=BB0_22 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB0_24
LBB0_22:                                ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x9, x8, lsl #2]
	cbz	w11, LBB0_21
; %bb.23:                               ;   in Loop: Header=BB0_22 Depth=1
	add	x12, x10, x22, lsl #3
	str	w11, [x12]
	strh	w8, [x12, #4]
	add	x22, x22, #1
	b	LBB0_21
LBB0_24:
	subs	x24, x22, #1
	b.ls	LBB0_129
; %bb.25:
	add	x25, sp, #3, lsl #12            ; =12288
	add	x25, x25, #528
	add	x1, x25, x22, lsl #3
	clz	x8, x22
	lsl	x8, x8, #1
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #528
	eor	x2, x8, #0x7e
	mov	w3, #1                          ; =0x1
	bl	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	cmp	x22, #5
	b.hs	LBB0_27
; %bb.26:
	mov	x8, #0                          ; =0x0
	b	LBB0_35
LBB0_27:
	cmp	x22, #17
	b.hs	LBB0_30
; %bb.28:
	mov	x8, #0                          ; =0x0
	b	LBB0_33
LBB0_29:
	add	x0, x19, #5
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	add	x22, x20, #5
	b	LBB0_118
LBB0_30:
	ands	x8, x22, #0xf
	mov	w9, #16                         ; =0x10
	csel	x9, x9, x8, eq
	sub	x8, x22, x9
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #528
	add	x10, x10, #64
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #2580
	add	x11, x11, #32
	mov	x12, x22
LBB0_31:                                ; =>This Inner Loop Header: Depth=1
	sub	x13, x10, #40
	sub	x14, x10, #48
	ldur	q0, [x10, #-64]
	mov.s	v0[1], v0[2]
	ld1.s	{ v0 }[2], [x14]
	ld1.s	{ v0 }[3], [x13]
	sub	x13, x10, #16
	ldur	q1, [x10, #-32]
	mov.s	v1[1], v1[2]
	ld1.s	{ v1 }[2], [x13]
	sub	x13, x10, #8
	ld1.s	{ v1 }[3], [x13]
	add	x13, x10, #24
	add	x14, x10, #16
	ldr	q2, [x10]
	mov.s	v2[1], v2[2]
	ld1.s	{ v2 }[2], [x14]
	ld1.s	{ v2 }[3], [x13]
	add	x13, x10, #56
	add	x14, x10, #48
	ldr	q3, [x10, #32]
	mov.s	v3[1], v3[2]
	ld1.s	{ v3 }[2], [x14]
	ld1.s	{ v3 }[3], [x13]
	stp	q0, q1, [x11, #-32]
	stp	q2, q3, [x11], #64
	add	x10, x10, #128
	sub	x12, x12, #16
	cmp	x9, x12
	b.ne	LBB0_31
; %bb.32:
	cmp	x9, #4
	b.ls	LBB0_35
LBB0_33:
	mov	x11, x8
	ands	x8, x22, #0x3
	mov	w9, #4                          ; =0x4
	csel	x12, x9, x8, eq
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #2580
	add	x9, x8, x11, lsl #2
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #528
	add	x10, x8, x11, lsl #3
	sub	x8, x22, x12
	add	x11, x12, x11
	sub	x11, x11, x22
LBB0_34:                                ; =>This Inner Loop Header: Depth=1
	add	x12, x10, #24
	add	x13, x10, #16
	ldr	q0, [x10], #32
	mov.s	v0[1], v0[2]
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	str	q0, [x9], #16
	adds	x11, x11, #4
	b.ne	LBB0_34
LBB0_35:
	add	x9, x25, x8, lsl #3
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2580
LBB0_36:                                ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x9], #8
	str	w11, [x10, x8, lsl #2]
	add	x8, x8, #1
	cmp	x22, x8
	b.ne	LBB0_36
; %bb.37:
	str	xzr, [sp, #6672]
	str	x22, [sp, #6664]
	lsl	x8, x22, #1
	sub	x9, x8, #1
	cmp	x22, x9
	b.hs	LBB0_49
; %bb.38:
	mov	x9, #0                          ; =0x0
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2580
	add	x11, x10, x22, lsl #2
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2584
	b	LBB0_41
LBB0_39:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #2568
LBB0_40:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x16, x15, #1
	ldr	w0, [x10, x14, lsl #2]
	str	x16, [x17]
	ldr	w16, [x10, x15, lsl #2]
	add	w16, w16, w0
	str	w16, [x11, x9, lsl #2]
	str	x13, [x12, x14, lsl #3]
	str	x13, [x12, x15, lsl #3]
	add	x9, x9, #1
	cmp	x24, x9
	b.eq	LBB0_49
LBB0_41:                                ; =>This Inner Loop Header: Depth=1
	add	x13, x22, x9
	ldr	x15, [sp, #6672]
	ldr	x14, [sp, #6664]
	cmp	x15, x22
	b.hs	LBB0_44
; %bb.42:                               ;   in Loop: Header=BB0_41 Depth=1
	cmp	x13, x14
	b.eq	LBB0_45
; %bb.43:                               ;   in Loop: Header=BB0_41 Depth=1
	ldr	w16, [x10, x15, lsl #2]
	ldr	w17, [x10, x14, lsl #2]
	cmp	w16, w17
	b.ls	LBB0_45
LBB0_44:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #2568
	add	x15, x14, #1
	str	x15, [x16]
	ldr	x16, [sp, #6672]
	ldr	x15, [sp, #6664]
	cmp	x16, x22
	b.hs	LBB0_39
	b	LBB0_46
LBB0_45:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #2576
	mov	x14, x15
	add	x15, x15, #1
	str	x15, [x16]
	ldr	x16, [sp, #6672]
	ldr	x15, [sp, #6664]
	cmp	x16, x22
	b.hs	LBB0_39
LBB0_46:                                ;   in Loop: Header=BB0_41 Depth=1
	cmp	x13, x15
	b.eq	LBB0_48
; %bb.47:                               ;   in Loop: Header=BB0_41 Depth=1
	ldr	w17, [x10, x16, lsl #2]
	ldr	w0, [x10, x15, lsl #2]
	cmp	w17, w0
	b.hi	LBB0_39
LBB0_48:                                ;   in Loop: Header=BB0_41 Depth=1
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #2576
	mov	x15, x16
	b	LBB0_40
LBB0_49:
	mov	x10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	sub	x8, x8, #2
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #528
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #2576
	add	x13, sp, #1, lsl #12            ; =4096
	add	x13, x13, #2584
	b	LBB0_52
LBB0_50:                                ;   in Loop: Header=BB0_52 Depth=1
	mov	w14, #0                         ; =0x0
	.p2align	6, , 4
LBB0_51:                                ;   in Loop: Header=BB0_52 Depth=1
	cmp	w9, w14
	csel	w9, w9, w14, hi
	add	x15, x11, x10, lsl #3
	ldrh	w15, [x15, #4]
	strb	w14, [x12, x15]
	add	x10, x10, #1
	cmp	x10, x22
	b.eq	LBB0_55
LBB0_52:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_54 Depth 2
	cmp	x10, x8
	b.eq	LBB0_50
; %bb.53:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w14, #0                         ; =0x0
	mov	x15, x10
LBB0_54:                                ;   Parent Loop BB0_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w14, w14, #1
	ldr	x15, [x13, x15, lsl #3]
	cmp	x15, x8
	b.ne	LBB0_54
	b	LBB0_51
LBB0_55:
	cmp	w9, #13
	b.lo	LBB0_62
; %bb.56:
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #520
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #520
	mov	w1, #2048                       ; =0x800
	bl	_bzero
	and	x8, x22, #0xfffffffffffffffe
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #528
	add	x9, x9, #8
	add	x10, x24, #8
	and	x11, x22, #0xfffffffffffffffe
LBB0_57:                                ; =>This Inner Loop Header: Depth=1
	ldur	w12, [x9, #-8]
	ldr	w13, [x9]
	ldurh	w14, [x9, #-4]
	ldrh	w15, [x9, #4]
	stur	w12, [x10, #-8]
	str	w13, [x10]
	sturh	w14, [x10, #-4]
	strh	w15, [x10, #4]
	add	x9, x9, #16
	add	x10, x10, #16
	subs	x11, x11, #2
	b.ne	LBB0_57
; %bb.58:
	subs	x8, x22, x8
	b.eq	LBB0_61
; %bb.59:
	lsl	x9, x22, #3
	and	x10, x9, #0xfffffffffffffff0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #520
	add	x9, x9, x10
	add	x9, x9, #4
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #528
	add	x10, x11, x10
	add	x10, x10, #4
LBB0_60:                                ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x10, #-4]
	ldrh	w12, [x10], #8
	stur	w11, [x9, #-4]
	strh	w12, [x9], #8
	subs	x8, x8, #1
	b.ne	LBB0_60
LBB0_61:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #520
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #2576
	mov	x1, x22
	mov	w2, #12                         ; =0xc
	bl	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
LBB0_62:
	add	x22, sp, #3, lsl #12            ; =12288
	add	x22, x22, #2576
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #2576
	mov	x1, sp
	bl	__ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	mov	x8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	q0, [sp, #14864]
	ldr	q1, [sp, #14880]
	ushll2.8h	v2, v0, #0
	ushll.4s	v3, v2, #0
	ushll.8h	v0, v0, #0
	ushll.4s	v6, v0, #0
	ushll2.4s	v2, v2, #0
	ushll2.4s	v0, v0, #0
	ushll2.8h	v4, v1, #0
	ldp	q7, q5, [x23, #32]
	ushll.4s	v16, v4, #0
	ushll.8h	v1, v1, #0
	ldp	q17, q18, [x23]
	ushll.4s	v19, v1, #0
	ushll2.4s	v20, v4, #0
	ushll2.4s	v1, v1, #0
	ldp	q21, q22, [x23, #96]
	mul.4s	v4, v18, v0
	mul.4s	v5, v5, v2
	mul.4s	v6, v17, v6
	ldp	q2, q0, [x23, #64]
	mul.4s	v7, v7, v3
	mul.4s	v0, v0, v1
	mul.4s	v1, v22, v20
	mul.4s	v2, v2, v19
	mul.4s	v3, v21, v16
	ldr	q16, [sp, #14896]
	ldr	q17, [sp, #14912]
	ushll2.8h	v18, v16, #0
	ldp	q19, q20, [x23, #160]
	ushll.4s	v21, v18, #0
	ushll.8h	v16, v16, #0
	ushll.4s	v22, v16, #0
	ldp	q23, q24, [x23, #128]
	ushll2.4s	v18, v18, #0
	ushll2.4s	v16, v16, #0
	ushll2.8h	v25, v17, #0
	ldp	q26, q27, [x23, #224]
	ushll.4s	v28, v25, #0
	ushll.8h	v17, v17, #0
	ushll.4s	v29, v17, #0
	ldp	q30, q31, [x23, #192]
	ushll2.4s	v25, v25, #0
	ushll2.4s	v17, v17, #0
	mul.4s	v24, v24, v16
	mul.4s	v20, v20, v18
	mul.4s	v22, v23, v22
	mul.4s	v19, v19, v21
	mul.4s	v21, v31, v17
	mul.4s	v23, v27, v25
	mul.4s	v25, v30, v29
	mul.4s	v26, v26, v28
	uaddl2.2d	v16, v4, v24
	uaddl2.2d	v17, v5, v20
	uaddl2.2d	v18, v6, v22
	uaddl2.2d	v27, v7, v19
	uaddl.2d	v24, v4, v24
	uaddl.2d	v20, v5, v20
	uaddl.2d	v6, v6, v22
	uaddl.2d	v19, v7, v19
	uaddl2.2d	v4, v0, v21
	uaddl2.2d	v5, v1, v23
	uaddl2.2d	v7, v2, v25
	uaddl2.2d	v22, v3, v26
	uaddl.2d	v21, v0, v21
	uaddl.2d	v23, v1, v23
	uaddl.2d	v2, v2, v25
	uaddl.2d	v1, v3, v26
	ldp	q3, q0, [x23, #256]
	ldp	q26, q25, [x23, #288]
	ldp	q29, q28, [x23, #320]
	ldp	q31, q30, [x23, #352]
	ldr	q8, [sp, #14928]
	ldr	q9, [sp, #14944]
	ushll.8h	v10, v8, #0
	ushll2.4s	v11, v10, #0
	ushll2.8h	v8, v8, #0
	ushll2.4s	v12, v8, #0
	ushll.4s	v10, v10, #0
	ushll.4s	v8, v8, #0
	ushll.8h	v13, v9, #0
	ushll2.4s	v14, v13, #0
	ushll2.8h	v9, v9, #0
	ushll2.4s	v15, v9, #0
	ushll.4s	v13, v13, #0
	ushll.4s	v9, v9, #0
	mul.4s	v26, v26, v8
	mul.4s	v8, v3, v10
	mul.4s	v25, v25, v12
	mul.4s	v10, v0, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw.2d	v0, v19, v26
	uaddw.2d	v3, v6, v8
	uaddw.2d	v19, v20, v25
	uaddw.2d	v20, v24, v10
	uaddw2.2d	v24, v27, v26
	uaddw2.2d	v18, v18, v8
	uaddw2.2d	v17, v17, v25
	uaddw2.2d	v25, v16, v10
	uaddw.2d	v1, v1, v31
	uaddw.2d	v6, v2, v29
	uaddw.2d	v16, v23, v30
	uaddw.2d	v21, v21, v28
	uaddw2.2d	v22, v22, v31
	uaddw2.2d	v23, v7, v29
	uaddw2.2d	v5, v5, v30
	uaddw2.2d	v26, v4, v28
	ldp	q2, q4, [x23, #416]
	ldp	q7, q27, [x23, #384]
	ldp	q28, q29, [x23, #480]
	ldp	q30, q31, [x23, #448]
	ldr	q8, [sp, #14960]
	ldr	q9, [sp, #14976]
	ushll2.8h	v10, v8, #0
	ushll.4s	v11, v10, #0
	ushll.8h	v8, v8, #0
	ushll.4s	v12, v8, #0
	ushll2.4s	v10, v10, #0
	ushll2.4s	v8, v8, #0
	ushll2.8h	v13, v9, #0
	ushll.4s	v14, v13, #0
	ushll.8h	v9, v9, #0
	ushll.4s	v15, v9, #0
	ushll2.4s	v13, v13, #0
	ushll2.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v4, v10
	mul.4s	v10, v7, v12
	mul.4s	v11, v2, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw2.2d	v2, v25, v27
	uaddw2.2d	v4, v17, v8
	uaddw2.2d	v7, v18, v10
	uaddw2.2d	v18, v24, v11
	uaddw.2d	v20, v20, v27
	uaddw.2d	v19, v19, v8
	uaddw.2d	v24, v3, v10
	uaddw.2d	v25, v0, v11
	uaddw2.2d	v0, v26, v31
	uaddw2.2d	v3, v5, v29
	uaddw2.2d	v17, v23, v30
	uaddw2.2d	v22, v22, v28
	uaddw.2d	v21, v21, v31
	uaddw.2d	v16, v16, v29
	uaddw.2d	v23, v6, v30
	uaddw.2d	v26, v1, v28
	ldp	q5, q1, [x23, #512]
	ldp	q27, q6, [x23, #544]
	ldp	q29, q28, [x23, #576]
	ldp	q31, q30, [x23, #608]
	ldr	q8, [sp, #14992]
	ldr	q9, [sp, #15008]
	ushll.8h	v10, v8, #0
	ushll2.4s	v11, v10, #0
	ushll2.8h	v8, v8, #0
	ushll2.4s	v12, v8, #0
	ushll.4s	v10, v10, #0
	ushll.4s	v8, v8, #0
	ushll.8h	v13, v9, #0
	ushll2.4s	v14, v13, #0
	ushll2.8h	v9, v9, #0
	ushll2.4s	v15, v9, #0
	ushll.4s	v13, v13, #0
	ushll.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v5, v10
	mul.4s	v10, v6, v12
	mul.4s	v11, v1, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw.2d	v1, v25, v27
	uaddw.2d	v5, v24, v8
	uaddw.2d	v6, v19, v10
	uaddw.2d	v19, v20, v11
	uaddw2.2d	v18, v18, v27
	uaddw2.2d	v20, v7, v8
	uaddw2.2d	v24, v4, v10
	uaddw2.2d	v25, v2, v11
	uaddw.2d	v2, v26, v31
	uaddw.2d	v4, v23, v29
	uaddw.2d	v7, v16, v30
	uaddw.2d	v21, v21, v28
	uaddw2.2d	v22, v22, v31
	uaddw2.2d	v17, v17, v29
	uaddw2.2d	v23, v3, v30
	uaddw2.2d	v26, v0, v28
	ldp	q0, q3, [x23, #672]
	ldp	q16, q27, [x23, #640]
	ldp	q28, q29, [x23, #736]
	ldp	q30, q31, [x23, #704]
	ldr	q8, [sp, #15024]
	ldr	q9, [sp, #15040]
	ushll2.8h	v10, v8, #0
	ushll.4s	v11, v10, #0
	ushll.8h	v8, v8, #0
	ushll.4s	v12, v8, #0
	ushll2.4s	v10, v10, #0
	ushll2.4s	v8, v8, #0
	ushll2.8h	v13, v9, #0
	ushll.4s	v14, v13, #0
	ushll.8h	v9, v9, #0
	ushll.4s	v15, v9, #0
	ushll2.4s	v13, v13, #0
	ushll2.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v3, v10
	mul.4s	v10, v16, v12
	mul.4s	v11, v0, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw2.2d	v0, v25, v27
	uaddw2.2d	v3, v24, v8
	uaddw2.2d	v16, v20, v10
	uaddw2.2d	v18, v18, v11
	uaddw.2d	v19, v19, v27
	uaddw.2d	v20, v6, v8
	uaddw.2d	v24, v5, v10
	uaddw.2d	v25, v1, v11
	uaddw2.2d	v1, v26, v31
	uaddw2.2d	v5, v23, v29
	uaddw2.2d	v6, v17, v30
	uaddw2.2d	v17, v22, v28
	uaddw.2d	v21, v21, v31
	uaddw.2d	v22, v7, v29
	uaddw.2d	v23, v4, v30
	uaddw.2d	v26, v2, v28
	ldp	q4, q2, [x23, #768]
	ldp	q27, q7, [x23, #800]
	ldp	q29, q28, [x23, #832]
	ldp	q31, q30, [x23, #864]
	ldr	q8, [sp, #15056]
	ldr	q9, [sp, #15072]
	ushll.8h	v10, v8, #0
	ushll2.4s	v11, v10, #0
	ushll2.8h	v8, v8, #0
	ushll2.4s	v12, v8, #0
	ushll.4s	v10, v10, #0
	ushll.4s	v8, v8, #0
	ushll.8h	v13, v9, #0
	ushll2.4s	v14, v13, #0
	ushll2.8h	v9, v9, #0
	ushll2.4s	v15, v9, #0
	ushll.4s	v13, v13, #0
	ushll.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v8, v4, v10
	mul.4s	v10, v7, v12
	mul.4s	v11, v2, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw.2d	v2, v25, v27
	uaddw.2d	v4, v24, v8
	uaddw.2d	v7, v20, v10
	uaddw.2d	v19, v19, v11
	uaddw2.2d	v18, v18, v27
	uaddw2.2d	v20, v16, v8
	uaddw2.2d	v24, v3, v10
	uaddw2.2d	v25, v0, v11
	uaddw.2d	v0, v26, v31
	uaddw.2d	v3, v23, v29
	uaddw.2d	v16, v22, v30
	uaddw.2d	v21, v21, v28
	uaddw2.2d	v17, v17, v31
	uaddw2.2d	v6, v6, v29
	uaddw2.2d	v5, v5, v30
	uaddw2.2d	v1, v1, v28
	ldp	q22, q23, [x23, #928]
	ldp	q26, q27, [x23, #896]
	ldp	q28, q29, [x23, #992]
	ldp	q30, q31, [x23, #960]
	ldr	q8, [sp, #15088]
	ldr	q9, [sp, #15104]
	ushll2.8h	v10, v8, #0
	ushll.4s	v11, v10, #0
	ushll.8h	v8, v8, #0
	ushll.4s	v12, v8, #0
	ushll2.4s	v10, v10, #0
	ushll2.4s	v8, v8, #0
	ushll2.8h	v13, v9, #0
	ushll.4s	v14, v13, #0
	ushll.8h	v9, v9, #0
	ushll.4s	v15, v9, #0
	ushll2.4s	v13, v13, #0
	ushll2.4s	v9, v9, #0
	mul.4s	v27, v27, v8
	mul.4s	v23, v23, v10
	mul.4s	v26, v26, v12
	mul.4s	v22, v22, v11
	mul.4s	v31, v31, v9
	mul.4s	v29, v29, v13
	mul.4s	v30, v30, v15
	mul.4s	v28, v28, v14
	uaddw2.2d	v25, v25, v27
	uaddw2.2d	v24, v24, v23
	uaddw2.2d	v20, v20, v26
	uaddw2.2d	v18, v18, v22
	uaddw.2d	v19, v19, v27
	uaddw.2d	v7, v7, v23
	uaddw.2d	v4, v4, v26
	uaddw.2d	v2, v2, v22
	uaddw2.2d	v1, v1, v31
	uaddw2.2d	v5, v5, v29
	uaddw2.2d	v6, v6, v30
	uaddw2.2d	v17, v17, v28
	uaddw.2d	v21, v21, v31
	uaddw.2d	v16, v16, v29
	uaddw.2d	v3, v3, v30
	uaddw.2d	v0, v0, v28
	add.2d	v0, v0, v2
	add.2d	v2, v3, v4
	add.2d	v3, v16, v7
	add.2d	v4, v21, v19
	add.2d	v7, v17, v18
	add.2d	v6, v6, v20
	add.2d	v5, v5, v24
	add.2d	v1, v1, v25
	add.2d	v1, v1, v5
	add.2d	v5, v6, v7
	add.2d	v1, v5, v1
	add.2d	v3, v4, v3
	add.2d	v0, v2, v0
	add.2d	v0, v0, v3
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x11, d0
	add	x0, x19, #5
	mov	w12, #256                       ; =0x100
	mov	w13, #15                        ; =0xf
	b	LBB0_66
LBB0_63:                                ;   in Loop: Header=BB0_66 Depth=1
	lsl	w15, w16, #4
	sub	w15, w15, #34
LBB0_64:                                ;   in Loop: Header=BB0_66 Depth=1
	strb	w15, [x0, x10]
	add	x10, x14, #2
LBB0_65:                                ;   in Loop: Header=BB0_66 Depth=1
	cmp	x8, #256
	b.hs	LBB0_102
LBB0_66:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_69 Depth 2
	mov	x14, x8
	ldrb	w15, [x22, x8]
	cmp	x8, #255
	b.ne	LBB0_68
; %bb.67:                               ;   in Loop: Header=BB0_66 Depth=1
	mov	w8, #256                        ; =0x100
	b	LBB0_71
LBB0_68:                                ;   in Loop: Header=BB0_66 Depth=1
	add	x8, x14, #1
LBB0_69:                                ;   Parent Loop BB0_66 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w16, [x22, x8]
	cmp	w16, w15
	b.ne	LBB0_71
; %bb.70:                               ;   in Loop: Header=BB0_69 Depth=2
	add	x8, x8, #1
	cmp	x8, #256
	b.ne	LBB0_69
LBB0_71:                                ;   in Loop: Header=BB0_66 Depth=1
	sub	x16, x8, x14
	cmp	w15, w9, uxtb
	b.ne	LBB0_78
; %bb.72:                               ;   in Loop: Header=BB0_66 Depth=1
	mov	x14, x10
	subs	x10, x16, #19
	b.lo	LBB0_83
LBB0_73:                                ;   in Loop: Header=BB0_66 Depth=1
	cmp	x14, #256
	b.hs	LBB0_120
; %bb.74:                               ;   in Loop: Header=BB0_66 Depth=1
	lsr	x15, x14, #1
	tbnz	w14, #0, LBB0_97
; %bb.75:                               ;   in Loop: Header=BB0_66 Depth=1
	orr	w16, w13, w10, lsl #4
	strb	w16, [x0, x15]
	cmp	x14, #253
	b.hi	LBB0_121
; %bb.76:                               ;   in Loop: Header=BB0_66 Depth=1
	lsr	x10, x10, #4
	and	w15, w10, #0xff
	cmp	w15, #16
	b.hs	LBB0_121
; %bb.77:                               ;   in Loop: Header=BB0_66 Depth=1
	add	x15, x14, #2
	lsr	x15, x15, #1
	strb	w10, [x0, x15]
	add	x10, x14, #3
	b	LBB0_65
LBB0_78:                                ;   in Loop: Header=BB0_66 Depth=1
	cmp	x10, #255
	b.hi	LBB0_122
; %bb.79:                               ;   in Loop: Header=BB0_66 Depth=1
	cmp	w15, #16
	b.hs	LBB0_122
; %bb.80:                               ;   in Loop: Header=BB0_66 Depth=1
	lsr	x9, x10, #1
	tbnz	w10, #0, LBB0_82
; %bb.81:                               ;   in Loop: Header=BB0_66 Depth=1
	strb	w15, [x0, x9]
	add	x14, x10, #1
	sub	x16, x16, #1
	mov	x9, x15
	subs	x10, x16, #19
	b.hs	LBB0_73
	b	LBB0_83
LBB0_82:                                ;   in Loop: Header=BB0_66 Depth=1
	ldrb	w14, [x0, x9]
	orr	w14, w14, w15, lsl #4
	strb	w14, [x0, x9]
	add	x14, x10, #1
	sub	x16, x16, #1
	mov	x9, x15
	subs	x10, x16, #19
	b.hs	LBB0_73
LBB0_83:                                ;   in Loop: Header=BB0_66 Depth=1
	cmp	x16, #2
	b.ls	LBB0_88
; %bb.84:                               ;   in Loop: Header=BB0_66 Depth=1
	cmp	x14, #256
	b.hs	LBB0_125
; %bb.85:                               ;   in Loop: Header=BB0_66 Depth=1
	lsr	x10, x14, #1
	tbz	w14, #0, LBB0_63
; %bb.86:                               ;   in Loop: Header=BB0_66 Depth=1
	ldrb	w15, [x0, x10]
	orr	w15, w15, #0xe0
	strb	w15, [x0, x10]
	cmp	x14, #255
	b.eq	LBB0_128
; %bb.87:                               ;   in Loop: Header=BB0_66 Depth=1
	add	x10, x14, #1
	sub	w15, w16, #3
	lsr	x10, x10, #1
	b	LBB0_64
LBB0_88:                                ;   in Loop: Header=BB0_66 Depth=1
	cbz	x16, LBB0_101
; %bb.89:                               ;   in Loop: Header=BB0_66 Depth=1
	cmp	w15, #15
	b.hi	LBB0_123
; %bb.90:                               ;   in Loop: Header=BB0_66 Depth=1
	subs	x10, x12, x14
	csel	x1, xzr, x10, lo
	cmp	x14, #255
	b.hi	LBB0_123
; %bb.91:                               ;   in Loop: Header=BB0_66 Depth=1
	lsl	w17, w15, #4
	lsr	x10, x14, #1
	mov	x2, x15
	tbz	w14, #0, LBB0_93
; %bb.92:                               ;   in Loop: Header=BB0_66 Depth=1
	ldrb	w2, [x0, x10]
	orr	w2, w2, w17
LBB0_93:                                ;   in Loop: Header=BB0_66 Depth=1
	strb	w2, [x0, x10]
	add	x10, x14, #1
	cmp	x16, #1
	b.eq	LBB0_65
; %bb.94:                               ;   in Loop: Header=BB0_66 Depth=1
	cmp	x1, #1
	b.eq	LBB0_123
; %bb.95:                               ;   in Loop: Header=BB0_66 Depth=1
	lsr	x10, x10, #1
	tbnz	w14, #0, LBB0_64
; %bb.96:                               ;   in Loop: Header=BB0_66 Depth=1
	ldrb	w15, [x0, x10]
	orr	w15, w15, w17
	b	LBB0_64
LBB0_97:                                ;   in Loop: Header=BB0_66 Depth=1
	ldrb	w10, [x0, x15]
	orr	w10, w10, #0xf0
	strb	w10, [x0, x15]
	cmp	x14, #255
	b.eq	LBB0_126
; %bb.98:                               ;   in Loop: Header=BB0_66 Depth=1
	add	x15, x14, #1
	sub	w10, w16, #19
	and	w16, w10, #0xf
	lsr	x15, x15, #1
	strb	w16, [x0, x15]
	cmp	x14, #253
	b.hi	LBB0_121
; %bb.99:                               ;   in Loop: Header=BB0_66 Depth=1
	ubfx	w10, w10, #4, #8
	cmp	w10, #16
	b.hs	LBB0_121
; %bb.100:                              ;   in Loop: Header=BB0_66 Depth=1
	add	x15, x14, #2
	lsr	x15, x15, #1
	ldrb	w16, [x0, x15]
	orr	w10, w16, w10, lsl #4
	strb	w10, [x0, x15]
	add	x10, x14, #3
	b	LBB0_65
LBB0_101:                               ;   in Loop: Header=BB0_66 Depth=1
	mov	x10, x14
	b	LBB0_65
LBB0_102:
	add	x8, x10, #1
	lsr	x9, x8, #1
	cmp	x20, #1025
	mov	w8, #4                          ; =0x4
	csinc	x8, x8, xzr, hs
	add	x12, x9, #5
	add	x9, x12, x8, lsl #2
	sub	x10, x9, #4
	add	x9, x10, x11, lsr #3
	add	x22, x20, #5
	cmp	x9, x22
	b.hs	LBB0_117
; %bb.103:
	mov	x9, #0                          ; =0x0
	mov	x13, #0                         ; =0x0
	mov	w11, #2                         ; =0x2
	cmp	x20, #1025
	csel	x11, xzr, x11, lo
	lsr	x11, x20, x11
	add	x12, x19, x12
	mov	x14, sp
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #2576
	mov	x16, x21
	mov	x17, x10
	b	LBB0_105
LBB0_104:                               ;   in Loop: Header=BB0_105 Depth=1
	sub	x9, x9, x11
	add	x16, x16, x11
	mov	x13, x1
	mov	x10, x17
	cmp	x1, x8
	b.eq	LBB0_115
LBB0_105:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_108 Depth 2
                                        ;     Child Loop BB0_112 Depth 2
	mul	x2, x13, x11
	add	x1, x13, #1
	add	x3, x2, x11
	cmp	x1, x8
	csel	x3, x20, x3, eq
	cmp	x2, x3
	b.hs	LBB0_113
; %bb.106:                              ;   in Loop: Header=BB0_105 Depth=1
	mov	w4, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	add	x3, x3, x9
	mov	x5, x16
	mov	x17, x10
	b	LBB0_108
LBB0_107:                               ;   in Loop: Header=BB0_108 Depth=2
	subs	x3, x3, #1
	b.eq	LBB0_110
LBB0_108:                               ;   Parent Loop BB0_105 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w6, [x5], #1
	ldrh	w7, [x14, x6, lsl #1]
	lsl	x7, x7, x4
	orr	x2, x7, x2
	ldrb	w6, [x15, x6]
	add	w4, w4, w6
	subs	w6, w4, #32
	b.lo	LBB0_107
; %bb.109:                              ;   in Loop: Header=BB0_108 Depth=2
	str	w2, [x19, x17]
	add	x17, x17, #4
	lsr	x2, x2, #32
	mov	x4, x6
	b	LBB0_107
LBB0_110:                               ;   in Loop: Header=BB0_105 Depth=1
	cbz	w4, LBB0_113
; %bb.111:                              ;   in Loop: Header=BB0_105 Depth=1
	add	w3, w4, #8
LBB0_112:                               ;   Parent Loop BB0_105 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	strb	w2, [x19, x17]
	add	x17, x17, #1
	lsr	x2, x2, #8
	sub	w3, w3, #8
	cmp	w3, #8
	b.hi	LBB0_112
LBB0_113:                               ;   in Loop: Header=BB0_105 Depth=1
	cmp	x1, x8
	b.eq	LBB0_104
; %bb.114:                              ;   in Loop: Header=BB0_105 Depth=1
	sub	w10, w17, w10
	str	w10, [x12, x13, lsl #2]
	b	LBB0_104
LBB0_115:
	cmp	x17, x22
	b.hs	LBB0_117
; %bb.116:
	mov	w8, #36                         ; =0x24
	strb	w8, [x19]
	mov	x22, x17
	b	LBB0_118
LBB0_117:
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
LBB0_118:
	ldur	x8, [x29, #-136]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_127
; %bb.119:
	mov	x0, x22
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #2848
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
LBB0_120:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp15:                                 ; EH_LABEL
Lloh8:
	adrp	x1, l_.str.14@PAGE
Lloh9:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ; EH_LABEL
	b	LBB0_130
LBB0_121:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp21:                                 ; EH_LABEL
Lloh10:
	adrp	x1, l_.str.14@PAGE
Lloh11:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ; EH_LABEL
	b	LBB0_130
LBB0_122:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp3:                                  ; EH_LABEL
Lloh12:
	adrp	x1, l_.str.14@PAGE
Lloh13:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ; EH_LABEL
	b	LBB0_130
LBB0_123:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp6:                                  ; EH_LABEL
Lloh14:
	adrp	x1, l_.str.14@PAGE
Lloh15:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ; EH_LABEL
	b	LBB0_130
LBB0_124:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp24:                                 ; EH_LABEL
Lloh16:
	adrp	x1, l_.str@PAGE
Lloh17:
	add	x1, x1, l_.str@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ; EH_LABEL
	b	LBB0_130
LBB0_125:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp9:                                  ; EH_LABEL
Lloh18:
	adrp	x1, l_.str.14@PAGE
Lloh19:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ; EH_LABEL
	b	LBB0_130
LBB0_126:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp18:                                 ; EH_LABEL
Lloh20:
	adrp	x1, l_.str.14@PAGE
Lloh21:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ; EH_LABEL
	b	LBB0_130
LBB0_127:
	bl	___stack_chk_fail
LBB0_128:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp12:                                 ; EH_LABEL
Lloh22:
	adrp	x1, l_.str.14@PAGE
Lloh23:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ; EH_LABEL
	b	LBB0_130
LBB0_129:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp0:                                  ; EH_LABEL
Lloh24:
	adrp	x1, l_.str.8@PAGE
Lloh25:
	add	x1, x1, l_.str.8@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ; EH_LABEL
LBB0_130:
Lloh26:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh27:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh28:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh29:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB0_131:
Ltmp2:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_132:
Ltmp14:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_133:
Ltmp20:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_134:
Ltmp11:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_135:
Ltmp26:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_136:
Ltmp8:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_137:
Ltmp5:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_138:
Ltmp23:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_139:
Ltmp17:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdr	Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpLdrGot	Lloh28, Lloh29
	.loh AdrpLdrGot	Lloh26, Lloh27
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ; >> Call Site 1 <<
	.uleb128 Ltmp15-Lfunc_begin0            ;   Call between Lfunc_begin0 and Ltmp15
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin0            ; >> Call Site 2 <<
	.uleb128 Ltmp16-Ltmp15                  ;   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin0            ;     jumps to Ltmp17
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin0            ; >> Call Site 3 <<
	.uleb128 Ltmp21-Ltmp16                  ;   Call between Ltmp16 and Ltmp21
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin0            ; >> Call Site 4 <<
	.uleb128 Ltmp22-Ltmp21                  ;   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin0            ;     jumps to Ltmp23
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin0            ; >> Call Site 5 <<
	.uleb128 Ltmp3-Ltmp22                   ;   Call between Ltmp22 and Ltmp3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ; >> Call Site 6 <<
	.uleb128 Ltmp4-Ltmp3                    ;   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ;     jumps to Ltmp5
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ; >> Call Site 7 <<
	.uleb128 Ltmp6-Ltmp4                    ;   Call between Ltmp4 and Ltmp6
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ; >> Call Site 8 <<
	.uleb128 Ltmp7-Ltmp6                    ;   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin0             ;     jumps to Ltmp8
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin0             ; >> Call Site 9 <<
	.uleb128 Ltmp24-Ltmp7                   ;   Call between Ltmp7 and Ltmp24
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin0            ; >> Call Site 10 <<
	.uleb128 Ltmp25-Ltmp24                  ;   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin0            ;     jumps to Ltmp26
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin0            ; >> Call Site 11 <<
	.uleb128 Ltmp9-Ltmp25                   ;   Call between Ltmp25 and Ltmp9
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ; >> Call Site 12 <<
	.uleb128 Ltmp10-Ltmp9                   ;   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin0            ;     jumps to Ltmp11
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin0            ; >> Call Site 13 <<
	.uleb128 Ltmp18-Ltmp10                  ;   Call between Ltmp10 and Ltmp18
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin0            ; >> Call Site 14 <<
	.uleb128 Ltmp19-Ltmp18                  ;   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin0            ;     jumps to Ltmp20
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin0            ; >> Call Site 15 <<
	.uleb128 Ltmp12-Ltmp19                  ;   Call between Ltmp19 and Ltmp12
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin0            ; >> Call Site 16 <<
	.uleb128 Ltmp13-Ltmp12                  ;   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin0            ;     jumps to Ltmp14
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin0            ; >> Call Site 17 <<
	.uleb128 Ltmp0-Ltmp13                   ;   Call between Ltmp13 and Ltmp0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ; >> Call Site 18 <<
	.uleb128 Ltmp1-Ltmp0                    ;   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ;     jumps to Ltmp2
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ; >> Call Site 19 <<
	.uleb128 Lfunc_end0-Ltmp1               ;   Call between Ltmp1 and Lfunc_end0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
__ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE: ; @_ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
; %bb.0:
	sub	sp, sp, #160
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, #0                          ; =0x0
	str	wzr, [sp, #112]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #80]
	str	q0, [sp, #64]
	add	x9, sp, #64
	b	LBB1_2
LBB1_1:                                 ;   in Loop: Header=BB1_2 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB1_5
LBB1_2:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x0, x8]
	cmp	w10, #13
	b.hs	LBB1_25
; %bb.3:                                ;   in Loop: Header=BB1_2 Depth=1
	cbz	w10, LBB1_1
; %bb.4:                                ;   in Loop: Header=BB1_2 Depth=1
	ldr	w11, [x9, w10, uxtw #2]
	add	w11, w11, #1
	str	w11, [x9, w10, uxtw #2]
	b	LBB1_1
LBB1_5:
	ldr	w8, [sp, #68]
	cmp	w8, #2
	b.hi	LBB1_26
; %bb.6:
	str	wzr, [sp, #16]
	lsl	w8, w8, #1
	ldr	w9, [sp, #72]
	add	w9, w8, w9
	cmp	w9, #4
	b.hi	LBB1_26
; %bb.7:
	str	w8, [sp, #20]
	lsl	w8, w9, #1
	ldr	w9, [sp, #76]
	add	w9, w8, w9
	cmp	w9, #8
	b.hi	LBB1_26
; %bb.8:
	str	w8, [sp, #24]
	lsl	w8, w9, #1
	ldr	w9, [sp, #80]
	add	w9, w8, w9
	cmp	w9, #16
	b.hi	LBB1_26
; %bb.9:
	str	w8, [sp, #28]
	lsl	w8, w9, #1
	ldr	w9, [sp, #84]
	add	w9, w8, w9
	cmp	w9, #32
	b.hi	LBB1_26
; %bb.10:
	str	w8, [sp, #32]
	lsl	w8, w9, #1
	ldr	w9, [sp, #88]
	add	w9, w8, w9
	cmp	w9, #64
	b.hi	LBB1_26
; %bb.11:
	str	w8, [sp, #36]
	lsl	w8, w9, #1
	ldr	w9, [sp, #92]
	add	w9, w8, w9
	cmp	w9, #128
	b.hi	LBB1_26
; %bb.12:
	str	w8, [sp, #40]
	lsl	w8, w9, #1
	ldr	w9, [sp, #96]
	add	w9, w8, w9
	cmp	w9, #256
	b.hi	LBB1_26
; %bb.13:
	str	w8, [sp, #44]
	lsl	w8, w9, #1
	ldr	w9, [sp, #100]
	add	w9, w8, w9
	cmp	w9, #512
	b.hi	LBB1_26
; %bb.14:
	str	w8, [sp, #48]
	lsl	w8, w9, #1
	ldr	w9, [sp, #104]
	add	w9, w8, w9
	cmp	w9, #1024
	b.hi	LBB1_26
; %bb.15:
	str	w8, [sp, #52]
	lsl	w8, w9, #1
	ldr	w9, [sp, #108]
	add	w9, w8, w9
	cmp	w9, #2048
	b.hi	LBB1_26
; %bb.16:
	str	w8, [sp, #56]
	lsl	w8, w9, #1
	ldr	w9, [sp, #112]
	add	w9, w8, w9
	cmp	w9, #1, lsl #12                 ; =4096
	b.hi	LBB1_26
; %bb.17:
	str	w8, [sp, #60]
	b.ne	LBB1_28
; %bb.18:
	mov	x8, #0                          ; =0x0
	add	x9, sp, #12
	b	LBB1_20
LBB1_19:                                ;   in Loop: Header=BB1_20 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB1_24
LBB1_20:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_22 Depth 2
	ldrb	w10, [x0, x8]
	cbz	w10, LBB1_19
; %bb.21:                               ;   in Loop: Header=BB1_20 Depth=1
	mov	w11, #0                         ; =0x0
	ldr	w12, [x9, w10, uxtw #2]
	add	w13, w12, #1
	str	w13, [x9, w10, uxtw #2]
LBB1_22:                                ;   Parent Loop BB1_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x13, x11
	and	w11, w12, #0x1
	bfi	w11, w13, #1, #16
	lsr	w12, w12, #1
	subs	w10, w10, #1
	b.ne	LBB1_22
; %bb.23:                               ;   in Loop: Header=BB1_20 Depth=1
	strh	w11, [x1, x8, lsl #1]
	b	LBB1_19
LBB1_24:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB1_25:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp27:                                 ; EH_LABEL
Lloh30:
	adrp	x1, l_.str.11@PAGE
Lloh31:
	add	x1, x1, l_.str.11@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ; EH_LABEL
	b	LBB1_27
LBB1_26:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp33:                                 ; EH_LABEL
Lloh32:
	adrp	x1, l_.str.12@PAGE
Lloh33:
	add	x1, x1, l_.str.12@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ; EH_LABEL
LBB1_27:
Lloh34:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh35:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh36:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh37:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB1_28:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp30:                                 ; EH_LABEL
Lloh38:
	adrp	x1, l_.str.13@PAGE
Lloh39:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ; EH_LABEL
	b	LBB1_27
LBB1_29:
Ltmp32:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_30:
Ltmp35:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_31:
Ltmp29:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpLdrGot	Lloh36, Lloh37
	.loh AdrpLdrGot	Lloh34, Lloh35
	.loh AdrpAdd	Lloh38, Lloh39
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ; >> Call Site 1 <<
	.uleb128 Ltmp27-Lfunc_begin1            ;   Call between Lfunc_begin1 and Ltmp27
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin1            ; >> Call Site 2 <<
	.uleb128 Ltmp28-Ltmp27                  ;   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin1            ;     jumps to Ltmp29
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin1            ; >> Call Site 3 <<
	.uleb128 Ltmp33-Ltmp28                  ;   Call between Ltmp28 and Ltmp33
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin1            ; >> Call Site 4 <<
	.uleb128 Ltmp34-Ltmp33                  ;   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin1            ;     jumps to Ltmp35
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin1            ; >> Call Site 5 <<
	.uleb128 Ltmp30-Ltmp34                  ;   Call between Ltmp34 and Ltmp30
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin1            ; >> Call Site 6 <<
	.uleb128 Ltmp31-Ltmp30                  ;   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin1            ;     jumps to Ltmp32
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin1            ; >> Call Site 7 <<
	.uleb128 Lfunc_end1-Ltmp31              ;   Call between Ltmp31 and Lfunc_end1
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function _ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
lCPI2_0:
	.long	12                              ; 0xc
	.long	13                              ; 0xd
	.long	14                              ; 0xe
	.long	15                              ; 0xf
lCPI2_1:
	.long	8                               ; 0x8
	.long	9                               ; 0x9
	.long	10                              ; 0xa
	.long	11                              ; 0xb
lCPI2_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI2_3:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI2_4:
	.byte	4                               ; 0x4
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	5                               ; 0x5
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	6                               ; 0x6
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	7                               ; 0x7
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI2_5:
	.byte	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	2                               ; 0x2
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	3                               ; 0x3
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI2_6:
	.byte	8                               ; 0x8
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	9                               ; 0x9
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	10                              ; 0xa
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	11                              ; 0xb
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
lCPI2_7:
	.byte	12                              ; 0xc
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	13                              ; 0xd
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	14                              ; 0xe
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	15                              ; 0xf
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	.p2align	2
__ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE: ; @_ZN18cng_huffman_kernel6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
; %bb.0:
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #1296
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
Lloh40:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh41:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh42:
	ldr	x8, [x8]
	stur	x8, [x29, #-160]
	subs	x25, x1, #5
	b.lo	LBB2_293
; %bb.1:
	mov	x22, x3
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x3, x8
	b.hi	LBB2_293
; %bb.2:
	ldur	w8, [x0, #1]
	cmp	x22, x8
	b.ne	LBB2_293
; %bb.3:
	mov	x21, x2
	ldrb	w8, [x0]
	cmp	w8, #36
	b.eq	LBB2_15
; %bb.4:
	cmp	w8, #4
	b.eq	LBB2_10
; %bb.5:
	cbnz	w8, LBB2_295
; %bb.6:
	add	x8, x22, #5
	cmp	x1, x8
	b.ne	LBB2_297
; %bb.7:
	cbz	x22, LBB2_222
; %bb.8:
	ldur	x8, [x29, #-160]
Lloh43:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh44:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh45:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_294
; %bb.9:
	add	x1, x0, #5
	mov	x0, x21
	mov	x2, x22
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1296
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	b	_memcpy
LBB2_10:
	cmp	x1, #6
	b.ne	LBB2_298
; %bb.11:
	cbz	x22, LBB2_298
; %bb.12:
	cmp	x22, #1
	b.lt	LBB2_222
; %bb.13:
	ldrb	w1, [x0, #5]
	ldur	x8, [x29, #-160]
Lloh46:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh47:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh48:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_294
; %bb.14:
	mov	x0, x21
	mov	x2, x22
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1296
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	b	_memset
LBB2_15:
	cmp	x1, #6
	b.ls	LBB2_295
; %bb.16:
	str	x1, [sp, #112]                  ; 8-byte Spill
	mov	x27, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #25840]
	str	q0, [sp, #25824]
	str	q0, [sp, #25808]
	str	q0, [sp, #25792]
	str	q0, [sp, #25776]
	str	q0, [sp, #25760]
	str	q0, [sp, #25744]
	str	q0, [sp, #25728]
	str	q0, [sp, #25712]
	str	q0, [sp, #25696]
	str	q0, [sp, #25680]
	str	q0, [sp, #25664]
	str	q0, [sp, #25648]
	str	q0, [sp, #25632]
	str	q0, [sp, #25616]
	str	q0, [sp, #25600]
	str	q0, [sp, #25584]
	str	q0, [sp, #25568]
	str	q0, [sp, #25552]
	str	q0, [sp, #25536]
	str	q0, [sp, #25520]
	str	q0, [sp, #25504]
	str	q0, [sp, #25488]
	str	q0, [sp, #25472]
	str	q0, [sp, #25456]
	str	q0, [sp, #25440]
	str	q0, [sp, #25424]
	str	q0, [sp, #25408]
	str	q0, [sp, #25392]
	str	q0, [sp, #25376]
	str	q0, [sp, #25360]
	str	q0, [sp, #25344]
	str	q0, [sp, #25328]
	str	q0, [sp, #25312]
	str	q0, [sp, #25296]
	str	q0, [sp, #25280]
	str	q0, [sp, #25264]
	str	q0, [sp, #25248]
	str	q0, [sp, #25232]
	str	q0, [sp, #25216]
	str	q0, [sp, #25200]
	str	q0, [sp, #25184]
	str	q0, [sp, #25168]
	str	q0, [sp, #25152]
	str	q0, [sp, #25136]
	str	q0, [sp, #25120]
	str	x0, [sp, #120]                  ; 8-byte Spill
	add	x28, x0, #5
	add	x19, sp, #6, lsl #12            ; =24576
	add	x19, x19, #1024
	mov	w20, #256                       ; =0x100
	str	q0, [sp, #25104]
	str	q0, [sp, #25088]
	b	LBB2_18
LBB2_17:                                ;   in Loop: Header=BB2_18 Depth=1
	strb	w9, [x19, x27]
	add	x27, x27, #1
	mov	x26, x10
	mov	x23, x9
	cmp	x27, #256
	b.hs	LBB2_28
LBB2_18:                                ; =>This Inner Loop Header: Depth=1
	lsr	x9, x26, #1
	cmp	x9, x25
	b.hs	LBB2_264
; %bb.19:                               ;   in Loop: Header=BB2_18 Depth=1
	ubfiz	w8, w26, #2, #1
	ldrb	w9, [x28, x9]
	lsr	w9, w9, w8
	and	w9, w9, #0xf
	add	x10, x26, #1
	cmp	w9, #12
	b.ls	LBB2_17
; %bb.20:                               ;   in Loop: Header=BB2_18 Depth=1
	cmp	w9, #13
	b.eq	LBB2_289
; %bb.21:                               ;   in Loop: Header=BB2_18 Depth=1
	lsr	x11, x10, #1
	cmp	x11, x25
	b.hs	LBB2_291
; %bb.22:                               ;   in Loop: Header=BB2_18 Depth=1
	ubfiz	x10, x10, #2, #1
	ldrb	w11, [x28, x11]
	lsr	x10, x11, x10
	and	x10, x10, #0xf
	add	x11, x26, #2
	cmp	w9, #15
	b.ne	LBB2_25
; %bb.23:                               ;   in Loop: Header=BB2_18 Depth=1
	lsr	x9, x11, #1
	cmp	x9, x25
	b.hs	LBB2_292
; %bb.24:                               ;   in Loop: Header=BB2_18 Depth=1
	ldrb	w9, [x28, x9]
	lsr	w8, w9, w8
	add	x26, x26, #3
	orr	w8, w10, w8, lsl #4
	and	x8, x8, #0xff
	add	x24, x8, #19
	b	LBB2_26
LBB2_25:                                ;   in Loop: Header=BB2_18 Depth=1
	add	x24, x10, #3
	mov	x26, x11
LBB2_26:                                ;   in Loop: Header=BB2_18 Depth=1
	sub	x8, x20, x27
	cmp	x24, x8
	b.hi	LBB2_290
; %bb.27:                               ;   in Loop: Header=BB2_18 Depth=1
	add	x0, x19, x27
	mov	x1, x23
	mov	x2, x24
	bl	_memset
	add	x27, x24, x27
	cmp	x27, #256
	b.lo	LBB2_18
LBB2_28:
	cmp	x26, #257
	b.hs	LBB2_299
; %bb.29:
	tbz	w26, #0, LBB2_31
; %bb.30:
	lsr	x8, x26, #1
	ldrb	w8, [x28, x8]
	cmp	w8, #16
	b.hs	LBB2_301
LBB2_31:
	add	x8, x26, #1
	lsr	x28, x8, #1
	add	x23, x28, #5
	mov	w8, #12                         ; =0xc
	cmp	x22, #1025
	csel	x8, xzr, x8, lo
	add	x8, x23, x8
	ldr	x25, [sp, #112]                 ; 8-byte Reload
	cmp	x25, x8
	b.lo	LBB2_300
; %bb.32:
	add	x19, sp, #6, lsl #12            ; =24576
	add	x19, x19, #1024
	add	x20, sp, #6, lsl #12            ; =24576
	add	x20, x20, #512
	add	x0, sp, #6, lsl #12             ; =24576
	add	x0, x0, #1024
	add	x1, sp, #6, lsl #12             ; =24576
	add	x1, x1, #512
	bl	__ZN18cng_huffman_kernel12_GLOBAL__N_19canonicalERKNSt3__15arrayIhLm256EEERNS2_ItLm256EEE
	add	x24, sp, #4, lsl #12            ; =16384
	add	x24, x24, #512
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #512
	mov	w1, #8192                       ; =0x2000
	bl	_bzero
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x27, [sp, #120]                 ; 8-byte Reload
	b	LBB2_34
LBB2_33:                                ;   in Loop: Header=BB2_34 Depth=1
	add	x8, x8, #1
	cmp	x8, #256
	b.eq	LBB2_38
LBB2_34:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_37 Depth 2
	ldrb	w11, [x19, x8]
	cbz	x11, LBB2_33
; %bb.35:                               ;   in Loop: Header=BB2_34 Depth=1
	ldrh	w10, [x20, x8, lsl #1]
	cmp	x10, #4095
	b.hi	LBB2_33
; %bb.36:                               ;   in Loop: Header=BB2_34 Depth=1
	lsl	x12, x9, x11
	orr	w11, w8, w11, lsl #8
LBB2_37:                                ;   Parent Loop BB2_34 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	strh	w11, [x24, x10, lsl #1]
	add	x10, x10, x12
	cmp	x10, #1, lsl #12                ; =4096
	b.lo	LBB2_37
	b	LBB2_33
LBB2_38:
	cmp	x22, #1025
	b.hs	LBB2_61
; %bb.39:
	sub	x9, x25, x23
	add	x10, x27, x23
	str	x10, [sp, #512]
	str	x9, [sp, #520]
	cbz	x22, LBB2_220
; %bb.40:
	mov	x13, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	x11, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x12, #0                         ; =0x0
Lloh49:
	adrp	x14, lCPI2_3@PAGE
Lloh50:
	ldr	q0, [x14, lCPI2_3@PAGEOFF]
Lloh51:
	adrp	x14, lCPI2_0@PAGE
Lloh52:
	ldr	q1, [x14, lCPI2_0@PAGEOFF]
Lloh53:
	adrp	x14, lCPI2_1@PAGE
Lloh54:
	ldr	q2, [x14, lCPI2_1@PAGEOFF]
	add	x15, x27, x28
Lloh55:
	adrp	x14, lCPI2_2@PAGE
Lloh56:
	ldr	q3, [x14, lCPI2_2@PAGEOFF]
Lloh57:
	adrp	x14, lCPI2_4@PAGE
Lloh58:
	ldr	q4, [x14, lCPI2_4@PAGEOFF]
Lloh59:
	adrp	x14, lCPI2_5@PAGE
Lloh60:
	ldr	q5, [x14, lCPI2_5@PAGEOFF]
	add	x14, x15, #21
	add	x15, x15, #5
	movi.4s	v6, #4
	sub	x16, x28, x25
Lloh61:
	adrp	x17, lCPI2_6@PAGE
Lloh62:
	ldr	q7, [x17, lCPI2_6@PAGEOFF]
	add	x16, x16, #5
Lloh63:
	adrp	x17, lCPI2_7@PAGE
Lloh64:
	ldr	q16, [x17, lCPI2_7@PAGEOFF]
	movi.4s	v17, #128
	movi.4s	v18, #32
	add	x17, sp, #4, lsl #12            ; =16384
	add	x17, x17, #512
	b	LBB2_44
LBB2_41:                                ;   in Loop: Header=BB2_44 Depth=1
	ldr	w4, [x10, x0]
LBB2_42:                                ;   in Loop: Header=BB2_44 Depth=1
	mov	w0, w4
	lsl	x0, x0, x8
	orr	x11, x0, x11
	orr	w8, w8, #0x20
	mov	x0, x12
LBB2_43:                                ;   in Loop: Header=BB2_44 Depth=1
	and	x1, x11, #0xfff
	ldrh	w1, [x17, x1, lsl #1]
	strb	w1, [x21, x13]
	lsr	x1, x1, #8
	lsr	x11, x11, x1
	sub	w8, w8, w1
	add	x13, x13, #1
	cmp	x13, x22
	b.eq	LBB2_221
LBB2_44:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_53 Depth 2
                                        ;     Child Loop BB2_57 Depth 2
                                        ;     Child Loop BB2_60 Depth 2
	cmp	w8, #11
	b.hi	LBB2_43
; %bb.45:                               ;   in Loop: Header=BB2_44 Depth=1
	add	x12, x0, #4
	cmp	x12, x9
	b.ls	LBB2_41
; %bb.46:                               ;   in Loop: Header=BB2_44 Depth=1
	subs	x1, x9, x0
	b.ls	LBB2_49
; %bb.47:                               ;   in Loop: Header=BB2_44 Depth=1
	cmp	x1, #4
	b.hs	LBB2_50
; %bb.48:                               ;   in Loop: Header=BB2_44 Depth=1
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB2_59
LBB2_49:                                ;   in Loop: Header=BB2_44 Depth=1
	mov	w4, #0                          ; =0x0
	b	LBB2_42
LBB2_50:                                ;   in Loop: Header=BB2_44 Depth=1
	cmp	x1, #32
	b.hs	LBB2_52
; %bb.51:                               ;   in Loop: Header=BB2_44 Depth=1
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB2_56
LBB2_52:                                ;   in Loop: Header=BB2_44 Depth=1
	and	x3, x1, #0x1c
	and	x2, x1, #0xffffffffffffffe0
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	add	x4, x14, x0
	and	x5, x1, #0xffffffffffffffe0
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v23, #0000000000000000
	mov.16b	v26, v0
	movi.2d	v24, #0000000000000000
	mov.16b	v27, v3
	movi.2d	v25, #0000000000000000
	mov.16b	v29, v2
	movi.2d	v28, #0000000000000000
	mov.16b	v30, v1
LBB2_53:                                ;   Parent Loop BB2_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q8, [x4, #-16]
	tbl.16b	v9, { v31 }, v4
	tbl.16b	v10, { v31 }, v5
	tbl.16b	v11, { v31 }, v7
	tbl.16b	v31, { v31 }, v16
	tbl.16b	v12, { v8 }, v5
	tbl.16b	v13, { v8 }, v4
	tbl.16b	v14, { v8 }, v7
	tbl.16b	v8, { v8 }, v16
	shl.4s	v15, v30, #3
	ushl.4s	v31, v31, v15
	add.4s	v15, v15, v17
	ushl.4s	v8, v8, v15
	shl.4s	v15, v29, #3
	ushl.4s	v11, v11, v15
	add.4s	v15, v15, v17
	ushl.4s	v14, v14, v15
	shl.4s	v15, v27, #3
	ushl.4s	v9, v9, v15
	add.4s	v15, v15, v17
	ushl.4s	v13, v13, v15
	shl.4s	v15, v26, #3
	ushl.4s	v10, v10, v15
	add.4s	v15, v15, v17
	ushl.4s	v12, v12, v15
	orr.16b	v22, v9, v22
	orr.16b	v20, v10, v20
	orr.16b	v21, v11, v21
	orr.16b	v23, v31, v23
	orr.16b	v24, v12, v24
	orr.16b	v19, v13, v19
	orr.16b	v25, v14, v25
	orr.16b	v28, v8, v28
	add.4s	v26, v26, v18
	add.4s	v27, v27, v18
	add.4s	v29, v29, v18
	add	x4, x4, #32
	add.4s	v30, v30, v18
	subs	x5, x5, #32
	b.ne	LBB2_53
; %bb.54:                               ;   in Loop: Header=BB2_44 Depth=1
	orr.16b	v19, v19, v22
	orr.16b	v22, v28, v23
	orr.16b	v20, v24, v20
	orr.16b	v21, v25, v21
	orr.16b	v20, v20, v21
	orr.16b	v19, v19, v22
	orr.16b	v19, v20, v19
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x4, d19
	lsr	x5, x4, #32
	orr	w4, w4, w5
	cmp	x1, x2
	b.eq	LBB2_42
; %bb.55:                               ;   in Loop: Header=BB2_44 Depth=1
	cbz	x3, LBB2_59
LBB2_56:                                ;   in Loop: Header=BB2_44 Depth=1
	mov	x5, x2
	and	x2, x1, #0xfffffffffffffffc
	movi.2d	v19, #0000000000000000
	mov.s	v19[0], w4
	dup.4s	v20, w5
	orr.16b	v20, v20, v0
	sub	x3, x5, x2
	add	x4, x0, x5
	add	x4, x15, x4
LBB2_57:                                ;   Parent Loop BB2_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s21, [x4], #4
	ushll.8h	v21, v21, #0
	ushll.4s	v21, v21, #0
	shl.4s	v22, v20, #3
	ushl.4s	v21, v21, v22
	orr.16b	v19, v21, v19
	add.4s	v20, v20, v6
	adds	x3, x3, #4
	b.ne	LBB2_57
; %bb.58:                               ;   in Loop: Header=BB2_44 Depth=1
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x3, d19
	lsr	x4, x3, #32
	orr	w4, w3, w4
	cmp	x1, x2
	b.eq	LBB2_42
LBB2_59:                                ;   in Loop: Header=BB2_44 Depth=1
	add	x3, x2, x0
	add	x0, x3, x16
	lsl	w1, w2, #3
	add	x2, x15, x3
LBB2_60:                                ;   Parent Loop BB2_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w3, [x2], #1
	lsl	w3, w3, w1
	orr	w4, w3, w4
	add	w1, w1, #8
	adds	x0, x0, #1
	b.lo	LBB2_60
	b	LBB2_42
LBB2_61:
	add	x19, sp, #512
	add	x0, sp, #512
	mov	w1, #16384                      ; =0x4000
	bl	_bzero
	mov	x8, #0                          ; =0x0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #512
	b	LBB2_64
LBB2_62:                                ;   in Loop: Header=BB2_64 Depth=1
	lsl	w11, w11, #16
	mov	w12, #16777216                  ; =0x1000000
LBB2_63:                                ;   in Loop: Header=BB2_64 Depth=1
	and	w10, w10, #0xff
	orr	w10, w10, w12
	orr	w10, w11, w10
	str	w10, [x19, x8, lsl #2]
	add	x8, x8, #1
	cmp	x8, #1, lsl #12                 ; =4096
	b.eq	LBB2_66
LBB2_64:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x9, x8, lsl #1]
	lsr	x11, x10, #8
	lsr	x12, x8, x11
	ldrh	w12, [x9, x12, lsl #1]
	add	w13, w11, w12, lsr #8
	cmp	w13, #12
	b.hi	LBB2_62
; %bb.65:                               ;   in Loop: Header=BB2_64 Depth=1
	lsl	w11, w13, #16
	bfi	w11, w12, #8, #8
	mov	w12, #33554432                  ; =0x2000000
	b	LBB2_63
LBB2_66:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #480]
	stp	q0, q0, [sp, #448]
	stp	q0, q0, [sp, #416]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #352]
	add	x11, x28, #17
	add	x9, x27, x23
	ldr	w8, [x9]
	sub	x10, x25, x11
	cmp	x10, x8
	stp	q0, q0, [sp, #256]
	b.lo	LBB2_296
; %bb.67:
	lsr	x16, x22, #2
	add	x23, x27, x11
	stp	x23, x8, [sp, #352]
	stp	x21, x16, [sp, #288]
	ldr	w10, [x9, #4]
	add	x11, x11, x8
	sub	x12, x25, x11
	cmp	x12, x10
	b.lo	LBB2_296
; %bb.68:
	add	x24, x27, x11
	stp	x24, x10, [sp, #392]
	add	x14, x21, x16
	stp	x14, x16, [sp, #304]
	ldr	w30, [x9, #8]
	add	x12, x11, x10
	sub	x9, x25, x12
	cmp	x9, x30
	b.lo	LBB2_296
; %bb.69:
	mov	x3, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x17, #0                         ; =0x0
	sub	x15, x16, x16, lsl #2
	add	x0, x15, x22
	add	x4, x27, x12
	add	x15, x27, x12
	str	x15, [sp, #224]                 ; 8-byte Spill
	stp	x4, x30, [sp, #432]
	lsl	x4, x16, #1
	add	x15, x21, x4
	stp	x15, x16, [sp, #320]
	add	x12, x12, x30
	sub	x26, x25, x12
	add	x12, x27, x12
	str	x12, [sp, #208]                 ; 8-byte Spill
	stp	x12, x26, [sp, #472]
	add	x12, x4, x16
	sub	x4, x22, x12
	cmn	x0, #1
	csel	x4, x4, x0, eq
	add	x0, x21, x12
	stp	x0, x4, [sp, #336]
	str	x4, [sp, #240]                  ; 8-byte Spill
	add	x4, sp, #512
LBB2_70:                                ; =>This Inner Loop Header: Depth=1
	sub	x12, x16, x2
	cmp	x12, #8
	b.lo	LBB2_78
; %bb.71:                               ;   in Loop: Header=BB2_70 Depth=1
	sub	x12, x16, x1
	cmp	x12, #8
	b.lo	LBB2_78
; %bb.72:                               ;   in Loop: Header=BB2_70 Depth=1
	ldr	x12, [sp, #240]                 ; 8-byte Reload
	sub	x12, x12, x3
	cmp	x12, #8
	b.lo	LBB2_78
; %bb.73:                               ;   in Loop: Header=BB2_70 Depth=1
	lsr	x12, x13, #3
	sub	x5, x8, x12
	cmp	x5, #8
	b.lo	LBB2_78
; %bb.74:                               ;   in Loop: Header=BB2_70 Depth=1
	lsr	x5, x11, #3
	sub	x7, x10, x5
	cmp	x7, #8
	b.lo	LBB2_78
; %bb.75:                               ;   in Loop: Header=BB2_70 Depth=1
	lsr	x7, x9, #3
	sub	x19, x30, x7
	cmp	x19, #8
	b.lo	LBB2_78
; %bb.76:                               ;   in Loop: Header=BB2_70 Depth=1
	lsr	x19, x6, #3
	sub	x20, x26, x19
	cmp	x20, #8
	b.lo	LBB2_78
; %bb.77:                               ;   in Loop: Header=BB2_70 Depth=1
	ldr	x12, [x23, x12]
	and	x20, x13, #0x7
	lsr	x12, x12, x20
	ldr	x5, [x24, x5]
	and	x20, x11, #0x7
	lsr	x5, x5, x20
	ldr	x20, [sp, #224]                 ; 8-byte Reload
	ldr	x7, [x20, x7]
	and	x20, x9, #0x7
	lsr	x7, x7, x20
	ldr	x20, [sp, #208]                 ; 8-byte Reload
	ldr	x19, [x20, x19]
	and	x20, x6, #0x7
	lsr	x19, x19, x20
	and	x20, x12, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x12, x12, x22
	add	x13, x13, w22, uxtb
	strh	w20, [x21, x17]
	add	x17, x17, x20, lsr #24
	and	x20, x5, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x5, x5, x22
	strh	w20, [x14, x2]
	add	x11, x11, w22, uxtb
	add	x2, x2, x20, lsr #24
	and	x20, x7, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x7, x7, x22
	add	x9, x9, w22, uxtb
	strh	w20, [x15, x1]
	add	x1, x1, x20, lsr #24
	and	x20, x19, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x19, x19, x22
	strh	w20, [x0, x3]
	add	x6, x6, w22, uxtb
	add	x3, x3, x20, lsr #24
	and	x20, x12, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x12, x12, x22
	add	x13, x13, w22, uxtb
	strh	w20, [x21, x17]
	add	x17, x17, x20, lsr #24
	and	x20, x5, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x5, x5, x22
	strh	w20, [x14, x2]
	add	x11, x11, w22, uxtb
	add	x2, x2, x20, lsr #24
	and	x20, x7, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x7, x7, x22
	add	x9, x9, w22, uxtb
	strh	w20, [x15, x1]
	add	x1, x1, x20, lsr #24
	and	x20, x19, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x19, x19, x22
	strh	w20, [x0, x3]
	add	x6, x6, w22, uxtb
	add	x3, x3, x20, lsr #24
	and	x20, x12, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x12, x12, x22
	add	x13, x13, w22, uxtb
	strh	w20, [x21, x17]
	add	x17, x17, x20, lsr #24
	and	x20, x5, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x5, x5, x22
	strh	w20, [x14, x2]
	add	x11, x11, w22, uxtb
	add	x2, x2, x20, lsr #24
	and	x20, x7, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x7, x7, x22
	add	x9, x9, w22, uxtb
	strh	w20, [x15, x1]
	add	x1, x1, x20, lsr #24
	and	x20, x19, #0xfff
	ldr	w20, [x4, x20, lsl #2]
	lsr	x22, x20, #16
	lsr	x19, x19, x22
	strh	w20, [x0, x3]
	add	x6, x6, w22, uxtb
	add	x3, x3, x20, lsr #24
	and	x12, x12, #0xfff
	ldr	w12, [x4, x12, lsl #2]
	lsr	x20, x12, #16
	add	x13, x13, w20, uxtb
	strh	w12, [x21, x17]
	and	x5, x5, #0xfff
	ldr	w5, [x4, x5, lsl #2]
	add	x17, x17, x12, lsr #24
	lsr	x12, x5, #16
	add	x11, x11, w12, uxtb
	strh	w5, [x14, x2]
	add	x2, x2, x5, lsr #24
	and	x12, x7, #0xfff
	ldr	w12, [x4, x12, lsl #2]
	lsr	x5, x12, #16
	strh	w12, [x15, x1]
	add	x9, x9, w5, uxtb
	add	x1, x1, x12, lsr #24
	and	x12, x19, #0xfff
	ldr	w12, [x4, x12, lsl #2]
	lsr	x5, x12, #16
	add	x6, x6, w5, uxtb
	strh	w12, [x0, x3]
	sub	x5, x16, x17
	add	x3, x3, x12, lsr #24
	cmp	x5, #7
	b.hi	LBB2_70
LBB2_78:
	str	x28, [sp, #104]                 ; 8-byte Spill
	lsr	x14, x13, #3
	add	x25, x14, #4
	adrp	x28, lCPI2_0@PAGE
	stp	x2, x1, [sp, #264]
	str	x3, [sp, #280]
	cmp	x25, x8
	str	x30, [sp, #160]                 ; 8-byte Spill
	str	x10, [sp, #176]                 ; 8-byte Spill
	str	x23, [sp, #144]                 ; 8-byte Spill
	str	x26, [sp, #192]                 ; 8-byte Spill
	b.hi	LBB2_224
; %bb.79:
	ldr	w5, [x23, x14]
LBB2_80:
	mov	w15, w5
	lsr	x14, x11, #3
	add	x26, x14, #4
	cmp	x26, x10
	str	x24, [sp, #128]                 ; 8-byte Spill
	b.hi	LBB2_227
; %bb.81:
	ldr	w7, [x24, x14]
LBB2_82:
	and	w14, w13, #0x7
	and	x13, x13, #0x7
	mov	w4, #32                         ; =0x20
	mov	w5, w7
	and	w7, w11, #0x7
	and	x11, x11, #0x7
	mov	w21, #32                        ; =0x20
	lsr	x0, x9, #3
	add	x27, x0, #4
	cmp	x27, x30
	b.hi	LBB2_230
; %bb.83:
	ldr	x12, [sp, #224]                 ; 8-byte Reload
	ldr	w19, [x12, x0]
LBB2_84:
	lsr	x23, x15, x13
	sub	w24, w4, w14
	lsr	x30, x5, x11
	sub	w21, w21, w7
	mov	w11, w19
	and	w12, w9, #0x7
	and	x9, x9, #0x7
	lsr	x22, x11, x9
	mov	w9, #32                         ; =0x20
	sub	w4, w9, w12
	lsr	x9, x6, #3
	add	x0, x9, #4
	ldr	x11, [sp, #192]                 ; 8-byte Reload
	cmp	x0, x11
	b.hi	LBB2_233
; %bb.85:
	ldr	x11, [sp, #208]                 ; 8-byte Reload
	ldr	w15, [x11, x9]
LBB2_86:
	mov	w9, w15
	and	w11, w6, #0x7
	and	x12, x6, #0x7
	lsr	x6, x9, x12
	mov	w9, #32                         ; =0x20
	sub	w7, w9, w11
	sub	x9, x16, x17
	cmp	x9, #2
	b.lo	LBB2_173
; %bb.87:
	mov	x15, x28
	ldr	x28, [sp, #288]
	ldr	x9, [sp, #304]
	ldr	x11, [sp, #320]
	ldr	x13, [sp, #336]
	ldr	x12, [sp, #120]                 ; 8-byte Reload
	ldr	x19, [sp, #104]                 ; 8-byte Reload
	add	x12, x12, x19
	add	x20, x12, #33
	add	x10, x12, #17
	add	x12, x20, x8
	stp	x12, x20, [sp, #40]             ; 16-byte Folded Spill
	add	x12, x10, x8
	stp	x12, x10, [sp, #88]             ; 16-byte Folded Spill
	ldr	x14, [sp, #176]                 ; 8-byte Reload
	neg	x12, x14
	str	x12, [sp, #64]                  ; 8-byte Spill
	add	x12, x14, x8
	add	x5, x20, x12
	str	x5, [sp, #32]                   ; 8-byte Spill
	add	x5, x10, x12
	str	x5, [sp, #80]                   ; 8-byte Spill
	ldr	x5, [sp, #160]                  ; 8-byte Reload
	str	x8, [sp, #120]                  ; 8-byte Spill
	mov	x8, x25
	neg	x25, x5
	str	x25, [sp, #56]                  ; 8-byte Spill
	mov	x25, x8
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	add	x14, x5, x14
	add	x14, x14, x8
	add	x20, x20, x14
	str	x20, [sp, #24]                  ; 8-byte Spill
	add	x10, x10, x14
	str	x10, [sp, #72]                  ; 8-byte Spill
	add	x12, x12, x5
	ldr	x14, [sp, #112]                 ; 8-byte Reload
	sub	x12, x12, x14
	add	x12, x12, x19
	add	x10, x12, #17
	str	x10, [sp, #112]                 ; 8-byte Spill
Lloh65:
	adrp	x12, lCPI2_3@PAGE
Lloh66:
	ldr	q0, [x12, lCPI2_3@PAGEOFF]
	movi.4s	v1, #4
	ldr	q2, [x15, lCPI2_0@PAGEOFF]
Lloh67:
	adrp	x12, lCPI2_1@PAGE
Lloh68:
	ldr	q3, [x12, lCPI2_1@PAGEOFF]
Lloh69:
	adrp	x12, lCPI2_2@PAGE
Lloh70:
	ldr	q4, [x12, lCPI2_2@PAGEOFF]
Lloh71:
	adrp	x12, lCPI2_4@PAGE
Lloh72:
	ldr	q5, [x12, lCPI2_4@PAGEOFF]
Lloh73:
	adrp	x12, lCPI2_5@PAGE
Lloh74:
	ldr	q6, [x12, lCPI2_5@PAGEOFF]
Lloh75:
	adrp	x12, lCPI2_6@PAGE
Lloh76:
	ldr	q7, [x12, lCPI2_6@PAGEOFF]
	movi.4s	v16, #128
	movi.4s	v17, #32
	add	x19, sp, #512
Lloh77:
	adrp	x12, lCPI2_7@PAGE
Lloh78:
	ldr	q18, [x12, lCPI2_7@PAGEOFF]
	b	LBB2_91
LBB2_88:                                ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #208]                 ; 8-byte Reload
	ldr	w12, [x12, x0]
LBB2_89:                                ;   in Loop: Header=BB2_91 Depth=1
	mov	w12, w12
	lsl	x12, x12, x7
	orr	x6, x12, x6
	orr	w7, w7, #0x20
	mov	x0, x5
LBB2_90:                                ;   in Loop: Header=BB2_91 Depth=1
	lsr	x12, x20, #16
	ubfx	x5, x20, #16, #8
	lsr	x23, x23, x12
	sub	w24, w24, w5
	add	x17, x17, x20, lsr #24
	lsr	x12, x15, #16
	ubfx	x5, x15, #16, #8
	lsr	x30, x30, x12
	sub	w21, w21, w5
	add	x2, x2, x15, lsr #24
	lsr	x12, x14, #16
	ubfx	x15, x14, #16, #8
	lsr	x22, x22, x12
	sub	w4, w4, w15
	add	x1, x1, x14, lsr #24
	and	x12, x6, #0xfff
	ldr	w12, [x19, x12, lsl #2]
	lsr	x14, x12, #16
	ubfx	x15, x12, #16, #8
	lsr	x6, x6, x14
	sub	w7, w7, w15
	strh	w12, [x13, x3]
	sub	x14, x16, x17
	add	x3, x3, x12, lsr #24
	cmp	x14, #1
	b.ls	LBB2_172
LBB2_91:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_137 Depth 2
                                        ;     Child Loop BB2_156 Depth 2
                                        ;     Child Loop BB2_159 Depth 2
                                        ;     Child Loop BB2_141 Depth 2
                                        ;     Child Loop BB2_162 Depth 2
                                        ;     Child Loop BB2_165 Depth 2
                                        ;     Child Loop BB2_145 Depth 2
                                        ;     Child Loop BB2_168 Depth 2
                                        ;     Child Loop BB2_171 Depth 2
                                        ;     Child Loop BB2_133 Depth 2
                                        ;     Child Loop BB2_150 Depth 2
                                        ;     Child Loop BB2_153 Depth 2
	sub	x12, x16, x2
	cmp	x12, #2
	b.lo	LBB2_172
; %bb.92:                               ;   in Loop: Header=BB2_91 Depth=1
	sub	x12, x16, x1
	cmp	x12, #2
	b.lo	LBB2_172
; %bb.93:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #240]                 ; 8-byte Reload
	sub	x12, x12, x3
	cmp	x12, #2
	b.lo	LBB2_172
; %bb.94:                               ;   in Loop: Header=BB2_91 Depth=1
	cmp	w24, #11
	b.ls	LBB2_98
; %bb.95:                               ;   in Loop: Header=BB2_91 Depth=1
	and	x12, x23, #0xfff
	ldr	w20, [x19, x12, lsl #2]
	strh	w20, [x28, x17]
	cmp	w21, #11
	b.ls	LBB2_101
LBB2_96:                                ;   in Loop: Header=BB2_91 Depth=1
	and	x12, x30, #0xfff
	ldr	w15, [x19, x12, lsl #2]
	strh	w15, [x9, x2]
	cmp	w4, #11
	b.ls	LBB2_104
LBB2_97:                                ;   in Loop: Header=BB2_91 Depth=1
	and	x12, x22, #0xfff
	ldr	w14, [x19, x12, lsl #2]
	strh	w14, [x11, x1]
	cmp	w7, #11
	b.hi	LBB2_90
	b	LBB2_107
LBB2_98:                                ;   in Loop: Header=BB2_91 Depth=1
	add	x14, x25, #4
	cmp	x14, x8
	b.hi	LBB2_111
; %bb.99:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #144]                 ; 8-byte Reload
	ldr	w5, [x12, x25]
LBB2_100:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w12, w5
	lsl	x12, x12, x24
	orr	x23, x12, x23
	orr	w24, w24, #0x20
	mov	x25, x14
	and	x12, x23, #0xfff
	ldr	w20, [x19, x12, lsl #2]
	strh	w20, [x28, x17]
	cmp	w21, #11
	b.hi	LBB2_96
LBB2_101:                               ;   in Loop: Header=BB2_91 Depth=1
	add	x14, x26, #4
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	cmp	x14, x10
	b.hi	LBB2_114
; %bb.102:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #128]                 ; 8-byte Reload
	ldr	w15, [x12, x26]
LBB2_103:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w12, w15
	lsl	x12, x12, x21
	orr	x30, x12, x30
	orr	w21, w21, #0x20
	mov	x26, x14
	and	x12, x30, #0xfff
	ldr	w15, [x19, x12, lsl #2]
	strh	w15, [x9, x2]
	cmp	w4, #11
	b.hi	LBB2_97
LBB2_104:                               ;   in Loop: Header=BB2_91 Depth=1
	add	x14, x27, #4
	ldr	x12, [sp, #160]                 ; 8-byte Reload
	cmp	x14, x12
	b.hi	LBB2_117
; %bb.105:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #224]                 ; 8-byte Reload
	ldr	w5, [x12, x27]
LBB2_106:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w12, w5
	lsl	x12, x12, x4
	orr	x22, x12, x22
	orr	w4, w4, #0x20
	mov	x27, x14
	and	x12, x22, #0xfff
	ldr	w14, [x19, x12, lsl #2]
	strh	w14, [x11, x1]
	cmp	w7, #11
	b.hi	LBB2_90
LBB2_107:                               ;   in Loop: Header=BB2_91 Depth=1
	add	x5, x0, #4
	ldr	x12, [sp, #192]                 ; 8-byte Reload
	cmp	x5, x12
	b.ls	LBB2_88
; %bb.108:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #192]                 ; 8-byte Reload
	subs	x10, x12, x0
	b.ls	LBB2_120
; %bb.109:                              ;   in Loop: Header=BB2_91 Depth=1
	cmp	x10, #4
	b.hs	LBB2_124
; %bb.110:                              ;   in Loop: Header=BB2_91 Depth=1
	str	xzr, [sp, #104]                 ; 8-byte Spill
	mov	w12, #0                         ; =0x0
	b	LBB2_152
LBB2_111:                               ;   in Loop: Header=BB2_91 Depth=1
	subs	x15, x8, x25
	b.ls	LBB2_121
; %bb.112:                              ;   in Loop: Header=BB2_91 Depth=1
	cmp	x15, #4
	b.hs	LBB2_126
; %bb.113:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	x20, #0                         ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB2_158
LBB2_114:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	subs	x12, x10, x26
	b.ls	LBB2_122
; %bb.115:                              ;   in Loop: Header=BB2_91 Depth=1
	cmp	x12, #4
	b.hs	LBB2_128
; %bb.116:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	x5, #0                          ; =0x0
	mov	w15, #0                         ; =0x0
	b	LBB2_164
LBB2_117:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x12, [sp, #160]                 ; 8-byte Reload
	subs	x12, x12, x27
	b.ls	LBB2_123
; %bb.118:                              ;   in Loop: Header=BB2_91 Depth=1
	cmp	x12, #4
	b.hs	LBB2_130
; %bb.119:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	x10, #0                         ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB2_170
LBB2_120:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w12, #0                         ; =0x0
	b	LBB2_89
LBB2_121:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w5, #0                          ; =0x0
	b	LBB2_100
LBB2_122:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w15, #0                         ; =0x0
	b	LBB2_103
LBB2_123:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	w5, #0                          ; =0x0
	b	LBB2_106
LBB2_124:                               ;   in Loop: Header=BB2_91 Depth=1
	str	x10, [sp, #16]                  ; 8-byte Spill
	cmp	x10, #32
	b.hs	LBB2_132
; %bb.125:                              ;   in Loop: Header=BB2_91 Depth=1
	str	xzr, [sp, #104]                 ; 8-byte Spill
	mov	w12, #0                         ; =0x0
	b	LBB2_149
LBB2_126:                               ;   in Loop: Header=BB2_91 Depth=1
	cmp	x15, #32
	b.hs	LBB2_136
; %bb.127:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	x20, #0                         ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB2_155
LBB2_128:                               ;   in Loop: Header=BB2_91 Depth=1
	cmp	x12, #32
	str	x12, [sp, #104]                 ; 8-byte Spill
	b.hs	LBB2_140
; %bb.129:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	x5, #0                          ; =0x0
	mov	w15, #0                         ; =0x0
	b	LBB2_161
LBB2_130:                               ;   in Loop: Header=BB2_91 Depth=1
	cmp	x12, #32
	str	x12, [sp, #104]                 ; 8-byte Spill
	b.hs	LBB2_144
; %bb.131:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	x10, #0                         ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB2_167
LBB2_132:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Reload
	add	x10, x8, x0
Lloh79:
	adrp	x12, lCPI2_0@PAGE
Lloh80:
	ldr	q19, [x12, lCPI2_0@PAGEOFF]
Lloh81:
	adrp	x12, lCPI2_1@PAGE
Lloh82:
	ldr	q20, [x12, lCPI2_1@PAGEOFF]
	movi.2d	v21, #0000000000000000
	ldr	x8, [sp, #16]                   ; 8-byte Reload
	and	x8, x8, #0xffffffffffffffe0
Lloh83:
	adrp	x12, lCPI2_2@PAGE
Lloh84:
	ldr	q24, [x12, lCPI2_2@PAGEOFF]
	movi.2d	v22, #0000000000000000
	movi.2d	v25, #0000000000000000
Lloh85:
	adrp	x12, lCPI2_3@PAGE
Lloh86:
	ldr	q28, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v23, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
LBB2_133:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q8, [x10, #-16]
	tbl.16b	v9, { v31 }, v5
	tbl.16b	v10, { v31 }, v6
	tbl.16b	v11, { v31 }, v7
	tbl.16b	v31, { v31 }, v18
	tbl.16b	v12, { v8 }, v6
	tbl.16b	v13, { v8 }, v5
	tbl.16b	v14, { v8 }, v7
	tbl.16b	v8, { v8 }, v18
	shl.4s	v15, v19, #3
	ushl.4s	v31, v31, v15
	add.4s	v15, v15, v16
	ushl.4s	v8, v8, v15
	shl.4s	v15, v20, #3
	ushl.4s	v11, v11, v15
	add.4s	v15, v15, v16
	ushl.4s	v14, v14, v15
	shl.4s	v15, v24, #3
	ushl.4s	v9, v9, v15
	add.4s	v15, v15, v16
	ushl.4s	v13, v13, v15
	shl.4s	v15, v28, #3
	ushl.4s	v10, v10, v15
	add.4s	v15, v15, v16
	ushl.4s	v12, v12, v15
	orr.16b	v25, v9, v25
	orr.16b	v22, v10, v22
	orr.16b	v23, v11, v23
	orr.16b	v26, v31, v26
	orr.16b	v27, v12, v27
	orr.16b	v21, v13, v21
	orr.16b	v29, v14, v29
	orr.16b	v30, v8, v30
	add.4s	v28, v28, v17
	add.4s	v24, v24, v17
	add.4s	v20, v20, v17
	add	x10, x10, #32
	add.4s	v19, v19, v17
	subs	x8, x8, #32
	b.ne	LBB2_133
; %bb.134:                              ;   in Loop: Header=BB2_91 Depth=1
	orr.16b	v19, v21, v25
	orr.16b	v20, v30, v26
	orr.16b	v21, v27, v22
	orr.16b	v22, v29, v23
	orr.16b	v21, v21, v22
	orr.16b	v19, v19, v20
	orr.16b	v19, v21, v19
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x8, d19
	lsr	x12, x8, #32
	orr	w12, w8, w12
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	and	x8, x10, #0xffffffffffffffe0
	cmp	x10, x8
	b.ne	LBB2_148
; %bb.135:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b	LBB2_89
LBB2_136:                               ;   in Loop: Header=BB2_91 Depth=1
	and	x8, x15, #0xffffffe0
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	ldr	x12, [sp, #48]                  ; 8-byte Reload
	mov	x10, x25
	add	x20, x12, x25
	and	x5, x15, #0xffffffe0
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v23, #0000000000000000
	mov.16b	v26, v0
	movi.2d	v24, #0000000000000000
	mov.16b	v27, v4
	movi.2d	v25, #0000000000000000
	mov.16b	v29, v3
	movi.2d	v28, #0000000000000000
	mov.16b	v30, v2
LBB2_137:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q8, [x20, #-16]
	tbl.16b	v9, { v31 }, v5
	tbl.16b	v10, { v31 }, v6
	tbl.16b	v11, { v31 }, v7
	tbl.16b	v31, { v31 }, v18
	tbl.16b	v12, { v8 }, v6
	tbl.16b	v13, { v8 }, v5
	tbl.16b	v14, { v8 }, v7
	tbl.16b	v8, { v8 }, v18
	shl.4s	v15, v30, #3
	ushl.4s	v31, v31, v15
	add.4s	v15, v15, v16
	ushl.4s	v8, v8, v15
	shl.4s	v15, v29, #3
	ushl.4s	v11, v11, v15
	add.4s	v15, v15, v16
	ushl.4s	v14, v14, v15
	shl.4s	v15, v27, #3
	ushl.4s	v9, v9, v15
	add.4s	v15, v15, v16
	ushl.4s	v13, v13, v15
	shl.4s	v15, v26, #3
	ushl.4s	v10, v10, v15
	add.4s	v15, v15, v16
	ushl.4s	v12, v12, v15
	orr.16b	v22, v9, v22
	orr.16b	v20, v10, v20
	orr.16b	v21, v11, v21
	orr.16b	v23, v31, v23
	orr.16b	v24, v12, v24
	orr.16b	v19, v13, v19
	orr.16b	v25, v14, v25
	orr.16b	v28, v8, v28
	add.4s	v26, v26, v17
	add.4s	v27, v27, v17
	add.4s	v29, v29, v17
	add	x20, x20, #32
	add.4s	v30, v30, v17
	subs	x5, x5, #32
	b.ne	LBB2_137
; %bb.138:                              ;   in Loop: Header=BB2_91 Depth=1
	orr.16b	v19, v19, v22
	orr.16b	v22, v28, v23
	orr.16b	v20, v24, v20
	orr.16b	v21, v25, v21
	orr.16b	v20, v20, v21
	orr.16b	v19, v19, v22
	orr.16b	v19, v20, v19
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x12, d19
	lsr	x5, x12, #32
	orr	w5, w12, w5
	cmp	x15, x8
	b.ne	LBB2_154
; %bb.139:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b	LBB2_100
LBB2_140:                               ;   in Loop: Header=BB2_91 Depth=1
	and	x10, x12, #0x1c
	and	x8, x12, #0xffffffe0
	stp	x10, x8, [sp, #8]               ; 16-byte Folded Spill
	ldr	x10, [sp, #40]                  ; 8-byte Reload
	add	x5, x10, x26
	mov	x8, x12
Lloh87:
	adrp	x12, lCPI2_0@PAGE
Lloh88:
	ldr	q19, [x12, lCPI2_0@PAGEOFF]
Lloh89:
	adrp	x12, lCPI2_1@PAGE
Lloh90:
	ldr	q20, [x12, lCPI2_1@PAGEOFF]
	movi.2d	v21, #0000000000000000
	and	x15, x8, #0xffffffe0
Lloh91:
	adrp	x12, lCPI2_2@PAGE
Lloh92:
	ldr	q24, [x12, lCPI2_2@PAGEOFF]
	movi.2d	v22, #0000000000000000
	movi.2d	v25, #0000000000000000
Lloh93:
	adrp	x12, lCPI2_3@PAGE
Lloh94:
	ldr	q28, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v23, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
LBB2_141:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q8, [x5, #-16]
	tbl.16b	v9, { v31 }, v5
	tbl.16b	v10, { v31 }, v6
	tbl.16b	v11, { v31 }, v7
	tbl.16b	v31, { v31 }, v18
	tbl.16b	v12, { v8 }, v6
	tbl.16b	v13, { v8 }, v5
	tbl.16b	v14, { v8 }, v7
	tbl.16b	v8, { v8 }, v18
	shl.4s	v15, v19, #3
	ushl.4s	v31, v31, v15
	add.4s	v15, v15, v16
	ushl.4s	v8, v8, v15
	shl.4s	v15, v20, #3
	ushl.4s	v11, v11, v15
	add.4s	v15, v15, v16
	ushl.4s	v14, v14, v15
	shl.4s	v15, v24, #3
	ushl.4s	v9, v9, v15
	add.4s	v15, v15, v16
	ushl.4s	v13, v13, v15
	shl.4s	v15, v28, #3
	ushl.4s	v10, v10, v15
	add.4s	v15, v15, v16
	ushl.4s	v12, v12, v15
	orr.16b	v25, v9, v25
	orr.16b	v22, v10, v22
	orr.16b	v23, v11, v23
	orr.16b	v26, v31, v26
	orr.16b	v27, v12, v27
	orr.16b	v21, v13, v21
	orr.16b	v29, v14, v29
	orr.16b	v30, v8, v30
	add.4s	v28, v28, v17
	add.4s	v24, v24, v17
	add.4s	v20, v20, v17
	add	x5, x5, #32
	add.4s	v19, v19, v17
	subs	x15, x15, #32
	b.ne	LBB2_141
; %bb.142:                              ;   in Loop: Header=BB2_91 Depth=1
	orr.16b	v19, v21, v25
	orr.16b	v20, v30, v26
	orr.16b	v21, v27, v22
	orr.16b	v22, v29, v23
	orr.16b	v21, v21, v22
	orr.16b	v19, v19, v20
	orr.16b	v19, v21, v19
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x12, d19
	lsr	x15, x12, #32
	orr	w15, w12, w15
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	cmp	x8, x10
	b.ne	LBB2_160
; %bb.143:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b	LBB2_103
LBB2_144:                               ;   in Loop: Header=BB2_91 Depth=1
	and	x10, x12, #0x1c
	and	x8, x12, #0xffffffe0
	stp	x10, x8, [sp, #8]               ; 16-byte Folded Spill
	ldr	x10, [sp, #32]                  ; 8-byte Reload
	add	x5, x10, x27
	mov	x8, x12
Lloh95:
	adrp	x12, lCPI2_0@PAGE
Lloh96:
	ldr	q19, [x12, lCPI2_0@PAGEOFF]
Lloh97:
	adrp	x12, lCPI2_1@PAGE
Lloh98:
	ldr	q20, [x12, lCPI2_1@PAGEOFF]
	movi.2d	v21, #0000000000000000
	and	x8, x8, #0xffffffe0
Lloh99:
	adrp	x12, lCPI2_2@PAGE
Lloh100:
	ldr	q24, [x12, lCPI2_2@PAGEOFF]
	movi.2d	v22, #0000000000000000
	movi.2d	v25, #0000000000000000
Lloh101:
	adrp	x12, lCPI2_3@PAGE
Lloh102:
	ldr	q28, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v23, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
LBB2_145:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q8, [x5, #-16]
	tbl.16b	v9, { v31 }, v5
	tbl.16b	v10, { v31 }, v6
	tbl.16b	v11, { v31 }, v7
	tbl.16b	v31, { v31 }, v18
	tbl.16b	v12, { v8 }, v6
	tbl.16b	v13, { v8 }, v5
	tbl.16b	v14, { v8 }, v7
	tbl.16b	v8, { v8 }, v18
	shl.4s	v15, v19, #3
	ushl.4s	v31, v31, v15
	add.4s	v15, v15, v16
	ushl.4s	v8, v8, v15
	shl.4s	v15, v20, #3
	ushl.4s	v11, v11, v15
	add.4s	v15, v15, v16
	ushl.4s	v14, v14, v15
	shl.4s	v15, v24, #3
	ushl.4s	v9, v9, v15
	add.4s	v15, v15, v16
	ushl.4s	v13, v13, v15
	shl.4s	v15, v28, #3
	ushl.4s	v10, v10, v15
	add.4s	v15, v15, v16
	ushl.4s	v12, v12, v15
	orr.16b	v25, v9, v25
	orr.16b	v22, v10, v22
	orr.16b	v23, v11, v23
	orr.16b	v26, v31, v26
	orr.16b	v27, v12, v27
	orr.16b	v21, v13, v21
	orr.16b	v29, v14, v29
	orr.16b	v30, v8, v30
	add.4s	v28, v28, v17
	add.4s	v24, v24, v17
	add.4s	v20, v20, v17
	add	x5, x5, #32
	add.4s	v19, v19, v17
	subs	x8, x8, #32
	b.ne	LBB2_145
; %bb.146:                              ;   in Loop: Header=BB2_91 Depth=1
	orr.16b	v19, v21, v25
	orr.16b	v20, v30, v26
	orr.16b	v21, v27, v22
	orr.16b	v22, v29, v23
	orr.16b	v21, v21, v22
	orr.16b	v19, v19, v20
	orr.16b	v19, v21, v19
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x12, d19
	lsr	x5, x12, #32
	orr	w5, w12, w5
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	cmp	x8, x10
	b.ne	LBB2_166
; %bb.147:                              ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b	LBB2_106
LBB2_148:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	and	x10, x10, #0xffffffffffffffe0
	str	x10, [sp, #104]                 ; 8-byte Spill
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	and	x10, x10, #0x1c
	cbz	x10, LBB2_152
LBB2_149:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x10, [sp, #104]                 ; 8-byte Reload
	ldr	x8, [sp, #16]                   ; 8-byte Reload
	and	x8, x8, #0xfffffffffffffffc
	movi.2d	v19, #0000000000000000
	mov.s	v19[0], w12
	mov	x12, x10
	dup.4s	v20, w12
	orr.16b	v20, v20, v0
	sub	x10, x10, x8
	add	x12, x12, x0
	ldr	x8, [sp, #72]                   ; 8-byte Reload
	add	x12, x8, x12
LBB2_150:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s21, [x12], #4
	ushll.8h	v21, v21, #0
	ushll.4s	v21, v21, #0
	shl.4s	v22, v20, #3
	ushl.4s	v21, v21, v22
	orr.16b	v19, v21, v19
	add.4s	v20, v20, v1
	adds	x10, x10, #4
	b.ne	LBB2_150
; %bb.151:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x8, d19
	lsr	x12, x8, #32
	orr	w12, w8, w12
	ldr	x8, [sp, #16]                   ; 8-byte Reload
	and	x10, x8, #0xfffffffffffffffc
	str	x10, [sp, #104]                 ; 8-byte Spill
	cmp	x8, x10
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b.eq	LBB2_89
LBB2_152:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x10, [sp, #104]                 ; 8-byte Reload
	add	x0, x10, x0
	ldr	x10, [sp, #112]                 ; 8-byte Reload
	add	x10, x0, x10
	str	x10, [sp, #16]                  ; 8-byte Spill
	ldr	x10, [sp, #104]                 ; 8-byte Reload
	lsl	w10, w10, #3
	str	w10, [sp, #104]                 ; 4-byte Spill
	ldr	x10, [sp, #72]                  ; 8-byte Reload
	add	x10, x10, x0
	str	x10, [sp, #8]                   ; 8-byte Spill
LBB2_153:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x10, [sp, #8]                   ; 8-byte Reload
	ldrb	w0, [x10], #1
	str	x10, [sp, #8]                   ; 8-byte Spill
	ldr	w10, [sp, #104]                 ; 4-byte Reload
	lsl	w0, w0, w10
	orr	w12, w0, w12
	add	w10, w10, #8
	str	w10, [sp, #104]                 ; 4-byte Spill
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	adds	x10, x10, #1
	str	x10, [sp, #16]                  ; 8-byte Spill
	b.lo	LBB2_153
	b	LBB2_89
LBB2_154:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	x25, x10
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	and	x20, x15, #0xffffffe0
	and	x10, x15, #0x1c
	cbz	x10, LBB2_158
LBB2_155:                               ;   in Loop: Header=BB2_91 Depth=1
	and	x8, x15, #0xfffffffc
	movi.2d	v19, #0000000000000000
	mov.s	v19[0], w5
	dup.4s	v20, w20
	orr.16b	v20, v20, v0
	sub	x12, x20, x8
	mov	x10, x25
	add	x5, x20, x25
	ldr	x20, [sp, #96]                  ; 8-byte Reload
	add	x5, x20, x5
LBB2_156:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s21, [x5], #4
	ushll.8h	v21, v21, #0
	ushll.4s	v21, v21, #0
	shl.4s	v22, v20, #3
	ushl.4s	v21, v21, v22
	orr.16b	v19, v21, v19
	add.4s	v20, v20, v1
	adds	x12, x12, #4
	b.ne	LBB2_156
; %bb.157:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x12, d19
	lsr	x5, x12, #32
	orr	w5, w12, w5
	and	x20, x15, #0xfffffffc
	cmp	x15, x20
	mov	x25, x10
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b.eq	LBB2_100
LBB2_158:                               ;   in Loop: Header=BB2_91 Depth=1
	mov	x15, x20
	add	x20, x20, x25
	neg	x10, x8
	add	x12, x20, x10
	lsl	w15, w15, #3
	ldr	x25, [sp, #96]                  ; 8-byte Reload
	add	x20, x25, x20
LBB2_159:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w25, [x20], #1
	lsl	w25, w25, w15
	orr	w5, w25, w5
	add	w15, w15, #8
	adds	x12, x12, #1
	b.lo	LBB2_159
	b	LBB2_100
LBB2_160:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	ldp	x10, x5, [sp, #8]               ; 16-byte Folded Reload
	cbz	x10, LBB2_164
LBB2_161:                               ;   in Loop: Header=BB2_91 Depth=1
	str	x25, [sp]                       ; 8-byte Spill
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	and	x8, x8, #0xfffffffc
	movi.2d	v19, #0000000000000000
	mov.s	v19[0], w15
	dup.4s	v20, w5
	orr.16b	v20, v20, v0
	mov	x25, x8
	sub	x12, x5, x8
	add	x15, x5, x26
	ldr	x10, [sp, #88]                  ; 8-byte Reload
	add	x15, x10, x15
LBB2_162:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s21, [x15], #4
	ushll.8h	v21, v21, #0
	ushll.4s	v21, v21, #0
	shl.4s	v22, v20, #3
	ushl.4s	v21, v21, v22
	orr.16b	v19, v21, v19
	add.4s	v20, v20, v1
	adds	x12, x12, #4
	b.ne	LBB2_162
; %bb.163:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x12, d19
	lsr	x15, x12, #32
	orr	w15, w12, w15
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	mov	x5, x25
	cmp	x8, x25
	ldr	x25, [sp]                       ; 8-byte Reload
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b.eq	LBB2_103
LBB2_164:                               ;   in Loop: Header=BB2_91 Depth=1
	add	x26, x5, x26
	ldr	x10, [sp, #64]                  ; 8-byte Reload
	add	x12, x26, x10
	lsl	w5, w5, #3
	ldr	x10, [sp, #88]                  ; 8-byte Reload
	add	x26, x10, x26
	mov	x10, x12
LBB2_165:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w12, [x26], #1
	lsl	w12, w12, w5
	orr	w15, w12, w15
	add	w5, w5, #8
	adds	x10, x10, #1
	b.lo	LBB2_165
	b	LBB2_103
LBB2_166:                               ;   in Loop: Header=BB2_91 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	ldp	x12, x10, [sp, #8]              ; 16-byte Folded Reload
	cbz	x12, LBB2_170
LBB2_167:                               ;   in Loop: Header=BB2_91 Depth=1
	str	x25, [sp]                       ; 8-byte Spill
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	and	x8, x8, #0xfffffffc
	movi.2d	v19, #0000000000000000
	mov.s	v19[0], w5
	dup.4s	v20, w10
	orr.16b	v20, v20, v0
	mov	x25, x8
	sub	x12, x10, x8
	add	x5, x10, x27
	ldr	x10, [sp, #80]                  ; 8-byte Reload
	add	x5, x10, x5
LBB2_168:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s21, [x5], #4
	ushll.8h	v21, v21, #0
	ushll.4s	v21, v21, #0
	shl.4s	v22, v20, #3
	ushl.4s	v21, v21, v22
	orr.16b	v19, v21, v19
	add.4s	v20, v20, v1
	adds	x12, x12, #4
	b.ne	LBB2_168
; %bb.169:                              ;   in Loop: Header=BB2_91 Depth=1
	mov	d20, v19[1]
	orr.8b	v19, v19, v20
	fmov	x12, d19
	lsr	x5, x12, #32
	orr	w5, w12, w5
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	mov	x10, x25
	cmp	x8, x25
	ldr	x25, [sp]                       ; 8-byte Reload
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	b.eq	LBB2_106
LBB2_170:                               ;   in Loop: Header=BB2_91 Depth=1
	add	x12, x10, x27
	mov	x27, x10
	ldr	x10, [sp, #56]                  ; 8-byte Reload
	add	x10, x12, x10
	str	x10, [sp, #8]                   ; 8-byte Spill
	lsl	w10, w27, #3
	str	w10, [sp, #16]                  ; 4-byte Spill
	ldr	x10, [sp, #80]                  ; 8-byte Reload
	add	x10, x10, x12
	str	x10, [sp, #104]                 ; 8-byte Spill
	ldr	x10, [sp, #8]                   ; 8-byte Reload
LBB2_171:                               ;   Parent Loop BB2_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x27, [sp, #104]                 ; 8-byte Reload
	ldrb	w12, [x27], #1
	str	x27, [sp, #104]                 ; 8-byte Spill
	ldr	w27, [sp, #16]                  ; 4-byte Reload
	lsl	w12, w12, w27
	orr	w5, w12, w5
	add	w27, w27, #8
	str	w27, [sp, #16]                  ; 4-byte Spill
	adds	x10, x10, #1
	b.lo	LBB2_171
	b	LBB2_106
LBB2_172:
	stp	x2, x1, [sp, #264]
	str	x3, [sp, #280]
	adrp	x28, lCPI2_0@PAGE
LBB2_173:
	mov	x19, #0                         ; =0x0
	str	x17, [sp, #256]
	ldr	x9, [sp, #144]                  ; 8-byte Reload
	stp	x9, x8, [sp, #352]
	stp	x25, x23, [sp, #368]
	str	w24, [sp, #384]
	ldr	x9, [sp, #128]                  ; 8-byte Reload
	ldr	x8, [sp, #176]                  ; 8-byte Reload
	stp	x9, x8, [sp, #392]
	stp	x26, x30, [sp, #408]
	str	w21, [sp, #424]
	ldr	x9, [sp, #224]                  ; 8-byte Reload
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	stp	x9, x8, [sp, #432]
	stp	x27, x22, [sp, #448]
	str	w4, [sp, #464]
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	ldr	x8, [sp, #192]                  ; 8-byte Reload
	stp	x9, x8, [sp, #472]
	stp	x0, x6, [sp, #488]
	str	w7, [sp, #504]
	add	x20, sp, #288
	add	x21, sp, #256
	mov	w22, #40                        ; =0x28
	add	x23, sp, #352
Lloh103:
	adrp	x8, lCPI2_3@PAGE
Lloh104:
	ldr	q0, [x8, lCPI2_3@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Spill
	ldr	q0, [x28, lCPI2_0@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Spill
Lloh105:
	adrp	x8, lCPI2_1@PAGE
Lloh106:
	ldr	q0, [x8, lCPI2_1@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Spill
Lloh107:
	adrp	x8, lCPI2_2@PAGE
Lloh108:
	ldr	q0, [x8, lCPI2_2@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
Lloh109:
	adrp	x8, lCPI2_4@PAGE
Lloh110:
	ldr	q29, [x8, lCPI2_4@PAGEOFF]
Lloh111:
	adrp	x8, lCPI2_5@PAGE
Lloh112:
	ldr	q30, [x8, lCPI2_5@PAGEOFF]
Lloh113:
	adrp	x8, lCPI2_6@PAGE
Lloh114:
	ldr	q31, [x8, lCPI2_6@PAGEOFF]
	movi.4s	v8, #128
	movi.4s	v9, #32
	add	x24, sp, #512
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #512
Lloh115:
	adrp	x8, lCPI2_7@PAGE
Lloh116:
	ldr	q10, [x8, lCPI2_7@PAGEOFF]
	stp	q30, q29, [sp, #224]            ; 32-byte Folded Spill
	stp	q10, q31, [sp, #192]            ; 32-byte Folded Spill
	b	LBB2_177
LBB2_174:                               ;   in Loop: Header=BB2_177 Depth=1
	ldr	x13, [x10, #24]
LBB2_175:                               ;   in Loop: Header=BB2_177 Depth=1
	and	x11, x13, #0xfff
	ldrh	w11, [x25, x11, lsl #1]
	ldr	x8, [x8]
	strb	w11, [x8, x9]
	lsr	x8, x11, #8
	ldr	x9, [x10, #24]
	lsr	x9, x9, x8
	str	x9, [x10, #24]
	ldr	w9, [x10, #32]
	sub	w8, w9, w8
	str	w8, [x10, #32]
LBB2_176:                               ;   in Loop: Header=BB2_177 Depth=1
	madd	x0, x19, x22, x23
	bl	__ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
	add	x19, x19, #1
	cmp	x19, #4
	ldp	q30, q29, [sp, #224]            ; 32-byte Folded Reload
	ldp	q10, q31, [sp, #192]            ; 32-byte Folded Reload
	movi.4s	v8, #128
	movi.4s	v9, #32
	b.eq	LBB2_222
LBB2_177:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_182 Depth 2
                                        ;       Child Loop BB2_191 Depth 3
                                        ;       Child Loop BB2_195 Depth 3
                                        ;       Child Loop BB2_198 Depth 3
                                        ;     Child Loop BB2_212 Depth 2
                                        ;     Child Loop BB2_216 Depth 2
                                        ;     Child Loop BB2_219 Depth 2
	add	x8, x20, x19, lsl #4
	ldr	x10, [x8, #8]
	ldr	x9, [x21, x19, lsl #3]
	sub	x11, x10, x9
	cmp	x11, #2
	b.lo	LBB2_200
; %bb.178:                              ;   in Loop: Header=BB2_177 Depth=1
	madd	x11, x19, x22, x23
	ldr	x12, [x8]
	ldr	w13, [x11, #32]
	ldr	x14, [x11, #24]
	b	LBB2_182
LBB2_179:                               ;   in Loop: Header=BB2_182 Depth=2
	ldr	x17, [x11]
	ldr	w4, [x17, x16]
LBB2_180:                               ;   in Loop: Header=BB2_182 Depth=2
	mov	w16, w4
	lsl	x16, x16, x13
	orr	x14, x16, x14
	str	x15, [x11, #16]
	orr	w13, w13, #0x20
LBB2_181:                               ;   in Loop: Header=BB2_182 Depth=2
	and	x15, x14, #0xfff
	ldr	w15, [x24, x15, lsl #2]
	lsr	x16, x15, #16
	ubfx	x17, x15, #16, #8
	lsr	x14, x14, x16
	sub	w13, w13, w17
	strh	w15, [x12, x9]
	add	x9, x9, x15, lsr #24
	sub	x15, x10, x9
	cmp	x15, #1
	b.ls	LBB2_199
LBB2_182:                               ;   Parent Loop BB2_177 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_191 Depth 3
                                        ;       Child Loop BB2_195 Depth 3
                                        ;       Child Loop BB2_198 Depth 3
	cmp	w13, #11
	b.hi	LBB2_181
; %bb.183:                              ;   in Loop: Header=BB2_182 Depth=2
	ldp	x17, x16, [x11, #8]
	add	x15, x16, #4
	cmp	x15, x17
	b.ls	LBB2_179
; %bb.184:                              ;   in Loop: Header=BB2_182 Depth=2
	subs	x1, x17, x16
	b.ls	LBB2_187
; %bb.185:                              ;   in Loop: Header=BB2_182 Depth=2
	ldr	x0, [x11]
	cmp	x1, #4
	b.hs	LBB2_188
; %bb.186:                              ;   in Loop: Header=BB2_182 Depth=2
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB2_197
LBB2_187:                               ;   in Loop: Header=BB2_182 Depth=2
	mov	w4, #0                          ; =0x0
	b	LBB2_180
LBB2_188:                               ;   in Loop: Header=BB2_182 Depth=2
	cmp	x1, #32
	b.hs	LBB2_190
; %bb.189:                              ;   in Loop: Header=BB2_182 Depth=2
	mov	x2, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	LBB2_194
LBB2_190:                               ;   in Loop: Header=BB2_182 Depth=2
	and	x3, x1, #0x1c
	and	x2, x1, #0xffffffffffffffe0
	add	x4, x0, x16
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	add	x4, x4, #16
	and	x5, x1, #0xffffffffffffffe0
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldp	q19, q7, [sp, #160]             ; 32-byte Folded Reload
	movi.2d	v6, #0000000000000000
	ldp	q17, q18, [sp, #128]            ; 32-byte Folded Reload
	movi.2d	v16, #0000000000000000
LBB2_191:                               ;   Parent Loop BB2_177 Depth=1
                                        ;     Parent Loop BB2_182 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q20, q21, [x4, #-16]
	tbl.16b	v22, { v20 }, v29
	tbl.16b	v23, { v20 }, v30
	tbl.16b	v24, { v20 }, v31
	tbl.16b	v20, { v20 }, v10
	tbl.16b	v25, { v21 }, v30
	tbl.16b	v26, { v21 }, v29
	tbl.16b	v27, { v21 }, v31
	tbl.16b	v21, { v21 }, v10
	shl.4s	v28, v19, #3
	ushl.4s	v20, v20, v28
	add.4s	v28, v28, v8
	ushl.4s	v21, v21, v28
	shl.4s	v28, v18, #3
	ushl.4s	v24, v24, v28
	add.4s	v28, v28, v8
	ushl.4s	v27, v27, v28
	shl.4s	v28, v17, #3
	ushl.4s	v22, v22, v28
	add.4s	v28, v28, v8
	ushl.4s	v26, v26, v28
	shl.4s	v28, v7, #3
	ushl.4s	v23, v23, v28
	add.4s	v28, v28, v8
	ushl.4s	v25, v25, v28
	orr.16b	v3, v22, v3
	orr.16b	v1, v23, v1
	orr.16b	v2, v24, v2
	orr.16b	v4, v20, v4
	orr.16b	v5, v25, v5
	orr.16b	v0, v26, v0
	orr.16b	v6, v27, v6
	orr.16b	v16, v21, v16
	add.4s	v7, v7, v9
	add.4s	v17, v17, v9
	add.4s	v18, v18, v9
	add	x4, x4, #32
	add.4s	v19, v19, v9
	subs	x5, x5, #32
	b.ne	LBB2_191
; %bb.192:                              ;   in Loop: Header=BB2_182 Depth=2
	orr.16b	v0, v0, v3
	orr.16b	v3, v16, v4
	orr.16b	v1, v5, v1
	orr.16b	v2, v6, v2
	orr.16b	v1, v1, v2
	orr.16b	v0, v0, v3
	orr.16b	v0, v1, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x4, d0
	lsr	x5, x4, #32
	orr	w4, w4, w5
	cmp	x1, x2
	b.eq	LBB2_180
; %bb.193:                              ;   in Loop: Header=BB2_182 Depth=2
	cbz	x3, LBB2_197
LBB2_194:                               ;   in Loop: Header=BB2_182 Depth=2
	mov	x5, x2
	and	x2, x1, #0xfffffffffffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w4
	dup.4s	v1, w5
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	orr.16b	v1, v1, v2
	sub	x3, x5, x2
	add	x4, x5, x16
	add	x4, x0, x4
LBB2_195:                               ;   Parent Loop BB2_177 Depth=1
                                        ;     Parent Loop BB2_182 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	s2, [x4], #4
	ushll.8h	v2, v2, #0
	ushll.4s	v2, v2, #0
	shl.4s	v3, v1, #3
	ushl.4s	v2, v2, v3
	movi.4s	v3, #4
	orr.16b	v0, v2, v0
	add.4s	v1, v1, v3
	adds	x3, x3, #4
	b.ne	LBB2_195
; %bb.196:                              ;   in Loop: Header=BB2_182 Depth=2
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x3, d0
	lsr	x4, x3, #32
	orr	w4, w3, w4
	cmp	x1, x2
	b.eq	LBB2_180
LBB2_197:                               ;   in Loop: Header=BB2_182 Depth=2
	add	x1, x2, x16
	sub	x16, x1, x17
	lsl	w17, w2, #3
	add	x0, x0, x1
LBB2_198:                               ;   Parent Loop BB2_177 Depth=1
                                        ;     Parent Loop BB2_182 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w1, [x0], #1
	lsl	w1, w1, w17
	orr	w4, w1, w4
	add	w17, w17, #8
	adds	x16, x16, #1
	b.lo	LBB2_198
	b	LBB2_180
LBB2_199:                               ;   in Loop: Header=BB2_177 Depth=1
	str	w13, [x11, #32]
	str	x14, [x11, #24]
LBB2_200:                               ;   in Loop: Header=BB2_177 Depth=1
	str	x9, [x21, x19, lsl #3]
	cmp	x9, x10
	b.hs	LBB2_176
; %bb.201:                              ;   in Loop: Header=BB2_177 Depth=1
	madd	x10, x19, x22, x23
	ldr	w11, [x10, #32]
	cmp	w11, #12
	b.hs	LBB2_174
; %bb.202:                              ;   in Loop: Header=BB2_177 Depth=1
	ldp	x14, x13, [x10, #8]
	add	x12, x13, #4
	cmp	x12, x14
	b.hi	LBB2_205
; %bb.203:                              ;   in Loop: Header=BB2_177 Depth=1
	ldr	x14, [x10]
	ldr	w1, [x14, x13]
LBB2_204:                               ;   in Loop: Header=BB2_177 Depth=1
	mov	w13, w1
	lsl	x13, x13, x11
	ldr	x14, [x10, #24]
	orr	x13, x13, x14
	stp	x12, x13, [x10, #16]
	orr	w11, w11, #0x20
	str	w11, [x10, #32]
	b	LBB2_175
LBB2_205:                               ;   in Loop: Header=BB2_177 Depth=1
	subs	x16, x14, x13
	b.ls	LBB2_208
; %bb.206:                              ;   in Loop: Header=BB2_177 Depth=1
	ldr	x15, [x10]
	cmp	x16, #4
	b.hs	LBB2_209
; %bb.207:                              ;   in Loop: Header=BB2_177 Depth=1
	mov	x17, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB2_218
LBB2_208:                               ;   in Loop: Header=BB2_177 Depth=1
	mov	w1, #0                          ; =0x0
	b	LBB2_204
LBB2_209:                               ;   in Loop: Header=BB2_177 Depth=1
	cmp	x16, #32
	b.hs	LBB2_211
; %bb.210:                              ;   in Loop: Header=BB2_177 Depth=1
	mov	x17, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	b	LBB2_215
LBB2_211:                               ;   in Loop: Header=BB2_177 Depth=1
	and	x0, x16, #0x1c
	and	x17, x16, #0xffffffffffffffe0
	add	x1, x15, x13
	add	x1, x1, #16
	mov	x3, x28
	ldr	q0, [x28, lCPI2_0@PAGEOFF]
Lloh117:
	adrp	x2, lCPI2_1@PAGE
Lloh118:
	ldr	q1, [x2, lCPI2_1@PAGEOFF]
Lloh119:
	adrp	x2, lCPI2_2@PAGE
Lloh120:
	ldr	q2, [x2, lCPI2_2@PAGEOFF]
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
Lloh121:
	adrp	x2, lCPI2_3@PAGE
Lloh122:
	ldr	q6, [x2, lCPI2_3@PAGEOFF]
	and	x2, x16, #0xffffffffffffffe0
	movi.2d	v7, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	ldp	q30, q29, [sp, #224]            ; 32-byte Folded Reload
	ldp	q10, q31, [sp, #192]            ; 32-byte Folded Reload
	movi.4s	v8, #128
	movi.4s	v9, #32
LBB2_212:                               ;   Parent Loop BB2_177 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q20, q21, [x1, #-16]
	tbl.16b	v22, { v20 }, v29
	tbl.16b	v23, { v20 }, v30
	tbl.16b	v24, { v20 }, v31
	tbl.16b	v20, { v20 }, v10
	tbl.16b	v25, { v21 }, v30
	tbl.16b	v26, { v21 }, v29
	tbl.16b	v27, { v21 }, v31
	tbl.16b	v21, { v21 }, v10
	shl.4s	v28, v0, #3
	ushl.4s	v20, v20, v28
	add.4s	v28, v28, v8
	ushl.4s	v21, v21, v28
	shl.4s	v28, v1, #3
	ushl.4s	v24, v24, v28
	add.4s	v28, v28, v8
	ushl.4s	v27, v27, v28
	shl.4s	v28, v2, #3
	ushl.4s	v22, v22, v28
	add.4s	v28, v28, v8
	ushl.4s	v26, v26, v28
	shl.4s	v28, v6, #3
	ushl.4s	v23, v23, v28
	add.4s	v28, v28, v8
	ushl.4s	v25, v25, v28
	orr.16b	v7, v22, v7
	orr.16b	v4, v23, v4
	orr.16b	v5, v24, v5
	orr.16b	v16, v20, v16
	orr.16b	v17, v25, v17
	orr.16b	v3, v26, v3
	orr.16b	v18, v27, v18
	orr.16b	v19, v21, v19
	add.4s	v6, v6, v9
	add.4s	v2, v2, v9
	add.4s	v1, v1, v9
	add	x1, x1, #32
	add.4s	v0, v0, v9
	subs	x2, x2, #32
	b.ne	LBB2_212
; %bb.213:                              ;   in Loop: Header=BB2_177 Depth=1
	orr.16b	v0, v3, v7
	orr.16b	v1, v19, v16
	orr.16b	v2, v17, v4
	orr.16b	v3, v18, v5
	orr.16b	v2, v2, v3
	orr.16b	v0, v0, v1
	orr.16b	v0, v2, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x1, d0
	lsr	x2, x1, #32
	orr	w1, w1, w2
	mov	x28, x3
	cmp	x16, x17
	b.eq	LBB2_204
; %bb.214:                              ;   in Loop: Header=BB2_177 Depth=1
	cbz	x0, LBB2_218
LBB2_215:                               ;   in Loop: Header=BB2_177 Depth=1
	mov	x2, x17
	and	x17, x16, #0xfffffffffffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w1
	dup.4s	v1, w2
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	orr.16b	v1, v1, v2
	sub	x0, x2, x17
	add	x1, x2, x13
	add	x1, x15, x1
	movi.4s	v4, #4
LBB2_216:                               ;   Parent Loop BB2_177 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s2, [x1], #4
	ushll.8h	v2, v2, #0
	ushll.4s	v2, v2, #0
	shl.4s	v3, v1, #3
	ushl.4s	v2, v2, v3
	orr.16b	v0, v2, v0
	add.4s	v1, v1, v4
	adds	x0, x0, #4
	b.ne	LBB2_216
; %bb.217:                              ;   in Loop: Header=BB2_177 Depth=1
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x0, d0
	lsr	x1, x0, #32
	orr	w1, w0, w1
	cmp	x16, x17
	b.eq	LBB2_204
LBB2_218:                               ;   in Loop: Header=BB2_177 Depth=1
	add	x16, x17, x13
	sub	x13, x16, x14
	lsl	w14, w17, #3
	add	x15, x15, x16
LBB2_219:                               ;   Parent Loop BB2_177 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w16, [x15], #1
	lsl	w16, w16, w14
	orr	w1, w16, w1
	add	w14, w14, #8
	adds	x13, x13, #1
	b.lo	LBB2_219
	b	LBB2_204
LBB2_220:
	mov	w8, #0                          ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
LBB2_221:
	str	x11, [sp, #536]
	str	x12, [sp, #528]
	str	w8, [sp, #544]
	add	x0, sp, #512
	bl	__ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
LBB2_222:
	ldur	x8, [x29, #-160]
Lloh123:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh124:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh125:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_294
; %bb.223:
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1296
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB2_224:
	subs	x15, x8, x14
	b.ls	LBB2_236
; %bb.225:
	mov	x21, x8
	add	x25, x14, #4
	mov	x20, x24
	mov	x19, x28
	cmp	x15, #4
	b.hs	LBB2_240
; %bb.226:
	mov	x0, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	mov	x28, x19
	mov	x24, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x25, x14, #4
	mov	x8, x21
	b	LBB2_269
LBB2_227:
	subs	x0, x10, x14
	b.ls	LBB2_237
; %bb.228:
	mov	x10, x8
	mov	x20, x28
	cmp	x0, #4
	b.hs	LBB2_242
; %bb.229:
	mov	x4, #0                          ; =0x0
	mov	w7, #0                          ; =0x0
	mov	x28, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	mov	x8, x10
	b	LBB2_275
LBB2_230:
	subs	x22, x30, x0
	b.ls	LBB2_238
; %bb.231:
	mov	x30, x8
	cmp	x22, #4
	b.hs	LBB2_244
; %bb.232:
	mov	x23, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	adrp	x28, lCPI2_0@PAGE
	mov	x8, x30
	b	LBB2_281
LBB2_233:
	ldr	x11, [sp, #192]                 ; 8-byte Reload
	subs	x11, x11, x9
	b.ls	LBB2_239
; %bb.234:
	mov	x19, x8
	mov	x7, x28
	cmp	x11, #4
	b.hs	LBB2_246
; %bb.235:
	mov	x13, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	mov	x28, x7
	mov	x8, x19
	b	LBB2_287
LBB2_236:
	mov	w5, #0                          ; =0x0
	b	LBB2_80
LBB2_237:
	mov	w7, #0                          ; =0x0
	b	LBB2_82
LBB2_238:
	mov	w19, #0                         ; =0x0
	b	LBB2_84
LBB2_239:
	mov	w15, #0                         ; =0x0
	b	LBB2_86
LBB2_240:
	cmp	x15, #32
	b.hs	LBB2_248
; %bb.241:
	mov	x0, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB2_266
LBB2_242:
	cmp	x0, #32
	b.hs	LBB2_252
; %bb.243:
	mov	x4, #0                          ; =0x0
	mov	w7, #0                          ; =0x0
	mov	x8, x10
	b	LBB2_272
LBB2_244:
	cmp	x22, #32
	b.hs	LBB2_256
; %bb.245:
	mov	x23, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	mov	x8, x30
	b	LBB2_278
LBB2_246:
	cmp	x11, #32
	b.hs	LBB2_260
; %bb.247:
	mov	x13, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	mov	x8, x19
	b	LBB2_284
LBB2_248:
	and	x4, x15, #0x1c
	and	x0, x15, #0xffffffe0
	ldr	x12, [sp, #120]                 ; 8-byte Reload
	add	x12, x14, x12
	ldr	x5, [sp, #104]                  ; 8-byte Reload
	add	x12, x12, x5
	add	x5, x12, #33
	ldr	q0, [x19, lCPI2_0@PAGEOFF]
Lloh126:
	adrp	x12, lCPI2_1@PAGE
Lloh127:
	ldr	q1, [x12, lCPI2_1@PAGEOFF]
Lloh128:
	adrp	x12, lCPI2_2@PAGE
Lloh129:
	ldr	q2, [x12, lCPI2_2@PAGEOFF]
Lloh130:
	adrp	x12, lCPI2_3@PAGE
Lloh131:
	ldr	q4, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v3, #0000000000000000
	movi.4s	v5, #128
	movi.4s	v6, #32
	and	x7, x15, #0xffffffe0
Lloh132:
	adrp	x12, lCPI2_4@PAGE
Lloh133:
	ldr	q17, [x12, lCPI2_4@PAGEOFF]
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
Lloh134:
	adrp	x12, lCPI2_5@PAGE
Lloh135:
	ldr	q20, [x12, lCPI2_5@PAGEOFF]
	movi.2d	v16, #0000000000000000
	movi.2d	v19, #0000000000000000
Lloh136:
	adrp	x12, lCPI2_6@PAGE
Lloh137:
	ldr	q23, [x12, lCPI2_6@PAGEOFF]
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
Lloh138:
	adrp	x12, lCPI2_7@PAGE
Lloh139:
	ldr	q25, [x12, lCPI2_7@PAGEOFF]
	movi.2d	v24, #0000000000000000
LBB2_249:                               ; =>This Inner Loop Header: Depth=1
	ldp	q26, q27, [x5, #-16]
	tbl.16b	v28, { v26 }, v17
	tbl.16b	v29, { v26 }, v20
	tbl.16b	v30, { v26 }, v23
	tbl.16b	v26, { v26 }, v25
	tbl.16b	v31, { v27 }, v20
	tbl.16b	v8, { v27 }, v17
	tbl.16b	v9, { v27 }, v23
	tbl.16b	v27, { v27 }, v25
	shl.4s	v10, v0, #3
	ushl.4s	v26, v26, v10
	add.4s	v10, v10, v5
	ushl.4s	v27, v27, v10
	shl.4s	v10, v1, #3
	ushl.4s	v30, v30, v10
	add.4s	v10, v10, v5
	ushl.4s	v9, v9, v10
	shl.4s	v10, v2, #3
	ushl.4s	v28, v28, v10
	add.4s	v10, v10, v5
	ushl.4s	v8, v8, v10
	shl.4s	v10, v4, #3
	ushl.4s	v29, v29, v10
	add.4s	v10, v10, v5
	ushl.4s	v31, v31, v10
	orr.16b	v18, v28, v18
	orr.16b	v7, v29, v7
	orr.16b	v16, v30, v16
	orr.16b	v19, v26, v19
	orr.16b	v21, v31, v21
	orr.16b	v3, v8, v3
	orr.16b	v22, v9, v22
	orr.16b	v24, v27, v24
	add.4s	v4, v4, v6
	add.4s	v2, v2, v6
	add.4s	v1, v1, v6
	add	x5, x5, #32
	add.4s	v0, v0, v6
	subs	x7, x7, #32
	b.ne	LBB2_249
; %bb.250:
	orr.16b	v0, v3, v18
	orr.16b	v1, v24, v19
	orr.16b	v2, v21, v7
	orr.16b	v3, v22, v16
	orr.16b	v2, v2, v3
	orr.16b	v0, v0, v1
	orr.16b	v0, v2, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x5, x12, #32
	orr	w5, w12, w5
	cmp	x15, x0
	b.ne	LBB2_265
; %bb.251:
	mov	x28, x19
	mov	x24, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	mov	x8, x21
	b	LBB2_80
LBB2_252:
	and	x5, x0, #0x1c
	and	x4, x0, #0xffffffe0
	add	x12, x14, x10
	ldr	x7, [sp, #120]                  ; 8-byte Reload
	ldr	x19, [sp, #104]                 ; 8-byte Reload
	add	x7, x7, x19
	add	x12, x12, x7
	add	x7, x12, #33
	ldr	q0, [x20, lCPI2_0@PAGEOFF]
Lloh140:
	adrp	x12, lCPI2_1@PAGE
Lloh141:
	ldr	q1, [x12, lCPI2_1@PAGEOFF]
Lloh142:
	adrp	x12, lCPI2_2@PAGE
Lloh143:
	ldr	q2, [x12, lCPI2_2@PAGEOFF]
Lloh144:
	adrp	x12, lCPI2_3@PAGE
Lloh145:
	ldr	q4, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v3, #0000000000000000
Lloh146:
	adrp	x12, lCPI2_4@PAGE
Lloh147:
	ldr	q5, [x12, lCPI2_4@PAGEOFF]
Lloh148:
	adrp	x12, lCPI2_5@PAGE
Lloh149:
	ldr	q6, [x12, lCPI2_5@PAGEOFF]
	movi.4s	v7, #128
	movi.4s	v17, #32
	and	x19, x0, #0xffffffe0
	movi.2d	v16, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v18, #0000000000000000
Lloh150:
	adrp	x12, lCPI2_6@PAGE
Lloh151:
	ldr	q22, [x12, lCPI2_6@PAGEOFF]
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
Lloh152:
	adrp	x12, lCPI2_7@PAGE
Lloh153:
	ldr	q24, [x12, lCPI2_7@PAGEOFF]
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB2_253:                               ; =>This Inner Loop Header: Depth=1
	ldp	q26, q27, [x7, #-16]
	tbl.16b	v28, { v26 }, v5
	tbl.16b	v29, { v26 }, v6
	tbl.16b	v30, { v26 }, v22
	tbl.16b	v26, { v26 }, v24
	tbl.16b	v31, { v27 }, v6
	tbl.16b	v8, { v27 }, v5
	tbl.16b	v9, { v27 }, v22
	tbl.16b	v27, { v27 }, v24
	shl.4s	v10, v0, #3
	ushl.4s	v26, v26, v10
	add.4s	v10, v10, v7
	ushl.4s	v27, v27, v10
	shl.4s	v10, v1, #3
	ushl.4s	v30, v30, v10
	add.4s	v10, v10, v7
	ushl.4s	v9, v9, v10
	shl.4s	v10, v2, #3
	ushl.4s	v28, v28, v10
	add.4s	v10, v10, v7
	ushl.4s	v8, v8, v10
	shl.4s	v10, v4, #3
	ushl.4s	v29, v29, v10
	add.4s	v10, v10, v7
	ushl.4s	v31, v31, v10
	orr.16b	v19, v28, v19
	orr.16b	v16, v29, v16
	orr.16b	v18, v30, v18
	orr.16b	v20, v26, v20
	orr.16b	v21, v31, v21
	orr.16b	v3, v8, v3
	orr.16b	v23, v9, v23
	orr.16b	v25, v27, v25
	add.4s	v4, v4, v17
	add.4s	v2, v2, v17
	add.4s	v1, v1, v17
	add	x7, x7, #32
	add.4s	v0, v0, v17
	subs	x19, x19, #32
	b.ne	LBB2_253
; %bb.254:
	orr.16b	v0, v3, v19
	orr.16b	v1, v25, v20
	orr.16b	v2, v21, v16
	orr.16b	v3, v23, v18
	orr.16b	v2, v2, v3
	orr.16b	v0, v0, v1
	orr.16b	v0, v2, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x7, x12, #32
	orr	w7, w12, w7
	cmp	x0, x4
	b.ne	LBB2_271
; %bb.255:
	mov	x28, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	mov	x8, x10
	b	LBB2_82
LBB2_256:
	and	x24, x22, #0x1c
	and	x23, x22, #0xffffffe0
	ldr	x12, [sp, #120]                 ; 8-byte Reload
	add	x12, x30, x12
	ldr	x19, [sp, #104]                 ; 8-byte Reload
	add	x12, x12, x19
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x19, x0, x10
	add	x12, x19, x12
	add	x28, x12, #33
Lloh154:
	adrp	x8, lCPI2_0@PAGE
Lloh155:
	ldr	q0, [x8, lCPI2_0@PAGEOFF]
Lloh156:
	adrp	x12, lCPI2_1@PAGE
Lloh157:
	ldr	q1, [x12, lCPI2_1@PAGEOFF]
Lloh158:
	adrp	x12, lCPI2_2@PAGE
Lloh159:
	ldr	q2, [x12, lCPI2_2@PAGEOFF]
Lloh160:
	adrp	x12, lCPI2_3@PAGE
Lloh161:
	ldr	q4, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v3, #0000000000000000
Lloh162:
	adrp	x12, lCPI2_4@PAGE
Lloh163:
	ldr	q5, [x12, lCPI2_4@PAGEOFF]
Lloh164:
	adrp	x12, lCPI2_5@PAGE
Lloh165:
	ldr	q6, [x12, lCPI2_5@PAGEOFF]
	movi.4s	v7, #128
	movi.4s	v17, #32
	and	x19, x22, #0xffffffe0
	movi.2d	v16, #0000000000000000
	movi.2d	v19, #0000000000000000
Lloh166:
	adrp	x12, lCPI2_6@PAGE
Lloh167:
	ldr	q21, [x12, lCPI2_6@PAGEOFF]
	movi.2d	v18, #0000000000000000
	movi.2d	v20, #0000000000000000
Lloh168:
	adrp	x12, lCPI2_7@PAGE
Lloh169:
	ldr	q24, [x12, lCPI2_7@PAGEOFF]
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB2_257:                               ; =>This Inner Loop Header: Depth=1
	ldp	q26, q27, [x28, #-16]
	tbl.16b	v28, { v26 }, v5
	tbl.16b	v29, { v26 }, v6
	tbl.16b	v30, { v26 }, v21
	tbl.16b	v26, { v26 }, v24
	tbl.16b	v31, { v27 }, v6
	tbl.16b	v8, { v27 }, v5
	tbl.16b	v9, { v27 }, v21
	tbl.16b	v27, { v27 }, v24
	shl.4s	v10, v0, #3
	ushl.4s	v26, v26, v10
	add.4s	v10, v10, v7
	ushl.4s	v27, v27, v10
	shl.4s	v10, v1, #3
	ushl.4s	v30, v30, v10
	add.4s	v10, v10, v7
	ushl.4s	v9, v9, v10
	shl.4s	v10, v2, #3
	ushl.4s	v28, v28, v10
	add.4s	v10, v10, v7
	ushl.4s	v8, v8, v10
	shl.4s	v10, v4, #3
	ushl.4s	v29, v29, v10
	add.4s	v10, v10, v7
	ushl.4s	v31, v31, v10
	orr.16b	v19, v28, v19
	orr.16b	v16, v29, v16
	orr.16b	v18, v30, v18
	orr.16b	v20, v26, v20
	orr.16b	v22, v31, v22
	orr.16b	v3, v8, v3
	orr.16b	v23, v9, v23
	orr.16b	v25, v27, v25
	add.4s	v4, v4, v17
	add.4s	v2, v2, v17
	add.4s	v1, v1, v17
	add	x28, x28, #32
	add.4s	v0, v0, v17
	subs	x19, x19, #32
	b.ne	LBB2_257
; %bb.258:
	orr.16b	v0, v3, v19
	orr.16b	v1, v25, v20
	orr.16b	v2, v22, v16
	orr.16b	v3, v23, v18
	orr.16b	v2, v2, v3
	orr.16b	v0, v0, v1
	orr.16b	v0, v2, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x19, x12, #32
	orr	w19, w12, w19
	adrp	x28, lCPI2_0@PAGE
	cmp	x22, x23
	b.ne	LBB2_277
; %bb.259:
	mov	x8, x30
	b	LBB2_84
LBB2_260:
	and	x14, x11, #0x1c
	and	x13, x11, #0xffffffffffffffe0
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x12, x10, x19
	ldr	x15, [sp, #120]                 ; 8-byte Reload
	add	x12, x12, x15
	ldr	x15, [sp, #160]                 ; 8-byte Reload
	add	x15, x9, x15
	add	x12, x15, x12
	ldr	x15, [sp, #104]                 ; 8-byte Reload
	add	x12, x12, x15
	add	x15, x12, #33
	ldr	q0, [x7, lCPI2_0@PAGEOFF]
Lloh170:
	adrp	x12, lCPI2_1@PAGE
Lloh171:
	ldr	q1, [x12, lCPI2_1@PAGEOFF]
Lloh172:
	adrp	x12, lCPI2_2@PAGE
Lloh173:
	ldr	q2, [x12, lCPI2_2@PAGEOFF]
Lloh174:
	adrp	x12, lCPI2_3@PAGE
Lloh175:
	ldr	q4, [x12, lCPI2_3@PAGEOFF]
	movi.2d	v3, #0000000000000000
Lloh176:
	adrp	x12, lCPI2_4@PAGE
Lloh177:
	ldr	q5, [x12, lCPI2_4@PAGEOFF]
Lloh178:
	adrp	x12, lCPI2_5@PAGE
Lloh179:
	ldr	q6, [x12, lCPI2_5@PAGEOFF]
Lloh180:
	adrp	x12, lCPI2_6@PAGE
Lloh181:
	ldr	q7, [x12, lCPI2_6@PAGEOFF]
	movi.4s	v16, #128
	movi.4s	v18, #32
	movi.2d	v17, #0000000000000000
Lloh182:
	adrp	x12, lCPI2_7@PAGE
Lloh183:
	ldr	q20, [x12, lCPI2_7@PAGEOFF]
	and	x5, x11, #0xffffffffffffffe0
	movi.2d	v21, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB2_261:                               ; =>This Inner Loop Header: Depth=1
	ldp	q26, q27, [x15, #-16]
	tbl.16b	v28, { v26 }, v5
	tbl.16b	v29, { v26 }, v6
	tbl.16b	v30, { v26 }, v7
	tbl.16b	v26, { v26 }, v20
	tbl.16b	v31, { v27 }, v6
	tbl.16b	v8, { v27 }, v5
	tbl.16b	v9, { v27 }, v7
	tbl.16b	v27, { v27 }, v20
	shl.4s	v10, v0, #3
	ushl.4s	v26, v26, v10
	add.4s	v10, v10, v16
	ushl.4s	v27, v27, v10
	shl.4s	v10, v1, #3
	ushl.4s	v30, v30, v10
	add.4s	v10, v10, v16
	ushl.4s	v9, v9, v10
	shl.4s	v10, v2, #3
	ushl.4s	v28, v28, v10
	add.4s	v10, v10, v16
	ushl.4s	v8, v8, v10
	shl.4s	v10, v4, #3
	ushl.4s	v29, v29, v10
	add.4s	v10, v10, v16
	ushl.4s	v31, v31, v10
	orr.16b	v21, v28, v21
	orr.16b	v17, v29, v17
	orr.16b	v19, v30, v19
	orr.16b	v22, v26, v22
	orr.16b	v23, v31, v23
	orr.16b	v3, v8, v3
	orr.16b	v24, v9, v24
	orr.16b	v25, v27, v25
	add.4s	v4, v4, v18
	add.4s	v2, v2, v18
	add.4s	v1, v1, v18
	add	x15, x15, #32
	add.4s	v0, v0, v18
	subs	x5, x5, #32
	b.ne	LBB2_261
; %bb.262:
	orr.16b	v0, v3, v21
	orr.16b	v1, v25, v22
	orr.16b	v2, v23, v17
	orr.16b	v3, v24, v19
	orr.16b	v2, v2, v3
	orr.16b	v0, v0, v1
	orr.16b	v0, v2, v0
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x15, x12, #32
	orr	w15, w12, w15
	cmp	x11, x13
	b.ne	LBB2_283
; %bb.263:
	mov	x28, x7
	mov	x8, x19
	b	LBB2_86
LBB2_264:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp39:                                 ; EH_LABEL
Lloh184:
	adrp	x1, l_.str.19@PAGE
Lloh185:
	add	x1, x1, l_.str.19@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ; EH_LABEL
	b	LBB2_302
LBB2_265:
	mov	x28, x19
	mov	x24, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x25, x14, #4
	mov	x8, x21
	cbz	x4, LBB2_269
LBB2_266:
	mov	x4, x0
	and	x0, x15, #0xfffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w5
	dup.4s	v1, w4
Lloh186:
	adrp	x12, lCPI2_3@PAGE
Lloh187:
	ldr	q2, [x12, lCPI2_3@PAGEOFF]
	orr.16b	v1, v1, v2
	sub	x12, x4, x0
	ldr	x5, [sp, #120]                  ; 8-byte Reload
	add	x4, x4, x5
	add	x4, x4, x14
	ldr	x5, [sp, #104]                  ; 8-byte Reload
	add	x4, x4, x5
	add	x4, x4, #17
	movi.4s	v2, #4
LBB2_267:                               ; =>This Inner Loop Header: Depth=1
	ldr	s3, [x4], #4
	ushll.8h	v3, v3, #0
	ushll.4s	v3, v3, #0
	shl.4s	v4, v1, #3
	ushl.4s	v3, v3, v4
	orr.16b	v0, v3, v0
	add.4s	v1, v1, v2
	adds	x12, x12, #4
	b.ne	LBB2_267
; %bb.268:
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x4, x12, #32
	orr	w5, w12, w4
	cmp	x15, x0
	mov	x28, x19
	mov	x24, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x25, x14, #4
	mov	x8, x21
	b.eq	LBB2_80
LBB2_269:
	add	x15, x0, x14
	sub	x12, x15, x8
	lsl	w14, w0, #3
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	ldr	x4, [sp, #104]                  ; 8-byte Reload
	add	x0, x0, x4
	add	x15, x15, x0
	add	x15, x15, #17
LBB2_270:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w0, [x15], #1
	lsl	w0, w0, w14
	orr	w5, w0, w5
	add	w14, w14, #8
	adds	x12, x12, #1
	b.lo	LBB2_270
	b	LBB2_80
LBB2_271:
	mov	x28, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	mov	x8, x10
	cbz	x5, LBB2_275
LBB2_272:
	mov	x5, x4
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w7
	and	x4, x0, #0xfffffffc
	dup.4s	v1, w5
Lloh188:
	adrp	x12, lCPI2_3@PAGE
Lloh189:
	ldr	q2, [x12, lCPI2_3@PAGEOFF]
	orr.16b	v1, v1, v2
	sub	x12, x5, x4
	add	x5, x5, x8
	add	x5, x5, x14
	ldr	x7, [sp, #120]                  ; 8-byte Reload
	ldr	x19, [sp, #104]                 ; 8-byte Reload
	add	x7, x7, x19
	add	x5, x5, x7
	add	x5, x5, #17
	movi.4s	v2, #4
LBB2_273:                               ; =>This Inner Loop Header: Depth=1
	ldr	s3, [x5], #4
	ushll.8h	v3, v3, #0
	ushll.4s	v3, v3, #0
	shl.4s	v4, v1, #3
	ushl.4s	v3, v3, v4
	orr.16b	v0, v3, v0
	add.4s	v1, v1, v2
	adds	x12, x12, #4
	b.ne	LBB2_273
; %bb.274:
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x5, x12, #32
	orr	w7, w12, w5
	cmp	x0, x4
	mov	x28, x20
	ldr	x30, [sp, #160]                 ; 8-byte Reload
	mov	x8, x10
	b.eq	LBB2_82
LBB2_275:
	add	x0, x4, x14
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	sub	x12, x0, x10
	lsl	w14, w4, #3
	ldr	x4, [sp, #120]                  ; 8-byte Reload
	add	x4, x8, x4
	add	x0, x0, x4
	ldr	x4, [sp, #104]                  ; 8-byte Reload
	add	x0, x0, x4
	add	x0, x0, #17
LBB2_276:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w4, [x0], #1
	lsl	w4, w4, w14
	orr	w7, w4, w7
	add	w14, w14, #8
	adds	x12, x12, #1
	b.lo	LBB2_276
	b	LBB2_82
LBB2_277:
	mov	x8, x30
	cbz	x24, LBB2_281
LBB2_278:
	mov	x20, x23
	and	x23, x22, #0xfffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w19
	dup.4s	v1, w20
Lloh190:
	adrp	x12, lCPI2_3@PAGE
Lloh191:
	ldr	q2, [x12, lCPI2_3@PAGEOFF]
	orr.16b	v1, v1, v2
	sub	x12, x20, x23
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x19, x20, x10
	add	x19, x19, x0
	ldr	x20, [sp, #120]                 ; 8-byte Reload
	add	x20, x8, x20
	ldr	x24, [sp, #104]                 ; 8-byte Reload
	add	x20, x20, x24
	add	x19, x19, x20
	add	x19, x19, #17
	movi.4s	v2, #4
LBB2_279:                               ; =>This Inner Loop Header: Depth=1
	ldr	s3, [x19], #4
	ushll.8h	v3, v3, #0
	ushll.4s	v3, v3, #0
	shl.4s	v4, v1, #3
	ushl.4s	v3, v3, v4
	orr.16b	v0, v3, v0
	add.4s	v1, v1, v2
	adds	x12, x12, #4
	b.ne	LBB2_279
; %bb.280:
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x19, x12, #32
	orr	w19, w12, w19
	cmp	x22, x23
	adrp	x28, lCPI2_0@PAGE
	mov	x8, x30
	b.eq	LBB2_84
LBB2_281:
	add	x20, x23, x0
	ldr	x12, [sp, #160]                 ; 8-byte Reload
	sub	x12, x20, x12
	lsl	w0, w23, #3
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x22, x10, x8
	add	x20, x20, x22
	ldr	x22, [sp, #120]                 ; 8-byte Reload
	ldr	x23, [sp, #104]                 ; 8-byte Reload
	add	x22, x22, x23
	add	x20, x20, x22
	add	x20, x20, #17
LBB2_282:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w22, [x20], #1
	lsl	w22, w22, w0
	orr	w19, w22, w19
	add	w0, w0, #8
	adds	x12, x12, #1
	b.lo	LBB2_282
	b	LBB2_84
LBB2_283:
	mov	x28, x7
	mov	x8, x19
	cbz	x14, LBB2_287
LBB2_284:
	mov	x14, x13
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w15
	dup.4s	v1, w14
	and	x13, x11, #0xfffffffffffffffc
Lloh192:
	adrp	x12, lCPI2_3@PAGE
Lloh193:
	ldr	q2, [x12, lCPI2_3@PAGEOFF]
	orr.16b	v1, v1, v2
	sub	x12, x14, x13
	ldr	x15, [sp, #160]                 ; 8-byte Reload
	add	x14, x14, x15
	add	x14, x14, x9
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x15, x10, x8
	ldr	x5, [sp, #120]                  ; 8-byte Reload
	add	x15, x15, x5
	add	x14, x14, x15
	ldr	x15, [sp, #104]                 ; 8-byte Reload
	add	x14, x14, x15
	add	x14, x14, #17
	movi.4s	v2, #4
LBB2_285:                               ; =>This Inner Loop Header: Depth=1
	ldr	s3, [x14], #4
	ushll.8h	v3, v3, #0
	ushll.4s	v3, v3, #0
	shl.4s	v4, v1, #3
	ushl.4s	v3, v3, v4
	orr.16b	v0, v3, v0
	add.4s	v1, v1, v2
	adds	x12, x12, #4
	b.ne	LBB2_285
; %bb.286:
	mov	d1, v0[1]
	orr.8b	v0, v0, v1
	fmov	x12, d0
	lsr	x14, x12, #32
	orr	w15, w12, w14
	cmp	x11, x13
	mov	x28, x7
	mov	x8, x19
	b.eq	LBB2_86
LBB2_287:
	add	x12, x13, x9
	ldr	x10, [sp, #176]                 ; 8-byte Reload
	add	x9, x8, x10
	add	x9, x12, x9
	ldr	x14, [sp, #160]                 ; 8-byte Reload
	add	x9, x9, x14
	ldp	x5, x11, [sp, #104]             ; 16-byte Folded Reload
	sub	x9, x9, x11
	add	x9, x9, x5
	add	x9, x9, #17
	lsl	w11, w13, #3
	add	x13, x14, x10
	add	x12, x12, x13
	ldr	x13, [sp, #120]                 ; 8-byte Reload
	add	x13, x8, x13
	add	x13, x13, x5
	add	x12, x12, x13
	add	x12, x12, #17
LBB2_288:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w13, [x12], #1
	lsl	w13, w13, w11
	orr	w15, w13, w15
	add	w11, w11, #8
	adds	x9, x9, #1
	b.lo	LBB2_288
	b	LBB2_86
LBB2_289:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp51:                                 ; EH_LABEL
Lloh194:
	adrp	x1, l_.str.15@PAGE
Lloh195:
	add	x1, x1, l_.str.15@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ; EH_LABEL
	b	LBB2_302
LBB2_290:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp48:                                 ; EH_LABEL
Lloh196:
	adrp	x1, l_.str.16@PAGE
Lloh197:
	add	x1, x1, l_.str.16@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ; EH_LABEL
	b	LBB2_302
LBB2_291:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp42:                                 ; EH_LABEL
Lloh198:
	adrp	x1, l_.str.19@PAGE
Lloh199:
	add	x1, x1, l_.str.19@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ; EH_LABEL
	b	LBB2_302
LBB2_292:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp45:                                 ; EH_LABEL
Lloh200:
	adrp	x1, l_.str.19@PAGE
Lloh201:
	add	x1, x1, l_.str.19@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ; EH_LABEL
	b	LBB2_302
LBB2_293:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp36:                                 ; EH_LABEL
Lloh202:
	adrp	x1, l_.str.1@PAGE
Lloh203:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ; EH_LABEL
	b	LBB2_302
LBB2_294:
	bl	___stack_chk_fail
LBB2_295:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp72:                                 ; EH_LABEL
Lloh204:
	adrp	x1, l_.str.4@PAGE
Lloh205:
	add	x1, x1, l_.str.4@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp73:                                 ; EH_LABEL
	b	LBB2_302
LBB2_296:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp60:                                 ; EH_LABEL
Lloh206:
	adrp	x1, l_.str.6@PAGE
Lloh207:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ; EH_LABEL
	b	LBB2_302
LBB2_297:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp69:                                 ; EH_LABEL
Lloh208:
	adrp	x1, l_.str.2@PAGE
Lloh209:
	add	x1, x1, l_.str.2@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp70:                                 ; EH_LABEL
	b	LBB2_302
LBB2_298:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp66:                                 ; EH_LABEL
Lloh210:
	adrp	x1, l_.str.3@PAGE
Lloh211:
	add	x1, x1, l_.str.3@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ; EH_LABEL
	b	LBB2_302
LBB2_299:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp54:                                 ; EH_LABEL
Lloh212:
	adrp	x1, l_.str.17@PAGE
Lloh213:
	add	x1, x1, l_.str.17@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ; EH_LABEL
	b	LBB2_302
LBB2_300:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp63:                                 ; EH_LABEL
Lloh214:
	adrp	x1, l_.str.5@PAGE
Lloh215:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ; EH_LABEL
	b	LBB2_302
LBB2_301:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp57:                                 ; EH_LABEL
Lloh216:
	adrp	x1, l_.str.18@PAGE
Lloh217:
	add	x1, x1, l_.str.18@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ; EH_LABEL
LBB2_302:
Lloh218:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh219:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh220:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh221:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB2_303:
Ltmp59:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_304:
Ltmp65:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_305:
Ltmp56:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_306:
Ltmp68:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_307:
Ltmp71:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_308:
Ltmp62:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_309:
Ltmp74:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_310:
Ltmp38:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_311:
Ltmp47:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_312:
Ltmp44:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_313:
Ltmp50:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_314:
Ltmp53:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_315:
Ltmp41:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdrGotLdr	Lloh40, Lloh41, Lloh42
	.loh AdrpLdrGotLdr	Lloh43, Lloh44, Lloh45
	.loh AdrpLdrGotLdr	Lloh46, Lloh47, Lloh48
	.loh AdrpLdr	Lloh63, Lloh64
	.loh AdrpAdrp	Lloh61, Lloh63
	.loh AdrpLdr	Lloh61, Lloh62
	.loh AdrpLdr	Lloh59, Lloh60
	.loh AdrpAdrp	Lloh57, Lloh59
	.loh AdrpLdr	Lloh57, Lloh58
	.loh AdrpAdrp	Lloh55, Lloh57
	.loh AdrpLdr	Lloh55, Lloh56
	.loh AdrpAdrp	Lloh53, Lloh55
	.loh AdrpLdr	Lloh53, Lloh54
	.loh AdrpAdrp	Lloh51, Lloh53
	.loh AdrpLdr	Lloh51, Lloh52
	.loh AdrpAdrp	Lloh49, Lloh51
	.loh AdrpLdr	Lloh49, Lloh50
	.loh AdrpLdr	Lloh77, Lloh78
	.loh AdrpAdrp	Lloh75, Lloh77
	.loh AdrpLdr	Lloh75, Lloh76
	.loh AdrpAdrp	Lloh73, Lloh75
	.loh AdrpLdr	Lloh73, Lloh74
	.loh AdrpAdrp	Lloh71, Lloh73
	.loh AdrpLdr	Lloh71, Lloh72
	.loh AdrpAdrp	Lloh69, Lloh71
	.loh AdrpLdr	Lloh69, Lloh70
	.loh AdrpAdrp	Lloh67, Lloh69
	.loh AdrpLdr	Lloh67, Lloh68
	.loh AdrpAdrp	Lloh65, Lloh67
	.loh AdrpLdr	Lloh65, Lloh66
	.loh AdrpLdr	Lloh85, Lloh86
	.loh AdrpAdrp	Lloh83, Lloh85
	.loh AdrpLdr	Lloh83, Lloh84
	.loh AdrpAdrp	Lloh81, Lloh83
	.loh AdrpLdr	Lloh81, Lloh82
	.loh AdrpAdrp	Lloh79, Lloh81
	.loh AdrpLdr	Lloh79, Lloh80
	.loh AdrpLdr	Lloh93, Lloh94
	.loh AdrpAdrp	Lloh91, Lloh93
	.loh AdrpLdr	Lloh91, Lloh92
	.loh AdrpAdrp	Lloh89, Lloh91
	.loh AdrpLdr	Lloh89, Lloh90
	.loh AdrpAdrp	Lloh87, Lloh89
	.loh AdrpLdr	Lloh87, Lloh88
	.loh AdrpLdr	Lloh101, Lloh102
	.loh AdrpAdrp	Lloh99, Lloh101
	.loh AdrpLdr	Lloh99, Lloh100
	.loh AdrpAdrp	Lloh97, Lloh99
	.loh AdrpLdr	Lloh97, Lloh98
	.loh AdrpAdrp	Lloh95, Lloh97
	.loh AdrpLdr	Lloh95, Lloh96
	.loh AdrpLdr	Lloh115, Lloh116
	.loh AdrpAdrp	Lloh113, Lloh115
	.loh AdrpLdr	Lloh113, Lloh114
	.loh AdrpAdrp	Lloh111, Lloh113
	.loh AdrpLdr	Lloh111, Lloh112
	.loh AdrpAdrp	Lloh109, Lloh111
	.loh AdrpLdr	Lloh109, Lloh110
	.loh AdrpAdrp	Lloh107, Lloh109
	.loh AdrpLdr	Lloh107, Lloh108
	.loh AdrpAdrp	Lloh105, Lloh107
	.loh AdrpLdr	Lloh105, Lloh106
	.loh AdrpAdrp	Lloh103, Lloh105
	.loh AdrpLdr	Lloh103, Lloh104
	.loh AdrpLdr	Lloh121, Lloh122
	.loh AdrpAdrp	Lloh119, Lloh121
	.loh AdrpLdr	Lloh119, Lloh120
	.loh AdrpAdrp	Lloh117, Lloh119
	.loh AdrpLdr	Lloh117, Lloh118
	.loh AdrpLdrGotLdr	Lloh123, Lloh124, Lloh125
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpAdrp	Lloh136, Lloh138
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpAdrp	Lloh134, Lloh136
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpAdrp	Lloh132, Lloh134
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpAdrp	Lloh130, Lloh132
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpAdrp	Lloh128, Lloh130
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpAdrp	Lloh126, Lloh128
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpAdrp	Lloh150, Lloh152
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpAdrp	Lloh148, Lloh150
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpAdrp	Lloh146, Lloh148
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpAdrp	Lloh144, Lloh146
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdrp	Lloh142, Lloh144
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpAdrp	Lloh140, Lloh142
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpAdrp	Lloh162, Lloh164
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpLdrGot	Lloh220, Lloh221
	.loh AdrpLdrGot	Lloh218, Lloh219
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ; >> Call Site 1 <<
	.uleb128 Ltmp39-Lfunc_begin2            ;   Call between Lfunc_begin2 and Ltmp39
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin2            ; >> Call Site 2 <<
	.uleb128 Ltmp40-Ltmp39                  ;   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin2            ;     jumps to Ltmp41
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin2            ; >> Call Site 3 <<
	.uleb128 Ltmp51-Ltmp40                  ;   Call between Ltmp40 and Ltmp51
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin2            ; >> Call Site 4 <<
	.uleb128 Ltmp52-Ltmp51                  ;   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin2            ;     jumps to Ltmp53
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin2            ; >> Call Site 5 <<
	.uleb128 Ltmp48-Ltmp52                  ;   Call between Ltmp52 and Ltmp48
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin2            ; >> Call Site 6 <<
	.uleb128 Ltmp49-Ltmp48                  ;   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin2            ;     jumps to Ltmp50
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin2            ; >> Call Site 7 <<
	.uleb128 Ltmp42-Ltmp49                  ;   Call between Ltmp49 and Ltmp42
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin2            ; >> Call Site 8 <<
	.uleb128 Ltmp43-Ltmp42                  ;   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin2            ;     jumps to Ltmp44
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin2            ; >> Call Site 9 <<
	.uleb128 Ltmp45-Ltmp43                  ;   Call between Ltmp43 and Ltmp45
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin2            ; >> Call Site 10 <<
	.uleb128 Ltmp46-Ltmp45                  ;   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin2            ;     jumps to Ltmp47
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin2            ; >> Call Site 11 <<
	.uleb128 Ltmp36-Ltmp46                  ;   Call between Ltmp46 and Ltmp36
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin2            ; >> Call Site 12 <<
	.uleb128 Ltmp37-Ltmp36                  ;   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin2            ;     jumps to Ltmp38
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin2            ; >> Call Site 13 <<
	.uleb128 Ltmp72-Ltmp37                  ;   Call between Ltmp37 and Ltmp72
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp72-Lfunc_begin2            ; >> Call Site 14 <<
	.uleb128 Ltmp73-Ltmp72                  ;   Call between Ltmp72 and Ltmp73
	.uleb128 Ltmp74-Lfunc_begin2            ;     jumps to Ltmp74
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp73-Lfunc_begin2            ; >> Call Site 15 <<
	.uleb128 Ltmp60-Ltmp73                  ;   Call between Ltmp73 and Ltmp60
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin2            ; >> Call Site 16 <<
	.uleb128 Ltmp61-Ltmp60                  ;   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin2            ;     jumps to Ltmp62
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin2            ; >> Call Site 17 <<
	.uleb128 Ltmp69-Ltmp61                  ;   Call between Ltmp61 and Ltmp69
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp69-Lfunc_begin2            ; >> Call Site 18 <<
	.uleb128 Ltmp70-Ltmp69                  ;   Call between Ltmp69 and Ltmp70
	.uleb128 Ltmp71-Lfunc_begin2            ;     jumps to Ltmp71
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp70-Lfunc_begin2            ; >> Call Site 19 <<
	.uleb128 Ltmp66-Ltmp70                  ;   Call between Ltmp70 and Ltmp66
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin2            ; >> Call Site 20 <<
	.uleb128 Ltmp67-Ltmp66                  ;   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin2            ;     jumps to Ltmp68
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin2            ; >> Call Site 21 <<
	.uleb128 Ltmp54-Ltmp67                  ;   Call between Ltmp67 and Ltmp54
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin2            ; >> Call Site 22 <<
	.uleb128 Ltmp55-Ltmp54                  ;   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin2            ;     jumps to Ltmp56
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin2            ; >> Call Site 23 <<
	.uleb128 Ltmp63-Ltmp55                  ;   Call between Ltmp55 and Ltmp63
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin2            ; >> Call Site 24 <<
	.uleb128 Ltmp64-Ltmp63                  ;   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin2            ;     jumps to Ltmp65
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin2            ; >> Call Site 25 <<
	.uleb128 Ltmp57-Ltmp64                  ;   Call between Ltmp64 and Ltmp57
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin2            ; >> Call Site 26 <<
	.uleb128 Ltmp58-Ltmp57                  ;   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin2            ;     jumps to Ltmp59
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin2            ; >> Call Site 27 <<
	.uleb128 Lfunc_end2-Ltmp58              ;   Call between Ltmp58 and Lfunc_end2
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
__ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv: ; @_ZNK18cng_huffman_kernel12_GLOBAL__N_16Reader6finishEv
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception3
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldp	x10, x8, [x0, #8]
	lsl	x8, x8, #3
	ldr	w9, [x0, #32]
	sub	x9, x8, x9
	add	x8, x9, #7
	lsr	x8, x8, #3
	cmp	x8, x10
	b.ne	LBB3_4
; %bb.1:
	ands	x9, x9, #0x7
	b.eq	LBB3_3
; %bb.2:
	ldr	x10, [x0]
	add	x8, x10, x8
	ldurb	w8, [x8, #-1]
	lsr	w8, w8, w9
	cbnz	w8, LBB3_5
LBB3_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB3_4:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp75:                                 ; EH_LABEL
Lloh222:
	adrp	x1, l_.str.20@PAGE
Lloh223:
	add	x1, x1, l_.str.20@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp76:                                 ; EH_LABEL
	b	LBB3_6
LBB3_5:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp78:                                 ; EH_LABEL
Lloh224:
	adrp	x1, l_.str.21@PAGE
Lloh225:
	add	x1, x1, l_.str.21@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp79:                                 ; EH_LABEL
LBB3_6:
Lloh226:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh227:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh228:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh229:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB3_7:
Ltmp80:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB3_8:
Ltmp77:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpLdrGot	Lloh228, Lloh229
	.loh AdrpLdrGot	Lloh226, Lloh227
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception3:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3      ; >> Call Site 1 <<
	.uleb128 Ltmp75-Lfunc_begin3            ;   Call between Lfunc_begin3 and Ltmp75
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp75-Lfunc_begin3            ; >> Call Site 2 <<
	.uleb128 Ltmp76-Ltmp75                  ;   Call between Ltmp75 and Ltmp76
	.uleb128 Ltmp77-Lfunc_begin3            ;     jumps to Ltmp77
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp76-Lfunc_begin3            ; >> Call Site 3 <<
	.uleb128 Ltmp78-Ltmp76                  ;   Call between Ltmp76 and Ltmp78
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp78-Lfunc_begin3            ; >> Call Site 4 <<
	.uleb128 Ltmp79-Ltmp78                  ;   Call between Ltmp78 and Ltmp79
	.uleb128 Ltmp80-Lfunc_begin3            ;     jumps to Ltmp80
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp79-Lfunc_begin3            ; >> Call Site 5 <<
	.uleb128 Lfunc_end3-Ltmp79              ;   Call between Ltmp79 and Lfunc_end3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end3:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE ; -- Begin function _ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.weak_def_can_be_hidden	__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
	.p2align	2
__ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE: ; @_ZN17cng_package_merge7lengthsENSt3__14spanIKNS_6SymbolELm18446744073709551615EEEjRNS0_5arrayIhLm256EEE
Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception4
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #4, lsl #12             ; =16384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	sub	x8, x1, #257
	cmn	x8, #255
	b.lo	LBB4_39
; %bb.1:
	mov	x22, x2
	sub	w8, w2, #13
	cmn	w8, #12
	b.lo	LBB4_39
; %bb.2:
	mov	x20, x1
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w22
	cmp	x1, x8
	b.hi	LBB4_39
; %bb.3:
	mov	x19, x3
	mov	x21, x0
	add	x23, sp, #3, lsl #12            ; =12288
	add	x0, sp, #3, lsl #12             ; =12288
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	mov	x24, sp
	mov	x0, sp
	mov	w1, #12288                      ; =0x3000
	bl	_bzero
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	cmp	x20, #5
	b.hs	LBB4_5
; %bb.4:
	mov	x8, #0                          ; =0x0
	b	LBB4_12
LBB4_5:
	cmp	x20, #17
	b.hs	LBB4_7
; %bb.6:
	mov	x8, #0                          ; =0x0
	b	LBB4_10
LBB4_7:
	ands	x8, x20, #0xf
	mov	w9, #16                         ; =0x10
	csel	x9, x9, x8, eq
	sub	x8, x20, x9
	add	x10, x21, #68
	mov	x11, sp
	add	x11, x11, #16
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #32
	mov	x13, x20
LBB4_8:                                 ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x10, #-52]
	ldur	q1, [x10, #-68]
	sub	x14, x10, #12
	sub	x15, x10, #20
	ldur	q2, [x10, #-36]
	mov.s	v2[1], v2[2]
	uzp1.4s	v0, v1, v0
	ldur	q1, [x10, #12]
	ldur	q3, [x10, #-4]
	add	x16, x10, #52
	ld1.s	{ v2 }[2], [x15]
	add	x15, x10, #44
	ldur	q4, [x10, #28]
	mov.s	v4[1], v4[2]
	ld1.s	{ v2 }[3], [x14]
	ld1.s	{ v4 }[2], [x15]
	uzp1.4s	v1, v3, v1
	ldursh	w14, [x10, #-8]
	ld1.s	{ v4 }[3], [x16]
	ldur	w15, [x10, #-16]
	ldp	q5, q3, [x10, #-48]
	ldur	q6, [x10, #-64]
	stp	q0, q2, [x12, #-32]
	mov.h	v6[1], v6[4]
	mov.h	v6[2], v5[0]
	stp	q1, q4, [x12], #64
	mov.h	v6[3], v5[4]
	ldrsh	w16, [x10, #56]
	ldp	q1, q0, [x10, #16]
	mov.h	v6[4], v3[0]
	ldr	q2, [x10]
	mov.h	v2[1], v2[4]
	mov.h	v6[5], v3[4]
	mov.h	v2[2], v1[0]
	mov.h	v2[3], v1[4]
	mov.h	v6[6], w15
	mov.h	v2[4], v0[0]
	mov.h	v2[5], v0[4]
	mov.h	v6[7], w14
	ldr	w14, [x10, #48]
	mov.h	v2[6], w14
	mov.h	v2[7], w16
	stp	q6, q2, [x11, #-16]
	add	x10, x10, #128
	sub	x13, x13, #16
	add	x11, x11, #32
	cmp	x9, x13
	b.ne	LBB4_8
; %bb.9:
	cmp	x9, #4
	b.ls	LBB4_12
LBB4_10:
	mov	x11, x8
	ands	x8, x20, #0x3
	mov	w9, #4                          ; =0x4
	csel	x12, x9, x8, eq
	mov	x8, sp
	add	x9, x8, x11, lsl #1
	add	x8, sp, #3, lsl #12             ; =12288
	add	x10, x8, x11, lsl #2
	add	x13, x21, x11, lsl #3
	sub	x8, x20, x12
	add	x11, x12, x11
	sub	x11, x11, x20
	add	x12, x13, #4
LBB4_11:                                ; =>This Inner Loop Header: Depth=1
	add	x13, x12, #12
	ldur	q0, [x12, #-4]
	mov.s	v0[1], v0[2]
	ld1.s	{ v0 }[2], [x13]
	add	x13, x12, #20
	ld1.s	{ v0 }[3], [x13]
	str	q0, [x10], #16
	ldrsh	w13, [x12, #24]
	ldr	w14, [x12, #16]
	ldr	q0, [x12], #32
	mov.h	v0[1], v0[4]
	mov.h	v0[2], w14
	mov.h	v0[3], w13
	str	d0, [x9], #8
	adds	x11, x11, #4
	b.ne	LBB4_11
LBB4_12:
	add	x9, x21, x8, lsl #3
	add	x9, x9, #4
LBB4_13:                                ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-4]
	str	w10, [x23, x8, lsl #2]
	ldrh	w10, [x9], #8
	strh	w10, [x24, x8, lsl #1]
	add	x8, x8, #1
	cmp	x20, x8
	b.ne	LBB4_13
; %bb.14:
	mov	w8, w22
	cmp	w22, #2
	b.lo	LBB4_27
; %bb.15:
	mov	x9, sp
	add	x9, x9, #1024
	mov	w10, #1                         ; =0x1
	add	x11, sp, #3, lsl #12            ; =12288
	mov	x12, x20
	b	LBB4_17
LBB4_16:                                ;   in Loop: Header=BB4_17 Depth=1
	add	x10, x10, #1
	add	x9, x9, #1024
	cmp	x10, x8
	b.eq	LBB4_29
LBB4_17:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_20 Depth 2
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mvn	w16, w10
	and	x15, x10, #0x1
	add	x15, x11, x15, lsl #11
	and	x16, x16, #0x1
	add	x16, x11, x16, lsl #11
	lsr	x17, x12, #1
	cmp	x17, #0
	cset	w1, ne
	mov	w0, #1                          ; =0x1
	mov	x12, #0                         ; =0x0
	b	LBB4_20
LBB4_18:                                ;   in Loop: Header=BB4_20 Depth=2
	str	w1, [x15, x12, lsl #2]
	lsl	w0, w13, #1
	add	w0, w0, #256
	strh	w0, [x9, x12, lsl #1]
	add	x13, x13, #1
LBB4_19:                                ;   in Loop: Header=BB4_20 Depth=2
	add	x12, x12, #1
	cmp	x14, x20
	cset	w0, lo
	cmp	x13, x17
	cset	w1, lo
	csinc	w2, w0, wzr, hs
	tbz	w2, #0, LBB4_16
LBB4_20:                                ;   Parent Loop BB4_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	tbz	w1, #0, LBB4_23
; %bb.21:                               ;   in Loop: Header=BB4_20 Depth=2
	add	x1, x16, x13, lsl #3
	ldp	w2, w1, [x1]
	add	w1, w1, w2
	tbz	w0, #0, LBB4_24
; %bb.22:                               ;   in Loop: Header=BB4_20 Depth=2
	lsl	x0, x14, #3
	ldr	w0, [x21, x0]
	cmp	w0, w1
	b.hi	LBB4_18
	b	LBB4_26
LBB4_23:                                ;   in Loop: Header=BB4_20 Depth=2
	mov	w1, #0                          ; =0x0
LBB4_24:                                ;   in Loop: Header=BB4_20 Depth=2
	cmp	x13, x17
	b.ne	LBB4_18
; %bb.25:                               ;   in Loop: Header=BB4_20 Depth=2
	lsl	x0, x14, #3
	ldr	w0, [x21, x0]
LBB4_26:                                ;   in Loop: Header=BB4_20 Depth=2
	add	x1, x21, x14, lsl #3
	str	w0, [x15, x12, lsl #2]
	ldrh	w0, [x1, #4]
	strh	w0, [x9, x12, lsl #1]
	add	x14, x14, #1
	b	LBB4_19
LBB4_27:
	lsl	x9, x20, #1
	sub	x9, x9, #2
	cmp	x9, x20
	b.ls	LBB4_30
LBB4_28:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp81:                                 ; EH_LABEL
Lloh230:
	adrp	x1, l_.str.10@PAGE
Lloh231:
	add	x1, x1, l_.str.10@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp82:                                 ; EH_LABEL
	b	LBB4_40
LBB4_29:
	lsl	x9, x20, #1
	sub	x9, x9, #2
	cmp	x9, x12
	b.hi	LBB4_28
LBB4_30:
	mov	x10, sp
	add	x10, x10, x8, lsl #10
	sub	x10, x10, #1024
	b	LBB4_33
LBB4_31:                                ;   in Loop: Header=BB4_33 Depth=1
	lsl	x9, x11, #1
LBB4_32:                                ;   in Loop: Header=BB4_33 Depth=1
	sub	x10, x10, #1024
	sub	x8, x8, #1
	cbz	w8, LBB4_38
LBB4_33:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_36 Depth 2
	cbz	x9, LBB4_32
; %bb.34:                               ;   in Loop: Header=BB4_33 Depth=1
	mov	x11, #0                         ; =0x0
	mov	x12, x10
	b	LBB4_36
LBB4_35:                                ;   in Loop: Header=BB4_36 Depth=2
	add	x11, x11, #1
	subs	x9, x9, #1
	b.eq	LBB4_31
LBB4_36:                                ;   Parent Loop BB4_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w13, [x12], #2
	cmp	x13, #255
	b.hi	LBB4_35
; %bb.37:                               ;   in Loop: Header=BB4_36 Depth=2
	ldrb	w14, [x19, x13]
	add	w14, w14, #1
	strb	w14, [x19, x13]
	subs	x9, x9, #1
	b.ne	LBB4_36
	b	LBB4_31
LBB4_38:
	add	sp, sp, #4, lsl #12             ; =16384
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB4_39:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp84:                                 ; EH_LABEL
Lloh232:
	adrp	x1, l_.str.9@PAGE
Lloh233:
	add	x1, x1, l_.str.9@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp85:                                 ; EH_LABEL
LBB4_40:
Lloh234:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh235:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh236:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh237:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB4_41:
Ltmp83:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB4_42:
Ltmp86:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpLdrGot	Lloh236, Lloh237
	.loh AdrpLdrGot	Lloh234, Lloh235
Lfunc_end4:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table4:
Lexception4:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end4-Lcst_begin4
Lcst_begin4:
	.uleb128 Lfunc_begin4-Lfunc_begin4      ; >> Call Site 1 <<
	.uleb128 Ltmp81-Lfunc_begin4            ;   Call between Lfunc_begin4 and Ltmp81
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp81-Lfunc_begin4            ; >> Call Site 2 <<
	.uleb128 Ltmp82-Ltmp81                  ;   Call between Ltmp81 and Ltmp82
	.uleb128 Ltmp83-Lfunc_begin4            ;     jumps to Ltmp83
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp82-Lfunc_begin4            ; >> Call Site 3 <<
	.uleb128 Ltmp84-Ltmp82                  ;   Call between Ltmp82 and Ltmp84
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp84-Lfunc_begin4            ; >> Call Site 4 <<
	.uleb128 Ltmp85-Ltmp84                  ;   Call between Ltmp84 and Ltmp85
	.uleb128 Ltmp86-Lfunc_begin4            ;     jumps to Ltmp86
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp85-Lfunc_begin4            ; >> Call Site 5 <<
	.uleb128 Lfunc_end4-Ltmp85              ;   Call between Ltmp85 and Lfunc_end4
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end4:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	6                               ; -- Begin function _ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb: ; @_ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x3
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
LBB5_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_2 Depth 2
                                        ;       Child Loop BB5_77 Depth 3
                                        ;       Child Loop BB5_75 Depth 3
                                        ;       Child Loop BB5_81 Depth 3
                                        ;       Child Loop BB5_85 Depth 3
                                        ;         Child Loop BB5_83 Depth 4
                                        ;         Child Loop BB5_84 Depth 4
                                        ;       Child Loop BB5_55 Depth 3
                                        ;       Child Loop BB5_60 Depth 3
                                        ;       Child Loop BB5_58 Depth 3
                                        ;       Child Loop BB5_63 Depth 3
                                        ;         Child Loop BB5_64 Depth 4
                                        ;         Child Loop BB5_65 Depth 4
	sub	x22, x20, #8
	sub	x26, x20, #16
	sub	x27, x20, #24
	mov	x24, x19
LBB5_2:                                 ;   Parent Loop BB5_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB5_77 Depth 3
                                        ;       Child Loop BB5_75 Depth 3
                                        ;       Child Loop BB5_81 Depth 3
                                        ;       Child Loop BB5_85 Depth 3
                                        ;         Child Loop BB5_83 Depth 4
                                        ;         Child Loop BB5_84 Depth 4
                                        ;       Child Loop BB5_55 Depth 3
                                        ;       Child Loop BB5_60 Depth 3
                                        ;       Child Loop BB5_58 Depth 3
                                        ;       Child Loop BB5_63 Depth 3
                                        ;         Child Loop BB5_64 Depth 4
                                        ;         Child Loop BB5_65 Depth 4
	mov	x19, x24
	sub	x8, x20, x24
	asr	x9, x8, #3
	subs	x8, x9, #2
	b.gt	LBB5_5
; %bb.3:                                ;   in Loop: Header=BB5_2 Depth=2
	b.lo	LBB5_154
; %bb.4:                                ;   in Loop: Header=BB5_2 Depth=2
	cmp	x9, #2
	b.ne	LBB5_8
	b	LBB5_95
LBB5_5:                                 ;   in Loop: Header=BB5_2 Depth=2
	cmp	x9, #3
	b.eq	LBB5_97
; %bb.6:                                ;   in Loop: Header=BB5_2 Depth=2
	cmp	x9, #4
	b.eq	LBB5_100
; %bb.7:                                ;   in Loop: Header=BB5_2 Depth=2
	cmp	x9, #5
	b.eq	LBB5_90
LBB5_8:                                 ;   in Loop: Header=BB5_2 Depth=2
	cmp	x9, #23
	b.le	LBB5_101
; %bb.9:                                ;   in Loop: Header=BB5_2 Depth=2
	cbz	x21, LBB5_111
; %bb.10:                               ;   in Loop: Header=BB5_2 Depth=2
	lsr	x8, x9, #1
	add	x8, x19, x8, lsl #3
	ldur	w10, [x20, #-8]
	ldurh	w11, [x20, #-4]
	cmp	x9, #129
	b.lo	LBB5_14
; %bb.11:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w9, [x8]
	ldrh	w12, [x8, #4]
	ldr	w13, [x19]
	ldrh	w14, [x19, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w9, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	cmp	w11, w12
	cset	w11, lo
	cmp	w10, w9
	cset	w9, lo
	csel	w11, w11, w9, eq
	tbz	w13, #0, LBB5_17
; %bb.12:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x19]
	lsr	x10, x9, #32
	cbz	w11, LBB5_23
; %bb.13:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w11, [x22]
	ldrh	w12, [x22, #4]
	strh	w12, [x19, #4]
	str	w11, [x19]
	strh	w10, [x22, #4]
	str	w9, [x22]
	b	LBB5_25
LBB5_14:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w9, [x19]
	ldrh	w12, [x19, #4]
	ldr	w13, [x8]
	ldrh	w14, [x8, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w9, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	cmp	w11, w12
	cset	w11, lo
	cmp	w10, w9
	cset	w9, lo
	csel	w11, w11, w9, eq
	tbz	w13, #0, LBB5_20
; %bb.15:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x8]
	lsr	x10, x9, #32
	cbz	w11, LBB5_31
; %bb.16:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w11, [x22]
	ldrh	w12, [x22, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	strh	w10, [x22, #4]
	str	w9, [x22]
	sub	x21, x21, #1
	tbz	w23, #0, LBB5_53
	b	LBB5_54
LBB5_17:                                ;   in Loop: Header=BB5_2 Depth=2
	cbz	w11, LBB5_25
; %bb.18:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x8]
	ldr	w10, [x22]
	ldrh	w11, [x22, #4]
	strh	w11, [x8, #4]
	str	w10, [x8]
	str	w9, [x22]
	lsr	x9, x9, #32
	strh	w9, [x22, #4]
	ldr	w9, [x8]
	ldrh	w10, [x8, #4]
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB5_25
; %bb.19:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x19]
	ldr	w10, [x8]
	ldrh	w11, [x8, #4]
	strh	w11, [x19, #4]
	str	w10, [x19]
	str	w9, [x8]
	lsr	x9, x9, #32
	strh	w9, [x8, #4]
	b	LBB5_25
LBB5_20:                                ;   in Loop: Header=BB5_2 Depth=2
	cbz	w11, LBB5_33
; %bb.21:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x19]
	ldr	w10, [x22]
	ldrh	w11, [x22, #4]
	strh	w11, [x19, #4]
	str	w10, [x19]
	str	w9, [x22]
	lsr	x9, x9, #32
	strh	w9, [x22, #4]
	ldr	w9, [x19]
	ldrh	w10, [x19, #4]
	ldr	w11, [x8]
	ldrh	w12, [x8, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB5_33
; %bb.22:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x8]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	strh	w11, [x8, #4]
	str	w10, [x8]
	str	w9, [x19]
	lsr	x8, x9, #32
	strh	w8, [x19, #4]
	sub	x21, x21, #1
	tbz	w23, #0, LBB5_53
	b	LBB5_54
LBB5_23:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w11, [x8]
	ldrh	w12, [x8, #4]
	strh	w12, [x19, #4]
	str	w11, [x19]
	strh	w10, [x8, #4]
	str	w9, [x8]
	ldur	w11, [x20, #-8]
	ldurh	w12, [x20, #-4]
	cmp	w12, w10, uxth
	cset	w10, lo
	cmp	w11, w9
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB5_25
; %bb.24:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x8]
	ldr	w10, [x22]
	ldrh	w11, [x22, #4]
	strh	w11, [x8, #4]
	str	w10, [x8]
	str	w9, [x22]
	lsr	x9, x9, #32
	strh	w9, [x22, #4]
LBB5_25:                                ;   in Loop: Header=BB5_2 Depth=2
	mov	x10, x19
	ldr	w11, [x10, #8]!
	mov	x9, x8
	ldr	w12, [x9, #-8]!
	ldrh	w13, [x9, #4]
	ldrh	w14, [x10, #4]
	cmp	w13, w14
	cset	w14, lo
	cmp	w12, w11
	cset	w11, lo
	csel	w11, w14, w11, eq
	ldur	w14, [x20, #-16]
	ldurh	w15, [x20, #-12]
	cmp	w15, w13
	cset	w13, lo
	cmp	w14, w12
	cset	w12, lo
	csel	w13, w13, w12, eq
	tbz	w11, #0, LBB5_28
; %bb.26:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x11, [x10]
	lsr	x12, x11, #32
	cbz	w13, LBB5_34
; %bb.27:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w13, [x26]
	ldrh	w14, [x26, #4]
	strh	w14, [x10, #4]
	str	w13, [x10]
	strh	w12, [x26, #4]
	str	w11, [x26]
	b	LBB5_36
LBB5_28:                                ;   in Loop: Header=BB5_2 Depth=2
	cbz	w13, LBB5_36
; %bb.29:                               ;   in Loop: Header=BB5_2 Depth=2
	ldur	x11, [x8, #-8]
	ldr	w12, [x26]
	ldrh	w13, [x26, #4]
	strh	w13, [x9, #4]
	str	w12, [x9]
	str	w11, [x26]
	lsr	x11, x11, #32
	strh	w11, [x26, #4]
	ldur	w11, [x8, #-8]
	ldurh	w12, [x8, #-4]
	ldr	w13, [x19, #8]
	ldrh	w14, [x19, #12]
	cmp	w12, w14
	cset	w12, lo
	cmp	w11, w13
	cset	w11, lo
	csel	w11, w12, w11, eq
	cbz	w11, LBB5_36
; %bb.30:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x11, [x10]
	ldr	w12, [x9]
	ldrh	w13, [x9, #4]
	strh	w13, [x10, #4]
	str	w12, [x10]
	str	w11, [x9]
	lsr	x10, x11, #32
	strh	w10, [x9, #4]
	b	LBB5_36
LBB5_31:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	strh	w10, [x19, #4]
	str	w9, [x19]
	ldur	w8, [x20, #-8]
	ldurh	w11, [x20, #-4]
	cmp	w11, w10, uxth
	cset	w10, lo
	cmp	w8, w9
	cset	w8, lo
	csel	w8, w10, w8, eq
	cbz	w8, LBB5_33
; %bb.32:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x8, [x19]
	ldr	w9, [x22]
	ldrh	w10, [x22, #4]
	strh	w10, [x19, #4]
	str	w9, [x19]
	str	w8, [x22]
	lsr	x8, x8, #32
	strh	w8, [x22, #4]
LBB5_33:                                ;   in Loop: Header=BB5_2 Depth=2
	sub	x21, x21, #1
	tbz	w23, #0, LBB5_53
	b	LBB5_54
LBB5_34:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w13, [x9]
	ldrh	w14, [x9, #4]
	strh	w14, [x10, #4]
	str	w13, [x10]
	strh	w12, [x9, #4]
	str	w11, [x9]
	ldur	w10, [x20, #-16]
	ldurh	w13, [x20, #-12]
	cmp	w13, w12, uxth
	cset	w12, lo
	cmp	w10, w11
	cset	w10, lo
	csel	w10, w12, w10, eq
	cbz	w10, LBB5_36
; %bb.35:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x10, [x9]
	ldr	w11, [x26]
	ldrh	w12, [x26, #4]
	strh	w12, [x9, #4]
	str	w11, [x9]
	str	w10, [x26]
	lsr	x10, x10, #32
	strh	w10, [x26, #4]
LBB5_36:                                ;   in Loop: Header=BB5_2 Depth=2
	mov	x11, x19
	ldr	w12, [x11, #16]!
	mov	x10, x8
	ldr	w13, [x10, #8]!
	ldrh	w14, [x10, #4]
	ldrh	w15, [x11, #4]
	cmp	w14, w15
	cset	w15, lo
	cmp	w13, w12
	cset	w12, lo
	csel	w12, w15, w12, eq
	ldur	w15, [x20, #-24]
	ldurh	w16, [x20, #-20]
	cmp	w16, w14
	cset	w14, lo
	cmp	w15, w13
	cset	w13, lo
	csel	w14, w14, w13, eq
	tbz	w12, #0, LBB5_39
; %bb.37:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x12, [x11]
	lsr	x13, x12, #32
	cbz	w14, LBB5_42
; %bb.38:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w14, [x27]
	ldrh	w15, [x27, #4]
	strh	w15, [x11, #4]
	str	w14, [x11]
	strh	w13, [x27, #4]
	str	w12, [x27]
	b	LBB5_44
LBB5_39:                                ;   in Loop: Header=BB5_2 Depth=2
	cbz	w14, LBB5_44
; %bb.40:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x12, [x8, #8]
	ldr	w13, [x27]
	ldrh	w14, [x27, #4]
	strh	w14, [x10, #4]
	str	w13, [x10]
	str	w12, [x27]
	lsr	x12, x12, #32
	strh	w12, [x27, #4]
	ldr	w12, [x8, #8]
	ldrh	w13, [x8, #12]
	ldr	w14, [x19, #16]
	ldrh	w15, [x19, #20]
	cmp	w13, w15
	cset	w13, lo
	cmp	w12, w14
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB5_44
; %bb.41:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x12, [x11]
	ldr	w13, [x10]
	ldrh	w14, [x10, #4]
	strh	w14, [x11, #4]
	str	w13, [x11]
	str	w12, [x10]
	lsr	x11, x12, #32
	strh	w11, [x10, #4]
	b	LBB5_44
LBB5_42:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w14, [x10]
	ldrh	w15, [x10, #4]
	strh	w15, [x11, #4]
	str	w14, [x11]
	strh	w13, [x10, #4]
	str	w12, [x10]
	ldur	w11, [x20, #-24]
	ldurh	w14, [x20, #-20]
	cmp	w14, w13, uxth
	cset	w13, lo
	cmp	w11, w12
	cset	w11, lo
	csel	w11, w13, w11, eq
	cbz	w11, LBB5_44
; %bb.43:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x11, [x10]
	ldr	w12, [x27]
	ldrh	w13, [x27, #4]
	strh	w13, [x10, #4]
	str	w12, [x10]
	str	w11, [x27]
	lsr	x11, x11, #32
	strh	w11, [x27, #4]
LBB5_44:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w15, [x8]
	ldrh	w16, [x8, #4]
	ldur	w11, [x8, #-8]
	ldurh	w12, [x8, #-4]
	cmp	w16, w12
	cset	w13, lo
	cmp	w15, w11
	cset	w14, lo
	csel	w17, w13, w14, eq
	ldr	w13, [x8, #8]
	ldrh	w14, [x8, #12]
	cmp	w14, w16
	cset	w16, lo
	cmp	w13, w15
	cset	w15, lo
	csel	w15, w16, w15, eq
	tbz	w17, #0, LBB5_47
; %bb.45:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x11, [x9]
	lsr	x12, x11, #32
	cbz	w15, LBB5_50
; %bb.46:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w13, [x10]
	str	w13, [x9]
	ldrh	w13, [x10, #4]
	strh	w13, [x9, #4]
	str	w11, [x10]
	strh	w12, [x10, #4]
	b	LBB5_52
LBB5_47:                                ;   in Loop: Header=BB5_2 Depth=2
	cbz	w15, LBB5_52
; %bb.48:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x13, [x8]
	ldr	w14, [x10]
	str	w14, [x8]
	ldrh	w10, [x10, #4]
	strh	w10, [x8, #4]
	str	w13, [x8, #8]
	lsr	x13, x13, #32
	strh	w13, [x8, #12]
	cmp	w10, w12
	cset	w10, lo
	cmp	w14, w11
	cset	w11, lo
	csel	w10, w10, w11, eq
	cbz	w10, LBB5_52
; %bb.49:                               ;   in Loop: Header=BB5_2 Depth=2
	ldur	x10, [x8, #-8]
	ldr	w11, [x8]
	str	w11, [x9]
	ldrh	w11, [x8, #4]
	strh	w11, [x9, #4]
	str	w10, [x8]
	lsr	x9, x10, #32
	strh	w9, [x8, #4]
	b	LBB5_52
LBB5_50:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w15, [x8]
	str	w15, [x9]
	ldrh	w15, [x8, #4]
	strh	w15, [x9, #4]
	str	w11, [x8]
	strh	w12, [x8, #4]
	cmp	w14, w12, uxth
	cset	w9, lo
	cmp	w13, w11
	cset	w11, lo
	csel	w9, w9, w11, eq
	cbz	w9, LBB5_52
; %bb.51:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x8]
	ldr	w11, [x10]
	str	w11, [x8]
	ldrh	w10, [x10, #4]
	strh	w10, [x8, #4]
	str	w9, [x8, #8]
	lsr	x9, x9, #32
	strh	w9, [x8, #12]
LBB5_52:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	x9, [x19]
	ldr	w10, [x8]
	ldrh	w11, [x8, #4]
	strh	w11, [x19, #4]
	str	w10, [x19]
	str	w9, [x8]
	lsr	x9, x9, #32
	strh	w9, [x8, #4]
	sub	x21, x21, #1
	tbnz	w23, #0, LBB5_54
LBB5_53:                                ;   in Loop: Header=BB5_2 Depth=2
	ldur	w8, [x19, #-8]
	ldurh	w9, [x19, #-4]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	tbz	w8, #0, LBB5_73
LBB5_54:                                ;   in Loop: Header=BB5_2 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	w8, [x19]
	ldrh	w9, [x19, #4]
LBB5_55:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x19, x12
	ldr	w11, [x10, #8]
	ldrh	w10, [x10, #12]
	cmp	w10, w9
	cset	w10, lo
	cmp	w11, w8
	cset	w11, lo
	csel	w10, w10, w11, eq
	add	x12, x12, #8
	tbnz	w10, #0, LBB5_55
; %bb.56:                               ;   in Loop: Header=BB5_2 Depth=2
	add	x10, x19, x12
	mov	x11, x20
	cmp	x12, #8
	b.ne	LBB5_60
; %bb.57:                               ;   in Loop: Header=BB5_2 Depth=2
	mov	x11, x20
LBB5_58:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x10, x11
	b.hs	LBB5_61
; %bb.59:                               ;   in Loop: Header=BB5_58 Depth=3
	ldr	w12, [x11, #-8]!
	ldrh	w13, [x11, #4]
	cmp	w13, w9
	cset	w13, lo
	cmp	w12, w8
	cset	w12, lo
	csel	w12, w13, w12, eq
	tbz	w12, #0, LBB5_58
	b	LBB5_61
LBB5_60:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w12, [x11, #-8]!
	ldrh	w13, [x11, #4]
	cmp	w13, w9
	cset	w13, lo
	cmp	w12, w8
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB5_60
LBB5_61:                                ;   in Loop: Header=BB5_2 Depth=2
	mov	x24, x10
	cmp	x10, x11
	b.hs	LBB5_67
; %bb.62:                               ;   in Loop: Header=BB5_2 Depth=2
	mov	x12, x11
LBB5_63:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB5_64 Depth 4
                                        ;         Child Loop BB5_65 Depth 4
	ldr	x13, [x24]
	ldr	w14, [x12]
	ldrh	w15, [x12, #4]
	strh	w15, [x24, #4]
	str	w14, [x24]
	str	w13, [x12]
	lsr	x13, x13, #32
	strh	w13, [x12, #4]
LBB5_64:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ;       Parent Loop BB5_63 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x24, #8]!
	ldrh	w14, [x24, #4]
	cmp	w14, w9
	cset	w14, lo
	cmp	w13, w8
	cset	w13, lo
	csel	w13, w14, w13, eq
	tbnz	w13, #0, LBB5_64
LBB5_65:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ;       Parent Loop BB5_63 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x12, #-8]!
	ldrh	w14, [x12, #4]
	cmp	w14, w9
	cset	w14, lo
	cmp	w13, w8
	cset	w13, lo
	csel	w13, w14, w13, eq
	cbz	w13, LBB5_65
; %bb.66:                               ;   in Loop: Header=BB5_63 Depth=3
	cmp	x24, x12
	b.lo	LBB5_63
LBB5_67:                                ;   in Loop: Header=BB5_2 Depth=2
	sub	x28, x24, #8
	cmp	x19, x28
	b.eq	LBB5_69
; %bb.68:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w12, [x28]
	ldrh	w13, [x28, #4]
	strh	w13, [x19, #4]
	str	w12, [x19]
LBB5_69:                                ;   in Loop: Header=BB5_2 Depth=2
	stur	w8, [x24, #-8]
	sturh	w9, [x24, #-4]
	cmp	x10, x11
	b.lo	LBB5_72
; %bb.70:                               ;   in Loop: Header=BB5_2 Depth=2
	sub	x1, x24, #8
	mov	x0, x19
	bl	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	mov	x25, x0
	mov	x0, x24
	mov	x1, x20
	bl	__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	cbnz	w0, LBB5_89
; %bb.71:                               ;   in Loop: Header=BB5_2 Depth=2
	tbnz	w25, #0, LBB5_2
LBB5_72:                                ;   in Loop: Header=BB5_2 Depth=2
	sub	x1, x24, #8
	and	w3, w23, #0x1
	mov	x0, x19
	mov	x2, x21
	bl	__ZNSt3__111__introsortB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafELb0EEEvT1_S8_T0_NS_15iterator_traitsIS8_E15difference_typeEb
	mov	w23, #0                         ; =0x0
	b	LBB5_2
LBB5_73:                                ;   in Loop: Header=BB5_2 Depth=2
	ldr	w8, [x19]
	ldrh	w9, [x19, #4]
	ldur	w10, [x20, #-8]
	ldurh	w11, [x20, #-4]
	cmp	w11, w9
	cset	w11, hi
	cmp	w10, w8
	cset	w10, hi
	csel	w10, w11, w10, eq
	tbz	w10, #0, LBB5_76
; %bb.74:                               ;   in Loop: Header=BB5_2 Depth=2
	mov	x24, x19
LBB5_75:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x24, #8]!
	ldrh	w11, [x24, #4]
	cmp	w11, w9
	cset	w11, hi
	cmp	w10, w8
	cset	w10, hi
	csel	w10, w11, w10, eq
	tbz	w10, #0, LBB5_75
	b	LBB5_79
LBB5_76:                                ;   in Loop: Header=BB5_2 Depth=2
	add	x10, x19, #8
LBB5_77:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov	x24, x10
	cmp	x10, x20
	b.hs	LBB5_79
; %bb.78:                               ;   in Loop: Header=BB5_77 Depth=3
	ldr	w10, [x24]
	ldrh	w11, [x24, #4]
	cmp	w11, w9
	cset	w11, hi
	cmp	w10, w8
	cset	w10, hi
	csel	w11, w11, w10, eq
	add	x10, x24, #8
	cbz	w11, LBB5_77
LBB5_79:                                ;   in Loop: Header=BB5_2 Depth=2
	mov	x10, x20
	cmp	x24, x20
	b.hs	LBB5_85
; %bb.80:                               ;   in Loop: Header=BB5_2 Depth=2
	mov	x10, x20
LBB5_81:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w11, [x10, #-8]!
	ldrh	w12, [x10, #4]
	cmp	w12, w9
	cset	w12, hi
	cmp	w11, w8
	cset	w11, hi
	csel	w11, w12, w11, eq
	tbnz	w11, #0, LBB5_81
	b	LBB5_85
LBB5_82:                                ;   in Loop: Header=BB5_85 Depth=3
	ldr	x11, [x24]
	ldr	w12, [x10]
	ldrh	w13, [x10, #4]
	strh	w13, [x24, #4]
	str	w12, [x24]
	str	w11, [x10]
	lsr	x11, x11, #32
	strh	w11, [x10, #4]
LBB5_83:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ;       Parent Loop BB5_85 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x24, #8]!
	ldrh	w12, [x24, #4]
	cmp	w12, w9
	cset	w12, hi
	cmp	w11, w8
	cset	w11, hi
	csel	w11, w12, w11, eq
	cbz	w11, LBB5_83
LBB5_84:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ;       Parent Loop BB5_85 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x10, #-8]!
	ldrh	w12, [x10, #4]
	cmp	w12, w9
	cset	w12, hi
	cmp	w11, w8
	cset	w11, hi
	csel	w11, w12, w11, eq
	tbnz	w11, #0, LBB5_84
LBB5_85:                                ;   Parent Loop BB5_1 Depth=1
                                        ;     Parent Loop BB5_2 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB5_83 Depth 4
                                        ;         Child Loop BB5_84 Depth 4
	cmp	x24, x10
	b.lo	LBB5_82
; %bb.86:                               ;   in Loop: Header=BB5_2 Depth=2
	sub	x10, x24, #8
	cmp	x19, x10
	b.eq	LBB5_88
; %bb.87:                               ;   in Loop: Header=BB5_2 Depth=2
	ldr	w11, [x10]
	ldrh	w10, [x10, #4]
	strh	w10, [x19, #4]
	str	w11, [x19]
LBB5_88:                                ;   in Loop: Header=BB5_2 Depth=2
	mov	w23, #0                         ; =0x0
	stur	w8, [x24, #-8]
	sturh	w9, [x24, #-4]
	b	LBB5_2
LBB5_89:                                ;   in Loop: Header=BB5_1 Depth=1
	mov	x20, x28
	tbz	w25, #0, LBB5_1
	b	LBB5_154
LBB5_90:
	add	x1, x19, #8
	add	x2, x19, #16
	add	x3, x19, #24
	mov	x0, x19
	bl	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	ldr	w8, [x20, #-8]!
	ldrh	w9, [x20, #4]
	ldr	w10, [x19, #24]
	ldrh	w11, [x19, #28]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB5_154
; %bb.91:
	ldr	x8, [x19, #24]
	ldr	w9, [x20]
	ldrh	w10, [x20, #4]
	sturh	w10, [x19, #28]
	stur	w9, [x19, #24]
	str	w8, [x20]
	lsr	x8, x8, #32
	strh	w8, [x20, #4]
	ldr	w8, [x19, #24]
	ldrh	w9, [x19, #28]
	ldr	w10, [x19, #16]
	ldrh	w11, [x19, #20]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB5_154
; %bb.92:
	ldr	x8, [x19, #16]
	ldurh	w9, [x19, #28]
	sturh	w9, [x19, #20]
	ldur	w9, [x19, #24]
	stur	w9, [x19, #16]
	str	w8, [x19, #24]
	lsr	x8, x8, #32
	strh	w8, [x19, #28]
	ldr	w8, [x19, #16]
	ldrh	w9, [x19, #20]
	ldr	w10, [x19, #8]
	ldrh	w11, [x19, #12]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB5_154
; %bb.93:
	ldr	x8, [x19, #8]
	ldurh	w9, [x19, #20]
	sturh	w9, [x19, #12]
	ldur	w9, [x19, #16]
	stur	w9, [x19, #8]
	str	w8, [x19, #16]
	lsr	x8, x8, #32
	strh	w8, [x19, #20]
	ldr	w8, [x19, #8]
	ldrh	w9, [x19, #12]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB5_154
; %bb.94:
	ldr	x8, [x19]
	ldur	w9, [x19, #8]
	str	w9, [x19]
	ldurh	w9, [x19, #12]
	strh	w9, [x19, #4]
	str	w8, [x19, #8]
	lsr	x8, x8, #32
	b	LBB5_145
LBB5_95:
	ldr	w8, [x20, #-8]!
	ldrh	w9, [x20, #4]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB5_154
; %bb.96:
	ldr	x8, [x19]
	ldr	w9, [x20]
	ldrh	w10, [x20, #4]
	strh	w10, [x19, #4]
	str	w9, [x19]
	str	w8, [x20]
	lsr	x8, x8, #32
	strh	w8, [x20, #4]
	b	LBB5_154
LBB5_97:
	mov	x8, x19
	ldr	w10, [x8, #8]!
	mov	x9, x20
	ldr	w11, [x9, #-8]!
	ldrh	w12, [x19, #12]
	ldr	w13, [x19]
	ldrh	w14, [x19, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w10, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	ldrh	w14, [x9, #4]
	cmp	w14, w12
	cset	w12, lo
	cmp	w11, w10
	cset	w10, lo
	csel	w11, w12, w10, eq
	tbz	w13, #0, LBB5_142
; %bb.98:
	ldr	x10, [x19]
	cbz	w11, LBB5_152
; %bb.99:
	ldr	w8, [x9]
	ldrh	w11, [x9, #4]
	strh	w11, [x19, #4]
	str	w8, [x19]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
	str	w10, [x9]
	b	LBB5_154
LBB5_100:
	add	x1, x19, #8
	add	x2, x19, #16
	mov	x0, x19
	mov	x3, x22
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
LBB5_101:
	cmp	x19, x20
	add	x10, x19, #8
	ccmp	x10, x20, #4, ne
	cset	w8, eq
	tbz	w23, #0, LBB5_146
; %bb.102:
	tbnz	w8, #0, LBB5_154
; %bb.103:
	mov	x8, #0                          ; =0x0
	mov	x12, x19
	b	LBB5_107
LBB5_104:                               ;   in Loop: Header=BB5_107 Depth=1
	mov	x14, x19
LBB5_105:                               ;   in Loop: Header=BB5_107 Depth=1
	str	w10, [x14]
	strh	w11, [x14, #4]
LBB5_106:                               ;   in Loop: Header=BB5_107 Depth=1
	add	x10, x9, #8
	add	x8, x8, #8
	mov	x12, x9
	cmp	x10, x20
	b.eq	LBB5_154
LBB5_107:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_109 Depth 2
	mov	x9, x10
	ldr	w10, [x12, #8]
	ldrh	w11, [x12, #12]
	ldr	w13, [x12]
	ldrh	w14, [x12, #4]
	cmp	w11, w14
	cset	w11, lo
	cmp	w10, w13
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB5_106
; %bb.108:                              ;   in Loop: Header=BB5_107 Depth=1
	ldr	x10, [x12, #8]
	ldr	w11, [x12]
	str	w11, [x9]
	ldrh	w11, [x12, #4]
	strh	w11, [x9, #4]
	lsr	x11, x10, #32
	mov	x13, x8
	mov	x14, x19
	cmp	x12, x19
	b.eq	LBB5_105
LBB5_109:                               ;   Parent Loop BB5_107 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x19, x13
	add	x12, x19, x13
	ldr	w15, [x12, #-8]!
	ldurh	w16, [x14, #-4]
	cmp	w16, w11, uxth
	cset	w16, hi
	cmp	w15, w10
	cset	w15, hi
	csel	w15, w16, w15, eq
	tbz	w15, #0, LBB5_105
; %bb.110:                              ;   in Loop: Header=BB5_109 Depth=2
	ldr	w15, [x12]
	str	w15, [x14]
	ldrh	w12, [x12, #4]
	strh	w12, [x14, #4]
	subs	x13, x13, #8
	b.ne	LBB5_109
	b	LBB5_104
LBB5_111:
	cmp	x19, x20
	b.eq	LBB5_154
; %bb.112:
	lsr	x8, x8, #1
	mov	x11, x8
	b	LBB5_115
LBB5_113:                               ;   in Loop: Header=BB5_115 Depth=1
	str	w12, [x13]
	strh	w14, [x13, #4]
LBB5_114:                               ;   in Loop: Header=BB5_115 Depth=1
	sub	x11, x10, #1
	cbz	x10, LBB5_130
LBB5_115:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_125 Depth 2
	mov	x10, x11
	cmp	x8, x11
	b.lo	LBB5_114
; %bb.116:                              ;   in Loop: Header=BB5_115 Depth=1
	lsl	x12, x10, #1
	mov	w11, #1                         ; =0x1
	bfi	x11, x10, #1, #62
	add	x13, x12, #2
	add	x14, x19, x11, lsl #3
	cmp	x13, x9
	b.hs	LBB5_119
; %bb.117:                              ;   in Loop: Header=BB5_115 Depth=1
	add	x12, x19, x13, lsl #3
	ldr	w15, [x14]
	ldrh	w14, [x14, #4]
	ldr	w16, [x12]
	ldrh	w17, [x12, #4]
	cmp	w14, w17
	cset	w12, lo
	cmp	w15, w16
	cset	w0, lo
	csel	w12, w12, w0, eq
	.p2align	6, , 4
; %bb.118:                              ;   in Loop: Header=BB5_115 Depth=1
	cmp	w12, #0
	csel	w12, w16, w15, ne
	csel	x11, x13, x11, ne
	csel	w13, w17, w14, ne
	b	LBB5_120
LBB5_119:                               ;   in Loop: Header=BB5_115 Depth=1
	ldr	w12, [x14]
	ldrh	w13, [x14, #4]
LBB5_120:                               ;   in Loop: Header=BB5_115 Depth=1
	add	x14, x19, x10, lsl #3
	ldr	w15, [x14]
	ldrh	w16, [x14, #4]
	cmp	w13, w16
	cset	w13, lo
	cmp	w12, w15
	cset	w12, lo
	csel	w12, w13, w12, eq
	tbnz	w12, #0, LBB5_114
; %bb.121:                              ;   in Loop: Header=BB5_115 Depth=1
	ldr	x12, [x14]
	mov	x16, x10
	b	LBB5_125
LBB5_122:                               ;   in Loop: Header=BB5_125 Depth=2
	add	x16, x19, x17, lsl #3
	ldr	w1, [x0]
	ldrh	w0, [x0, #4]
	ldr	w2, [x16]
	ldrh	w3, [x16, #4]
	cmp	w0, w3
	cset	w16, lo
	cmp	w1, w2
	cset	w4, lo
	csel	w16, w16, w4, eq
	.p2align	6, , 4
; %bb.123:                              ;   in Loop: Header=BB5_125 Depth=2
	cmp	w16, #0
	csel	w16, w2, w1, ne
	csel	x15, x17, x15, ne
	csel	w17, w3, w0, ne
LBB5_124:                               ;   in Loop: Header=BB5_125 Depth=2
	cmp	w17, w14, uxth
	cset	w17, lo
	cmp	w16, w12
	cset	w16, lo
	csel	w17, w17, w16, eq
	mov	x16, x11
	mov	x11, x15
	cbnz	w17, LBB5_113
LBB5_125:                               ;   Parent Loop BB5_115 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x19, x11, lsl #3
	ldr	w14, [x13]
	ldrh	w15, [x13, #4]
	add	x16, x19, x16, lsl #3
	strh	w15, [x16, #4]
	str	w14, [x16]
	lsr	x14, x12, #32
	cmp	x8, x11
	b.lt	LBB5_113
; %bb.126:                              ;   in Loop: Header=BB5_125 Depth=2
	lsl	x16, x11, #1
	mov	w15, #1                         ; =0x1
	bfi	x15, x11, #1, #62
	add	x17, x16, #2
	add	x0, x19, x15, lsl #3
	cmp	x17, x9
	b.lt	LBB5_122
; %bb.127:                              ;   in Loop: Header=BB5_125 Depth=2
	ldr	w16, [x0]
	ldrh	w17, [x0, #4]
	b	LBB5_124
LBB5_128:                               ;   in Loop: Header=BB5_130 Depth=1
	str	w10, [x8]
	strh	w11, [x8, #4]
LBB5_129:                               ;   in Loop: Header=BB5_130 Depth=1
	cmp	x9, #2
	sub	x9, x9, #1
	b.le	LBB5_154
LBB5_130:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_133 Depth 2
                                        ;     Child Loop BB5_139 Depth 2
	mov	x13, #0                         ; =0x0
	ldr	x10, [x19]
	sub	x8, x9, #2
	lsr	x11, x8, #1
	mov	x12, x19
	b	LBB5_133
LBB5_131:                               ;   in Loop: Header=BB5_133 Depth=2
	ldr	w16, [x15, #16]!
	ldur	w17, [x15, #-8]
	ldurh	w0, [x15, #-4]
	ldrh	w1, [x15, #4]
	cmp	w0, w1
	cset	w0, lo
	cmp	w17, w16
	cset	w16, lo
	csel	w16, w0, w16, eq
	cmp	w16, #0
	csel	x8, x15, x8, ne
	csel	x13, x13, x14, ne
LBB5_132:                               ;   in Loop: Header=BB5_133 Depth=2
	ldr	w14, [x8]
	ldrh	w15, [x8, #4]
	strh	w15, [x12, #4]
	str	w14, [x12]
	mov	x12, x8
	cmp	x13, x11
	b.gt	LBB5_135
LBB5_133:                               ;   Parent Loop BB5_130 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x12, x13, lsl #3
	add	x8, x15, #8
	lsl	x16, x13, #1
	mov	w14, #1                         ; =0x1
	bfi	x14, x13, #1, #63
	add	x13, x16, #2
	cmp	x13, x9
	b.lt	LBB5_131
; %bb.134:                              ;   in Loop: Header=BB5_133 Depth=2
	mov	x13, x14
	b	LBB5_132
LBB5_135:                               ;   in Loop: Header=BB5_130 Depth=1
	sub	x20, x20, #8
	lsr	x11, x10, #32
	cmp	x8, x20
	b.eq	LBB5_128
; %bb.136:                              ;   in Loop: Header=BB5_130 Depth=1
	ldr	w12, [x20]
	ldrh	w13, [x20, #4]
	strh	w13, [x8, #4]
	str	w12, [x8]
	strh	w11, [x20, #4]
	str	w10, [x20]
	sub	x10, x8, x19
	add	x10, x10, #8
	asr	x10, x10, #3
	subs	x10, x10, #2
	b.lt	LBB5_129
; %bb.137:                              ;   in Loop: Header=BB5_130 Depth=1
	lsr	x10, x10, #1
	add	x11, x19, x10, lsl #3
	ldr	w12, [x11]
	ldrh	w13, [x11, #4]
	ldr	w14, [x8]
	ldrh	w15, [x8, #4]
	cmp	w13, w15
	cset	w13, lo
	cmp	w12, w14
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB5_129
; %bb.138:                              ;   in Loop: Header=BB5_130 Depth=1
	ldr	x12, [x8]
LBB5_139:                               ;   Parent Loop BB5_130 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x13, x8
	mov	x8, x11
	ldr	w11, [x11]
	ldrh	w14, [x8, #4]
	strh	w14, [x13, #4]
	str	w11, [x13]
	lsr	x13, x12, #32
	cbz	x10, LBB5_141
; %bb.140:                              ;   in Loop: Header=BB5_139 Depth=2
	sub	x10, x10, #1
	lsr	x10, x10, #1
	add	x11, x19, x10, lsl #3
	ldr	w14, [x11]
	ldrh	w15, [x11, #4]
	cmp	w15, w13, uxth
	cset	w15, lo
	cmp	w14, w12
	cset	w14, lo
	csel	w14, w15, w14, eq
	tbnz	w14, #0, LBB5_139
LBB5_141:                               ;   in Loop: Header=BB5_130 Depth=1
	str	w12, [x8]
	strh	w13, [x8, #4]
	b	LBB5_129
LBB5_142:
	cbz	w11, LBB5_154
; %bb.143:
	ldr	x10, [x19, #8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x10, x10, #32
	strh	w10, [x9, #4]
	ldr	w9, [x19, #8]
	ldrh	w10, [x19, #12]
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB5_154
; %bb.144:
	ldr	x9, [x19]
	ldr	w10, [x8]
	str	w10, [x19]
	ldrh	w8, [x8, #4]
	strh	w8, [x19, #4]
	str	w9, [x19, #8]
	lsr	x8, x9, #32
LBB5_145:
	strh	w8, [x19, #12]
	b	LBB5_154
LBB5_146:
	tbz	w8, #0, LBB5_148
	b	LBB5_154
LBB5_147:                               ;   in Loop: Header=BB5_148 Depth=1
	add	x10, x19, #8
	cmp	x10, x20
	b.eq	LBB5_154
LBB5_148:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_150 Depth 2
	ldr	w8, [x19, #8]
	ldrh	w9, [x19, #12]
	ldr	w11, [x19]
	ldrh	w12, [x19, #4]
	mov	x19, x10
	cmp	w9, w12
	cset	w9, lo
	cmp	w8, w11
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB5_147
; %bb.149:                              ;   in Loop: Header=BB5_148 Depth=1
	ldr	x8, [x19]
	lsr	x9, x8, #32
	mov	x10, x19
LBB5_150:                               ;   Parent Loop BB5_148 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x11, x10
	ldr	w12, [x10, #-8]!
	str	w12, [x11]
	ldurh	w12, [x11, #-4]
	strh	w12, [x11, #4]
	ldur	w12, [x11, #-16]
	ldurh	w11, [x11, #-12]
	cmp	w11, w9, uxth
	cset	w11, hi
	cmp	w12, w8
	cset	w12, hi
	csel	w11, w11, w12, eq
	tbnz	w11, #0, LBB5_150
; %bb.151:                              ;   in Loop: Header=BB5_148 Depth=1
	str	w8, [x10]
	strh	w9, [x10, #4]
	b	LBB5_147
LBB5_152:
	ldr	w11, [x8]
	str	w11, [x19]
	ldrh	w11, [x8, #4]
	strh	w11, [x19, #4]
	str	w10, [x19, #8]
	lsr	x11, x10, #32
	strh	w11, [x19, #12]
	ldur	w12, [x20, #-8]
	ldurh	w13, [x20, #-4]
	cmp	w13, w11, uxth
	cset	w11, lo
	cmp	w12, w10
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB5_154
; %bb.153:
	ldr	x10, [x8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
LBB5_154:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function _ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_: ; @_ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	.cfi_startproc
; %bb.0:
	ldr	w10, [x1]
	ldrh	w11, [x1, #4]
	ldr	w8, [x0]
	ldrh	w9, [x0, #4]
	cmp	w11, w9
	cset	w9, lo
	cmp	w10, w8
	cset	w8, lo
	csel	w12, w9, w8, eq
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	cmp	w9, w11
	cset	w11, lo
	cmp	w8, w10
	cset	w10, lo
	csel	w11, w11, w10, eq
	tbz	w12, #0, LBB6_3
; %bb.1:
	ldr	x10, [x0]
	cbz	w11, LBB6_6
; %bb.2:
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	strh	w9, [x0, #4]
	str	w8, [x0]
	lsr	x8, x10, #32
	strh	w8, [x2, #4]
	str	w10, [x2]
	ubfx	x9, x10, #32, #16
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	mov	x8, x10
	b	LBB6_9
LBB6_3:
	cbz	w11, LBB6_9
; %bb.4:
	ldr	x8, [x1]
	ldr	w9, [x2]
	ldrh	w10, [x2, #4]
	strh	w10, [x1, #4]
	str	w9, [x1]
	str	w8, [x2]
	lsr	x9, x8, #32
	strh	w9, [x2, #4]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	ldr	w11, [x0]
	ldrh	w12, [x0, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB6_8
; %bb.5:
	ldr	x8, [x0]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	strh	w10, [x0, #4]
	str	w9, [x0]
	str	w8, [x1]
	lsr	x8, x8, #32
	strh	w8, [x1, #4]
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	b	LBB6_9
LBB6_6:
	ldr	w8, [x1]
	ldrh	w9, [x1, #4]
	strh	w9, [x0, #4]
	str	w8, [x0]
	lsr	x11, x10, #32
	strh	w11, [x1, #4]
	str	w10, [x1]
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	cmp	w9, w11, uxth
	cset	w11, lo
	cmp	w8, w10
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB6_9
; %bb.7:
	ldr	x8, [x1]
	ldr	w9, [x2]
	ldrh	w10, [x2, #4]
	strh	w10, [x1, #4]
	str	w9, [x1]
	str	w8, [x2]
	lsr	x9, x8, #32
	strh	w9, [x2, #4]
	ubfx	x9, x8, #32, #16
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB6_9
LBB6_8:
	ubfx	x9, x8, #32, #16
LBB6_9:
	ldr	w10, [x3]
	ldrh	w11, [x3, #4]
	cmp	w11, w9
	cset	w9, lo
	cmp	w10, w8
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB6_13
; %bb.10:
	ldr	x8, [x2]
	ldr	w9, [x3]
	ldrh	w10, [x3, #4]
	strh	w10, [x2, #4]
	str	w9, [x2]
	str	w8, [x3]
	lsr	x8, x8, #32
	strh	w8, [x3, #4]
	ldr	w8, [x2]
	ldrh	w9, [x2, #4]
	ldr	w10, [x1]
	ldrh	w11, [x1, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB6_13
; %bb.11:
	ldr	x8, [x1]
	ldr	w9, [x2]
	ldrh	w10, [x2, #4]
	strh	w10, [x1, #4]
	str	w9, [x1]
	str	w8, [x2]
	lsr	x8, x8, #32
	strh	w8, [x2, #4]
	ldr	w8, [x1]
	ldrh	w9, [x1, #4]
	ldr	w10, [x0]
	ldrh	w11, [x0, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB6_13
; %bb.12:
	ldr	x8, [x0]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	strh	w10, [x0, #4]
	str	w9, [x0]
	str	w8, [x1]
	lsr	x8, x8, #32
	strh	w8, [x1, #4]
LBB6_13:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function _ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
__ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_: ; @_ZNSt3__127__insertion_sort_incompleteB9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafEEEbT1_S8_T0_
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	sub	x8, x1, x0
	asr	x8, x8, #3
	cmp	x8, #2
	b.gt	LBB7_5
; %bb.1:
	b.lo	LBB7_39
; %bb.2:
	cmp	x8, #2
	b.ne	LBB7_16
; %bb.3:
	ldr	w8, [x1, #-8]!
	ldrh	w9, [x1, #4]
	ldr	w10, [x0]
	ldrh	w11, [x0, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB7_39
; %bb.4:
	ldr	x8, [x0]
	ldr	w9, [x1]
	ldrh	w10, [x1, #4]
	strh	w10, [x0, #4]
	str	w9, [x0]
	str	w8, [x1]
	lsr	x8, x8, #32
	strh	w8, [x1, #4]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_5:
	cmp	x8, #3
	b.eq	LBB7_13
; %bb.6:
	cmp	x8, #4
	b.eq	LBB7_19
; %bb.7:
	cmp	x8, #5
	b.ne	LBB7_16
; %bb.8:
	mov	x20, x1
	add	x1, x0, #8
	add	x2, x0, #16
	add	x3, x0, #24
	mov	x19, x0
	bl	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	mov	x8, x20
	ldr	w9, [x8, #-8]!
	ldrh	w10, [x8, #4]
	ldr	w11, [x19, #24]
	ldrh	w12, [x19, #28]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB7_39
; %bb.9:
	ldr	x9, [x19, #24]
	ldr	w10, [x8]
	ldrh	w11, [x8, #4]
	sturh	w11, [x19, #28]
	stur	w10, [x19, #24]
	str	w9, [x8]
	lsr	x9, x9, #32
	strh	w9, [x8, #4]
	ldr	w8, [x19, #24]
	ldrh	w9, [x19, #28]
	ldr	w10, [x19, #16]
	ldrh	w11, [x19, #20]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB7_39
; %bb.10:
	ldr	x8, [x19, #16]
	ldurh	w9, [x19, #28]
	sturh	w9, [x19, #20]
	ldur	w9, [x19, #24]
	stur	w9, [x19, #16]
	str	w8, [x19, #24]
	lsr	x8, x8, #32
	strh	w8, [x19, #28]
	ldr	w8, [x19, #16]
	ldrh	w9, [x19, #20]
	ldr	w10, [x19, #8]
	ldrh	w11, [x19, #12]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB7_39
; %bb.11:
	ldr	x8, [x19, #8]
	ldurh	w9, [x19, #20]
	sturh	w9, [x19, #12]
	ldur	w9, [x19, #16]
	stur	w9, [x19, #8]
	str	w8, [x19, #16]
	lsr	x8, x8, #32
	strh	w8, [x19, #20]
	ldr	w8, [x19, #8]
	ldrh	w9, [x19, #12]
	ldr	w10, [x19]
	ldrh	w11, [x19, #4]
	cmp	w9, w11
	cset	w9, lo
	cmp	w8, w10
	cset	w8, lo
	csel	w8, w9, w8, eq
	cbz	w8, LBB7_39
; %bb.12:
	ldr	x8, [x19]
	ldur	w9, [x19, #8]
	str	w9, [x19]
	ldurh	w9, [x19, #12]
	strh	w9, [x19, #4]
	str	w8, [x19, #8]
	lsr	x8, x8, #32
	strh	w8, [x19, #12]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_13:
	mov	x8, x0
	ldr	w10, [x8, #8]!
	mov	x9, x1
	ldr	w11, [x9, #-8]!
	ldrh	w12, [x0, #12]
	ldr	w13, [x0]
	ldrh	w14, [x0, #4]
	cmp	w12, w14
	cset	w14, lo
	cmp	w10, w13
	cset	w13, lo
	csel	w13, w14, w13, eq
	ldrh	w14, [x9, #4]
	cmp	w14, w12
	cset	w12, lo
	cmp	w11, w10
	cset	w10, lo
	csel	w11, w12, w10, eq
	tbz	w13, #0, LBB7_20
; %bb.14:
	ldr	x10, [x0]
	cbz	w11, LBB7_26
; %bb.15:
	ldr	w8, [x9]
	ldrh	w11, [x9, #4]
	strh	w11, [x0, #4]
	str	w8, [x0]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
	str	w10, [x9]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_16:
	mov	x8, x0
	ldr	w10, [x8, #16]!
	mov	x9, x0
	ldr	w14, [x9, #8]!
	ldrh	w15, [x0, #12]
	ldr	w11, [x0]
	ldrh	w12, [x0, #4]
	cmp	w15, w12
	cset	w13, lo
	cmp	w14, w11
	cset	w16, lo
	csel	w16, w13, w16, eq
	ldrh	w13, [x0, #20]
	cmp	w13, w15
	cset	w15, lo
	cmp	w10, w14
	cset	w14, lo
	csel	w14, w15, w14, eq
	tbz	w16, #0, LBB7_23
; %bb.17:
	ldr	x11, [x0]
	cbz	w14, LBB7_28
; %bb.18:
	ldr	w9, [x8]
	str	w9, [x0]
	ldrh	w9, [x8, #4]
	strh	w9, [x0, #4]
	str	w11, [x0, #16]
	lsr	x9, x11, #32
	strh	w9, [x0, #20]
	b	LBB7_30
LBB7_19:
	sub	x3, x1, #8
	add	x1, x0, #8
	add	x2, x0, #16
	bl	__ZNSt3__17__sort4B9nqe230102INS_17_ClassicAlgPolicyERN18cng_huffman_kernel12_GLOBAL__N_16BeforeEPNS3_4LeafETnNS_9enable_ifIXnt21__use_branchless_sortIT0_T1_EEiE4typeELi0EEEvSA_SA_SA_SA_S9_
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_20:
	cbz	w11, LBB7_39
; %bb.21:
	ldr	x10, [x0, #8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x10, x10, #32
	strh	w10, [x9, #4]
	ldr	w9, [x0, #8]
	ldrh	w10, [x0, #12]
	ldr	w11, [x0]
	ldrh	w12, [x0, #4]
	cmp	w10, w12
	cset	w10, lo
	cmp	w9, w11
	cset	w9, lo
	csel	w9, w10, w9, eq
	cbz	w9, LBB7_39
; %bb.22:
	ldr	x9, [x0]
	ldr	w10, [x8]
	str	w10, [x0]
	ldrh	w8, [x8, #4]
	strh	w8, [x0, #4]
	str	w9, [x0, #8]
	lsr	x8, x9, #32
	strh	w8, [x0, #12]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_23:
	cbz	w14, LBB7_30
; %bb.24:
	ldr	x10, [x0, #8]
	ldrh	w13, [x8, #4]
	strh	w13, [x9, #4]
	ldr	w13, [x8]
	str	w13, [x9]
	str	w10, [x0, #16]
	lsr	x10, x10, #32
	strh	w10, [x0, #20]
	ldr	w10, [x0, #8]
	ldrh	w13, [x0, #12]
	cmp	w13, w12
	cset	w12, lo
	cmp	w10, w11
	cset	w10, lo
	csel	w10, w12, w10, eq
	cbz	w10, LBB7_30
; %bb.25:
	ldr	x10, [x0]
	ldr	w11, [x9]
	str	w11, [x0]
	ldrh	w9, [x9, #4]
	strh	w9, [x0, #4]
	str	w10, [x0, #8]
	lsr	x9, x10, #32
	strh	w9, [x0, #12]
	b	LBB7_30
LBB7_26:
	ldr	w11, [x8]
	str	w11, [x0]
	ldrh	w11, [x8, #4]
	strh	w11, [x0, #4]
	str	w10, [x0, #8]
	lsr	x11, x10, #32
	strh	w11, [x0, #12]
	ldur	w12, [x1, #-8]
	ldurh	w13, [x1, #-4]
	cmp	w13, w11, uxth
	cset	w11, lo
	cmp	w12, w10
	cset	w10, lo
	csel	w10, w11, w10, eq
	cbz	w10, LBB7_39
; %bb.27:
	ldr	x10, [x8]
	ldr	w11, [x9]
	ldrh	w12, [x9, #4]
	strh	w12, [x8, #4]
	str	w11, [x8]
	str	w10, [x9]
	lsr	x8, x10, #32
	strh	w8, [x9, #4]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_28:
	ldr	w12, [x9]
	str	w12, [x0]
	ldrh	w12, [x9, #4]
	strh	w12, [x0, #4]
	str	w11, [x0, #8]
	lsr	x12, x11, #32
	strh	w12, [x0, #12]
	cmp	w13, w12, uxth
	cset	w12, lo
	cmp	w10, w11
	cset	w10, lo
	csel	w10, w12, w10, eq
	cbz	w10, LBB7_30
; %bb.29:
	ldr	x10, [x9]
	ldr	w11, [x8]
	str	w11, [x9]
	ldrh	w11, [x8, #4]
	strh	w11, [x9, #4]
	str	w10, [x8]
	lsr	x9, x10, #32
	strh	w9, [x8, #4]
LBB7_30:
	add	x9, x0, #24
	cmp	x9, x1
	b.eq	LBB7_39
; %bb.31:
	mov	x10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	b	LBB7_33
LBB7_32:                                ;   in Loop: Header=BB7_33 Depth=1
	add	x13, x15, #16
	str	w12, [x13]
	strh	w8, [x13, #4]
	add	w11, w11, #1
	cmp	w11, #8
	b.ne	LBB7_38
	b	LBB7_40
LBB7_33:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_35 Depth 2
	ldr	w12, [x9]
	ldrh	w13, [x9, #4]
	ldr	w14, [x8]
	ldrh	w15, [x8, #4]
	cmp	w13, w15
	cset	w13, lo
	cmp	w12, w14
	cset	w12, lo
	csel	w12, w13, w12, eq
	cbz	w12, LBB7_38
; %bb.34:                               ;   in Loop: Header=BB7_33 Depth=1
	ldr	x12, [x9]
	ldr	w13, [x8]
	str	w13, [x9]
	ldrh	w8, [x8, #4]
	strh	w8, [x9, #4]
	lsr	x8, x12, #32
	mov	x13, x10
LBB7_35:                                ;   Parent Loop BB7_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x0, x13
	add	x14, x0, x13
	ldr	w16, [x14, #8]!
	ldrh	w17, [x14, #4]
	cmp	w17, w8, uxth
	cset	w17, hi
	cmp	w16, w12
	cset	w16, hi
	csel	w16, w17, w16, eq
	tbz	w16, #0, LBB7_32
; %bb.36:                               ;   in Loop: Header=BB7_35 Depth=2
	ldr	w15, [x14]
	stur	w15, [x14, #8]
	ldrh	w15, [x14, #4]
	sturh	w15, [x14, #12]
	sub	x13, x13, #8
	cmn	x13, #16
	b.ne	LBB7_35
; %bb.37:                               ;   in Loop: Header=BB7_33 Depth=1
	str	w12, [x0]
	strh	w8, [x0, #4]
	add	w11, w11, #1
	cmp	w11, #8
	b.eq	LBB7_40
LBB7_38:                                ;   in Loop: Header=BB7_33 Depth=1
	mov	x8, x9
	add	x9, x9, #8
	add	x10, x10, #8
	cmp	x9, x1
	b.ne	LBB7_33
LBB7_39:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB7_40:
	add	x8, x9, #8
	cmp	x8, x1
	cset	w0, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"Huffman capacity"

l_.str.1:                               ; @.str.1
	.asciz	"Huffman output extent"

l_.str.2:                               ; @.str.2
	.asciz	"Huffman stored extent"

l_.str.3:                               ; @.str.3
	.asciz	"Huffman constant extent"

l_.str.4:                               ; @.str.4
	.asciz	"Huffman coding"

l_.str.5:                               ; @.str.5
	.asciz	"Huffman coded extent"

l_.str.6:                               ; @.str.6
	.asciz	"Huffman stream extent"

l_.str.8:                               ; @.str.8
	.asciz	"Huffman nondegenerate population"

l_.str.9:                               ; @.str.9
	.asciz	"package-merge shape"

l_.str.10:                              ; @.str.10
	.asciz	"package-merge feasibility"

l_.str.11:                              ; @.str.11
	.asciz	"Huffman code length"

l_.str.12:                              ; @.str.12
	.asciz	"Huffman prefix population"

l_.str.13:                              ; @.str.13
	.asciz	"Huffman complete tree"

l_.str.14:                              ; @.str.14
	.asciz	"Huffman table capacity"

l_.str.15:                              ; @.str.15
	.asciz	"Huffman reserved table token"

l_.str.16:                              ; @.str.16
	.asciz	"Huffman table run"

l_.str.17:                              ; @.str.17
	.asciz	"Huffman table bound"

l_.str.18:                              ; @.str.18
	.asciz	"Huffman table padding"

l_.str.19:                              ; @.str.19
	.asciz	"Huffman table extent"

l_.str.20:                              ; @.str.20
	.asciz	"Huffman exact byte extent"

l_.str.21:                              ; @.str.21
	.asciz	"Huffman bit padding"

.subsections_via_symbols
