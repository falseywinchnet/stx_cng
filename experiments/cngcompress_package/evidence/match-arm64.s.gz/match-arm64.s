	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE ; -- Begin function _ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE
	.p2align	2
__ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE: ; @_ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x0, [sp, #64]                   ; 8-byte Spill
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x1, x8
	b.hi	LBB0_92
; %bb.1:
	mov	x10, x1
	mov	w8, #131071                     ; =0x1ffff
	add	w8, w10, w8
	lsr	w8, w8, #15
	and	x8, x8, #0xfc
	add	x21, x1, #5
	add	x8, x21, x8
	cmp	x3, x8
	b.lo	LBB0_92
; %bb.2:
	mov	x22, x2
	mov	w8, #16                         ; =0x10
	strb	w8, [x2]
	strb	w10, [x2, #1]
	lsr	x8, x10, #8
	strb	w8, [x2, #2]
	lsr	x8, x10, #16
	strb	w8, [x2, #3]
	strb	wzr, [x2, #4]
	mov	w8, #67                         ; =0x43
	cmp	x10, #67
	csel	x8, x10, x8, hi
	lsr	x8, x8, #2
	mov	w9, #16384                      ; =0x4000
	cmp	x8, #4, lsl #12                 ; =16384
	csel	x8, x8, x9, lo
	clz	x8, x8
	mov	x9, #-9223372036854775808       ; =0x8000000000000000
	lsr	x19, x9, x8
	lsl	x1, x19, #4
	mov	x0, x4
	str	x10, [sp, #72]                  ; 8-byte Spill
	mov	x20, x4
	bl	_bzero
	ldr	x5, [sp, #72]                   ; 8-byte Reload
	cbz	x5, LBB0_82
; %bb.3:
	mov	x3, #0                          ; =0x0
	sub	x30, x19, #1
	mov	w27, #16                        ; =0x10
	movk	w27, #2, lsl #16
	mov	w4, #31153                      ; =0x79b1
	movk	w4, #40503, lsl #16
	add	x8, x20, #64, lsl #12           ; =262144
	stp	x21, x8, [sp, #8]               ; 16-byte Folded Spill
	add	x8, x20, #64, lsl #12           ; =262144
	add	x25, x8, #1
	add	x8, x20, #64, lsl #12           ; =262144
	add	x8, x8, #2
	str	x8, [sp, #96]                   ; 8-byte Spill
	mov	w23, #5                         ; =0x5
	mov	w19, #-128                      ; =0xffffff80
	mov	w6, #262144                     ; =0x40000
	ldr	x1, [sp, #64]                   ; 8-byte Reload
	mov	x7, x20
	str	x20, [sp, #80]                  ; 8-byte Spill
	str	x30, [sp, #56]                  ; 8-byte Spill
	str	x22, [sp, #24]                  ; 8-byte Spill
	b	LBB0_6
LBB0_4:                                 ;   in Loop: Header=BB0_6 Depth=1
	add	w8, w0, #4
	add	x9, x22, x23
	stp	w8, w20, [x9]
	mov	x24, x0
	add	x0, x9, #8
	ldr	x8, [sp, #80]                   ; 8-byte Reload
	mov	w9, #16                         ; =0x10
	movk	w9, #6, lsl #16
	add	x1, x8, x9
	mov	x2, x24
	bl	_memcpy
	add	x8, x24, #8
LBB0_5:                                 ;   in Loop: Header=BB0_6 Depth=1
	add	x23, x8, x23
	ldp	x8, x30, [sp, #48]              ; 16-byte Folded Reload
	mov	x3, x8
	ldp	x1, x5, [sp, #64]               ; 16-byte Folded Reload
	cmp	x8, x5
	ldr	x7, [sp, #80]                   ; 8-byte Reload
	mov	w4, #31153                      ; =0x79b1
	movk	w4, #40503, lsl #16
	mov	w6, #262144                     ; =0x40000
	b.hs	LBB0_80
LBB0_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_10 Depth 2
                                        ;       Child Loop BB0_25 Depth 3
                                        ;       Child Loop BB0_28 Depth 3
                                        ;       Child Loop BB0_33 Depth 3
                                        ;       Child Loop BB0_36 Depth 3
                                        ;       Child Loop BB0_48 Depth 3
                                        ;       Child Loop BB0_54 Depth 3
                                        ;       Child Loop BB0_58 Depth 3
                                        ;     Child Loop BB0_67 Depth 2
	sub	x8, x5, x3
	cmp	x8, #32, lsl #12                ; =131072
	mov	w9, #131072                     ; =0x20000
	csel	x24, x8, x9, lo
	add	x0, x1, x3
	add	x9, x24, x3
	stp	x23, x9, [sp, #40]              ; 16-byte Folded Spill
	cmp	x8, #8
	str	x0, [sp, #32]                   ; 8-byte Spill
	b.lo	LBB0_69
; %bb.7:                                ;   in Loop: Header=BB0_6 Depth=1
	mov	w10, #0                         ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x26, #0                         ; =0x0
	mov	x11, x24
	mov	x8, x3
	mov	x22, x3
	str	x3, [sp, #88]                   ; 8-byte Spill
	stur	x24, [x29, #-88]                ; 8-byte Folded Spill
	b	LBB0_10
LBB0_8:                                 ;   in Loop: Header=BB0_10 Depth=2
	mov	x9, #0                          ; =0x0
	add	x8, x1, x8
	ldrh	w10, [x8]
	ldrb	w11, [x1, x22]
	orr	w10, w10, w11, lsl #16
	ldrb	w8, [x8, #3]
	orr	w8, w10, w8, lsl #24
	mul	w10, w8, w4
	lsr	w10, w10, #18
	and	x10, x30, x10
	add	x10, x7, x10, lsl #4
	ldr	x11, [x10]
	str	x11, [x10, #8]
	sub	w11, w22, #1
	stp	w8, w11, [x10]
LBB0_9:                                 ;   in Loop: Header=BB0_10 Depth=2
	mov	w10, #1                         ; =0x1
	mov	x8, x22
	ldur	x24, [x29, #-88]                ; 8-byte Folded Reload
	add	x11, x24, x3
	sub	x11, x11, x22
	cmp	x11, #7
	b.ls	LBB0_63
LBB0_10:                                ;   Parent Loop BB0_6 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_25 Depth 3
                                        ;       Child Loop BB0_28 Depth 3
                                        ;       Child Loop BB0_33 Depth 3
                                        ;       Child Loop BB0_36 Depth 3
                                        ;       Child Loop BB0_48 Depth 3
                                        ;       Child Loop BB0_54 Depth 3
                                        ;       Child Loop BB0_58 Depth 3
	add	x13, x1, x22
	ldr	w15, [x13]
	mul	w12, w15, w4
	lsr	w12, w12, #18
	and	x12, x30, x12
	add	x12, x7, x12, lsl #4
	ldp	w0, w16, [x12]
	ldr	x17, [x12, #8]
	stp	w0, w16, [x12, #8]
	add	w14, w22, #1
	stp	w15, w14, [x12]
	ldr	w14, [x13, #4]
	cmp	w16, #0
	ccmp	w0, w15, #0, ne
	b.ne	LBB0_14
; %bb.11:                               ;   in Loop: Header=BB0_10 Depth=2
	sub	w12, w16, #1
	add	x0, x1, x12
	ldr	w2, [x0, #4]
	cmp	w2, w14
	b.ne	LBB0_14
; %bb.12:                               ;   in Loop: Header=BB0_10 Depth=2
	cmp	x11, #16
	b.hs	LBB0_24
; %bb.13:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	w20, #8                         ; =0x8
	cmp	x20, x11
	b.lo	LBB0_28
	b	LBB0_31
LBB0_14:                                ;   in Loop: Header=BB0_10 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
LBB0_15:                                ;   in Loop: Header=BB0_10 Depth=2
	lsr	x0, x17, #32
	cmp	w15, w17
	ccmp	w16, w0, #4, eq
	ccmp	x0, #0, #4, ne
	b.eq	LBB0_45
; %bb.16:                               ;   in Loop: Header=BB0_10 Depth=2
	sub	w15, w0, #1
	cbz	x20, LBB0_21
; %bb.17:                               ;   in Loop: Header=BB0_10 Depth=2
	add	x16, x1, x20
	add	x16, x16, x15
	ldurb	w16, [x16, #-1]
	add	x17, x13, x20
	ldurb	w17, [x17, #-1]
	cmp	w16, w17
	b.ne	LBB0_46
; %bb.18:                               ;   in Loop: Header=BB0_10 Depth=2
	cmp	x20, x11
	b.ne	LBB0_21
; %bb.19:                               ;   in Loop: Header=BB0_10 Depth=2
	cmp	x12, x15
	b.lo	LBB0_21
; %bb.20:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	x20, x11
	b	LBB0_46
LBB0_21:                                ;   in Loop: Header=BB0_10 Depth=2
	add	x16, x1, x15
	ldr	w17, [x16, #4]
	cmp	w17, w14
	b.ne	LBB0_45
; %bb.22:                               ;   in Loop: Header=BB0_10 Depth=2
	cmp	x11, #16
	b.hs	LBB0_32
; %bb.23:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	w14, #8                         ; =0x8
	cmp	x14, x11
	b.lo	LBB0_36
	b	LBB0_39
LBB0_24:                                ;   in Loop: Header=BB0_10 Depth=2
	and	x20, x11, #0xfffffffffffffff8
	sub	x2, x11, #8
	mov	w6, #8                          ; =0x8
LBB0_25:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x3, [x0, x6]
	ldr	x4, [x13, x6]
	cmp	x3, x4
	b.ne	LBB0_40
; %bb.26:                               ;   in Loop: Header=BB0_25 Depth=3
	add	x6, x6, #8
	sub	x2, x2, #8
	cmp	x2, #7
	b.hi	LBB0_25
; %bb.27:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	w4, #31153                      ; =0x79b1
	movk	w4, #40503, lsl #16
	mov	w6, #262144                     ; =0x40000
	cmp	x20, x11
	b.hs	LBB0_31
LBB0_28:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w3, [x0, x20]
	ldrb	w2, [x13, x20]
	cmp	w3, w2
	b.ne	LBB0_31
; %bb.29:                               ;   in Loop: Header=BB0_28 Depth=3
	add	x20, x20, #1
	cmp	x11, x20
	b.ne	LBB0_28
; %bb.30:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	x20, x11
LBB0_31:                                ;   in Loop: Header=BB0_10 Depth=2
	ldr	x3, [sp, #88]                   ; 8-byte Reload
	b	LBB0_15
LBB0_32:                                ;   in Loop: Header=BB0_10 Depth=2
	and	x14, x11, #0xfffffffffffffff8
	sub	x0, x11, #8
	mov	w17, #8                         ; =0x8
LBB0_33:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x3, [x16, x17]
	ldr	x2, [x13, x17]
	cmp	x3, x2
	b.ne	LBB0_41
; %bb.34:                               ;   in Loop: Header=BB0_33 Depth=3
	add	x17, x17, #8
	sub	x0, x0, #8
	cmp	x0, #7
	b.hi	LBB0_33
; %bb.35:                               ;   in Loop: Header=BB0_10 Depth=2
	ldr	x3, [sp, #88]                   ; 8-byte Reload
	cmp	x14, x11
	b.hs	LBB0_39
LBB0_36:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w17, [x16, x14]
	ldrb	w0, [x13, x14]
	cmp	w17, w0
	b.ne	LBB0_39
; %bb.37:                               ;   in Loop: Header=BB0_36 Depth=3
	add	x14, x14, #1
	cmp	x11, x14
	b.ne	LBB0_36
; %bb.38:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	x14, x11
LBB0_39:                                ;   in Loop: Header=BB0_10 Depth=2
	cmp	x14, x20
	b.ls	LBB0_42
	b	LBB0_44
LBB0_40:                                ;   in Loop: Header=BB0_10 Depth=2
	eor	x0, x4, x3
	rbit	x0, x0
	clz	x0, x0
	add	x20, x6, x0, lsr #3
	mov	w4, #31153                      ; =0x79b1
	movk	w4, #40503, lsl #16
	mov	w6, #262144                     ; =0x40000
	ldr	x3, [sp, #88]                   ; 8-byte Reload
	b	LBB0_15
LBB0_41:                                ;   in Loop: Header=BB0_10 Depth=2
	eor	x13, x2, x3
	rbit	x13, x13
	clz	x13, x13
	add	x14, x17, x13, lsr #3
	ldr	x3, [sp, #88]                   ; 8-byte Reload
	cmp	x14, x20
	b.hi	LBB0_44
LBB0_42:                                ;   in Loop: Header=BB0_10 Depth=2
	b.ne	LBB0_45
; %bb.43:                               ;   in Loop: Header=BB0_10 Depth=2
	cmp	x12, x15
	b.hs	LBB0_45
LBB0_44:                                ;   in Loop: Header=BB0_10 Depth=2
	mov	x12, x15
	mov	x20, x14
LBB0_45:                                ;   in Loop: Header=BB0_10 Depth=2
	cbz	x20, LBB0_62
LBB0_46:                                ;   in Loop: Header=BB0_10 Depth=2
	cmp	x26, x27
	b.eq	LBB0_84
; %bb.47:                               ;   in Loop: Header=BB0_10 Depth=2
	sub	x23, x22, x12
	sub	x2, x22, x8
	add	x9, x22, x26
	sub	x24, x9, x8
	add	x28, x24, #1
	ldr	x9, [sp, #96]                   ; 8-byte Reload
	add	x21, x9, x24
	sub	x10, x22, x8
LBB0_48:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x9, x10, #7
	cmp	x9, #0
	csel	w11, wzr, w19, eq
	bfxil	w11, w10, #0, #7
	add	x10, x7, x26
	strb	w11, [x10, x6]
	cbz	x9, LBB0_50
; %bb.49:                               ;   in Loop: Header=BB0_48 Depth=3
	add	x26, x26, #1
	add	x24, x24, #1
	add	x28, x28, #1
	add	x21, x21, #1
	mov	x10, x9
	cmp	x27, x26
	b.ne	LBB0_48
	b	LBB0_84
LBB0_50:                                ;   in Loop: Header=BB0_10 Depth=2
	mvn	x9, x26
	add	x9, x9, x27
	cmp	x2, x9
	b.hi	LBB0_88
; %bb.51:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	x27, x22
	subs	x22, x22, x8
	b.eq	LBB0_53
; %bb.52:                               ;   in Loop: Header=BB0_10 Depth=2
	add	x0, x25, x26
	add	x1, x1, x8
	bl	_memcpy
	ldp	x7, x3, [sp, #80]               ; 16-byte Folded Reload
	mov	w6, #262144                     ; =0x40000
	mov	w4, #31153                      ; =0x79b1
	movk	w4, #40503, lsl #16
	ldp	x30, x1, [sp, #56]              ; 16-byte Folded Reload
	ldr	x5, [sp, #72]                   ; 8-byte Reload
LBB0_53:                                ;   in Loop: Header=BB0_10 Depth=2
	add	x8, x22, x26
	add	x8, x8, #1
	mov	w9, #16                         ; =0x10
	movk	w9, #2, lsl #16
	cmp	x8, x9
	mov	x22, x27
	mov	w27, #16                        ; =0x10
	movk	w27, #2, lsl #16
	b.hs	LBB0_85
LBB0_54:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x24, #1
	lsr	x10, x23, #7
	cmp	x10, #0
	csel	w8, wzr, w19, eq
	bfxil	w8, w23, #0, #7
	strb	w8, [x25, x24]
	sub	x8, x27, #1
	cbz	x10, LBB0_56
; %bb.55:                               ;   in Loop: Header=BB0_54 Depth=3
	add	x28, x28, #1
	add	x21, x21, #1
	mov	x24, x9
	mov	x23, x10
	cmp	x9, x8
	b.lo	LBB0_54
	b	LBB0_85
LBB0_56:                                ;   in Loop: Header=BB0_10 Depth=2
	cmp	x9, x8
	b.hs	LBB0_86
; %bb.57:                               ;   in Loop: Header=BB0_10 Depth=2
	sub	x9, x20, #8
LBB0_58:                                ;   Parent Loop BB0_6 Depth=1
                                        ;     Parent Loop BB0_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x10, x9, #7
	cmp	x10, #0
	csel	w11, wzr, w19, eq
	bfxil	w11, w9, #0, #7
	strb	w11, [x21], #1
	cbz	x10, LBB0_60
; %bb.59:                               ;   in Loop: Header=BB0_58 Depth=3
	add	x28, x28, #1
	mov	x9, x10
	cmp	x28, x8
	b.lo	LBB0_58
	b	LBB0_86
LBB0_60:                                ;   in Loop: Header=BB0_10 Depth=2
	add	x22, x20, x22
	sub	x8, x22, #2
	sub	x9, x5, x8
	add	x26, x28, #2
	cmp	x9, #4
	b.hs	LBB0_8
; %bb.61:                               ;   in Loop: Header=BB0_10 Depth=2
	mov	x9, #0                          ; =0x0
	b	LBB0_9
LBB0_62:                                ;   in Loop: Header=BB0_10 Depth=2
	add	x9, x9, #1
	lsr	x12, x9, #6
	add	x13, x12, #1
	cmp	x11, x13
	csinc	x11, x11, x12, lo
	add	x22, x11, x22
	add	x11, x24, x3
	sub	x11, x11, x22
	cmp	x11, #7
	b.hi	LBB0_10
LBB0_63:                                ;   in Loop: Header=BB0_6 Depth=1
	tbz	w10, #0, LBB0_70
; %bb.64:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x9, x24, x3
	subs	x2, x9, x8
	b.eq	LBB0_73
; %bb.65:                               ;   in Loop: Header=BB0_6 Depth=1
	subs	x9, x27, x26
	b.eq	LBB0_89
; %bb.66:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x10, x3, x24
	add	x10, x10, x26
	sub	x11, x10, x8
	ldr	x10, [sp, #16]                  ; 8-byte Reload
	add	x10, x10, x26
	add	x26, x11, #1
	mov	x12, x2
LBB0_67:                                ;   Parent Loop BB0_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x11, x12, #7
	cmp	x11, #0
	csel	w13, wzr, w19, eq
	bfxil	w13, w12, #0, #7
	strb	w13, [x10]
	cbz	x11, LBB0_71
; %bb.68:                               ;   in Loop: Header=BB0_67 Depth=2
	add	x26, x26, #1
	add	x10, x10, #1
	mov	x12, x11
	subs	x9, x9, #1
	b.ne	LBB0_67
	b	LBB0_89
LBB0_69:                                ;   in Loop: Header=BB0_6 Depth=1
	mov	w21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	x26, x24
	b	LBB0_75
LBB0_70:                                ;   in Loop: Header=BB0_6 Depth=1
	mov	w21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	ldr	x0, [sp, #32]                   ; 8-byte Reload
	mov	x26, x24
	b	LBB0_75
LBB0_71:                                ;   in Loop: Header=BB0_6 Depth=1
	sub	x9, x9, #1
	cmp	x2, x9
	b.hi	LBB0_91
; %bb.72:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x10, #1
	add	x1, x1, x8
	bl	_memcpy
	ldr	x7, [sp, #80]                   ; 8-byte Reload
LBB0_73:                                ;   in Loop: Header=BB0_6 Depth=1
	add	x8, x24, #3
	cmp	x26, x8
	b.hi	LBB0_90
; %bb.74:                               ;   in Loop: Header=BB0_6 Depth=1
	mov	w21, #1                         ; =0x1
	mov	x20, x26
	mov	w23, #4                         ; =0x4
	add	x0, x7, #64, lsl #12            ; =262144
LBB0_75:                                ;   in Loop: Header=BB0_6 Depth=1
	mov	w8, #16                         ; =0x10
	movk	w8, #6, lsl #16
	add	x2, x7, x8
	mov	x1, x26
	mov	w3, #1024                       ; =0x400
	movk	w3, #4, lsl #16
	bl	__ZN23stx_cngcompress_huffman6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	add	x8, x0, x23
	cmp	x8, x24
	b.hs	LBB0_78
; %bb.76:                               ;   in Loop: Header=BB0_6 Depth=1
	ldr	x22, [sp, #24]                  ; 8-byte Reload
	ldr	x23, [sp, #40]                  ; 8-byte Reload
	tbnz	w21, #0, LBB0_4
; %bb.77:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x8, x22, x23
	strb	w0, [x8]
	lsr	x9, x0, #8
	strb	w9, [x8, #1]
	lsr	x9, x0, #16
	strb	w9, [x8, #2]
	lsr	w9, w0, #24
	orr	w9, w9, #0x40
	strb	w9, [x8, #3]
	mov	x24, x0
	add	x0, x8, #4
	ldr	x8, [sp, #80]                   ; 8-byte Reload
	mov	w9, #16                         ; =0x10
	movk	w9, #6, lsl #16
	add	x1, x8, x9
	b	LBB0_79
LBB0_78:                                ;   in Loop: Header=BB0_6 Depth=1
	ldp	x22, x1, [sp, #24]              ; 16-byte Folded Reload
	ldr	x23, [sp, #40]                  ; 8-byte Reload
	add	x8, x22, x23
	strb	w24, [x8]
	lsr	x9, x24, #8
	strb	w9, [x8, #1]
	lsr	x9, x24, #16
	strb	w9, [x8, #2]
	mov	w9, #128                        ; =0x80
	strb	w9, [x8, #3]
	add	x0, x8, #4
LBB0_79:                                ;   in Loop: Header=BB0_6 Depth=1
	mov	x2, x24
	bl	_memcpy
	add	x8, x24, #4
	b	LBB0_5
LBB0_80:
	ldr	x19, [sp, #8]                   ; 8-byte Reload
	cmp	x23, x19
	b.lo	LBB0_83
; %bb.81:
	strb	wzr, [x22], #5
	mov	x0, x22
	mov	x2, x5
	bl	_memcpy
	mov	x23, x19
	b	LBB0_83
LBB0_82:
	strb	wzr, [x22]
	mov	w23, #5                         ; =0x5
LBB0_83:
	mov	x0, x23
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB0_84:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp9:                                  ; EH_LABEL
Lloh0:
	adrp	x1, l_.str.14@PAGE
Lloh1:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ; EH_LABEL
	b	LBB0_87
LBB0_85:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp0:                                  ; EH_LABEL
Lloh2:
	adrp	x1, l_.str.14@PAGE
Lloh3:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ; EH_LABEL
	b	LBB0_87
LBB0_86:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp3:                                  ; EH_LABEL
Lloh4:
	adrp	x1, l_.str.14@PAGE
Lloh5:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ; EH_LABEL
LBB0_87:
Lloh6:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh7:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh8:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh9:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB0_88:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp6:                                  ; EH_LABEL
Lloh10:
	adrp	x1, l_.str.11@PAGE
Lloh11:
	add	x1, x1, l_.str.11@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ; EH_LABEL
	b	LBB0_87
LBB0_89:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp15:                                 ; EH_LABEL
Lloh12:
	adrp	x1, l_.str.14@PAGE
Lloh13:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ; EH_LABEL
	b	LBB0_87
LBB0_90:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp18:                                 ; EH_LABEL
Lloh14:
	adrp	x1, l_.str.13@PAGE
Lloh15:
	add	x1, x1, l_.str.13@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ; EH_LABEL
	b	LBB0_87
LBB0_91:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp12:                                 ; EH_LABEL
Lloh16:
	adrp	x1, l_.str.12@PAGE
Lloh17:
	add	x1, x1, l_.str.12@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ; EH_LABEL
	b	LBB0_87
LBB0_92:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp21:                                 ; EH_LABEL
Lloh18:
	adrp	x1, l_.str@PAGE
Lloh19:
	add	x1, x1, l_.str@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ; EH_LABEL
	b	LBB0_87
LBB0_93:
Ltmp23:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_94:
Ltmp14:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_95:
Ltmp20:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_96:
Ltmp17:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_97:
Ltmp8:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_98:
Ltmp5:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_99:
Ltmp2:                                  ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB0_100:
Ltmp11:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpLdrGot	Lloh8, Lloh9
	.loh AdrpLdrGot	Lloh6, Lloh7
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ; >> Call Site 1 <<
	.uleb128 Ltmp9-Lfunc_begin0             ;   Call between Lfunc_begin0 and Ltmp9
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ; >> Call Site 2 <<
	.uleb128 Ltmp10-Ltmp9                   ;   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin0            ;     jumps to Ltmp11
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin0            ; >> Call Site 3 <<
	.uleb128 Ltmp0-Ltmp10                   ;   Call between Ltmp10 and Ltmp0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ; >> Call Site 4 <<
	.uleb128 Ltmp1-Ltmp0                    ;   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ;     jumps to Ltmp2
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ; >> Call Site 5 <<
	.uleb128 Ltmp3-Ltmp1                    ;   Call between Ltmp1 and Ltmp3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ; >> Call Site 6 <<
	.uleb128 Ltmp4-Ltmp3                    ;   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ;     jumps to Ltmp5
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ; >> Call Site 7 <<
	.uleb128 Ltmp6-Ltmp4                    ;   Call between Ltmp4 and Ltmp6
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ; >> Call Site 8 <<
	.uleb128 Ltmp7-Ltmp6                    ;   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin0             ;     jumps to Ltmp8
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin0             ; >> Call Site 9 <<
	.uleb128 Ltmp15-Ltmp7                   ;   Call between Ltmp7 and Ltmp15
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin0            ; >> Call Site 10 <<
	.uleb128 Ltmp16-Ltmp15                  ;   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin0            ;     jumps to Ltmp17
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin0            ; >> Call Site 11 <<
	.uleb128 Ltmp18-Ltmp16                  ;   Call between Ltmp16 and Ltmp18
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin0            ; >> Call Site 12 <<
	.uleb128 Ltmp19-Ltmp18                  ;   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin0            ;     jumps to Ltmp20
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin0            ; >> Call Site 13 <<
	.uleb128 Ltmp12-Ltmp19                  ;   Call between Ltmp19 and Ltmp12
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin0            ; >> Call Site 14 <<
	.uleb128 Ltmp13-Ltmp12                  ;   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin0            ;     jumps to Ltmp14
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin0            ; >> Call Site 15 <<
	.uleb128 Ltmp21-Ltmp13                  ;   Call between Ltmp13 and Ltmp21
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin0            ; >> Call Site 16 <<
	.uleb128 Ltmp22-Ltmp21                  ;   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin0            ;     jumps to Ltmp23
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin0            ; >> Call Site 17 <<
	.uleb128 Lfunc_end0-Ltmp22              ;   Call between Ltmp22 and Lfunc_end0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE ; -- Begin function _ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE
	.p2align	2
__ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE: ; @_ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #5
	b.lo	LBB1_51
; %bb.1:
	mov	x19, x3
	mov	w8, #8                          ; =0x8
	movk	w8, #32, lsl #16
	cmp	x3, x8
	b.hi	LBB1_51
; %bb.2:
	mov	x21, x0
	ldur	w8, [x0, #1]
	cmp	x19, x8
	b.ne	LBB1_51
; %bb.3:
	mov	x20, x2
	mov	x25, x1
	ldrb	w8, [x21]
	cmp	w8, #16
	b.eq	LBB1_8
; %bb.4:
	cbnz	w8, LBB1_52
; %bb.5:
	add	x8, x19, #5
	cmp	x25, x8
	b.ne	LBB1_53
; %bb.6:
	cbz	x19, LBB1_41
; %bb.7:
	add	x1, x21, #5
	mov	x0, x20
	mov	x2, x19
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	b	_memcpy
LBB1_8:
	cbz	x19, LBB1_52
; %bb.9:
	mov	x23, x4
	mov	x22, #0                         ; =0x0
	mov	w9, #5                          ; =0x5
	mov	w27, #131072                    ; =0x20000
	stp	x21, x19, [sp, #16]             ; 16-byte Folded Spill
	str	x25, [sp, #8]                   ; 8-byte Spill
	b	LBB1_12
LBB1_10:                                ;   in Loop: Header=BB1_12 Depth=1
	add	x0, x21, x26
	add	x2, x20, x22
	mov	x1, x24
	mov	x3, x28
	bl	__ZN23stx_cngcompress_huffman6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
LBB1_11:                                ;   in Loop: Header=BB1_12 Depth=1
	add	x9, x26, x24
	add	x22, x28, x22
	cmp	x22, x19
	b.hs	LBB1_40
LBB1_12:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_23 Depth 2
                                        ;       Child Loop BB1_33 Depth 3
	sub	x8, x25, x9
	cmp	x8, #3
	b.ls	LBB1_46
; %bb.13:                               ;   in Loop: Header=BB1_12 Depth=1
	add	x8, x21, x9
	ldrb	w10, [x8, #3]
	cmp	w10, #192
	b.hs	LBB1_45
; %bb.14:                               ;   in Loop: Header=BB1_12 Depth=1
	lsl	w11, w10, #24
	ldrb	w12, [x8, #2]
	ldrb	w13, [x8, #1]
	ldrb	w14, [x8]
	add	x26, x9, #4
	and	w9, w11, #0x3f000000
	orr	w9, w9, w12, lsl #16
	orr	w9, w9, w14
	orr	w24, w9, w13, lsl #8
	sub	x9, x19, x22
	cmp	x9, #32, lsl #12                ; =131072
	csel	x28, x9, x27, lo
	sub	x9, x25, x26
	cmp	x9, x24
	b.lo	LBB1_44
; %bb.15:                               ;   in Loop: Header=BB1_12 Depth=1
	tbnz	w11, #31, LBB1_34
; %bb.16:                               ;   in Loop: Header=BB1_12 Depth=1
	cmp	w10, #64
	b.hs	LBB1_10
; %bb.17:                               ;   in Loop: Header=BB1_12 Depth=1
	cmp	w24, #8
	b.ls	LBB1_49
; %bb.18:                               ;   in Loop: Header=BB1_12 Depth=1
	str	x26, [sp, #48]                  ; 8-byte Spill
	ldr	w26, [x21, x26]
	add	x9, x28, #3
	cmp	x9, x26
	b.lo	LBB1_50
; %bb.19:                               ;   in Loop: Header=BB1_12 Depth=1
	add	x0, x8, #8
	str	x24, [sp, #40]                  ; 8-byte Spill
	sub	x1, x24, #4
	mov	x2, x23
	mov	x3, x26
	bl	__ZN23stx_cngcompress_huffman6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	mov	x8, #0                          ; =0x0
	str	xzr, [sp, #56]
	add	x9, x28, x22
	add	x24, x28, x22
	cmp	x22, x9
	b.hs	LBB1_38
; %bb.20:                               ;   in Loop: Header=BB1_12 Depth=1
	str	x28, [sp, #32]                  ; 8-byte Spill
	mov	x19, x22
	b	LBB1_23
LBB1_21:                                ;   in Loop: Header=BB1_23 Depth=2
	add	x8, x20, x19
	sub	x1, x8, x28
	add	x0, x20, x19
	mov	x2, x27
	bl	_memcpy
LBB1_22:                                ;   in Loop: Header=BB1_23 Depth=2
	add	x19, x27, x19
	cmp	x19, x24
	b.hs	LBB1_36
LBB1_23:                                ;   Parent Loop BB1_12 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_33 Depth 3
	add	x2, sp, #56
	mov	x0, x23
	mov	x1, x26
	bl	__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	ldr	x21, [sp, #56]
	sub	x8, x24, x19
	sub	x9, x26, x21
	cmp	x0, x9
	ccmp	x0, x8, #2, ls
	b.hi	LBB1_42
; %bb.24:                               ;   in Loop: Header=BB1_23 Depth=2
	mov	x27, x0
	cbz	x0, LBB1_26
; %bb.25:                               ;   in Loop: Header=BB1_23 Depth=2
	add	x0, x20, x19
	add	x1, x23, x21
	mov	x2, x27
	bl	_memcpy
LBB1_26:                                ;   in Loop: Header=BB1_23 Depth=2
	add	x8, x21, x27
	str	x8, [sp, #56]
	add	x19, x27, x19
	subs	x21, x24, x19
	b.eq	LBB1_37
; %bb.27:                               ;   in Loop: Header=BB1_23 Depth=2
	add	x2, sp, #56
	mov	x0, x23
	mov	x1, x26
	bl	__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	mov	x28, x0
	add	x2, sp, #56
	mov	x0, x23
	mov	x1, x26
	bl	__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	sub	x8, x28, #1
	cmp	x8, x19
	b.hs	LBB1_43
; %bb.28:                               ;   in Loop: Header=BB1_23 Depth=2
	add	x27, x0, #8
	cmp	x27, x21
	b.hi	LBB1_43
; %bb.29:                               ;   in Loop: Header=BB1_23 Depth=2
	cmp	x28, x27
	b.hs	LBB1_21
; %bb.30:                               ;   in Loop: Header=BB1_23 Depth=2
	add	x25, x20, x19
	cmp	x28, #1
	b.ne	LBB1_32
; %bb.31:                               ;   in Loop: Header=BB1_23 Depth=2
	ldurb	w1, [x25, #-1]
	add	x0, x20, x19
	mov	x2, x27
	bl	_memset
	b	LBB1_22
LBB1_32:                                ;   in Loop: Header=BB1_23 Depth=2
	sub	x1, x25, x28
	add	x0, x20, x19
	mov	x2, x28
	bl	_memcpy
LBB1_33:                                ;   Parent Loop BB1_12 Depth=1
                                        ;     Parent Loop BB1_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x8, x27, x28
	cmp	x8, x28
	csel	x21, x8, x28, lo
	add	x0, x25, x28
	add	x1, x20, x19
	mov	x2, x21
	bl	_memcpy
	add	x28, x21, x28
	cmp	x28, x27
	b.lo	LBB1_33
	b	LBB1_22
LBB1_34:                                ;   in Loop: Header=BB1_12 Depth=1
	cmp	x28, x24
	b.ne	LBB1_47
; %bb.35:                               ;   in Loop: Header=BB1_12 Depth=1
	add	x0, x20, x22
	add	x1, x21, x26
	mov	x2, x24
	bl	_memcpy
	mov	w27, #131072                    ; =0x20000
	b	LBB1_11
LBB1_36:                                ;   in Loop: Header=BB1_12 Depth=1
	ldr	x8, [sp, #56]
LBB1_37:                                ;   in Loop: Header=BB1_12 Depth=1
	ldp	x21, x19, [sp, #16]             ; 16-byte Folded Reload
	ldr	x25, [sp, #8]                   ; 8-byte Reload
	mov	w27, #131072                    ; =0x20000
	ldr	x28, [sp, #32]                  ; 8-byte Reload
LBB1_38:                                ;   in Loop: Header=BB1_12 Depth=1
	cmp	x8, x26
	b.ne	LBB1_48
; %bb.39:                               ;   in Loop: Header=BB1_12 Depth=1
	ldp	x24, x26, [sp, #40]             ; 16-byte Folded Reload
	b	LBB1_11
LBB1_40:
	cmp	x9, x25
	b.ne	LBB1_54
LBB1_41:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB1_42:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp39:                                 ; EH_LABEL
Lloh20:
	adrp	x1, l_.str.15@PAGE
Lloh21:
	add	x1, x1, l_.str.15@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ; EH_LABEL
	b	LBB1_55
LBB1_43:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp42:                                 ; EH_LABEL
Lloh22:
	adrp	x1, l_.str.16@PAGE
Lloh23:
	add	x1, x1, l_.str.16@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ; EH_LABEL
	b	LBB1_55
LBB1_44:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp54:                                 ; EH_LABEL
Lloh24:
	adrp	x1, l_.str.6@PAGE
Lloh25:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ; EH_LABEL
	b	LBB1_55
LBB1_45:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp30:                                 ; EH_LABEL
Lloh26:
	adrp	x1, l_.str.5@PAGE
Lloh27:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ; EH_LABEL
	b	LBB1_55
LBB1_46:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp27:                                 ; EH_LABEL
Lloh28:
	adrp	x1, l_.str.4@PAGE
Lloh29:
	add	x1, x1, l_.str.4@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ; EH_LABEL
	b	LBB1_55
LBB1_47:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp33:                                 ; EH_LABEL
Lloh30:
	adrp	x1, l_.str.7@PAGE
Lloh31:
	add	x1, x1, l_.str.7@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ; EH_LABEL
	b	LBB1_55
LBB1_48:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp45:                                 ; EH_LABEL
Lloh32:
	adrp	x1, l_.str.17@PAGE
Lloh33:
	add	x1, x1, l_.str.17@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ; EH_LABEL
	b	LBB1_55
LBB1_49:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp36:                                 ; EH_LABEL
Lloh34:
	adrp	x1, l_.str.8@PAGE
Lloh35:
	add	x1, x1, l_.str.8@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ; EH_LABEL
	b	LBB1_55
LBB1_50:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp51:                                 ; EH_LABEL
Lloh36:
	adrp	x1, l_.str.9@PAGE
Lloh37:
	add	x1, x1, l_.str.9@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ; EH_LABEL
	b	LBB1_55
LBB1_51:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp24:                                 ; EH_LABEL
Lloh38:
	adrp	x1, l_.str.1@PAGE
Lloh39:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ; EH_LABEL
	b	LBB1_55
LBB1_52:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp60:                                 ; EH_LABEL
Lloh40:
	adrp	x1, l_.str.3@PAGE
Lloh41:
	add	x1, x1, l_.str.3@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ; EH_LABEL
	b	LBB1_55
LBB1_53:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp57:                                 ; EH_LABEL
Lloh42:
	adrp	x1, l_.str.2@PAGE
Lloh43:
	add	x1, x1, l_.str.2@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ; EH_LABEL
	b	LBB1_55
LBB1_54:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp48:                                 ; EH_LABEL
Lloh44:
	adrp	x1, l_.str.10@PAGE
Lloh45:
	add	x1, x1, l_.str.10@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ; EH_LABEL
LBB1_55:
Lloh46:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh47:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh48:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh49:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB1_56:
Ltmp50:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_57:
Ltmp59:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_58:
Ltmp62:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_59:
Ltmp26:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_60:
Ltmp53:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_61:
Ltmp38:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_62:
Ltmp47:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_63:
Ltmp35:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_64:
Ltmp29:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_65:
Ltmp32:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_66:
Ltmp56:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_67:
Ltmp44:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB1_68:
Ltmp41:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpLdrGot	Lloh48, Lloh49
	.loh AdrpLdrGot	Lloh46, Lloh47
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ; >> Call Site 1 <<
	.uleb128 Ltmp39-Lfunc_begin1            ;   Call between Lfunc_begin1 and Ltmp39
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin1            ; >> Call Site 2 <<
	.uleb128 Ltmp40-Ltmp39                  ;   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin1            ;     jumps to Ltmp41
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin1            ; >> Call Site 3 <<
	.uleb128 Ltmp42-Ltmp40                  ;   Call between Ltmp40 and Ltmp42
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin1            ; >> Call Site 4 <<
	.uleb128 Ltmp43-Ltmp42                  ;   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin1            ;     jumps to Ltmp44
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin1            ; >> Call Site 5 <<
	.uleb128 Ltmp54-Ltmp43                  ;   Call between Ltmp43 and Ltmp54
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin1            ; >> Call Site 6 <<
	.uleb128 Ltmp55-Ltmp54                  ;   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin1            ;     jumps to Ltmp56
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin1            ; >> Call Site 7 <<
	.uleb128 Ltmp30-Ltmp55                  ;   Call between Ltmp55 and Ltmp30
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin1            ; >> Call Site 8 <<
	.uleb128 Ltmp31-Ltmp30                  ;   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin1            ;     jumps to Ltmp32
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin1            ; >> Call Site 9 <<
	.uleb128 Ltmp27-Ltmp31                  ;   Call between Ltmp31 and Ltmp27
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin1            ; >> Call Site 10 <<
	.uleb128 Ltmp28-Ltmp27                  ;   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin1            ;     jumps to Ltmp29
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin1            ; >> Call Site 11 <<
	.uleb128 Ltmp33-Ltmp28                  ;   Call between Ltmp28 and Ltmp33
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin1            ; >> Call Site 12 <<
	.uleb128 Ltmp34-Ltmp33                  ;   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin1            ;     jumps to Ltmp35
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin1            ; >> Call Site 13 <<
	.uleb128 Ltmp45-Ltmp34                  ;   Call between Ltmp34 and Ltmp45
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin1            ; >> Call Site 14 <<
	.uleb128 Ltmp46-Ltmp45                  ;   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin1            ;     jumps to Ltmp47
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin1            ; >> Call Site 15 <<
	.uleb128 Ltmp36-Ltmp46                  ;   Call between Ltmp46 and Ltmp36
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin1            ; >> Call Site 16 <<
	.uleb128 Ltmp37-Ltmp36                  ;   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin1            ;     jumps to Ltmp38
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin1            ; >> Call Site 17 <<
	.uleb128 Ltmp51-Ltmp37                  ;   Call between Ltmp37 and Ltmp51
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin1            ; >> Call Site 18 <<
	.uleb128 Ltmp52-Ltmp51                  ;   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin1            ;     jumps to Ltmp53
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin1            ; >> Call Site 19 <<
	.uleb128 Ltmp24-Ltmp52                  ;   Call between Ltmp52 and Ltmp24
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin1            ; >> Call Site 20 <<
	.uleb128 Ltmp25-Ltmp24                  ;   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin1            ;     jumps to Ltmp26
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin1            ; >> Call Site 21 <<
	.uleb128 Ltmp60-Ltmp25                  ;   Call between Ltmp25 and Ltmp60
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin1            ; >> Call Site 22 <<
	.uleb128 Ltmp61-Ltmp60                  ;   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin1            ;     jumps to Ltmp62
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin1            ; >> Call Site 23 <<
	.uleb128 Ltmp57-Ltmp61                  ;   Call between Ltmp61 and Ltmp57
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin1            ; >> Call Site 24 <<
	.uleb128 Ltmp58-Ltmp57                  ;   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin1            ;     jumps to Ltmp59
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin1            ; >> Call Site 25 <<
	.uleb128 Ltmp48-Ltmp58                  ;   Call between Ltmp58 and Ltmp48
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin1            ; >> Call Site 26 <<
	.uleb128 Ltmp49-Ltmp48                  ;   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin1            ;     jumps to Ltmp50
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin1            ; >> Call Site 27 <<
	.uleb128 Lfunc_end1-Ltmp49              ;   Call between Ltmp49 and Lfunc_end1
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm: ; @_ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x9, [x2]
	cmp	x1, x9
	csel	x10, x1, x9, hi
	cmp	x9, x1
	b.hs	LBB2_11
; %bb.1:
	mov	x8, x0
	ldrb	w12, [x0, x9]
	add	x11, x9, #1
	str	x11, [x2]
	and	x0, x12, #0x7f
	tbz	w12, #7, LBB2_10
; %bb.2:
	cmp	x1, x11
	b.eq	LBB2_11
; %bb.3:
	ldrb	w13, [x8, x11]
	add	x12, x9, #2
	str	x12, [x2]
	bfi	x0, x13, #7, #7
	mov	x11, x13
	tbz	w13, #7, LBB2_9
; %bb.4:
	cmp	x12, x10
	b.eq	LBB2_11
; %bb.5:
	ldrb	w13, [x8, x12]
	add	x12, x9, #3
	str	x12, [x2]
	bfi	x0, x13, #14, #7
	mov	x11, x13
	tbz	w13, #7, LBB2_9
; %bb.6:
	cmp	x12, x10
	b.eq	LBB2_11
; %bb.7:
	ldrb	w11, [x8, x12]
	add	x8, x9, #4
	str	x8, [x2]
	tbnz	w11, #7, LBB2_14
; %bb.8:
	bfi	x0, x11, #21, #7
LBB2_9:
	cbz	w11, LBB2_13
LBB2_10:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB2_11:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp69:                                 ; EH_LABEL
Lloh50:
	adrp	x1, l_.str.18@PAGE
Lloh51:
	add	x1, x1, l_.str.18@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp70:                                 ; EH_LABEL
LBB2_12:
Lloh52:
	adrp	x1, __ZTISt13runtime_error@GOTPAGE
Lloh53:
	ldr	x1, [x1, __ZTISt13runtime_error@GOTPAGEOFF]
Lloh54:
	adrp	x2, __ZNSt13runtime_errorD1Ev@GOTPAGE
Lloh55:
	ldr	x2, [x2, __ZNSt13runtime_errorD1Ev@GOTPAGEOFF]
	mov	x0, x19
	bl	___cxa_throw
LBB2_13:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp63:                                 ; EH_LABEL
Lloh56:
	adrp	x1, l_.str.19@PAGE
Lloh57:
	add	x1, x1, l_.str.19@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ; EH_LABEL
	b	LBB2_12
LBB2_14:
	mov	w0, #16                         ; =0x10
	bl	___cxa_allocate_exception
	mov	x19, x0
Ltmp66:                                 ; EH_LABEL
Lloh58:
	adrp	x1, l_.str.20@PAGE
Lloh59:
	add	x1, x1, l_.str.20@PAGEOFF
	bl	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ; EH_LABEL
	b	LBB2_12
LBB2_15:
Ltmp68:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_16:
Ltmp65:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
LBB2_17:
Ltmp71:                                 ; EH_LABEL
	mov	x20, x0
	mov	x0, x19
	bl	___cxa_free_exception
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpLdrGot	Lloh54, Lloh55
	.loh AdrpLdrGot	Lloh52, Lloh53
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh58, Lloh59
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	255                             ; @TType Encoding = omit
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ; >> Call Site 1 <<
	.uleb128 Ltmp69-Lfunc_begin2            ;   Call between Lfunc_begin2 and Ltmp69
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp69-Lfunc_begin2            ; >> Call Site 2 <<
	.uleb128 Ltmp70-Ltmp69                  ;   Call between Ltmp69 and Ltmp70
	.uleb128 Ltmp71-Lfunc_begin2            ;     jumps to Ltmp71
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp70-Lfunc_begin2            ; >> Call Site 3 <<
	.uleb128 Ltmp63-Ltmp70                  ;   Call between Ltmp70 and Ltmp63
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin2            ; >> Call Site 4 <<
	.uleb128 Ltmp64-Ltmp63                  ;   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin2            ;     jumps to Ltmp65
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin2            ; >> Call Site 5 <<
	.uleb128 Ltmp66-Ltmp64                  ;   Call between Ltmp64 and Ltmp66
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin2            ; >> Call Site 6 <<
	.uleb128 Ltmp67-Ltmp66                  ;   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin2            ;     jumps to Ltmp68
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin2            ; >> Call Site 7 <<
	.uleb128 Lfunc_end2-Ltmp67              ;   Call between Ltmp67 and Lfunc_end2
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"match packet capacity"

l_.str.1:                               ; @.str.1
	.asciz	"match packet output extent"

l_.str.2:                               ; @.str.2
	.asciz	"match stored extent"

l_.str.3:                               ; @.str.3
	.asciz	"match packet coding"

l_.str.4:                               ; @.str.4
	.asciz	"match block header extent"

l_.str.5:                               ; @.str.5
	.asciz	"match reserved block flags"

l_.str.6:                               ; @.str.6
	.asciz	"match block extent"

l_.str.7:                               ; @.str.7
	.asciz	"match stored block extent"

l_.str.8:                               ; @.str.8
	.asciz	"match coded block header"

l_.str.9:                               ; @.str.9
	.asciz	"match parsed bound"

l_.str.10:                              ; @.str.10
	.asciz	"match exact packet extent"

l_.str.11:                              ; @.str.11
	.asciz	"match literal capacity"

l_.str.12:                              ; @.str.12
	.asciz	"match tail capacity"

l_.str.13:                              ; @.str.13
	.asciz	"match parse bound"

l_.str.14:                              ; @.str.14
	.asciz	"match integer capacity"

l_.str.15:                              ; @.str.15
	.asciz	"match literal extent"

l_.str.16:                              ; @.str.16
	.asciz	"match reference extent"

l_.str.17:                              ; @.str.17
	.asciz	"match exact consumption"

l_.str.18:                              ; @.str.18
	.asciz	"match integer extent"

l_.str.19:                              ; @.str.19
	.asciz	"match integer canonical form"

l_.str.20:                              ; @.str.20
	.asciz	"match integer width"

.subsections_via_symbols
