	.build_version macos, 26, 0	sdk_version 26, 2
	.section	__TEXT,__text,regular,pure_instructions
	.att_syntax
	.globl	__ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE ## -- Begin function _ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE
	.p2align	4
__ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE: ## @_ZN21stx_cngcompress_match6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15EncodeWorkspaceE
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$2097160, %rsi                  ## imm = 0x200008
	ja	LBB0_2
## %bb.1:
	movq	%rsi, -56(%rbp)                 ## 8-byte Spill
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	addl	$131071, %eax                   ## imm = 0x1FFFF
	shrl	$15, %eax
	andl	$252, %eax
	movq	-56(%rbp), %rsi                 ## 8-byte Reload
	addq	%rsi, %rax
	addq	$5, %rax
	cmpq	%rax, %rcx
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	jb	LBB0_2
## %bb.5:
	movq	%r8, %r14
	movq	%rdi, %r12
	movb	$16, (%rdx)
	movb	%al, 1(%rdx)
	movq	-56(%rbp), %rax                 ## 8-byte Reload
                                        ## kill: def $eax killed $eax killed $rax
	shrl	$16, %eax
	cmpq	$68, -56(%rbp)                  ## 8-byte Folded Reload
	movl	$67, %ecx
	cmovaeq	-56(%rbp), %rcx                 ## 8-byte Folded Reload
	shrq	$2, %rcx
	cmpq	$16384, %rcx                    ## imm = 0x4000
	movq	%rdx, %rbx
	movl	$16384, %edx                    ## imm = 0x4000
	cmovbq	%rcx, %rdx
	movq	-56(%rbp), %rcx                 ## 8-byte Reload
	movb	%ch, 2(%rbx)
	bsrq	%rdx, %rcx
	notl	%ecx
	movabsq	$-9223372036854775808, %r15     ## imm = 0x8000000000000000
                                        ## kill: def $cl killed $cl killed $rcx
	shrq	%cl, %r15
	movb	%al, 3(%rbx)
	movb	$0, 4(%rbx)
	movq	%r15, %rsi
	shlq	$4, %rsi
	movq	%r8, %rdi
	callq	___bzero
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	testq	%rdx, %rdx
	je	LBB0_99
## %bb.6:
	movq	%rbx, -112(%rbp)                ## 8-byte Spill
	leaq	5(%rdx), %rax
	movq	%rax, -168(%rbp)                ## 8-byte Spill
	decq	%r15
	leaq	262144(%r14), %rax
	movq	%rax, -176(%rbp)                ## 8-byte Spill
	leaq	393232(%r14), %rax
	movq	%rax, -152(%rbp)                ## 8-byte Spill
	leaq	262145(%r14), %rax
	movq	%rax, -144(%rbp)                ## 8-byte Spill
	leaq	262146(%r14), %rax
	movq	%rax, -184(%rbp)                ## 8-byte Spill
	movl	$5, %eax
	xorl	%r13d, %r13d
	movq	%r12, -88(%rbp)                 ## 8-byte Spill
	movq	%r14, -80(%rbp)                 ## 8-byte Spill
	movq	%r15, %rsi
	movq	%r15, -136(%rbp)                ## 8-byte Spill
	jmp	LBB0_7
	.p2align	4
LBB0_91:                                ##   in Loop: Header=BB0_7 Depth=1
	movq	-112(%rbp), %rcx                ## 8-byte Reload
	movq	-128(%rbp), %rbx                ## 8-byte Reload
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movb	%al, (%rcx,%rbx)
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movb	%ah, 1(%rcx,%rbx)
	movq	-48(%rbp), %rax                 ## 8-byte Reload
                                        ## kill: def $eax killed $eax killed $rax
	shrl	$16, %eax
	movb	%al, 2(%rcx,%rbx)
	movb	$-128, 3(%rcx,%rbx)
	leaq	(%rcx,%rbx), %rdi
	addq	$4, %rdi
	movq	-120(%rbp), %rsi                ## 8-byte Reload
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	callq	_memcpy
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	addq	$4, %rax
LBB0_95:                                ##   in Loop: Header=BB0_7 Depth=1
	addq	%rbx, %rax
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %r13
	movq	-136(%rbp), %rsi                ## 8-byte Reload
	jae	LBB0_96
LBB0_7:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB0_9 Depth 2
                                        ##       Child Loop BB0_15 Depth 3
                                        ##       Child Loop BB0_20 Depth 3
                                        ##       Child Loop BB0_38 Depth 3
                                        ##       Child Loop BB0_43 Depth 3
                                        ##       Child Loop BB0_32 Depth 3
                                        ##       Child Loop BB0_59 Depth 3
                                        ##       Child Loop BB0_66 Depth 3
                                        ##     Child Loop BB0_79 Depth 2
	movq	%r13, %r9
	movq	%rax, -128(%rbp)                ## 8-byte Spill
	movq	%rdx, %rax
	subq	%r13, %rax
	cmpq	$131072, %rax                   ## imm = 0x20000
	movl	$131072, %edx                   ## imm = 0x20000
	cmovbq	%rax, %rdx
	leaq	(%r12,%r13), %rdi
	addq	%rdx, %r13
	cmpq	$8, %rax
	movq	%rdx, -48(%rbp)                 ## 8-byte Spill
	movq	%rdi, -120(%rbp)                ## 8-byte Spill
	jb	LBB0_92
## %bb.8:                               ##   in Loop: Header=BB0_7 Depth=1
	movq	$0, -160(%rbp)                  ## 8-byte Folded Spill
	movq	%r9, %r10
	movq	%r9, %rcx
	movq	$0, -64(%rbp)                   ## 8-byte Folded Spill
	xorl	%r15d, %r15d
	movq	%r9, -96(%rbp)                  ## 8-byte Spill
	jmp	LBB0_9
	.p2align	4
LBB0_72:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	-88(%rbp), %r12                 ## 8-byte Reload
	movl	-2(%r12,%rbx), %eax
	imull	$-1640531535, %eax, %ecx        ## imm = 0x9E3779B1
	shrl	$18, %ecx
	andl	%esi, %ecx
	shll	$4, %ecx
	movq	(%r14,%rcx), %rdx
	movq	%rdx, 8(%r14,%rcx)
	leal	-1(%rbx), %edx
	movl	%eax, (%r14,%rcx)
	movl	%edx, 4(%r14,%rcx)
	movq	%r13, %r15
	movq	$0, -64(%rbp)                   ## 8-byte Folded Spill
	movq	%rbx, %r10
LBB0_73:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r9), %r13
LBB0_74:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	%r13, %rdx
	subq	%rbx, %rdx
	movq	%rbx, %rcx
	cmpq	$7, %rdx
	jbe	LBB0_75
LBB0_9:                                 ##   Parent Loop BB0_7 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB0_15 Depth 3
                                        ##       Child Loop BB0_20 Depth 3
                                        ##       Child Loop BB0_38 Depth 3
                                        ##       Child Loop BB0_43 Depth 3
                                        ##       Child Loop BB0_32 Depth 3
                                        ##       Child Loop BB0_59 Depth 3
                                        ##       Child Loop BB0_66 Depth 3
	movq	%r10, -72(%rbp)                 ## 8-byte Spill
	leaq	(%r12,%rcx), %rdi
	movl	(%r12,%rcx), %r9d
	imull	$-1640531535, %r9d, %eax        ## imm = 0x9E3779B1
	shrl	$18, %eax
	andl	%esi, %eax
	shll	$4, %eax
	movl	(%r14,%rax), %r10d
	movl	4(%r14,%rax), %r11d
	movq	8(%r14,%rax), %rbx
	movl	%r10d, 8(%r14,%rax)
	movl	%r11d, 12(%r14,%rax)
	leal	1(%rcx), %esi
	movl	%r9d, (%r14,%rax)
	movl	%esi, 4(%r14,%rax)
	movq	%rcx, -104(%rbp)                ## 8-byte Spill
	movl	4(%r12,%rcx), %r8d
	testl	%r11d, %r11d
	je	LBB0_12
## %bb.10:                              ##   in Loop: Header=BB0_9 Depth=2
	movl	$0, %ecx
	movl	$0, %esi
	cmpl	%r9d, %r10d
	jne	LBB0_17
## %bb.11:                              ##   in Loop: Header=BB0_9 Depth=2
	leal	-1(%r11), %ecx
	cmpl	%r8d, 4(%r12,%rcx)
	jne	LBB0_12
## %bb.13:                              ##   in Loop: Header=BB0_9 Depth=2
	leaq	(%r12,%rcx), %r10
	movl	$8, %esi
	cmpq	$16, %rdx
	jb	LBB0_19
## %bb.14:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%rdx, %rsi
	andq	$-8, %rsi
	leaq	-8(%rdx), %r12
	movl	$8, %r14d
	.p2align	4
LBB0_15:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	(%r10,%r14), %r13
	movq	(%rdi,%r14), %rax
	cmpq	%rax, %r13
	jne	LBB0_16
## %bb.23:                              ##   in Loop: Header=BB0_15 Depth=3
	addq	$8, %r14
	addq	$-8, %r12
	cmpq	$7, %r12
	ja	LBB0_15
## %bb.24:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	-88(%rbp), %r12                 ## 8-byte Reload
	movq	-80(%rbp), %r14                 ## 8-byte Reload
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	-96(%rbp), %r13                 ## 8-byte Reload
	addq	%rax, %r13
LBB0_19:                                ##   in Loop: Header=BB0_9 Depth=2
	cmpq	%rdx, %rsi
	jae	LBB0_17
	.p2align	4
LBB0_20:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movzbl	(%r10,%rsi), %eax
	cmpb	(%rdi,%rsi), %al
	jne	LBB0_17
## %bb.21:                              ##   in Loop: Header=BB0_20 Depth=3
	incq	%rsi
	cmpq	%rsi, %rdx
	jne	LBB0_20
## %bb.22:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%rdx, %rsi
	jmp	LBB0_17
	.p2align	4
LBB0_12:                                ##   in Loop: Header=BB0_9 Depth=2
	xorl	%ecx, %ecx
	xorl	%esi, %esi
LBB0_17:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	%rbx, %r10
	shrq	$32, %r10
	sete	%al
	cmpl	%ebx, %r9d
	setne	%r9b
	cmpl	%r10d, %r11d
	sete	%r11b
	orb	%al, %r11b
	orb	%r9b, %r11b
	je	LBB0_25
## %bb.18:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	-104(%rbp), %r11                ## 8-byte Reload
	jmp	LBB0_50
	.p2align	4
LBB0_25:                                ##   in Loop: Header=BB0_9 Depth=2
	decl	%r10d
	testq	%rsi, %rsi
	movq	-104(%rbp), %r11                ## 8-byte Reload
	je	LBB0_35
## %bb.26:                              ##   in Loop: Header=BB0_9 Depth=2
	leaq	(%r12,%rsi), %rax
	movzbl	-1(%r10,%rax), %eax
	cmpb	-1(%rdi,%rsi), %al
	jne	LBB0_30
## %bb.27:                              ##   in Loop: Header=BB0_9 Depth=2
	cmpq	%rdx, %rsi
	jne	LBB0_35
## %bb.28:                              ##   in Loop: Header=BB0_9 Depth=2
	cmpl	%r10d, %ecx
	jb	LBB0_35
## %bb.29:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%rdx, %rsi
	jmp	LBB0_30
	.p2align	4
LBB0_35:                                ##   in Loop: Header=BB0_9 Depth=2
	cmpl	%r8d, 4(%r12,%r10)
	jne	LBB0_50
## %bb.36:                              ##   in Loop: Header=BB0_9 Depth=2
	leaq	(%r12,%r10), %r9
	movl	$8, %r8d
	cmpq	$16, %rdx
	jb	LBB0_42
## %bb.37:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%rdx, %r8
	andq	$-8, %r8
	leaq	-8(%rdx), %rbx
	movl	$8, %r11d
	.p2align	4
LBB0_38:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	(%r9,%r11), %r14
	movq	(%rdi,%r11), %rax
	cmpq	%rax, %r14
	jne	LBB0_39
## %bb.40:                              ##   in Loop: Header=BB0_38 Depth=3
	addq	$8, %r11
	addq	$-8, %rbx
	cmpq	$7, %rbx
	ja	LBB0_38
## %bb.41:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	-80(%rbp), %r14                 ## 8-byte Reload
	movq	-104(%rbp), %r11                ## 8-byte Reload
LBB0_42:                                ##   in Loop: Header=BB0_9 Depth=2
	cmpq	%rdx, %r8
	jae	LBB0_46
	.p2align	4
LBB0_43:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movzbl	(%r9,%r8), %eax
	cmpb	(%rdi,%r8), %al
	jne	LBB0_46
## %bb.44:                              ##   in Loop: Header=BB0_43 Depth=3
	incq	%r8
	cmpq	%r8, %rdx
	jne	LBB0_43
## %bb.45:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%rdx, %r8
LBB0_46:                                ##   in Loop: Header=BB0_9 Depth=2
	cmpq	%rsi, %r8
	jbe	LBB0_47
	jmp	LBB0_49
LBB0_16:                                ##   in Loop: Header=BB0_9 Depth=2
	xorq	%r13, %rax
	rep		bsfq	%rax, %rsi
	shrl	$3, %esi
	addq	%r14, %rsi
	movq	-88(%rbp), %r12                 ## 8-byte Reload
	movq	-80(%rbp), %r14                 ## 8-byte Reload
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	-96(%rbp), %r10                 ## 8-byte Reload
	leaq	(%rax,%r10), %r13
	jmp	LBB0_17
LBB0_39:                                ##   in Loop: Header=BB0_9 Depth=2
	xorq	%r14, %rax
	rep		bsfq	%rax, %r8
	shrl	$3, %r8d
	addq	%r11, %r8
	movq	-80(%rbp), %r14                 ## 8-byte Reload
	movq	-104(%rbp), %r11                ## 8-byte Reload
	cmpq	%rsi, %r8
	ja	LBB0_49
LBB0_47:                                ##   in Loop: Header=BB0_9 Depth=2
	jne	LBB0_50
## %bb.48:                              ##   in Loop: Header=BB0_9 Depth=2
	cmpl	%r10d, %ecx
	jae	LBB0_50
LBB0_49:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	%r10, %rcx
	movq	%r8, %rsi
	.p2align	4
LBB0_50:                                ##   in Loop: Header=BB0_9 Depth=2
	testq	%rsi, %rsi
	je	LBB0_51
LBB0_30:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	%rsi, -64(%rbp)                 ## 8-byte Spill
	cmpq	$131088, %r15                   ## imm = 0x20010
	movq	-144(%rbp), %r8                 ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
	movq	-96(%rbp), %r9                  ## 8-byte Reload
	movq	-72(%rbp), %rsi                 ## 8-byte Reload
	je	LBB0_53
## %bb.31:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%r11, %rbx
	subq	%rcx, %rbx
	movq	%r11, %rdx
	subq	%rsi, %rdx
	leaq	(%r11,%r15), %r14
	subq	%rsi, %r14
	leaq	1(%r14), %r13
	movq	-184(%rbp), %rax                ## 8-byte Reload
	leaq	(%rax,%r14), %r12
	movq	%rdx, %rax
	.p2align	4
LBB0_32:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movl	%eax, %ecx
	andb	$127, %cl
	shrq	$7, %rax
	setne	%r10b
	shlb	$7, %r10b
	orb	%cl, %r10b
	movb	%r10b, -1(%r8,%r15)
	testq	%rax, %rax
	je	LBB0_33
## %bb.52:                              ##   in Loop: Header=BB0_32 Depth=3
	incq	%r15
	incq	%r14
	incq	%r13
	incq	%r12
	cmpq	$131088, %r15                   ## imm = 0x20010
	jne	LBB0_32
	jmp	LBB0_53
	.p2align	4
LBB0_33:                                ##   in Loop: Header=BB0_9 Depth=2
	movl	$131087, %eax                   ## imm = 0x2000F
	subq	%r15, %rax
	cmpq	%rax, %rdx
	ja	LBB0_34
## %bb.56:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%r11, %rax
	subq	%rsi, %rax
	je	LBB0_58
## %bb.57:                              ##   in Loop: Header=BB0_9 Depth=2
	leaq	(%r8,%r15), %rdi
	addq	-88(%rbp), %rsi                 ## 8-byte Folded Reload
	movq	%rax, -72(%rbp)                 ## 8-byte Spill
	callq	_memcpy
	movq	-72(%rbp), %rax                 ## 8-byte Reload
	movq	-104(%rbp), %r11                ## 8-byte Reload
	movq	-96(%rbp), %r9                  ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
	movq	-144(%rbp), %r8                 ## 8-byte Reload
LBB0_58:                                ##   in Loop: Header=BB0_9 Depth=2
	addq	%r15, %rax
	incq	%rax
	cmpq	$131087, %rax                   ## imm = 0x2000F
	movq	-136(%rbp), %rsi                ## 8-byte Reload
	ja	LBB0_61
	.p2align	4
LBB0_59:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movl	%ebx, %eax
	andb	$127, %al
	shrq	$7, %rbx
	setne	%cl
	shlb	$7, %cl
	orb	%al, %cl
	movb	%cl, (%r8,%r14)
	incq	%r14
	testq	%rbx, %rbx
	je	LBB0_64
## %bb.60:                              ##   in Loop: Header=BB0_59 Depth=3
	incq	%r13
	incq	%r12
	cmpq	$131087, %r14                   ## imm = 0x2000F
	jb	LBB0_59
	jmp	LBB0_61
	.p2align	4
LBB0_64:                                ##   in Loop: Header=BB0_9 Depth=2
	cmpq	$131086, %r14                   ## imm = 0x2000E
	movq	-80(%rbp), %r14                 ## 8-byte Reload
	ja	LBB0_68
## %bb.65:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	-64(%rbp), %rax                 ## 8-byte Reload
	addq	$-8, %rax
	.p2align	4
LBB0_66:                                ##   Parent Loop BB0_7 Depth=1
                                        ##     Parent Loop BB0_9 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movl	%eax, %ecx
	andb	$127, %cl
	shrq	$7, %rax
	setne	%dl
	shlb	$7, %dl
	orb	%cl, %dl
	movb	%dl, (%r12)
	testq	%rax, %rax
	je	LBB0_70
## %bb.67:                              ##   in Loop: Header=BB0_66 Depth=3
	incq	%r13
	incq	%r12
	cmpq	$131087, %r13                   ## imm = 0x2000F
	jb	LBB0_66
	jmp	LBB0_68
	.p2align	4
LBB0_70:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	-64(%rbp), %rbx                 ## 8-byte Reload
	addq	%r11, %rbx
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	subq	%rbx, %rax
	addq	$2, %rax
	addq	$2, %r13
	movb	$1, %cl
	movq	%rcx, -160(%rbp)                ## 8-byte Spill
	cmpq	$4, %rax
	jae	LBB0_72
## %bb.71:                              ##   in Loop: Header=BB0_9 Depth=2
	movq	%r13, %r15
	movq	$0, -64(%rbp)                   ## 8-byte Folded Spill
	movq	%rbx, %r10
	movq	-88(%rbp), %r12                 ## 8-byte Reload
	jmp	LBB0_73
	.p2align	4
LBB0_51:                                ##   in Loop: Header=BB0_9 Depth=2
	movq	-64(%rbp), %rbx                 ## 8-byte Reload
	incq	%rbx
	movq	%rbx, -64(%rbp)                 ## 8-byte Spill
	shrq	$6, %rbx
	incq	%rbx
	cmpq	%rbx, %rdx
	cmovbq	%rdx, %rbx
	addq	%r11, %rbx
	movq	-136(%rbp), %rsi                ## 8-byte Reload
	movq	-144(%rbp), %r8                 ## 8-byte Reload
	movq	-120(%rbp), %rdi                ## 8-byte Reload
	movq	-72(%rbp), %r10                 ## 8-byte Reload
	jmp	LBB0_74
	.p2align	4
LBB0_75:                                ##   in Loop: Header=BB0_7 Depth=1
	testb	$1, -160(%rbp)                  ## 1-byte Folded Reload
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	je	LBB0_92
## %bb.76:                              ##   in Loop: Header=BB0_7 Depth=1
	movq	%r13, %rdx
	subq	%r10, %rdx
	je	LBB0_87
## %bb.77:                              ##   in Loop: Header=BB0_7 Depth=1
	cmpq	$131088, %r15                   ## imm = 0x20010
	je	LBB0_81
## %bb.78:                              ##   in Loop: Header=BB0_7 Depth=1
	leaq	(%r8,%r15), %rdi
	movl	$131088, %eax                   ## imm = 0x20010
	subq	%r15, %rax
	xorl	%ebx, %ebx
	movq	%rdx, %rcx
	.p2align	4
LBB0_79:                                ##   Parent Loop BB0_7 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movl	%ecx, %esi
	andb	$127, %sil
	shrq	$7, %rcx
	setne	%r8b
	shlb	$7, %r8b
	orb	%sil, %r8b
	movb	%r8b, -1(%rdi,%rbx)
	testq	%rcx, %rcx
	je	LBB0_83
## %bb.80:                              ##   in Loop: Header=BB0_79 Depth=2
	incq	%rbx
	cmpq	%rbx, %rax
	jne	LBB0_79
	jmp	LBB0_81
	.p2align	4
LBB0_92:                                ##   in Loop: Header=BB0_7 Depth=1
	movl	$263168, %ecx                   ## imm = 0x40400
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	movq	-152(%rbp), %rbx                ## 8-byte Reload
	movq	%rbx, %rdx
	callq	__ZN23stx_cngcompress_huffman6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	cmpq	-48(%rbp), %rax                 ## 8-byte Folded Reload
	jae	LBB0_91
## %bb.93:                              ##   in Loop: Header=BB0_7 Depth=1
	movq	-112(%rbp), %rcx                ## 8-byte Reload
	movq	-128(%rbp), %rdx                ## 8-byte Reload
	movb	%al, (%rcx,%rdx)
	movb	%ah, 1(%rcx,%rdx)
	movq	%rax, %r15
	shrl	$16, %eax
	movb	%al, 2(%rcx,%rdx)
	movb	$64, 3(%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdi
	addq	$4, %rdi
	movq	%rbx, %rsi
	movq	%rdx, %rbx
	movq	%r15, %rdx
	callq	_memcpy
	addq	$4, %r15
	movq	%r15, %rax
	jmp	LBB0_95
LBB0_83:                                ##   in Loop: Header=BB0_7 Depth=1
	movl	$131087, %ecx                   ## imm = 0x2000F
	subq	%r15, %rcx
	subq	%rbx, %rcx
	cmpq	%rcx, %rdx
	ja	LBB0_84
## %bb.86:                              ##   in Loop: Header=BB0_7 Depth=1
	addq	%rbx, %rdi
	leaq	(%r12,%r10), %rsi
	movq	%r10, -72(%rbp)                 ## 8-byte Spill
	callq	_memcpy
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	movq	-96(%rbp), %rax                 ## 8-byte Reload
	addq	%rcx, %rax
	addq	%r15, %rax
	subq	-72(%rbp), %rax                 ## 8-byte Folded Reload
	leaq	(%rax,%rbx), %r15
	incq	%r15
LBB0_87:                                ##   in Loop: Header=BB0_7 Depth=1
	leaq	3(%rcx), %rax
	cmpq	%rax, %r15
	movq	-152(%rbp), %rbx                ## 8-byte Reload
	ja	LBB0_88
## %bb.90:                              ##   in Loop: Header=BB0_7 Depth=1
	movl	$263168, %ecx                   ## imm = 0x40400
	movq	-176(%rbp), %rdi                ## 8-byte Reload
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	__ZN23stx_cngcompress_huffman6encodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	leaq	4(%rax), %rcx
	cmpq	-48(%rbp), %rcx                 ## 8-byte Folded Reload
	jae	LBB0_91
## %bb.94:                              ##   in Loop: Header=BB0_7 Depth=1
	leal	4(%rax), %ecx
	movq	-112(%rbp), %rdx                ## 8-byte Reload
	movq	-128(%rbp), %rsi                ## 8-byte Reload
	movl	%ecx, (%rdx,%rsi)
	movl	%r15d, 4(%rdx,%rsi)
	leaq	8(%rdx,%rsi), %rdi
	movq	%rsi, %r15
	movq	%rbx, %rsi
	movq	%rax, %rdx
	movq	%rax, %rbx
	callq	_memcpy
	addq	$8, %rbx
	movq	%rbx, %rax
	movq	%r15, %rbx
	jmp	LBB0_95
LBB0_96:
	movq	-168(%rbp), %rbx                ## 8-byte Reload
	cmpq	%rbx, %rax
	jb	LBB0_98
## %bb.97:
	movq	-112(%rbp), %rdi                ## 8-byte Reload
	movb	$0, (%rdi)
	addq	$5, %rdi
	movq	%r12, %rsi
	callq	_memcpy
	movq	%rbx, %rax
	jmp	LBB0_98
LBB0_99:
	movb	$0, (%rbx)
	movl	$5, %eax
LBB0_98:
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB0_53:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp9:                                  ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp10:                                 ## EH_LABEL
	jmp	LBB0_3
LBB0_61:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp0:                                  ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp1:                                  ## EH_LABEL
	jmp	LBB0_3
LBB0_68:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp3:                                  ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp4:                                  ## EH_LABEL
LBB0_3:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB0_34:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp6:                                  ## EH_LABEL
	leaq	L_.str.11(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp7:                                  ## EH_LABEL
	jmp	LBB0_3
LBB0_81:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp15:                                 ## EH_LABEL
	leaq	L_.str.14(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp16:                                 ## EH_LABEL
	jmp	LBB0_3
LBB0_88:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp18:                                 ## EH_LABEL
	leaq	L_.str.13(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp19:                                 ## EH_LABEL
	jmp	LBB0_3
LBB0_84:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp12:                                 ## EH_LABEL
	leaq	L_.str.12(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp13:                                 ## EH_LABEL
	jmp	LBB0_3
LBB0_2:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp21:                                 ## EH_LABEL
	leaq	L_.str(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp22:                                 ## EH_LABEL
	jmp	LBB0_3
LBB0_4:
Ltmp23:                                 ## EH_LABEL
	jmp	LBB0_63
LBB0_85:
Ltmp14:                                 ## EH_LABEL
	jmp	LBB0_63
LBB0_89:
Ltmp20:                                 ## EH_LABEL
	jmp	LBB0_63
LBB0_82:
Ltmp17:                                 ## EH_LABEL
	jmp	LBB0_63
LBB0_55:
Ltmp8:                                  ## EH_LABEL
	jmp	LBB0_63
LBB0_69:
Ltmp5:                                  ## EH_LABEL
	jmp	LBB0_63
LBB0_62:
Ltmp2:                                  ## EH_LABEL
	jmp	LBB0_63
LBB0_54:
Ltmp11:                                 ## EH_LABEL
LBB0_63:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0      ## >> Call Site 1 <<
	.uleb128 Ltmp9-Lfunc_begin0             ##   Call between Lfunc_begin0 and Ltmp9
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ## >> Call Site 2 <<
	.uleb128 Ltmp10-Ltmp9                   ##   Call between Ltmp9 and Ltmp10
	.uleb128 Ltmp11-Lfunc_begin0            ##     jumps to Ltmp11
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp10-Lfunc_begin0            ## >> Call Site 3 <<
	.uleb128 Ltmp0-Ltmp10                   ##   Call between Ltmp10 and Ltmp0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp0-Lfunc_begin0             ## >> Call Site 4 <<
	.uleb128 Ltmp1-Ltmp0                    ##   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ##     jumps to Ltmp2
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp1-Lfunc_begin0             ## >> Call Site 5 <<
	.uleb128 Ltmp3-Ltmp1                    ##   Call between Ltmp1 and Ltmp3
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ## >> Call Site 6 <<
	.uleb128 Ltmp4-Ltmp3                    ##   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ##     jumps to Ltmp5
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ## >> Call Site 7 <<
	.uleb128 Ltmp6-Ltmp4                    ##   Call between Ltmp4 and Ltmp6
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ## >> Call Site 8 <<
	.uleb128 Ltmp7-Ltmp6                    ##   Call between Ltmp6 and Ltmp7
	.uleb128 Ltmp8-Lfunc_begin0             ##     jumps to Ltmp8
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp7-Lfunc_begin0             ## >> Call Site 9 <<
	.uleb128 Ltmp15-Ltmp7                   ##   Call between Ltmp7 and Ltmp15
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp15-Lfunc_begin0            ## >> Call Site 10 <<
	.uleb128 Ltmp16-Ltmp15                  ##   Call between Ltmp15 and Ltmp16
	.uleb128 Ltmp17-Lfunc_begin0            ##     jumps to Ltmp17
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp16-Lfunc_begin0            ## >> Call Site 11 <<
	.uleb128 Ltmp18-Ltmp16                  ##   Call between Ltmp16 and Ltmp18
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp18-Lfunc_begin0            ## >> Call Site 12 <<
	.uleb128 Ltmp19-Ltmp18                  ##   Call between Ltmp18 and Ltmp19
	.uleb128 Ltmp20-Lfunc_begin0            ##     jumps to Ltmp20
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp19-Lfunc_begin0            ## >> Call Site 13 <<
	.uleb128 Ltmp12-Ltmp19                  ##   Call between Ltmp19 and Ltmp12
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp12-Lfunc_begin0            ## >> Call Site 14 <<
	.uleb128 Ltmp13-Ltmp12                  ##   Call between Ltmp12 and Ltmp13
	.uleb128 Ltmp14-Lfunc_begin0            ##     jumps to Ltmp14
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp13-Lfunc_begin0            ## >> Call Site 15 <<
	.uleb128 Ltmp21-Ltmp13                  ##   Call between Ltmp13 and Ltmp21
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp21-Lfunc_begin0            ## >> Call Site 16 <<
	.uleb128 Ltmp22-Ltmp21                  ##   Call between Ltmp21 and Ltmp22
	.uleb128 Ltmp23-Lfunc_begin0            ##     jumps to Ltmp23
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp22-Lfunc_begin0            ## >> Call Site 17 <<
	.uleb128 Lfunc_end0-Ltmp22              ##   Call between Ltmp22 and Lfunc_end0
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end0:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE ## -- Begin function _ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE
	.p2align	4
__ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE: ## @_ZN21stx_cngcompress_match6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEERNS_15DecodeWorkspaceE
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception1
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdx, -48(%rbp)                 ## 8-byte Spill
	cmpq	$5, %rsi
	jb	LBB1_52
## %bb.1:
	movq	%rcx, %rbx
	cmpq	$2097160, %rcx                  ## imm = 0x200008
	ja	LBB1_52
## %bb.2:
	movq	%rdi, %r11
	movl	1(%rdi), %eax
	cmpq	%rax, %rbx
	jne	LBB1_52
## %bb.3:
	movq	%rsi, %r15
	movzbl	(%r11), %eax
	cmpl	$16, %eax
	je	LBB1_8
## %bb.4:
	testl	%eax, %eax
	jne	LBB1_53
## %bb.5:
	leaq	5(%rbx), %rax
	cmpq	%rax, %r15
	jne	LBB1_54
## %bb.6:
	testq	%rbx, %rbx
	je	LBB1_42
## %bb.7:
	addq	$5, %r11
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	movq	%r11, %rsi
	movq	%rbx, %rdx
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	_memcpy                         ## TAILCALL
LBB1_8:
	testq	%rbx, %rbx
	je	LBB1_53
## %bb.9:
	movq	%r8, %r13
	movl	$5, %r12d
	xorl	%r8d, %r8d
	movq	%rbx, -104(%rbp)                ## 8-byte Spill
	movq	%r11, -112(%rbp)                ## 8-byte Spill
	movq	%r15, -96(%rbp)                 ## 8-byte Spill
	movq	%r13, -136(%rbp)                ## 8-byte Spill
	jmp	LBB1_13
	.p2align	4
LBB1_10:                                ##   in Loop: Header=BB1_13 Depth=1
	leaq	(%r11,%r12), %rdi
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r8), %rdx
	movq	%r9, %rsi
	movq	%r9, %r15
	movq	%rcx, %r14
	movq	%r11, %rbx
	callq	__ZN23stx_cngcompress_huffman6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	movq	%rbx, %r11
	movq	-104(%rbp), %rbx                ## 8-byte Reload
	movq	%r15, %rax
	movq	-96(%rbp), %r15                 ## 8-byte Reload
LBB1_11:                                ##   in Loop: Header=BB1_13 Depth=1
	movq	-64(%rbp), %r8                  ## 8-byte Reload
	addq	%rax, %r12
	addq	%r14, %r8
	cmpq	%rbx, %r8
	jae	LBB1_41
LBB1_13:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_24 Depth 2
                                        ##       Child Loop BB1_35 Depth 3
	movq	%r15, %rax
	subq	%r12, %rax
	cmpq	$3, %rax
	jbe	LBB1_46
## %bb.14:                              ##   in Loop: Header=BB1_13 Depth=1
	movzbl	3(%r11,%r12), %eax
	cmpb	$-64, %al
	jae	LBB1_45
## %bb.15:                              ##   in Loop: Header=BB1_13 Depth=1
	leaq	(%r11,%r12), %rdi
	movl	%eax, %r10d
	shll	$24, %r10d
	movzbl	2(%rdi), %edx
	shll	$16, %edx
	movzwl	(%rdi), %esi
	addq	$4, %r12
	movl	%r10d, %r9d
	andl	$1056964608, %r9d               ## imm = 0x3F000000
	orl	%esi, %r9d
	orl	%edx, %r9d
	movq	%rbx, %rcx
	subq	%r8, %rcx
	cmpq	$131072, %rcx                   ## imm = 0x20000
	movl	$131072, %edx                   ## imm = 0x20000
	cmovaeq	%rdx, %rcx
	movq	%r15, %rdx
	subq	%r12, %rdx
	cmpq	%r9, %rdx
	jb	LBB1_47
## %bb.16:                              ##   in Loop: Header=BB1_13 Depth=1
	testl	%r10d, %r10d
	movq	%r8, -64(%rbp)                  ## 8-byte Spill
	js	LBB1_36
## %bb.17:                              ##   in Loop: Header=BB1_13 Depth=1
	cmpb	$64, %al
	jae	LBB1_10
## %bb.18:                              ##   in Loop: Header=BB1_13 Depth=1
	cmpl	$8, %r9d
	jbe	LBB1_49
## %bb.19:                              ##   in Loop: Header=BB1_13 Depth=1
	movl	(%r11,%r12), %r8d
	leaq	3(%rcx), %rax
	cmpq	%r8, %rax
	jb	LBB1_50
## %bb.20:                              ##   in Loop: Header=BB1_13 Depth=1
	movq	%rcx, %rbx
	movq	%r9, -80(%rbp)                  ## 8-byte Spill
	leaq	-4(%r9), %rsi
	addq	$8, %rdi
	movq	%r13, %rdx
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movq	%r8, %rcx
	callq	__ZN23stx_cngcompress_huffman6decodeENSt3__14spanIKhLm18446744073709551615EEENS1_IhLm18446744073709551615EEE
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	movq	%rbx, -120(%rbp)                ## 8-byte Spill
	leaq	(%rbx,%r15), %rax
	movq	$0, -56(%rbp)
	movq	%rax, -88(%rbp)                 ## 8-byte Spill
	cmpq	%rax, %r15
	movq	%r12, -128(%rbp)                ## 8-byte Spill
	jb	LBB1_24
## %bb.21:                              ##   in Loop: Header=BB1_13 Depth=1
	xorl	%r12d, %r12d
	jmp	LBB1_39
	.p2align	4
LBB1_22:                                ##   in Loop: Header=BB1_24 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r15), %rdi
	movq	%rdi, %rsi
	subq	%r14, %rsi
	movq	%r13, %rdx
	callq	_memcpy
LBB1_23:                                ##   in Loop: Header=BB1_24 Depth=2
	addq	%r13, %r15
	cmpq	-88(%rbp), %r15                 ## 8-byte Folded Reload
	movq	-136(%rbp), %r13                ## 8-byte Reload
	jae	LBB1_38
LBB1_24:                                ##   Parent Loop BB1_13 Depth=1
                                        ## =>  This Loop Header: Depth=2
                                        ##       Child Loop BB1_35 Depth 3
	movq	%r13, %rdi
	movq	-72(%rbp), %rbx                 ## 8-byte Reload
	movq	%rbx, %rsi
	leaq	-56(%rbp), %rdx
	callq	__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	movq	-56(%rbp), %r12
	subq	%r12, %rbx
	cmpq	%rbx, %rax
	ja	LBB1_43
## %bb.25:                              ##   in Loop: Header=BB1_24 Depth=2
	movq	%rax, %r14
	movq	-88(%rbp), %rax                 ## 8-byte Reload
	subq	%r15, %rax
	cmpq	%rax, %r14
	ja	LBB1_43
## %bb.26:                              ##   in Loop: Header=BB1_24 Depth=2
	testq	%r14, %r14
	je	LBB1_28
## %bb.27:                              ##   in Loop: Header=BB1_24 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r15), %rdi
	leaq	(%r12,%r13), %rsi
	movq	%r14, %rdx
	callq	_memcpy
LBB1_28:                                ##   in Loop: Header=BB1_24 Depth=2
	addq	%r14, %r12
	movq	%r12, -56(%rbp)
	addq	%r14, %r15
	movq	-88(%rbp), %rbx                 ## 8-byte Reload
	subq	%r15, %rbx
	je	LBB1_39
## %bb.29:                              ##   in Loop: Header=BB1_24 Depth=2
	movq	%r13, %rdi
	movq	-72(%rbp), %rsi                 ## 8-byte Reload
	leaq	-56(%rbp), %r12
	movq	%r12, %rdx
	callq	__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	movq	%rax, %r14
	movq	%r13, %rdi
	movq	-72(%rbp), %rsi                 ## 8-byte Reload
	movq	%r12, %rdx
	callq	__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
	movq	%rax, %r13
	leaq	-1(%r14), %rax
	cmpq	%r15, %rax
	jae	LBB1_44
## %bb.30:                              ##   in Loop: Header=BB1_24 Depth=2
	addq	$8, %r13
	cmpq	%rbx, %r13
	ja	LBB1_44
## %bb.31:                              ##   in Loop: Header=BB1_24 Depth=2
	cmpl	%r13d, %r14d
	jae	LBB1_22
## %bb.32:                              ##   in Loop: Header=BB1_24 Depth=2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r15), %r12
	cmpl	$1, %r14d
	jne	LBB1_34
## %bb.33:                              ##   in Loop: Header=BB1_24 Depth=2
	movzbl	-1(%r12), %esi
	movq	%r12, %rdi
	movq	%r13, %rdx
	callq	_memset
	jmp	LBB1_23
	.p2align	4
LBB1_34:                                ##   in Loop: Header=BB1_24 Depth=2
	movq	%r12, %rsi
	subq	%r14, %rsi
	movq	%r12, %rdi
	movq	%r14, %rdx
	callq	_memcpy
	.p2align	4
LBB1_35:                                ##   Parent Loop BB1_13 Depth=1
                                        ##     Parent Loop BB1_24 Depth=2
                                        ## =>    This Inner Loop Header: Depth=3
	movq	%r14, %rbx
	movq	%r13, %r14
	subq	%rbx, %r14
	cmpq	%rbx, %r14
	cmovaeq	%rbx, %r14
	leaq	(%r12,%rbx), %rdi
	movq	%r12, %rsi
	movq	%r14, %rdx
	callq	_memcpy
	addq	%rbx, %r14
	cmpq	%r13, %r14
	jb	LBB1_35
	jmp	LBB1_23
	.p2align	4
LBB1_36:                                ##   in Loop: Header=BB1_13 Depth=1
	cmpq	%r9, %rcx
	jne	LBB1_48
## %bb.37:                              ##   in Loop: Header=BB1_13 Depth=1
	movq	%rcx, %r14
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r8), %rdi
	leaq	(%r11,%r12), %rsi
	movq	%r9, %rdx
	movq	%r9, -80(%rbp)                  ## 8-byte Spill
	callq	_memcpy
	movq	-112(%rbp), %r11                ## 8-byte Reload
	movq	-80(%rbp), %rax                 ## 8-byte Reload
	jmp	LBB1_11
LBB1_38:                                ##   in Loop: Header=BB1_13 Depth=1
	movq	-56(%rbp), %r12
LBB1_39:                                ##   in Loop: Header=BB1_13 Depth=1
	cmpq	-72(%rbp), %r12                 ## 8-byte Folded Reload
	jne	LBB1_51
## %bb.40:                              ##   in Loop: Header=BB1_13 Depth=1
	movq	-104(%rbp), %rbx                ## 8-byte Reload
	movq	-112(%rbp), %r11                ## 8-byte Reload
	movq	-96(%rbp), %r15                 ## 8-byte Reload
	movq	-128(%rbp), %r12                ## 8-byte Reload
	movq	-64(%rbp), %r8                  ## 8-byte Reload
	movq	-80(%rbp), %rax                 ## 8-byte Reload
	movq	-120(%rbp), %r14                ## 8-byte Reload
	addq	%rax, %r12
	addq	%r14, %r8
	cmpq	%rbx, %r8
	jb	LBB1_13
LBB1_41:
	cmpq	%r15, %r12
	jne	LBB1_55
LBB1_42:
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB1_43:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp39:                                 ## EH_LABEL
	leaq	L_.str.15(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp40:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_44:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp42:                                 ## EH_LABEL
	leaq	L_.str.16(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp43:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_45:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp30:                                 ## EH_LABEL
	leaq	L_.str.5(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp31:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_46:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp27:                                 ## EH_LABEL
	leaq	L_.str.4(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp28:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_47:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp54:                                 ## EH_LABEL
	leaq	L_.str.6(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp55:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_48:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp33:                                 ## EH_LABEL
	leaq	L_.str.7(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp34:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_49:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp36:                                 ## EH_LABEL
	leaq	L_.str.8(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp37:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_50:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp51:                                 ## EH_LABEL
	leaq	L_.str.9(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp52:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_51:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp45:                                 ## EH_LABEL
	leaq	L_.str.17(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp46:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_52:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp24:                                 ## EH_LABEL
	leaq	L_.str.1(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp25:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_53:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp60:                                 ## EH_LABEL
	leaq	L_.str.3(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp61:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_54:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp57:                                 ## EH_LABEL
	leaq	L_.str.2(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp58:                                 ## EH_LABEL
	jmp	LBB1_56
LBB1_55:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp48:                                 ## EH_LABEL
	leaq	L_.str.10(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp49:                                 ## EH_LABEL
LBB1_56:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB1_57:
Ltmp50:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_58:
Ltmp59:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_59:
Ltmp62:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_60:
Ltmp26:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_61:
Ltmp47:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_62:
Ltmp53:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_63:
Ltmp38:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_64:
Ltmp35:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_65:
Ltmp56:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_66:
Ltmp29:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_67:
Ltmp32:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_68:
Ltmp44:                                 ## EH_LABEL
	jmp	LBB1_70
LBB1_69:
Ltmp41:                                 ## EH_LABEL
LBB1_70:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception1:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1      ## >> Call Site 1 <<
	.uleb128 Ltmp39-Lfunc_begin1            ##   Call between Lfunc_begin1 and Ltmp39
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp39-Lfunc_begin1            ## >> Call Site 2 <<
	.uleb128 Ltmp40-Ltmp39                  ##   Call between Ltmp39 and Ltmp40
	.uleb128 Ltmp41-Lfunc_begin1            ##     jumps to Ltmp41
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp40-Lfunc_begin1            ## >> Call Site 3 <<
	.uleb128 Ltmp42-Ltmp40                  ##   Call between Ltmp40 and Ltmp42
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp42-Lfunc_begin1            ## >> Call Site 4 <<
	.uleb128 Ltmp43-Ltmp42                  ##   Call between Ltmp42 and Ltmp43
	.uleb128 Ltmp44-Lfunc_begin1            ##     jumps to Ltmp44
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp43-Lfunc_begin1            ## >> Call Site 5 <<
	.uleb128 Ltmp30-Ltmp43                  ##   Call between Ltmp43 and Ltmp30
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp30-Lfunc_begin1            ## >> Call Site 6 <<
	.uleb128 Ltmp31-Ltmp30                  ##   Call between Ltmp30 and Ltmp31
	.uleb128 Ltmp32-Lfunc_begin1            ##     jumps to Ltmp32
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp31-Lfunc_begin1            ## >> Call Site 7 <<
	.uleb128 Ltmp27-Ltmp31                  ##   Call between Ltmp31 and Ltmp27
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp27-Lfunc_begin1            ## >> Call Site 8 <<
	.uleb128 Ltmp28-Ltmp27                  ##   Call between Ltmp27 and Ltmp28
	.uleb128 Ltmp29-Lfunc_begin1            ##     jumps to Ltmp29
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp28-Lfunc_begin1            ## >> Call Site 9 <<
	.uleb128 Ltmp54-Ltmp28                  ##   Call between Ltmp28 and Ltmp54
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp54-Lfunc_begin1            ## >> Call Site 10 <<
	.uleb128 Ltmp55-Ltmp54                  ##   Call between Ltmp54 and Ltmp55
	.uleb128 Ltmp56-Lfunc_begin1            ##     jumps to Ltmp56
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp55-Lfunc_begin1            ## >> Call Site 11 <<
	.uleb128 Ltmp33-Ltmp55                  ##   Call between Ltmp55 and Ltmp33
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp33-Lfunc_begin1            ## >> Call Site 12 <<
	.uleb128 Ltmp34-Ltmp33                  ##   Call between Ltmp33 and Ltmp34
	.uleb128 Ltmp35-Lfunc_begin1            ##     jumps to Ltmp35
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp34-Lfunc_begin1            ## >> Call Site 13 <<
	.uleb128 Ltmp36-Ltmp34                  ##   Call between Ltmp34 and Ltmp36
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp36-Lfunc_begin1            ## >> Call Site 14 <<
	.uleb128 Ltmp37-Ltmp36                  ##   Call between Ltmp36 and Ltmp37
	.uleb128 Ltmp38-Lfunc_begin1            ##     jumps to Ltmp38
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp37-Lfunc_begin1            ## >> Call Site 15 <<
	.uleb128 Ltmp51-Ltmp37                  ##   Call between Ltmp37 and Ltmp51
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp51-Lfunc_begin1            ## >> Call Site 16 <<
	.uleb128 Ltmp52-Ltmp51                  ##   Call between Ltmp51 and Ltmp52
	.uleb128 Ltmp53-Lfunc_begin1            ##     jumps to Ltmp53
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp52-Lfunc_begin1            ## >> Call Site 17 <<
	.uleb128 Ltmp45-Ltmp52                  ##   Call between Ltmp52 and Ltmp45
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp45-Lfunc_begin1            ## >> Call Site 18 <<
	.uleb128 Ltmp46-Ltmp45                  ##   Call between Ltmp45 and Ltmp46
	.uleb128 Ltmp47-Lfunc_begin1            ##     jumps to Ltmp47
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp46-Lfunc_begin1            ## >> Call Site 19 <<
	.uleb128 Ltmp24-Ltmp46                  ##   Call between Ltmp46 and Ltmp24
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp24-Lfunc_begin1            ## >> Call Site 20 <<
	.uleb128 Ltmp25-Ltmp24                  ##   Call between Ltmp24 and Ltmp25
	.uleb128 Ltmp26-Lfunc_begin1            ##     jumps to Ltmp26
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp25-Lfunc_begin1            ## >> Call Site 21 <<
	.uleb128 Ltmp60-Ltmp25                  ##   Call between Ltmp25 and Ltmp60
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp60-Lfunc_begin1            ## >> Call Site 22 <<
	.uleb128 Ltmp61-Ltmp60                  ##   Call between Ltmp60 and Ltmp61
	.uleb128 Ltmp62-Lfunc_begin1            ##     jumps to Ltmp62
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp61-Lfunc_begin1            ## >> Call Site 23 <<
	.uleb128 Ltmp57-Ltmp61                  ##   Call between Ltmp61 and Ltmp57
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp57-Lfunc_begin1            ## >> Call Site 24 <<
	.uleb128 Ltmp58-Ltmp57                  ##   Call between Ltmp57 and Ltmp58
	.uleb128 Ltmp59-Lfunc_begin1            ##     jumps to Ltmp59
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp58-Lfunc_begin1            ## >> Call Site 25 <<
	.uleb128 Ltmp48-Ltmp58                  ##   Call between Ltmp58 and Ltmp48
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp48-Lfunc_begin1            ## >> Call Site 26 <<
	.uleb128 Ltmp49-Ltmp48                  ##   Call between Ltmp48 and Ltmp49
	.uleb128 Ltmp50-Lfunc_begin1            ##     jumps to Ltmp50
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp49-Lfunc_begin1            ## >> Call Site 27 <<
	.uleb128 Lfunc_end1-Ltmp49              ##   Call between Ltmp49 and Lfunc_end1
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end1:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4                               ## -- Begin function _ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
__ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm: ## @_ZN21stx_cngcompress_match12_GLOBAL__N_17integerENSt3__14spanIKhLm18446744073709551615EEERm
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception2
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	(%rdx), %rcx
	cmpq	%rsi, %rcx
	movq	%rsi, %r9
	cmovaq	%rcx, %r9
	jae	LBB2_1
## %bb.4:
	movzbl	(%rdi,%rcx), %eax
	movl	%eax, %r10d
	leaq	1(%rcx), %r8
	movq	%r8, (%rdx)
	andl	$127, %eax
	testb	%r10b, %r10b
	jns	LBB2_18
## %bb.5:
	cmpq	%r8, %rsi
	je	LBB2_1
## %bb.6:
	movzbl	1(%rdi,%rcx), %r8d
	leaq	2(%rcx), %r10
	movq	%r10, (%rdx)
	movl	%r8d, %esi
	andl	$127, %esi
	shll	$7, %esi
	orq	%rax, %rsi
	testb	%r8b, %r8b
	jns	LBB2_7
## %bb.11:
	cmpq	%r9, %r10
	je	LBB2_1
## %bb.12:
	movzbl	2(%rdi,%rcx), %r8d
	leaq	3(%rcx), %rax
	movq	%rax, (%rdx)
	movl	%r8d, %r10d
	andl	$127, %r10d
	shll	$14, %r10d
	orq	%r10, %rsi
	testb	%r8b, %r8b
	jns	LBB2_7
## %bb.13:
	cmpq	%r9, %rax
	je	LBB2_1
## %bb.14:
	movzbl	3(%rdi,%rcx), %r8d
	addq	$4, %rcx
	movq	%rcx, (%rdx)
	testb	%r8b, %r8b
	js	LBB2_16
## %bb.15:
	movl	%r8d, %eax
	andl	$127, %eax
	shll	$21, %eax
	orq	%rax, %rsi
LBB2_7:
	movq	%rsi, %rax
	testb	%r8b, %r8b
	je	LBB2_8
LBB2_18:
	popq	%rbx
	popq	%r14
	popq	%rbp
	retq
LBB2_1:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp69:                                 ## EH_LABEL
	leaq	L_.str.18(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp70:                                 ## EH_LABEL
LBB2_2:
	movq	__ZTISt13runtime_error@GOTPCREL(%rip), %rsi
	movq	__ZNSt13runtime_errorD1Ev@GOTPCREL(%rip), %rdx
	movq	%rbx, %rdi
	callq	___cxa_throw
LBB2_8:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp63:                                 ## EH_LABEL
	leaq	L_.str.19(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp64:                                 ## EH_LABEL
	jmp	LBB2_2
LBB2_16:
	movl	$16, %edi
	callq	___cxa_allocate_exception
	movq	%rax, %rbx
Ltmp66:                                 ## EH_LABEL
	leaq	L_.str.20(%rip), %rsi
	movq	%rax, %rdi
	callq	__ZNSt13runtime_errorC1EPKc
Ltmp67:                                 ## EH_LABEL
	jmp	LBB2_2
LBB2_17:
Ltmp68:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_9:
Ltmp65:                                 ## EH_LABEL
	jmp	LBB2_10
LBB2_3:
Ltmp71:                                 ## EH_LABEL
LBB2_10:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	___cxa_free_exception
	movq	%r14, %rdi
	callq	__Unwind_Resume
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception2:
	.byte	255                             ## @LPStart Encoding = omit
	.byte	255                             ## @TType Encoding = omit
	.byte	1                               ## Call site Encoding = uleb128
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Lfunc_begin2-Lfunc_begin2      ## >> Call Site 1 <<
	.uleb128 Ltmp69-Lfunc_begin2            ##   Call between Lfunc_begin2 and Ltmp69
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp69-Lfunc_begin2            ## >> Call Site 2 <<
	.uleb128 Ltmp70-Ltmp69                  ##   Call between Ltmp69 and Ltmp70
	.uleb128 Ltmp71-Lfunc_begin2            ##     jumps to Ltmp71
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp70-Lfunc_begin2            ## >> Call Site 3 <<
	.uleb128 Ltmp63-Ltmp70                  ##   Call between Ltmp70 and Ltmp63
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp63-Lfunc_begin2            ## >> Call Site 4 <<
	.uleb128 Ltmp64-Ltmp63                  ##   Call between Ltmp63 and Ltmp64
	.uleb128 Ltmp65-Lfunc_begin2            ##     jumps to Ltmp65
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp64-Lfunc_begin2            ## >> Call Site 5 <<
	.uleb128 Ltmp66-Ltmp64                  ##   Call between Ltmp64 and Ltmp66
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp66-Lfunc_begin2            ## >> Call Site 6 <<
	.uleb128 Ltmp67-Ltmp66                  ##   Call between Ltmp66 and Ltmp67
	.uleb128 Ltmp68-Lfunc_begin2            ##     jumps to Ltmp68
	.byte	0                               ##   On action: cleanup
	.uleb128 Ltmp67-Lfunc_begin2            ## >> Call Site 7 <<
	.uleb128 Lfunc_end2-Ltmp67              ##   Call between Ltmp67 and Lfunc_end2
	.byte	0                               ##     has no landing pad
	.byte	0                               ##   On action: cleanup
Lcst_end2:
	.p2align	2, 0x0
                                        ## -- End function
	.section	__TEXT,__cstring,cstring_literals
L_.str:                                 ## @.str
	.asciz	"match packet capacity"

L_.str.1:                               ## @.str.1
	.asciz	"match packet output extent"

L_.str.2:                               ## @.str.2
	.asciz	"match stored extent"

L_.str.3:                               ## @.str.3
	.asciz	"match packet coding"

L_.str.4:                               ## @.str.4
	.asciz	"match block header extent"

L_.str.5:                               ## @.str.5
	.asciz	"match reserved block flags"

L_.str.6:                               ## @.str.6
	.asciz	"match block extent"

L_.str.7:                               ## @.str.7
	.asciz	"match stored block extent"

L_.str.8:                               ## @.str.8
	.asciz	"match coded block header"

L_.str.9:                               ## @.str.9
	.asciz	"match parsed bound"

L_.str.10:                              ## @.str.10
	.asciz	"match exact packet extent"

L_.str.11:                              ## @.str.11
	.asciz	"match literal capacity"

L_.str.12:                              ## @.str.12
	.asciz	"match tail capacity"

L_.str.13:                              ## @.str.13
	.asciz	"match parse bound"

L_.str.14:                              ## @.str.14
	.asciz	"match integer capacity"

L_.str.15:                              ## @.str.15
	.asciz	"match literal extent"

L_.str.16:                              ## @.str.16
	.asciz	"match reference extent"

L_.str.17:                              ## @.str.17
	.asciz	"match exact consumption"

L_.str.18:                              ## @.str.18
	.asciz	"match integer extent"

L_.str.19:                              ## @.str.19
	.asciz	"match integer canonical form"

L_.str.20:                              ## @.str.20
	.asciz	"match integer width"

.subsections_via_symbols
